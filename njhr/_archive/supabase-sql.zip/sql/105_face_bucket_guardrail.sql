-- ============================================================
-- 105_face_bucket_guardrail.sql
--
-- บันทึกค่า Guardrail ของบัคเก็ต Snapshot ใบหน้า "njhr-face" ให้อยู่ใน Source
-- (ค่านี้ถูกตั้งบน Production แล้วเมื่อ 15/08/2026 — ไฟล์นี้ทำให้ Restore/Deploy
--  สภาพแวดล้อมใหม่ได้ค่าเดียวกันเป๊ะ ไม่ต้องพึ่งการตั้งค่าด้วยมือ)
--
-- ทำอะไร:
--   · file_size_limit    = 3 MB     (3,145,728 bytes)
--   · allowed_mime_types = image/jpeg   ตาม Snapshot ที่ระบบสร้างจริง
--   · public             = false        คงเดิม ไม่แตะ
--
-- ทำไม: เดิม file_size_limit / allowed_mime_types เป็น NULL
--   → การจำกัดขนาดพึ่ง "ค่า size ที่ Client แจ้ง" ใน Edge Function njhr-face-file
--     เพียงอย่างเดียว ซึ่งปลอมได้
--   → และทำให้ออก Signed Upload URL ล่วงหน้า (Upload Reservation แบบ Parallel)
--     อย่างปลอดภัยไม่ได้ เพราะยังไม่รู้ขนาด Blob
--   หลังตั้งค่านี้ Storage เป็นผู้ Reject การอัปโหลดจริงที่เกินขนาด/MIME ผิด
--   จึงเข้มกว่าเดิม และเปิดทางให้ทำ Reservation ขนานกับ Camera/Model/GPS ได้
--
-- Idempotent: รันซ้ำกี่ครั้งก็ได้ผลเท่าเดิม · ไม่มี DROP/DELETE/TRUNCATE
-- ไม่แตะ: bucket อื่น · ไฟล์เดิม · storage path · policy · ไม่เปิดสิทธิ์ anon ใด ๆ
-- ============================================================

-- ---------- PREFLIGHT (รันดูก่อน — ต้องไม่มีไฟล์เดิมขัดเงื่อนไข) ----------
-- select id, public, file_size_limit,
--        array_to_string(allowed_mime_types, ',') as mimes
--   from storage.buckets where id = 'njhr-face';
--
-- select count(*)                                             as objects,
--        coalesce(max((metadata->>'size')::bigint), 0)         as max_size_bytes,
--        string_agg(distinct coalesce(metadata->>'mimetype','?'), ', ') as mimetypes_in_use,
--        count(*) filter (where (metadata->>'size')::bigint > 3145728) as over_3mb
--   from storage.objects where bucket_id = 'njhr-face';
--
-- ค่าที่วัดได้จริงบน Production ก่อนตั้ง (15/08/2026):
--   objects = 295 · max_size_bytes = 67,331 · mimetypes_in_use = image/jpeg · over_3mb = 0
--   → ไม่มีไฟล์เดิมใดขัดกับเงื่อนไขใหม่ และการอ่านไฟล์เดิมไม่ถูกกระทบ
--   ถ้า over_3mb > 0 หรือมี MIME อื่น ให้ "หยุด" และรายงานก่อน ห้ามรันต่อ

begin;

-- [Fail Closed] ตรวจสอบ Source ทั้งโฟลเดอร์ sql/ แล้วไม่พบ Migration ใดสร้างบัคเก็ต
-- njhr-face เลย (สร้างด้วยมือผ่าน Supabase Dashboard) ไฟล์นี้จึงต้อง "หยุด" ถ้าไม่พบ
-- แทนที่จะ UPDATE 0 rows แล้วจบสำเร็จแบบเงียบ ๆ ซึ่งทำให้ Environment ใหม่
-- ไม่มี Guardrail จริงทั้งที่ Migration รายงานว่าผ่าน
-- [Reproducible] ตรวจ Source ทั้งโฟลเดอร์ sql/ แล้วไม่มี Migration ใดสร้าง njhr-face
-- (Production สร้างด้วยมือผ่าน Dashboard) ไฟล์นี้จึงต้องสร้างเองได้แบบ idempotent
-- คอลัมน์ที่ใช้ ตรวจจาก schema จริงของ storage.buckets บน Production:
--   id text NOT NULL · name text NOT NULL · public boolean DEFAULT false
--   file_size_limit bigint · allowed_mime_types ARRAY
--   (owner/owner_id/type/created_at/updated_at ปล่อยเป็น default — ไม่แตะ)
-- private ตั้งแต่วินาทีที่สร้าง ไม่มีช่วงที่เป็น public แม้แต่ชั่วขณะ
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('njhr-face', 'njhr-face', false, 3145728, array['image/jpeg'])
on conflict (id) do nothing;

update storage.buckets
   set file_size_limit    = 3145728,                 -- 3 MB
       allowed_mime_types = array['image/jpeg']
 where id = 'njhr-face'
   and (file_size_limit    is distinct from 3145728
     or allowed_mime_types is distinct from array['image/jpeg']);

-- ยืนยันผลลัพธ์ในทรานแซกชันเดียวกัน — ไม่ตรงตามที่ต้องการ = Rollback ทั้งก้อน
do $v$
declare b record;
begin
  select * into b from storage.buckets where id = 'njhr-face';
  if b.public is distinct from false
     or b.file_size_limit is distinct from 3145728
     or b.allowed_mime_types is distinct from array['image/jpeg'] then
    raise exception '105: ค่า Guardrail ไม่ตรงตามที่กำหนด (public=% size=% mime=%)',
      b.public, b.file_size_limit, b.allowed_mime_types using errcode = '23514';
  end if;
end $v$;

commit;

-- ---------- VERIFICATION (ต้องได้ตามนี้) ----------
-- select id, public, file_size_limit, array_to_string(allowed_mime_types, ',') as mimes
--   from storage.buckets where id = 'njhr-face';
--   --> njhr-face | false | 3145728 | image/jpeg
--
-- select count(*) from storage.objects where bucket_id = 'njhr-face';
--   --> ต้องเท่ากับ PREFLIGHT (ไม่มีไฟล์หาย)

-- ---------- ROLLBACK (กรณีต้องถอยเท่านั้น) ----------
-- begin;
-- update storage.buckets
--    set file_size_limit = null, allowed_mime_types = null
--  where id = 'njhr-face';
-- commit;
-- ⚠ ถอยแล้วจะไม่มีการบังคับขนาด/MIME ฝั่ง Storage อีก
--    ต้องกลับไปพึ่ง size ที่ Client แจ้งเท่านั้น (อ่อนกว่าเดิม)
--    และต้องเลิกใช้ Upload Reservation แบบไม่ส่ง size ใน face.js ด้วย
