-- ============================================================
-- 107_leave_half_period.sql
-- เพิ่มคอลัมน์ leave_requests.half_period  (HALF_AM / HALF_PM / NULL)
--
-- ทำไม: njhr_leave_submit_core_v145 รับ p_mode = HALF_AM/HALF_PM จริง
--       แต่ยุบเหลือ leave_unit='halfday' แล้ว "ทิ้งค่า AM/PM"
--       ทำให้ Attendance Report แยกครึ่งเช้า/ครึ่งบ่ายไม่ได้
--
-- Backfill: อ่านจาก approvals->0->'meta'->>'mode' เท่านั้น
--   ห้ามเดาจากเวลา < 12:00 / start_time / ชื่อกะ / total_days
--   ถ้าพิสูจน์ไม่ได้ → NULL (NOT VERIFIED) ห้ามสุ่มค่า
--
-- ค่าที่ตรวจจริงบน Production (15/08/2026): leave_requests = 9 แถว
--   halfday = 3 แถว · meta.mode = HALF_AM ครบทั้ง 3 · HALF_PM = 0
--   → backfill ได้ครบโดยไม่ต้องเดาแม้แต่แถวเดียว
--
-- backward-compatible: คอลัมน์ใหม่เป็น nullable ไม่มี default
--   โค้ดเดิมที่ไม่รู้จักคอลัมน์นี้ทำงานได้เหมือนเดิมทุกประการ
-- ============================================================

-- ---------- PREFLIGHT ----------
-- select count(*) as total,
--        count(*) filter (where leave_unit = 'halfday') as halfday,
--        count(*) filter (where leave_unit = 'halfday'
--               and approvals->0->'meta'->>'mode' in ('HALF_AM','HALF_PM')) as halfday_with_meta
--   from public.leave_requests;
--   --> total 9 · halfday 3 · halfday_with_meta 3
--   ถ้า halfday_with_meta < halfday แปลว่ามีแถวที่พิสูจน์ไม่ได้ → จะได้ NULL (ถูกต้อง ไม่ต้องหยุด)

begin;

-- ---------- A. คอลัมน์ ----------
alter table public.leave_requests add column if not exists half_period text;

alter table public.leave_requests drop constraint if exists leave_requests_half_period_chk;
-- Invariant จริง: half_period มีค่าได้เฉพาะเมื่อ leave_unit = 'halfday' เท่านั้น
-- FULL (day) / HOURLY (hour) ถูกบังคับให้เป็น NULL "ที่ระดับ Constraint"
-- ไม่ใช่พึ่ง Trigger อย่างเดียว → direct UPDATE ก็สร้าง state ผิดไม่ได้
alter table public.leave_requests add constraint leave_requests_half_period_chk
  check (
    half_period is null
    or (leave_unit = 'halfday' and half_period in ('HALF_AM','HALF_PM'))
  );

-- ---------- B. Backfill จาก metadata เท่านั้น ----------
update public.leave_requests r
   set half_period = r.approvals->0->'meta'->>'mode'
 where r.half_period is null
   and r.leave_unit = 'halfday'
   and r.approvals->0->'meta'->>'mode' in ('HALF_AM','HALF_PM');
-- แถวที่ไม่มี metadata จะยังเป็น NULL = NOT VERIFIED (ตั้งใจ ไม่เดา)

-- ---------- C. Trigger เขียนค่าให้ใบใหม่ ----------
-- เลือกใช้ Trigger แทนการแก้ njhr_leave_submit_core_v145 ก้อนใหญ่
-- เพื่อไม่แตะ Business Logic เดิมแม้แต่บรรทัดเดียว
-- (core เขียน approvals[0].meta.mode อยู่แล้ว จึงอ่านจากแถวที่กำลัง insert ได้ตรง ๆ)
create or replace function public.njhr_leave_fill_half_period()
returns trigger language plpgsql as $$
begin
  if new.half_period is null then
    if new.leave_unit = 'halfday'
       and new.approvals->0->'meta'->>'mode' in ('HALF_AM','HALF_PM') then
      new.half_period := new.approvals->0->'meta'->>'mode';
    end if;
  end if;
  -- FULL / HOURLY ต้องเป็น NULL เสมอ
  if coalesce(new.leave_unit,'') <> 'halfday' then
    new.half_period := null;
  end if;
  return new;
end $$;

drop trigger if exists njhr_leave_fill_half_period_tg on public.leave_requests;
-- ครอบคลุมทั้ง INSERT และ UPDATE ทุกคอลัมน์ที่ทำให้ invariant เปลี่ยนได้
-- (approvals · leave_unit · half_period เอง) — direct update ก็ถูกทำให้ถูกต้องเสมอ
create trigger njhr_leave_fill_half_period_tg
  before insert or update of approvals, leave_unit, half_period on public.leave_requests
  for each row execute function public.njhr_leave_fill_half_period();

commit;

-- ---------- VERIFICATION ----------
-- select leave_unit, half_period, approvals->0->'meta'->>'mode' as meta_mode, count(*)
--   from public.leave_requests group by 1,2,3 order by 1,2;
--   --> halfday ทุกแถวที่มี meta ต้องได้ half_period ตรงกับ meta_mode
--   --> day / hour ต้องเป็น NULL ทั้งหมด
-- select count(*) from public.leave_requests;   --> 9 (ไม่มีแถวหาย)

-- ---------- ROLLBACK ----------
-- begin;
-- drop trigger if exists njhr_leave_fill_half_period_tg on public.leave_requests;
-- drop function if exists public.njhr_leave_fill_half_period();
-- alter table public.leave_requests drop constraint if exists leave_requests_half_period_chk;
-- -- คอลัมน์เก็บไว้ได้ ไม่กระทบโค้ดเดิม (หรือ: alter table ... drop column half_period;)
-- commit;
