-- ============================================================
-- 104B_close_public_attachments.sql   [รันเป็นขั้นตอนสุดท้าย]
--
-- ⚠ ต้องรันหลังจากทำครบ 2 ข้อนี้แล้วเท่านั้น:
--     1) รัน 104A_reqfile_prepare.sql เรียบร้อย
--     2) Deploy เว็บ (BuildID ใหม่) + Edge Function njhr-req-file เรียบร้อย
--   ถ้ารันก่อน → พนักงานจะแนบไฟล์ไม่ได้ เพราะ anon INSERT ถูกถอนแล้ว
--   แต่หน้าเว็บเก่ายังอัปโหลดตรงเข้า Storage อยู่
--
-- ทำอะไร: ปิด public ของ 2 bucket + ถอน Policy ที่เปิดกว้างทั้งหมด
-- ไม่แตะ: ไฟล์ใน Storage (0 การเขียน) · bucket อื่น · storage_admin_delete
-- ============================================================

-- ---------- PREFLIGHT (ต้องได้ตามนี้ก่อนรัน) ----------
-- select id, public from storage.buckets where id in ('leave-attachments','ot-attachments');
--   --> true, true
-- select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
--  where n.nspname='public' and p.proname in ('njhr_reqfile_access','njhr_reqfile_upload_path');
--   --> 2   (ถ้าไม่ใช่ 2 แปลว่ายังไม่ได้รัน 104A — หยุด)
-- select count(*) from storage.objects where bucket_id in ('leave-attachments','ot-attachments');
--   --> จดตัวเลขไว้ ต้องเท่าเดิมหลังรัน

begin;

-- ---------- ปิดประตูสาธารณะ ----------
update storage.buckets set public = false where id in ('leave-attachments','ot-attachments');

drop policy if exists "nj_v6_storage_leave_attachments" on storage.objects;  -- ALL ของ anon (อันตรายสุด)
drop policy if exists "njhr_leave_read" on storage.objects;                   -- SELECT ของ anon
drop policy if exists "njhr_ot_read"   on storage.objects;                    -- SELECT ของ anon

-- Policy รวมที่เปิดอ่านทุก bucket ยกเว้นชุด njhr เดิม → เพิ่ม 2 bucket นี้เข้ารายการยกเว้น
alter policy "njhr_sig_no_public" on storage.objects
  using (bucket_id <> ALL (ARRAY['njhr-signatures'::text, 'njhr-doc-pdf'::text,
                                 'njhr-emp-files'::text, 'njhr-face'::text,
                                 'leave-attachments'::text, 'ot-attachments'::text]));

-- [เข้มขึ้นตามคำสั่ง] ถอนสิทธิ์ anon ออก "ทั้งหมด" รวม Upload
drop policy if exists "njhr_leave_upload" on storage.objects;    -- INSERT ของ anon
drop policy if exists "njhr_ot_upload"   on storage.objects;     -- INSERT ของ anon
drop policy if exists "leave_attach_auth_all" on storage.objects; -- ALL ของ authenticated
--   (ระบบ NJHR ใช้ opaque token ไม่มีใครล็อกอินเป็น role authenticated —
--    ถอนทิ้งเพื่อปิด ALL policy ตามเงื่อนไขตรวจรับ ไม่มีผู้ใช้จริงได้รับผลกระทบ)
-- คงไว้: storage_admin_delete (อิง current_user_role() ตาม Role เดิม ไม่ใช่ anon)

-- Upload ใหม่ทำผ่าน Edge Function njhr-req-file action=upload-url เท่านั้น:
-- RPC ออก "เส้นทางไฟล์" ให้หลังตรวจ token — โฟลเดอร์ผูกกับ employee_id ของเจ้าของ token
-- (Naming convention เดิมทุกส่วน: <prefix>/<emp_id>/<ts36>-<rand>-<safe><ext>)
commit;

-- ---------- VERIFICATION 104B (ต้องผ่านทุกข้อ) ----------
-- 1) select id, public from storage.buckets where id in ('leave-attachments','ot-attachments');
--    --> false, false
-- 2) ไม่เหลือ Policy "เปิดกว้าง" บน 2 bucket นี้
--    ⚠ ต้องยกเว้น njhr_sig_no_public เพราะ Policy นี้ "จำเป็นต้องอ้างถึง" 2 bucket
--      เพื่อทำ exclusion (bucket_id <> ALL(...)) — การอ้างถึงคือสิ่งที่ถูกต้อง ไม่ใช่ช่องโหว่
--    select polname from pg_policy where polrelid='storage.objects'::regclass
--      and polname <> 'njhr_sig_no_public'
--      and (coalesce(pg_get_expr(polqual,polrelid),'')||coalesce(pg_get_expr(polwithcheck,polrelid),''))
--          ~ '(leave-attachments|ot-attachments)';
--    --> 0 แถว
-- 2b) njhr_sig_no_public ต้อง exclude ครบทั้ง 2 bucket:
--    select pg_get_expr(polqual,polrelid) from pg_policy
--     where polrelid='storage.objects'::regclass and polname='njhr_sig_no_public';
--    --> ต้องมีทั้ง 'leave-attachments' และ 'ot-attachments' ใน ARRAY
-- 3) จำนวนไฟล์เท่าเดิมทุกไบต์ (เทียบกับ PREFLIGHT):
--    select count(*) from storage.objects where bucket_id in ('leave-attachments','ot-attachments');
-- 4) เปิด Public URL เก่าในเบราว์เซอร์ที่ไม่ได้ล็อกอิน --> ต้องได้ 400/403 ไม่ใช่ไฟล์

-- ---------- ROLLBACK 104B ----------
-- begin;
-- update storage.buckets set public = true where id in ('leave-attachments','ot-attachments');
-- create policy "njhr_leave_read"   on storage.objects for select to authenticated, anon using (bucket_id='leave-attachments');
-- create policy "njhr_ot_read"     on storage.objects for select to authenticated, anon using (bucket_id='ot-attachments');
-- create policy "njhr_leave_upload" on storage.objects for insert to authenticated, anon with check (bucket_id='leave-attachments');
-- create policy "njhr_ot_upload"   on storage.objects for insert to authenticated, anon with check (bucket_id='ot-attachments');
-- create policy "nj_v6_storage_leave_attachments" on storage.objects for all to authenticated, anon
--   using (bucket_id='leave-attachments') with check (bucket_id='leave-attachments');
-- create policy "leave_attach_auth_all" on storage.objects for all
--   using (bucket_id='leave-attachments' and auth.role()='authenticated')
--   with check (bucket_id='leave-attachments' and auth.role()='authenticated');
-- alter policy "njhr_sig_no_public" on storage.objects
--   using (bucket_id <> ALL (ARRAY['njhr-signatures'::text,'njhr-doc-pdf'::text,
--                                  'njhr-emp-files'::text,'njhr-face'::text]));
-- commit;
