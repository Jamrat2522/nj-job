-- ============================================================
-- 109_error_monitoring.sql   [รอบ A — Error Monitoring กลาง]
--
-- เพิ่มระบบบันทึกข้อผิดพลาดฝั่ง Client สำหรับ Production
--
-- ⚠ ตาราง public.error_logs ที่มีอยู่แล้วเป็นของ "ระบบนำเข้า Excel" คนละแอป
--   (คอลัมน์ invoice_no · product_code · excel_row · customer_id)
--   จึงห้ามใช้ปนกันเด็ดขาด → สร้างตารางใหม่ njhr_error_logs แยกต่างหาก
--
-- แยกจาก Security/Audit Log:
--   Audit  = njhr_audit_write() → ตาราง audit เดิม (ใครทำอะไร · เก็บยาว)
--   Error  = ตารางนี้ (ระบบขัดข้อง · เก็บ 90 วัน · ไม่มีข้อมูลส่วนบุคคล)
--
-- ห้ามบันทึก: Password · Token · Face image · Descriptor · พิกัด GPS จริง ·
--            เอกสารพนักงาน · ข้อมูลส่วนบุคคล
--   → Redaction ทำ 2 ชั้น: ฝั่ง Client ก่อนส่ง + ฝั่ง SQL ในฟังก์ชันนี้อีกชั้น
--
-- ไม่แตะ: ตาราง/ฟังก์ชัน/policy เดิมใด ๆ · เป็นการเพิ่มล้วน
-- ============================================================

-- ---------- PREFLIGHT ----------
-- select table_name from information_schema.tables
--  where table_schema='public' and table_name in ('error_logs','njhr_error_logs');
--   --> ต้องเห็น error_logs (ของเดิม คนละแอป) และยังไม่มี njhr_error_logs

begin;

-- ---------- 1) ตาราง ----------
create table if not exists public.njhr_error_logs (
  id            uuid primary key default gen_random_uuid(),
  occurred_at   timestamptz not null default now(),
  kind          text not null,            -- JS_ERROR · UNHANDLED_REJECTION · RPC_FAIL · EDGE_FAIL · SW_ERROR
  source        text,                     -- ชื่อ RPC / Edge Function / ไฟล์
  message       text not null,            -- ผ่าน Redaction แล้ว
  stack         text,                     -- ผ่าน Redaction แล้ว (จำกัดความยาว)
  route         text,                     -- hash route เช่น #/attendance
  build_version text,
  app_user_id   uuid not null,            -- resolve จาก token ฝั่งเซิร์ฟเวอร์เท่านั้น (บังคับมี)
  employee_id   uuid,
  device        text, browser text, os text,
  created_at    timestamptz not null default now()
);

create index if not exists njhr_error_logs_occurred_idx on public.njhr_error_logs (occurred_at desc);
create index if not exists njhr_error_logs_kind_idx     on public.njhr_error_logs (kind, occurred_at desc);
-- รองรับ Rate limit query (นับต่อผู้ใช้ในชั่วโมงล่าสุด)
create index if not exists njhr_error_logs_user_idx     on public.njhr_error_logs (app_user_id, occurred_at desc);

alter table public.njhr_error_logs enable row level security;
-- ปิดสิทธิ์ระดับตารางให้ client ทุก role — เข้าถึงได้ผ่าน RPC SECURITY DEFINER เท่านั้น
revoke all on table public.njhr_error_logs from anon, authenticated, public;
-- ไม่มี policy = anon/authenticated อ่าน/เขียนตรงไม่ได้เลย
-- เข้าถึงได้เฉพาะผ่าน RPC SECURITY DEFINER ด้านล่าง

-- ---------- 2) Redaction ฝั่งเซิร์ฟเวอร์ (ชั้นที่สอง) ----------
create or replace function public.njhr_error_redact(p text)
 returns text language sql immutable as $$
  select case when p is null then null else
    left(
      regexp_replace(
      regexp_replace(
      regexp_replace(
      regexp_replace(
      regexp_replace(
      regexp_replace(
      regexp_replace(
      regexp_replace(
      regexp_replace(p,
        /* [109b] ต้องมาก่อน rule token= — ไม่งั้นเหลือ path ของ Signed URL ทั้งเส้น */
        'https?://[^\s"'']*/storage/v1/[^\s"'']*', '[signed-url]', 'gi'),
        /* [109b] Face descriptor / embedding — เดิมเหลือ ",0.456,0.789]" หลุดค่า */
        '\[\s*-?\d+\.\d+(\s*,\s*-?\d+\.\d+){2,}\s*\]', '[descriptor]', 'g'),
        'eyJ[A-Za-z0-9_.-]{10,}', '[token]', 'g'),                       -- JWT
        '(sb_publishable_|sbp_|sk_)[A-Za-z0-9_-]{6,}', '[key]', 'g'),    -- API key
        'data:[a-z/+.-]+;base64,[A-Za-z0-9+/=]+', '[image]', 'g'),       -- รูป base64 (รวม Face)
        '(token|apikey|api_key|key|password|passwd|pwd|secret|signature|descriptor|p256dh|auth)\s*[=:"'']+\s*[^\s,&"''}]+',
        '\1=[hidden]', 'gi'),
        '("?\y(lat|lng|lon|latitude|longitude)\y"?)\s*[=:]\s*"?-?\d{1,3}(\.\d+)?"?', '\1=[geo]', 'gi'),
        '-?\d{1,3}\.\d{4,}\s*,\s*-?\d{1,3}\.\d{4,}', '[geo]', 'g'),      -- คู่พิกัด lat,lng
        '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', '[email]', 'g'),
      2000)
  end
$$;

-- ---------- 3) RPC เขียน Log ----------
-- p_token "บังคับ" ต้องเป็น NJHR session ที่ใช้ได้จริง
--   njhr_ctx() ตรวจ njhr_sessions: token ตรง · not revoked · expires_at > now()
--   ไม่มี / ปลอม / หมดอายุ / ถูกเพิกถอน → raise 28000 → ไม่ INSERT
-- app_user_id / employee_id resolve ฝั่งเซิร์ฟเวอร์เท่านั้น ไม่รับจากฝั่ง Client
--
-- [Permission] ระบบใช้ Custom NJHR Session Token และ Browser เรียก PostgREST ด้วย
--   publishable/anon key → จึงต้องคง GRANT EXECUTE ให้ anon ไว้ ไม่งั้นหน้าเว็บใช้ไม่ได้
--   ความปลอดภัยมาจาก njhr_ctx() ในตัวฟังก์ชัน + REVOKE สิทธิ์ระดับตาราง ไม่ใช่จากการถอน grant
create or replace function public.njhr_error_log_write(
  p_token text, p_kind text, p_source text, p_message text,
  p_stack text, p_route text, p_build text,
  p_device text, p_browser text, p_os text)
 returns void
 language plpgsql
 security definer
 set search_path to 'public'
as $function$
declare c record; v_kind text := upper(btrim(coalesce(p_kind,''))); v_n int;
begin
  if v_kind not in ('JS_ERROR','UNHANDLED_REJECTION','RPC_FAIL','EDGE_FAIL','SW_ERROR') then
    v_kind := 'JS_ERROR';
  end if;

  /* [Security] ต้องมี NJHR session token ที่ใช้ได้จริงเท่านั้นจึงเขียนได้
     njhr_ctx() ตรวจ njhr_sessions: token ตรง · not revoked · expires_at > now()
     ไม่มี token / ปลอม / หมดอายุ / ถูกเพิกถอน → raise 28000 → ไม่ INSERT
     ⚠ ห้ามใช้ exception handler กลืน error ที่นี่ (เดิมทำแล้วเปิดช่องให้ anon ยิง log ปลอม) */
  select * into c from public.njhr_ctx(p_token);

  /* [Security] Rate limit ฝั่งเซิร์ฟเวอร์ — 30 รายการ/ผู้ใช้/ชั่วโมง
     Client-side limit มีไว้เพื่อ Performance เท่านั้น ห้ามใช้เป็น Security หลัก

     ⚠ count(*) แล้วค่อย INSERT ไม่ atomic — หลาย request พร้อมกันผ่าน count ได้ทั้งหมด
     จึงล็อกแบบ transaction-level advisory lock ต่อ app_user_id ก่อนนับ
     ทำให้คำขอของผู้ใช้คนเดียวกันถูก serialize · ผู้ใช้คนอื่นไม่ถูกบล็อก
     ปลดล็อกอัตโนมัติเมื่อจบ transaction · ไม่ต้องสร้างตารางใหม่
     ใช้ pg_advisory_xact_lock(key1, key2): key1 = ค่าคงที่ของโมดูลนี้ กันชนกับระบบอื่น
     key2 = hashtext(app_user_id) */
  perform pg_advisory_xact_lock(109109109, hashtext(c.app_user_id::text));

  select count(*) into v_n from public.njhr_error_logs
   where app_user_id = c.app_user_id and occurred_at > now() - interval '1 hour';
  /* เกินโควตา = เงียบ (ไม่ raise) เพื่อไม่ให้ตัว Monitoring กลายเป็นต้นเหตุ error ใหม่ */
  if v_n >= 30 then return; end if;

  insert into public.njhr_error_logs
    (kind, source, message, stack, route, build_version,
     app_user_id, employee_id, device, browser, os)
  values (v_kind,
          left(public.njhr_error_redact(p_source), 200),
          coalesce(left(public.njhr_error_redact(p_message), 1000), '(no message)'),
          left(public.njhr_error_redact(p_stack), 2000),
          left(public.njhr_error_redact(p_route), 120),
          left(coalesce(p_build,''), 60),
          c.app_user_id, c.employee_id,
          left(coalesce(p_device,''), 40), left(coalesce(p_browser,''), 60), left(coalesce(p_os,''), 60));
end $function$;

revoke all on function public.njhr_error_log_write(text,text,text,text,text,text,text,text,text,text)
  from public;
grant execute on function public.njhr_error_log_write(text,text,text,text,text,text,text,text,text,text)
  to anon, authenticated, service_role;

-- ---------- 4) อ่าน Log (เฉพาะผู้ดูแล) ----------
create or replace function public.njhr_error_log_list(
  p_token text, p_kind text default null, p_limit int default 200, p_offset int default 0)
 returns setof public.njhr_error_logs
 language plpgsql stable security definer set search_path to 'public'
as $function$
declare c record;
begin
  select * into c from public.njhr_ctx(p_token);
  if c.role not in ('SUPER_ADMIN','ADMIN') then
    raise exception 'ไม่มีสิทธิ์ดูบันทึกข้อผิดพลาด' using errcode='42501';
  end if;
  return query
    select * from public.njhr_error_logs e
     where (p_kind is null or p_kind = '' or e.kind = upper(p_kind))
     order by e.occurred_at desc
     limit least(greatest(coalesce(p_limit,200),1),1000) offset greatest(coalesce(p_offset,0),0);
end $function$;

revoke all on function public.njhr_error_log_list(text,text,int,int) from public;
grant execute on function public.njhr_error_log_list(text,text,int,int) to anon, authenticated, service_role;

-- ---------- 5) Retention 90 วัน (Dry Run เป็นค่าเริ่มต้น) ----------
-- pg_cron ไม่ได้ติดตั้งบนโปรเจกต์นี้ (ตรวจแล้ว) จึงต้องเรียกเป็นระยะจากภายนอก
-- p_dry_run = true (ค่าเริ่มต้น) → "นับอย่างเดียว ไม่ลบ" ตามกฎ Production Safety
create or replace function public.njhr_error_log_cleanup(
  p_token text, p_days int default 90, p_dry_run boolean default true)
 returns table(would_delete bigint, deleted bigint, cutoff timestamptz)
 language plpgsql security definer set search_path to 'public'
as $function$
declare c record; v_cut timestamptz; v_n bigint; v_d bigint := 0;
begin
  select * into c from public.njhr_ctx(p_token);
  if c.role <> 'SUPER_ADMIN' then
    raise exception 'เฉพาะ SUPER_ADMIN เท่านั้น' using errcode='42501';
  end if;
  v_cut := now() - make_interval(days => greatest(coalesce(p_days,90), 30));
  select count(*) into v_n from public.njhr_error_logs where occurred_at < v_cut;
  if not coalesce(p_dry_run, true) then
    delete from public.njhr_error_logs where occurred_at < v_cut;
    get diagnostics v_d = row_count;
    perform public.njhr_audit_write(p_token, 'ERRORLOG_CLEANUP', 'system', 'njhr_error_logs',
      null, 'ลบบันทึกข้อผิดพลาดเก่ากว่า ' || v_cut::date || ' จำนวน ' || v_d || ' รายการ',
      null, null, null);
  end if;
  return query select v_n, v_d, v_cut;
end $function$;

revoke all on function public.njhr_error_log_cleanup(text,int,boolean) from public;
grant execute on function public.njhr_error_log_cleanup(text,int,boolean) to anon, authenticated, service_role;

commit;

-- ---------- VERIFY ----------
-- select count(*) from information_schema.tables where table_schema='public' and table_name='njhr_error_logs';  --> 1
-- select relrowsecurity from pg_class where relname='njhr_error_logs';                                          --> true
-- select count(*) from pg_policy where polrelid='public.njhr_error_logs'::regclass;                             --> 0 (เข้าถึงผ่าน RPC เท่านั้น)
-- select public.njhr_error_redact('token=abc123 eyJhbGciOiJI0000000000 13.7563,100.5018 a@b.com');
--   --> ต้องเห็น [hidden] · [token] · [geo] · [email] ครบ
-- select * from public.njhr_error_log_cleanup('<super_admin_token>', 90, true);   --> Dry Run: deleted = 0
-- [Security] token ปลอม/ว่าง ต้องเขียนไม่ได้:
--   select public.njhr_error_log_write('FAKE','JS_ERROR','t','m',null,null,null,null,null,null);
--   --> ERROR 28000 'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่'  และ njhr_error_logs ต้องไม่มีแถวเพิ่ม
--   select public.njhr_error_log_write(null,'JS_ERROR','t','m',null,null,null,null,null,null);
--   --> ERROR 28000 เช่นกัน
-- [Security] client เขียนตารางตรงไม่ได้ (RLS เปิด · ไม่มี policy · ไม่มี table grant):
--   select has_table_privilege('anon','public.njhr_error_logs','INSERT');   --> false
--   select has_table_privilege('anon','public.njhr_error_logs','SELECT');   --> false
--   select has_table_privilege('authenticated','public.njhr_error_logs','SELECT'); --> false
-- [Security] Rate limit: ยิงเกิน 30 ครั้ง/ชม. ต่อผู้ใช้ → แถวที่ 31 ต้องไม่ถูกบันทึก
--   ทดสอบ parallel: เปิด 5 session ยิงพร้อมกัน 40 ครั้ง → ต้องได้ไม่เกิน 30 แถว/ชม.
-- [Redaction] Exact GPS ต้องไม่เหลือทุกรูปแบบ:
--   select public.njhr_error_redact('lat=13.7563 lng=100.5018');
--     --> lat=[geo] lng=[geo]
--   select public.njhr_error_redact('{"lat":13.7563,"lng":100.5018}');
--     --> {"lat"=[geo],"lng"=[geo]}
--   select public.njhr_error_redact('latitude: 13.75631, longitude: 100.50177');
--     --> latitude=[geo], longitude=[geo]
--   select public.njhr_error_redact('pos 13.7563,100.5018 failed');
--     --> pos [geo] failed
--   select public.njhr_error_redact('HTTP 404 at line 25 col 13');
--     --> ต้องไม่เปลี่ยน (ห้ามทำลายข้อความ Error ส่วนอื่น)
-- select count(*) from public.error_logs;   --> 14 (ของเดิมคนละแอป ต้องไม่ถูกแตะ)

-- ---------- ROLLBACK ----------
-- begin;
-- drop function if exists public.njhr_error_log_cleanup(text,int,boolean);
-- drop function if exists public.njhr_error_log_list(text,text,int,int);
-- drop function if exists public.njhr_error_log_write(text,text,text,text,text,text,text,text,text,text);
-- drop function if exists public.njhr_error_redact(text);
-- drop table if exists public.njhr_error_logs;   -- ลบเฉพาะตารางใหม่ · ไม่แตะ public.error_logs
-- commit;
