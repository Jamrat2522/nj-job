-- ============================================================
-- 106_leave_quota_vacation_only.sql
-- Hard Quota บังคับเฉพาะ VACATION เท่านั้น
--
-- Root Cause (จากนิยามจริงบน Production):
--   njhr_leave_quota() คืนค่าไม่ null ให้ SICK / PERSONAL ด้วย
--     (จาก employees.leave_sick / leave_personal)
--   njhr_leave_submit_core_v145 บังคับทุกประเภทที่ quota ไม่ null:
--     if v_quota is not null then ... raise 'วันลาคงเหลือไม่เพียงพอ'
--   → ลาป่วย/ลากิจ ถูก Block เมื่อโควตาหมด ซึ่งผิด Business Rule
--
-- การแก้: เพิ่มเงื่อนไข v_type = 'VACATION' ที่จุดบังคับเพียงจุดเดียว
--   · njhr_leave_quota  ไม่แตะ  → Report/UI ยังอ่านตัวเลขได้ครบทุกประเภท
--   · njhr_leave_balances ไม่แตะ → used/pending/remaining คงเดิมทั้งหมด
--   · ไม่แตะ Workflow · Approval · Payroll · OT · Shift
--
-- ⚠ ไฟล์นี้ใช้ ALTER แบบ "แทนที่ทั้งฟังก์ชัน" ไม่ได้ เพราะ core เป็นฟังก์ชันยาว
--   จึงใช้วิธีอ่านนิยามจริงแล้วแทนที่เฉพาะบรรทัดเงื่อนไข (ปลอดภัยและตรวจสอบได้)
-- ============================================================

-- ---------- PREFLIGHT (ต้องได้ตามนี้ก่อนรัน) ----------
-- 1) ต้องเจอเงื่อนไขเดิมพอดี 1 ครั้ง
-- select (length(pg_get_functiondef(p.oid))
--        - length(replace(pg_get_functiondef(p.oid), 'if v_quota is not null then', '')))
--        / length('if v_quota is not null then') as hits
--   from pg_proc p join pg_namespace n on n.oid = p.pronamespace
--  where n.nspname = 'public' and p.proname = 'njhr_leave_submit_core_v145';
--   --> 1   (ถ้าไม่ใช่ 1 ให้หยุดและรายงานก่อน ห้ามรันต่อ)
--
-- 2) จำนวนใบลาตั้งต้น (ต้องเท่าเดิมหลังรัน)
-- select count(*) from public.leave_requests;   --> 9

begin;

do $mig$
declare v_src text; v_new text; v_hits int;
begin
  select pg_get_functiondef(p.oid) into v_src
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
   where n.nspname = 'public' and p.proname = 'njhr_leave_submit_core_v145';

  if v_src is null then
    raise exception 'ไม่พบ njhr_leave_submit_core_v145';
  end if;

  -- ป้องกันรันซ้ำ: ถ้าแก้ไปแล้วให้ข้าม (idempotent)
  if position('if v_type = ''VACATION'' and v_quota is not null then' in v_src) > 0 then
    raise notice '106: แก้ไปแล้ว ข้าม';
    return;
  end if;

  /* [Fail Closed] ต้องเจอเงื่อนไขเดิม "พอดี 1 จุด" เท่านั้น
     0 จุด = Source เปลี่ยนไปแล้ว · >1 จุด = replace จะแก้หลายที่โดยไม่ตั้งใจ
     ทั้งสองกรณีต้องหยุด ห้ามแก้ */
  v_hits := (length(v_src) - length(replace(v_src, 'if v_quota is not null then', '')))
            / length('if v_quota is not null then');
  if v_hits <> 1 then
    raise exception '106: พบเงื่อนไข ''if v_quota is not null then'' จำนวน % จุด (ต้องเป็น 1) — หยุดเพื่อความปลอดภัย', v_hits;
  end if;

  v_new := replace(v_src,
    'if v_quota is not null then',
    'if v_type = ''VACATION'' and v_quota is not null then');

  if v_new = v_src then
    raise exception '106: แทนที่ไม่สำเร็จ';
  end if;

  execute v_new;
end $mig$;

commit;

-- ---------- VERIFICATION (ต้องผ่านทุกข้อ) ----------
-- 1) select position('if v_type = ''VACATION'' and v_quota is not null then'
--                    in pg_get_functiondef(p.oid)) > 0 as fixed
--      from pg_proc p join pg_namespace n on n.oid = p.pronamespace
--     where n.nspname = 'public' and p.proname = 'njhr_leave_submit_core_v145';
--    --> true
-- 2) select count(*) from public.leave_requests;              --> 9 (เท่าเดิม)
-- 3) njhr_leave_quota / njhr_leave_balances ต้องไม่เปลี่ยน:
--    select proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace
--     where n.nspname='public' and proname in ('njhr_leave_quota','njhr_leave_balances');
--    --> 2 แถว (ยังอยู่ครบ ไม่ถูกแก้)
-- 4) ทดสอบจริงบนเว็บ: พนักงานที่ leave_sick เหลือ 0 ต้องยื่นลาป่วยได้
--    และพนักงานที่ leave_vacation เหลือ 0 ต้องยื่นลาพักร้อนไม่ได้

-- ---------- ROLLBACK ----------
-- begin;
-- do $rb$
-- declare v_src text; begin
--   select pg_get_functiondef(p.oid) into v_src from pg_proc p
--     join pg_namespace n on n.oid=p.pronamespace
--    where n.nspname='public' and p.proname='njhr_leave_submit_core_v145';
--   execute replace(v_src,
--     'if v_type = ''VACATION'' and v_quota is not null then',
--     'if v_quota is not null then');
-- end $rb$;
-- commit;
