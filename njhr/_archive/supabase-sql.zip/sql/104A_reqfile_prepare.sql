-- ============================================================
-- 104A_reqfile_prepare.sql   [รันก่อน — ปลอดภัย 100%]
-- ปิด Public Access ของไฟล์แนบใบลา + OT อย่างปลอดภัย
--
-- ทำอะไรบ้าง (เรียงตามลำดับใน Transaction เดียว):
--   A. เพิ่มคอลัมน์ leave_attachments.file_path + Backfill จาก file_url เดิม
--   B. Trigger เติม file_path อัตโนมัติสำหรับแถวใหม่
--      (ไม่ต้องแก้ njhr_leave_submit_core_v145 ก้อนใหญ่เลย)
--   C. njhr_leave_detail คืน 'path' เพิ่มใน attachments (คีย์เดิมครบ ไม่มีอะไรหาย)
--   D. RPC ใหม่ njhr_reqfile_access — ประตูตรวจสิทธิ์ก่อนออก Signed URL
--      กติกาสิทธิ์ "ลอกจาก RPC เดิมที่ใช้จริง" ไม่คิดใหม่:
--        LEAVE = เจ้าของ | HR | SUPER_ADMIN | ADMIN ที่อยู่ใน Workflow (njhr_leave_detail เดิม)
--        OT    = เจ้าของ | HR | SUPER_ADMIN | ADMIN ที่อยู่ใน Workflow (njhr_ot_attach_list เดิม)
--   E. ปิด public ของ 2 bucket + ถอน Policy ของ anon ออกทั้งหมด (อ่าน/อัปโหลด/ALL)
--      + เพิ่ม 2 bucket นี้เข้า exclusion ของ njhr_sig_no_public
--      + RPC ออกเส้นทางอัปโหลด — Upload ใหม่ผ่าน Edge Function (Signed Upload URL)
--
-- ไม่แตะ: ไฟล์ใน Storage (0 การเขียน) · Face/Emp-doc bucket · Approval Workflow ·
--         Payroll · Attendance · Shift · njhr_ot_attach_* เดิม · storage_admin_delete
-- ============================================================

-- ---------- PREFLIGHT (รันดูก่อน ต้องได้ตามคาด) ----------
-- 1) bucket ยังเป็น public = true ทั้งคู่
--    select id, public from storage.buckets where id in ('leave-attachments','ot-attachments');
-- 2) จำนวนข้อมูลตั้งต้น (ณ วันที่เขียน: leave_attachments = 2, njhr_ot_attachments = 0,
--    storage: leave = 2 objects, ot = 1 object)
--    select (select count(*) from public.leave_attachments) leave_rows,
--           (select count(*) from public.njhr_ot_attachments) ot_rows,
--           (select count(*) from storage.objects where bucket_id='leave-attachments') st_leave,
--           (select count(*) from storage.objects where bucket_id='ot-attachments') st_ot;
-- 3) policy ที่จะถูกถอนมีอยู่จริง
--    select polname from pg_policy where polrelid='storage.objects'::regclass
--     and polname in ('nj_v6_storage_leave_attachments','njhr_leave_read','njhr_ot_read','njhr_sig_no_public');

begin;

-- ---------- A. คอลัมน์ path + Backfill ----------
alter table public.leave_attachments add column if not exists file_path text;

update public.leave_attachments
   set file_path = substring(file_url from '/object/public/leave-attachments/(.+)$')
 where file_path is null
   and file_url like '%/object/public/leave-attachments/%';

-- แถวที่ client ยุคใหม่ส่ง path มาในช่อง url ตรง ๆ (หลัง Deploy หน้าเว็บใหม่)
update public.leave_attachments
   set file_path = file_url
 where file_path is null
   and coalesce(file_url,'') <> ''
   and file_url not like 'http%';

-- ---------- B. Trigger เติม file_path ให้แถวใหม่ ----------
create or replace function public.njhr_leaveatt_fill_path()
returns trigger language plpgsql as $$
begin
  if coalesce(new.file_path,'') = '' then
    if new.file_url like '%/object/public/leave-attachments/%' then
      new.file_path := substring(new.file_url from '/object/public/leave-attachments/(.+)$');
    elsif coalesce(new.file_url,'') <> '' and new.file_url not like 'http%' then
      new.file_path := new.file_url;   -- client ใหม่ส่ง path มาในช่อง url
    end if;
  end if;
  return new;
end $$;

drop trigger if exists njhr_leaveatt_fill_path_tg on public.leave_attachments;
create trigger njhr_leaveatt_fill_path_tg
  before insert on public.leave_attachments
  for each row execute function public.njhr_leaveatt_fill_path();

-- ---------- C. njhr_leave_detail คืน path เพิ่ม (คีย์เดิมครบทุกตัว) ----------
-- ต้นฉบับ = นิยามจริงจาก Production ณ วันที่ 15/08/2026 เปลี่ยนเฉพาะ jsonb ไฟล์แนบ
CREATE OR REPLACE FUNCTION public.njhr_leave_detail(p_token text, p_leave_id uuid)
 RETURNS TABLE(id uuid, employee_id uuid, emp_name text, leave_type text, status text, ui_status text, approvals jsonb, attachments jsonb, request_no text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
#variable_conflict use_column
declare c record; r public.leave_requests;
begin
  select * into c from public.njhr_ctx(p_token);
  select * into r from public.leave_requests where leave_requests.id = p_leave_id;
  if not found then raise exception 'ไม่พบใบลานี้' using errcode='P0002'; end if;
  if c.role not in ('SUPER_ADMIN','HR') and r.employee_id is distinct from c.employee_id and not (c.role='ADMIN' and public.njhr_request_approver_member('LEAVE',r.employee_id,c.employee_id)) then
    raise exception 'คุณไม่มีสิทธิ์ดูใบลาของพนักงานคนอื่น' using errcode='42501';
  end if;
  return query
  select r.id, r.employee_id,
         (select coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,'')
            from public.employees e where e.id = r.employee_id),
         r.leave_type::text, r.status::text,
         case when r.status='PENDING'
               and (select x->>'action' from jsonb_array_elements(coalesce(r.approvals,'[]'::jsonb)) x
                     order by (x->>'seq')::int desc limit 1) = 'INFO'
              then 'NEED_MORE_INFO' else r.status::text end,
         coalesce(r.approvals,'[]'::jsonb),
         coalesce((select jsonb_agg(jsonb_build_object(
                     'name', a.file_name, 'url', a.file_url, 'size', a.file_size,
                     'path', a.file_path)                                  -- [104] เพิ่ม path
                   order by a.created_at)
                     from public.leave_attachments a where a.leave_id = r.id), '[]'::jsonb),
         r.request_no                              -- [R3] เลขที่คำขอ
  ;
end $function$;

-- ---------- D. ประตูตรวจสิทธิ์ก่อนออก Signed URL ----------
create or replace function public.njhr_reqfile_access(p_token text, p_path text)
 returns table(bucket_id text, storage_path text, file_name text, mime_type text)
 language plpgsql
 security definer
 set search_path to 'public'
as $function$
#variable_conflict use_column
declare c record; la record; oa record; lr record; orq record; v_path text := btrim(coalesce(p_path,''));
begin
  select * into c from public.njhr_ctx(p_token);

  if v_path like 'leave/%' then
    select * into la from public.leave_attachments a where a.file_path = v_path
     order by a.created_at desc limit 1;
    if not found then raise exception 'ไม่พบไฟล์แนบนี้' using errcode='P0002'; end if;
    select * into lr from public.leave_requests l where l.id = la.leave_id;
    if not found then raise exception 'ไม่พบใบลาของไฟล์นี้' using errcode='P0002'; end if;
    -- กติกาเดียวกับ njhr_leave_detail ทุกตัวอักษร
    if c.role not in ('SUPER_ADMIN','HR') and lr.employee_id is distinct from c.employee_id
       and not (c.role='ADMIN' and public.njhr_request_approver_member('LEAVE',lr.employee_id,c.employee_id)) then
      raise exception 'คุณไม่มีสิทธิ์เปิดไฟล์แนบของพนักงานคนอื่น' using errcode='42501';
    end if;
    perform public.njhr_audit_write(p_token, 'REQFILE_VIEW', 'leave', 'leave_attachments',
      la.id::text, 'เปิดไฟล์แนบใบลา ' || la.file_name, null, null, null);
    return query select 'leave-attachments'::text, la.file_path, la.file_name,
                        'application/octet-stream'::text;
    return;
  end if;

  if v_path like 'ot/%' then
    select * into oa from public.njhr_ot_attachments a
     where a.file_path = v_path and a.deleted_at is null
     order by a.created_at desc limit 1;
    if not found then raise exception 'ไม่พบไฟล์แนบนี้' using errcode='P0002'; end if;
    -- กติกาเดียวกับ njhr_ot_attach_list ทุกตัวอักษร
    if oa.employee_id is distinct from c.employee_id
       and c.role not in ('SUPER_ADMIN','HR')
       and not (c.role='ADMIN' and oa.ot_id is not null and exists (
             select 1 from public.ot_requests o
              where o.id = oa.ot_id
                and public.njhr_request_approver_member('OT', o.employee_id, c.employee_id))) then
      raise exception 'คุณไม่มีสิทธิ์เปิดไฟล์แนบของพนักงานคนอื่น' using errcode='42501';
    end if;
    perform public.njhr_audit_write(p_token, 'REQFILE_VIEW', 'ot', 'njhr_ot_attachments',
      oa.id::text, 'เปิดไฟล์แนบ OT ' || oa.file_name, null, null, null);
    return query select 'ot-attachments'::text, oa.file_path, oa.file_name,
                        coalesce(oa.content_type,'application/octet-stream');
    return;
  end if;

  raise exception 'เส้นทางไฟล์ไม่ถูกต้อง' using errcode='22023';
end $function$;

revoke all on function public.njhr_reqfile_access(text, text) from public, anon, authenticated;
grant execute on function public.njhr_reqfile_access(text, text) to service_role;
-- เรียกได้จาก service_role (Edge Function) เท่านั้น — เบราว์เซอร์เรียกตรงไม่ได้
-- GRANT จำเป็น: REVOKE ... FROM public ถอนสิทธิ์เริ่มต้นออกทั้งหมดรวม service_role ด้วย
-- (ตรงกับ ACL จริงของ njhr_empfile_access ใน Production: service_role=X/postgres)


-- ---------- E. RPC ออก "เส้นทางไฟล์" สำหรับอัปโหลด (แทน anon INSERT) ----------
-- Upload ใหม่ทำผ่าน Edge Function njhr-req-file action=upload-url เท่านั้น
-- โฟลเดอร์ผูกกับ employee_id ของเจ้าของ token -> ปลอมเป็นคนอื่นไม่ได้
-- Naming convention เดิมทุกส่วน: <prefix>/<emp_id>/<ts>-<rand5>-<safe><ext>
create or replace function public.njhr_reqfile_upload_path(p_token text, p_kind text, p_file_name text)
 returns table(storage_path text)
 language plpgsql
 security definer
 set search_path to 'public'
as $function$
#variable_conflict use_column
declare c record; v_kind text := lower(btrim(coalesce(p_kind,'')));
        v_name text := coalesce(p_file_name,'file'); v_ext text; v_safe text;
begin
  select * into c from public.njhr_ctx(p_token);           -- token ไม่ถูกต้อง = raise ที่นี่
  if c.employee_id is null then
    raise exception 'บัญชีนี้ไม่ได้ผูกกับพนักงาน จึงแนบไฟล์คำขอไม่ได้' using errcode='42501';
  end if;
  if v_kind not in ('leave','ot') then
    raise exception 'ประเภทไฟล์แนบไม่ถูกต้อง' using errcode='22023';
  end if;
  v_ext  := coalesce(substring(v_name from '\.[A-Za-z0-9]{1,8}$'), '');
  v_safe := coalesce(nullif(left(regexp_replace(regexp_replace(v_name,'\.[^.]*$',''),
                                                '[^A-Za-z0-9_\-]+','_','g'), 40), ''), 'file');
  return query select v_kind || '/' || c.employee_id || '/' ||
    lpad(to_hex(floor(extract(epoch from clock_timestamp())*1000)::bigint), 9, '0') || '-' ||
    substr(md5(random()::text || clock_timestamp()::text), 1, 5) || '-' || v_safe || v_ext;
end $function$;

revoke all on function public.njhr_reqfile_upload_path(text, text, text) from public, anon, authenticated;
grant execute on function public.njhr_reqfile_upload_path(text, text, text) to service_role;
-- เรียกได้จาก service_role (Edge Function) เท่านั้น

commit;

-- ---------- VERIFICATION 104A ----------
-- select count(*) from public.leave_attachments where file_path is null;        --> 0
-- select proname from pg_proc where proname in
--   ('njhr_reqfile_access','njhr_reqfile_upload_path','njhr_leaveatt_fill_path'); --> 3 แถว
-- select p.proname, array_to_string(p.proacl,' | ') from pg_proc p
--  join pg_namespace n on n.oid=p.pronamespace
--  where n.nspname='public' and p.proname like 'njhr_reqfile%';
--   --> ต้องเห็น service_role=X/postgres ทั้ง 2 ตัว (ไม่งั้น Edge Function จะได้ permission denied)
-- select id, public from storage.buckets where id in ('leave-attachments','ot-attachments');
--   --> ยังเป็น true (ถูกต้อง — 104B เป็นตัวปิด)

-- ---------- ROLLBACK 104A ----------
-- begin;
-- drop function if exists public.njhr_reqfile_upload_path(text, text, text);
-- drop function if exists public.njhr_reqfile_access(text, text);
-- drop trigger if exists njhr_leaveatt_fill_path_tg on public.leave_attachments;
-- drop function if exists public.njhr_leaveatt_fill_path();
-- -- คอลัมน์ file_path และคีย์ 'path' ใน njhr_leave_detail เก็บไว้ได้ ไม่กระทบ client เดิม
-- commit;
