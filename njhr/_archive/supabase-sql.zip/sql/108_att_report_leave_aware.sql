-- ============================================================
-- 108_att_report_leave_aware.sql   [CRITICAL — อ่านทั้งไฟล์ก่อนรัน]
--
-- njhr_att_report ต้องรู้จัก "วันลาที่อนุมัติแล้ว"
--
-- ⚠ เปลี่ยน RETURNS TABLE ด้วย CREATE OR REPLACE ไม่ได้
--   PostgreSQL: "cannot change return type of existing function"
--   จึงต้อง DROP (ระบุ signature เจาะจง ห้าม CASCADE) แล้ว CREATE ใหม่
--   ในทรานแซกชันเดียว พร้อมคืน owner / ACL / attribute เดิมครบ
--
-- ค่าเดิมที่ตรวจจาก Production (15/08/2026) และต้องคืนให้ครบ:
--   owner    : postgres
--   volatile : STABLE (s)          secdef : true
--   config   : search_path=public
--   ACL      : =X/postgres | postgres=X/postgres | anon=X/postgres
--              | authenticated=X/postgres | service_role=X/postgres
--              → PUBLIC มี EXECUTE + grant ตรงให้ anon / authenticated / service_role
--   args     : p_token text, p_from date, p_to date, p_type text, p_dept text,
--              p_employee uuid, p_q text, p_limit integer, p_offset integer
--
-- Return: คอลัมน์เดิม 15 ตัว "ชื่อ/ชนิด/ลำดับเดิมทุกตัว" + เพิ่ม 5 ตัวต่อท้าย
--   leave_status · leave_type · leave_mode · leave_start_time · leave_end_time
--
-- ⚠ ไม่เปลี่ยนความหมายของ status เดิมเด็ดขาด
--   แถวที่มาจากตาราง attendance → status = ค่าเดิมทุกประการ
--   แถว "วันลาที่ไม่มี attendance" (แถวใหม่ที่ไม่เคยมีมาก่อน) → status = NULL
--     เพื่อไม่ให้ Consumer เดิม (Payroll / REPORT ALL) ที่อ่าน r.status
--     ตีความเป็นสถานะการลงเวลาใด ๆ · สถานะการลาอ่านจาก leave_status แทน
--
-- ห้ามสร้าง Punch ปลอม: check_in / check_out ของแถววันลา = NULL
-- ห้ามแก้ตาราง attendance: ฟังก์ชันเป็น STABLE อ่านอย่างเดียว
-- ต้องรัน 107 (half_period) ก่อนไฟล์นี้
-- ============================================================

-- ---------- PREFLIGHT (ต้องได้ตามนี้ทุกข้อ ก่อนรัน) ----------
-- 1) มีคอลัมน์ half_period แล้ว (107 รันแล้ว)
-- select count(*) from information_schema.columns
--  where table_schema='public' and table_name='leave_requests' and column_name='half_period';   --> 1
--
-- 2) signature / owner / ACL / attribute เดิม (จดค่าไว้เทียบหลัง COMMIT)
-- select pg_get_function_identity_arguments(p.oid) as args,
--        pg_get_function_result(p.oid)             as result,
--        pg_get_userbyid(p.proowner)               as owner,
--        array_to_string(p.proacl,' | ')           as acl,
--        p.provolatile, p.prosecdef, array_to_string(p.proconfig,',') as config
--   from pg_proc p join pg_namespace n on n.oid=p.pronamespace
--  where n.nspname='public' and p.proname='njhr_att_report';
--
-- 3) ตรวจ dependency "ทุกตัว" ก่อน DROP
--    ⚠ ห้ามกรองด้วย deptype <> 'n' — normal dependency ใช้ deptype = 'n' พอดี
--       การกรองแบบนั้นจะซ่อน dependent ที่แท้จริงทั้งหมด
-- select d.classid::regclass as dep_class, d.objid, d.deptype,
--        pg_describe_object(d.classid, d.objid, d.objsubid) as depends_on_it
--   from pg_depend d
--  where d.refobjid = (select p.oid from pg_proc p join pg_namespace n on n.oid=p.pronamespace
--                       where n.nspname='public' and p.proname='njhr_att_report')
--    and d.refclassid = 'pg_proc'::regclass;
--   --> คาดหวัง: มีเฉพาะแถวที่ depends_on_it ชี้ไป schema public (deptype='n')
--       ถ้าเจอ view / rule / trigger / function อื่นอ้างถึง → หยุด ห้าม DROP
--       (ตรวจซ้ำด้วยการค้นชื่อในนิยาม object อื่น)
-- select p.proname from pg_proc p join pg_namespace n on n.oid=p.pronamespace
--  where n.nspname='public' and p.proname <> 'njhr_att_report'
--    and pg_get_functiondef(p.oid) like '%njhr_att_report%';
--   --> ต้องไม่มีแถว
-- select viewname from pg_views where schemaname='public' and definition like '%njhr_att_report%';
--   --> ต้องไม่มีแถว
--
-- 4) จดจำนวนแถวรายงานเดิมไว้เทียบ (ใช้ token ของ SUPER_ADMIN)
-- select count(*) from public.njhr_att_report('<token>','2026-08-01','2026-08-31','ATTEND',null,null,null,2000,0);

begin;

-- ---------- DROP แบบระบุ signature เจาะจง · ห้าม CASCADE ----------
drop function public.njhr_att_report(text, date, date, text, text, uuid, text, integer, integer);

-- ---------- CREATE ใหม่ · input signature เดิม 100% ----------
create function public.njhr_att_report(
  p_token text, p_from date, p_to date, p_type text DEFAULT 'ATTEND'::text,
  p_dept text DEFAULT NULL::text, p_employee uuid DEFAULT NULL::uuid,
  p_q text DEFAULT NULL::text, p_limit integer DEFAULT 500, p_offset integer DEFAULT 0)
 returns table(
   -- ===== 15 คอลัมน์เดิม ชื่อ/ชนิด/ลำดับเดิมทุกตัว =====
   work_date date, employee_id uuid, emp_code text, prefix text, emp_name text,
   nickname text, department text, position_name text,
   check_in timestamp with time zone, check_out timestamp with time zone,
   work_hours numeric, status text, late_min integer, shift_name text,
   total_count bigint,
   -- ===== [108] เพิ่มต่อท้ายเท่านั้น =====
   leave_status text, leave_type text, leave_mode text,
   leave_start_time time without time zone, leave_end_time time without time zone,
   raw_status text, raw_late_min integer)
 language plpgsql
 stable security definer
 set search_path to 'public'
as $function$
#variable_conflict use_column
declare c record; q text := lower(btrim(coalesce(p_q,''))); ty text := upper(btrim(coalesce(p_type,'ATTEND')));
begin
  select * into c from public.njhr_att_guard(p_token);
  if p_from is null or p_to is null then
    raise exception 'กรุณาเลือกช่วงวันที่' using errcode='22023';
  end if;
  if p_from > p_to then
    raise exception 'วันที่เริ่มต้นต้องไม่เกินวันที่สิ้นสุด' using errcode='22023';
  end if;
  if ty not in ('ATTEND','LATE') then
    raise exception 'ประเภทรายงานไม่ถูกต้อง (%)', p_type using errcode='22023';
  end if;
  if not c.is_manager and c.employee_id is null then
    raise exception 'บัญชีนี้ยังไม่ได้เชื่อมกับข้อมูลพนักงาน' using errcode='28000';
  end if;

  return query
  with emp as (
    select e.* from public.employees e
     where (p_dept is null or p_dept = '' or e.department_name = p_dept)
       and (p_employee is null or e.id = p_employee)
       and (c.is_manager or e.id = c.employee_id)
       and (q = '' or lower(coalesce(e.emp_code,'')) like '%'||q||'%'
            or lower(coalesce(e.first_name,'')||' '||coalesce(e.last_name,'')) like '%'||q||'%'
            or lower(coalesce(e.prefix,'')||coalesce(e.first_name,'')||' '||coalesce(e.last_name,'')) like '%'||q||'%'
            or lower(coalesce(e.nickname,'')) like '%'||q||'%')),

  -- ===== วันลาที่ "อนุมัติแล้ว" เท่านั้น กางเป็นรายวัน =====
  -- PENDING / REJECTED / CANCELLED ไม่ถูกดึงมาเลย จึงไม่มีทางกระทบ Attendance
  lv0 as (
    select r.employee_id lid, d::date lwd, r.leave_type::text ltype, r.leave_unit lunit,
           r.half_period lhalf, r.start_time lst, r.end_time let
      from public.leave_requests r
      cross join lateral generate_series(r.start_date, r.end_date, interval '1 day') d
     where r.status = 'APPROVED'
       and d::date between p_from and p_to
       /* กรองวันไม่ทำงานออกให้ตรงกับ njhr_leave_workdays() เป๊ะ
          (จันทร์–ศุกร์ และไม่ใช่วันหยุดในตาราง holidays)
          → FULL หลายวันที่คาบเสาร์-อาทิตย์/วันหยุด จะไม่สร้าง Leave row ในวันนั้น */
       and extract(isodow from d) < 6
       and not exists (select 1 from public.holidays h where h.holiday_date = d::date)),

  lv1 as (
    select l.*,
           case when l.lunit = 'halfday' then coalesce(l.lhalf, 'HALF')
                when l.lunit = 'hour'    then 'HOURLY'
                else 'FULL' end lmode
      from lv0 l),

  /* กะจริง + จุดกึ่งกลางกะ (ห้าม hardcode 12:00) · กะข้ามคืนบวก 24 ชม. ก่อนหาร */
  lv2 as (
    select l.*, s.start_time sh_s, s.end_time sh_e,
           coalesce(s.late_allow_minutes, 0) sh_allow,
           /* จุดกึ่งกลางกะ — ห้าม cast interval ที่หารแล้วเป็น ::time ก่อนบวก
              เพราะจะกลายเป็น time + time → ERROR 42725 (operator does not exist)
              ต้องบวก interval เข้ากับ time ตรง ๆ ผลลัพธ์เป็น time โดยอัตโนมัติ
              ทดสอบจริงบน Production: 08:30–17:30 → 13:00 · 20:00–05:00 (overnight) → 00:30 */
           case when s.start_time is null or s.end_time is null then null
                else s.start_time
                     + (
                         (
                           (s.end_time - s.start_time)
                           + case when coalesce(s.is_overnight,false)
                                  then interval '24 hours'
                                  else interval '0'
                             end
                         ) / 2
                       )
           end sh_mid
      from lv1 l
      left join lateral public.njhr_shift_at(l.lid, l.lwd) s on true),

  /* ---------- ช่วงลา + "ขอบเขตเวลาที่ต้องทำงานจริง" หลัง Overlay ----------
     eff_s / eff_e = เวลาเริ่ม/สิ้นสุดที่พนักงานยังต้องทำงานในวันนั้น
       FULL     → ไม่ต้องทำงานเลย (NULL ทั้งคู่)
       HALF_AM  → เริ่มงานจริงที่จุดกึ่งกลางกะ  (เช้าลา)
       HALF_PM  → เลิกงานจริงที่จุดกึ่งกลางกะ  (บ่ายลา)
       HOURLY   → ตัดเฉพาะช่วงที่คาบขอบกะ · เวลานอกช่วงลายังต้องทำงานตามปกติ
     ไม่มีกะ → NULL (NOT VERIFIED) ไม่เดาเวลา */
  lv as (
    select v.lid, v.lwd, v.ltype, v.lmode, v.sh_s, v.sh_e, v.sh_allow,
           case v.lmode when 'HALF_AM' then v.sh_s
                        when 'HALF_PM' then v.sh_mid
                        when 'HOURLY'  then v.lst
                        when 'FULL'    then v.sh_s
                        else null end lfrom,
           case v.lmode when 'HALF_AM' then v.sh_mid
                        when 'HALF_PM' then v.sh_e
                        when 'HOURLY'  then v.let
                        when 'FULL'    then v.sh_e
                        else null end lto,
           case v.lmode
             when 'FULL'    then null
             when 'HALF_AM' then v.sh_mid
             when 'HOURLY'  then
               case when v.lst is not null and v.let is not null and v.sh_s is not null
                         and v.lst <= v.sh_s and v.let > v.sh_s
                    then v.let else v.sh_s end
             else v.sh_s end eff_s,
           case v.lmode
             when 'FULL'    then null
             when 'HALF_PM' then v.sh_mid
             when 'HOURLY'  then
               case when v.lst is not null and v.let is not null and v.sh_e is not null
                         and v.let >= v.sh_e and v.lst < v.sh_e
                    then v.lst else v.sh_e end
             else v.sh_e end eff_e
      from lv2 v),

  base as (
    select a.work_date wd, e.id eid, e.emp_code ec, coalesce(e.prefix,'') epx,
           btrim(coalesce(e.first_name,'')||' '||coalesce(e.last_name,'')) enm,
           coalesce(e.nickname,'') enk, coalesce(e.department_name,'') edept,
           coalesce(e.position_name,'') epos,
           a.check_in ci, a.check_out co, a.work_hours wh, a.status::text st,
           public.njhr_att_late_min(a.employee_id, a.work_date, a.check_in) lm,
           (select s.shift_name from public.njhr_shift_at(e.id, a.work_date) s) shn
      from public.attendance a
      join emp e on e.id = a.employee_id
     where a.work_date between p_from and p_to),

  /* วันลาที่ไม่มีแถว attendance → ต้องมีแถวในรายงาน (ไม่ใช่ Punch ปลอม) */
  leaveonly as (
    select l.lwd wd, e.id eid, e.emp_code ec, coalesce(e.prefix,'') epx,
           btrim(coalesce(e.first_name,'')||' '||coalesce(e.last_name,'')) enm,
           coalesce(e.nickname,'') enk, coalesce(e.department_name,'') edept,
           coalesce(e.position_name,'') epos,
           null::timestamptz ci, null::timestamptz co, null::numeric wh,
           null::text st, 0 lm,
           (select s.shift_name from public.njhr_shift_at(e.id, l.lwd) s) shn
      from lv l
      join emp e on e.id = l.lid
     where not exists (select 1 from public.attendance a
                        where a.employee_id = l.lid and a.work_date = l.lwd)),

  allrows as (select * from base union all select * from leaveonly),

  /* ---------- แยก raw ↔ effective ----------
     raw_status / raw_late_min = ค่าดิบจากตาราง attendance (ไม่ถูกแตะ)
     status / late_min         = ค่าหลัง Overlay วันลาที่อนุมัติแล้ว
       FULL   → status = 'LEAVE' · late = 0 · ไม่ฟ้อง Missing IN/OUT
       HALF   → late คำนวณใหม่จาก eff_s (เข้างานจริง) ไม่ใช่ต้นกะ
       HOURLY → late คำนวณจาก eff_s ที่ปรับตามช่วงลาที่คาบต้นกะเท่านั้น
     เวลานอกช่วงลายังถูกตรวจตามปกติ ไม่มีการยกเว้นเกินขอบเขต */
  eff as (
    select r.*,
           case when l.lid is null then null else 'LEAVE' end lstatus,
           l.ltype, l.lmode, l.lfrom, l.lto,
           case
             when l.lid is null then r.lm
             when l.lmode = 'FULL' then 0
             when r.ci is null or l.eff_s is null then 0
             else greatest(0, (
                    case when r.ci <= ((r.wd::text||' '||l.eff_s::text)::timestamp at time zone 'Asia/Bangkok')
                                      + make_interval(mins => l.sh_allow)
                         then 0
                         else (extract(epoch from (r.ci
                                - ((r.wd::text||' '||l.eff_s::text)::timestamp at time zone 'Asia/Bangkok')))/60)::int
                    end))
           end eff_lm
      from allrows r
      left join lv l on l.lid = r.eid and l.lwd = r.wd),

  /* ---------- Effective Status ต้องสอดคล้องกับ Effective Late เสมอ ----------
     ห้ามแก้เฉพาะ late_min แล้วปล่อย status = 'LATE' ค้างไว้
     FULL Approved            → 'LEAVE'  (late = 0 อยู่แล้วจาก eff)
     HALF_AM/HALF_PM/HOURLY   → raw 'LATE' แต่ effective late = 0 → 'NORMAL'
                                 effective late > 0                → 'LATE'
     ไม่มีวันลา               → คงค่าดิบทุกประการ
     enum จริงของ attendance.status: NORMAL · LATE · ABSENT · LEAVE · HOLIDAY
     ค่าดิบยังอ่านได้จาก raw_status / raw_late_min */
  joined as (
    select e2.*,
           case
             when e2.lstatus is null then e2.st                      -- ไม่มีวันลา = คงเดิม
             when e2.lmode = 'FULL'  then 'LEAVE'
             when e2.eff_lm > 0      then 'LATE'
             when e2.st = 'LATE'     then 'NORMAL'                   -- สายหายไปหลัง Overlay
             else e2.st
           end eff_st
      from eff e2),

  filtered as (select * from joined j where ty = 'ATTEND' or j.eff_lm > 0)
  select f.wd, f.eid, f.ec, f.epx, f.enm, f.enk, f.edept, f.epos,
         f.ci, f.co, f.wh, f.eff_st, f.eff_lm, f.shn, (select count(*) from filtered),
         f.lstatus, f.ltype, f.lmode, f.lfrom, f.lto,
         f.st, f.lm
    from filtered f order by f.wd desc, f.ec
   limit least(greatest(coalesce(p_limit,500),1),2000) offset greatest(coalesce(p_offset,0),0);
end $function$;

-- ---------- คืน owner + ACL เดิมให้ครบ ----------
alter function public.njhr_att_report(text, date, date, text, text, uuid, text, integer, integer)
  owner to postgres;

-- ACL เดิม: PUBLIC มี EXECUTE (=X/postgres) + grant ตรงให้ 3 role
grant execute on function public.njhr_att_report(text, date, date, text, text, uuid, text, integer, integer) to public;
grant execute on function public.njhr_att_report(text, date, date, text, text, uuid, text, integer, integer) to anon;
grant execute on function public.njhr_att_report(text, date, date, text, text, uuid, text, integer, integer) to authenticated;
grant execute on function public.njhr_att_report(text, date, date, text, text, uuid, text, integer, integer) to service_role;

-- ---------- ให้ PostgREST อ่าน schema ใหม่ ----------
notify pgrst, 'reload schema';

-- ---------- VERIFY ในทรานแซกชันเดียวกัน — ไม่ตรง = Rollback ทั้งก้อน ----------
do $v$
declare r record;
begin
  select pg_get_function_identity_arguments(p.oid) args,
         pg_get_userbyid(p.proowner) owner, p.provolatile vol, p.prosecdef secdef,
         array_to_string(p.proconfig,',') cfg,
         array_to_string(p.proacl,' | ') acl,
         pg_get_function_result(p.oid) res
    into r
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
   where n.nspname = 'public' and p.proname = 'njhr_att_report';

  if r.args is distinct from
     'p_token text, p_from date, p_to date, p_type text, p_dept text, p_employee uuid, p_q text, p_limit integer, p_offset integer' then
    raise exception '108: input signature เปลี่ยน (%)', r.args;
  end if;
  if r.owner <> 'postgres' then raise exception '108: owner ผิด (%)', r.owner; end if;
  if r.vol <> 's' then raise exception '108: ไม่ใช่ STABLE'; end if;
  if not r.secdef then raise exception '108: ไม่ใช่ SECURITY DEFINER'; end if;
  if r.cfg is distinct from 'search_path=public' then raise exception '108: search_path ผิด (%)', r.cfg; end if;
  if position('anon=X' in r.acl) = 0 or position('authenticated=X' in r.acl) = 0
     or position('service_role=X' in r.acl) = 0 or position('=X/postgres' in r.acl) = 0 then
    raise exception '108: ACL ไม่ครบ (%)', r.acl;
  end if;
  -- คอลัมน์เดิมต้องอยู่ครบและอยู่ก่อนคอลัมน์ใหม่เสมอ
  if position('work_date date' in r.res) = 0 or position('total_count bigint' in r.res) = 0
     or position('leave_status text' in r.res) = 0
     or position('total_count bigint' in r.res) > position('leave_status text' in r.res) then
    raise exception '108: ลำดับคอลัมน์ผิด (%)', r.res;
  end if;
end $v$;

commit;

-- ---------- VERIFICATION หลัง COMMIT (ต้องผ่านทุกข้อ) ----------
-- 1) เรียกผ่าน PostgREST ได้จริงหลัง reload schema (จากหน้าเว็บหรือ curl)
-- 2) ตาราง attendance ต้องไม่มีแถวเพิ่ม/เปลี่ยน:
--    select count(*) from public.attendance;      --> เท่ากับก่อนรัน
-- 3) ใบลา APPROVED ต้องขึ้น leave_status='LEAVE':
--    2026-08-11 FULL · 2026-08-13 FULL · 2026-08-14 HALF_AM
-- 4) ใบ PENDING (08-27) · REJECTED (06-01, 08-13, 08-14) · CANCELLED (08-17)
--    ต้อง "ไม่" ปรากฏเป็นวันลาเลย (leave_status = NULL)
-- 5) แถวที่มาจาก attendance: status ต้องเท่าค่าเดิมทุกแถว (Payroll/REPORT ALL ไม่กระทบ)
-- 6) แถว leaveonly: status = NULL · check_in/check_out = NULL

-- ---------- ROLLBACK ----------
-- คืนนิยามเดิม (15 คอลัมน์ ไม่มี lv/leaveonly) ด้วยขั้นตอนเดียวกัน:
--   begin;
--   drop function public.njhr_att_report(text,date,date,text,text,uuid,text,integer,integer);
--   <<CREATE FUNCTION ต้นฉบับเดิม — เก็บสำเนาไว้ก่อนรัน 108 ด้วย PREFLIGHT ข้อ 2>>
--   alter function ... owner to postgres;
--   grant execute ... to public, anon, authenticated, service_role;
--   notify pgrst, 'reload schema';
--   commit;
-- ⚠ ต้อง dump นิยามเดิมเก็บไว้ก่อนรัน 108 เสมอ:
--   select pg_get_functiondef(p.oid) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
--    where n.nspname='public' and p.proname='njhr_att_report';
