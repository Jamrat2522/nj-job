-- ============================================================
-- NJ HR V2 — R3_request_no_expose.sql  (ส่วนที่ 3: แสดงเลขทุกหน้า)
--
-- เพิ่มคอลัมน์ request_no เข้า RETURNS TABLE ของ 5 RPC
--   njhr_leave_list · njhr_leave_queue · njhr_leave_detail
--   njhr_ot_list · njhr_report_all_ot
--
-- เนื้อฟังก์ชันคัดลอกจาก pg_get_functiondef ของ Production ทุกบรรทัด
-- แก้เพียง 2 จุดต่อฟังก์ชัน: เพิ่ม request_no ใน RETURNS TABLE และใน select
-- คอลัมน์ใหม่ต่อท้ายเสมอ ลำดับคอลัมน์เดิมจึงไม่ขยับ
--
-- ⚠ ต้อง DROP ก่อน CREATE เพราะเปลี่ยน RETURNS TABLE
--   DROP ลบ GRANT ไปด้วย จึงต้อง grant คืนทุกตัวหลัง CREATE
--   ทำในไฟล์เดียวเป็น Transaction เดียว ถ้าล้มกลางทางจะ Rollback ทั้งหมด
--
-- ต้องรัน R1 และ R2 มาก่อน · รันซ้ำได้
-- ============================================================

do $$
begin
  if not exists (select 1 from information_schema.columns
                  where table_schema='public' and table_name='leave_requests' and column_name='request_no') then
    raise exception 'PREFLIGHT: ไม่พบ leave_requests.request_no — ต้องรัน R1 ก่อน';
  end if;
  if not exists (select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                  where n.nspname='public' and p.proname='njhr_leave_submit'
                    and pg_get_functiondef(p.oid) like '%njhr\_next\_request\_no%') then
    raise exception 'PREFLIGHT: njhr_leave_submit ยังไม่ออกเลข — ต้องรัน R2 ก่อน';
  end if;
  raise notice 'PREFLIGHT ผ่าน';
end $$;

begin;

drop function if exists public.njhr_leave_list(text, text, integer, integer);
CREATE OR REPLACE FUNCTION public.njhr_leave_list(p_token text, p_status text DEFAULT NULL::text, p_limit integer DEFAULT 20, p_offset integer DEFAULT 0)
 RETURNS TABLE(id uuid, leave_type text, start_date date, end_date date, leave_unit text, start_time time without time zone, end_time time without time zone, hours numeric, is_halfday boolean, total_days numeric, reason text, status text, ui_status text, created_at timestamp with time zone, file_name text, approvals jsonb, total_count bigint, request_no text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
#variable_conflict use_column
declare c record; lim int := least(greatest(coalesce(p_limit,20),1),100);
begin
  select * into c from public.njhr_ctx(p_token);
  if c.employee_id is null then
    raise exception 'บัญชีนี้ยังไม่ได้เชื่อมกับข้อมูลพนักงาน' using errcode='28000';
  end if;
  return query
  with base as (
    select r.* from public.leave_requests r
     where r.employee_id = c.employee_id
       and (p_status is null or p_status = '' or r.status::text = p_status)),
  cnt as (select count(*) n from base)
  select b.id, b.leave_type::text, b.start_date, b.end_date, b.leave_unit,
         b.start_time, b.end_time, b.hours, b.is_halfday, b.total_days,
         b.reason, b.status::text,
         -- สถานะที่ใช้แสดงผล: PENDING ที่ถูก "ขอข้อมูลเพิ่ม" ล่าสุด = NEED_MORE_INFO (เหมือน workflow เดิม)
         case when b.status = 'PENDING'
               and (select x->>'action' from jsonb_array_elements(coalesce(b.approvals,'[]'::jsonb)) x
                     order by (x->>'seq')::int desc limit 1) = 'INFO'
              then 'NEED_MORE_INFO' else b.status::text end,
         b.created_at,
         (select a.file_name from public.leave_attachments a
           where a.leave_id = b.id order by a.created_at limit 1),
         coalesce(b.approvals,'[]'::jsonb),
         (select n from cnt),
         b.request_no                              -- [R3] เลขที่คำขอ (null = คำขอเก่า)
    from base b
   order by b.created_at desc
   limit lim offset greatest(coalesce(p_offset,0),0);
end $function$;
revoke all on function public.njhr_leave_list(text, text, integer, integer) from public;
grant execute on function public.njhr_leave_list(text, text, integer, integer) to anon, authenticated;

drop function if exists public.njhr_leave_queue(text, integer, integer);
CREATE OR REPLACE FUNCTION public.njhr_leave_queue(p_token text, p_limit integer DEFAULT 40, p_offset integer DEFAULT 0)
 RETURNS TABLE(id uuid, employee_id uuid, emp_code text, emp_name text, department text, leave_type text, start_date date, end_date date, leave_unit text, start_time time without time zone, end_time time without time zone, hours numeric, is_halfday boolean, total_days numeric, reason text, status text, ui_status text, created_at timestamp with time zone, file_name text, remaining numeric, total_count bigint, request_no text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
#variable_conflict use_column
declare c record; lim int := least(greatest(coalesce(p_limit,40),1),200);
begin
  select * into c from public.njhr_ctx(p_token);
  if c.role not in ('SUPER_ADMIN','ADMIN','HR','MANAGER') then
    raise exception 'คุณไม่มีสิทธิ์อนุมัติรายการ' using errcode='42501';
  end if;
  return query
  with base as (select r.* from public.leave_requests r where r.status = 'PENDING'),
  cnt as (select count(*) n from base)
  select b.id, b.employee_id, e.emp_code,
         (coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,'')),
         e.department_name, b.leave_type::text, b.start_date, b.end_date, b.leave_unit,
         b.start_time, b.end_time, b.hours, b.is_halfday, b.total_days,
         b.reason, b.status::text,
         case when (select x->>'action' from jsonb_array_elements(coalesce(b.approvals,'[]'::jsonb)) x
                     order by (x->>'seq')::int desc limit 1) = 'INFO'
              then 'NEED_MORE_INFO' else b.status::text end,
         b.created_at,
         (select a.file_name from public.leave_attachments a
           where a.leave_id = b.id order by a.created_at limit 1),
         case when public.njhr_leave_quota(b.employee_id, b.leave_type::text) is null then null
              else round(public.njhr_leave_quota(b.employee_id, b.leave_type::text)
                   - coalesce((select sum(coalesce(r2.total_days,0)+coalesce(r2.hours,0)/8)
                                 from public.leave_requests r2
                                where r2.employee_id = b.employee_id
                                  and r2.leave_type = b.leave_type
                                  and r2.status in ('APPROVED','PENDING')
                                  and extract(year from r2.start_date) = extract(year from b.start_date)),0), 2) end,
         (select n from cnt),
         b.request_no                              -- [R3] เลขที่คำขอ
    from base b left join public.employees e on e.id = b.employee_id
   order by b.created_at asc
   limit lim offset greatest(coalesce(p_offset,0),0);
end $function$;
revoke all on function public.njhr_leave_queue(text, integer, integer) from public;
grant execute on function public.njhr_leave_queue(text, integer, integer) to anon, authenticated;

drop function if exists public.njhr_leave_detail(text, uuid);
CREATE OR REPLACE FUNCTION public.njhr_leave_detail(p_token text, p_leave_id uuid)
 RETURNS TABLE(id uuid, employee_id uuid, emp_name text, leave_type text, status text, ui_status text, approvals jsonb, attachments jsonb, request_no text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
#variable_conflict use_column
declare c record; r public.leave_requests;
begin
  select * into c from public.njhr_ctx(p_token);
  select * into r from public.leave_requests where leave_requests.id = p_leave_id;
  if not found then raise exception 'ไม่พบใบลานี้' using errcode='P0002'; end if;
  if c.role not in ('SUPER_ADMIN','ADMIN','HR','MANAGER') and r.employee_id is distinct from c.employee_id then
    raise exception 'คุณไม่มีสิทธิ์ดูใบลาของพนักงานคนอื่น' using errcode='42501';
  end if;
  return query
  select r.id, r.employee_id,
         (select coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,'')
            from public.employees e where e.id = r.employee_id),
         r.leave_type::text, r.status::text,
         case when r.status='PENDING'
               and (select x->>'action' from jsonb_array_elements(coalesce(r.approvals,'[]'::jsonb)) x
                     order by (x->>'seq')::int desc limit 1) = 'INFO'
              then 'NEED_MORE_INFO' else r.status::text end,
         coalesce(r.approvals,'[]'::jsonb),
         coalesce((select jsonb_agg(jsonb_build_object(
                     'name', a.file_name, 'url', a.file_url, 'size', a.file_size)
                   order by a.created_at)
                     from public.leave_attachments a where a.leave_id = r.id), '[]'::jsonb),
         r.request_no                              -- [R3] เลขที่คำขอ
  ;
end $function$;
revoke all on function public.njhr_leave_detail(text, uuid) from public;
grant execute on function public.njhr_leave_detail(text, uuid) to anon, authenticated;

drop function if exists public.njhr_ot_list(text, date, date, text, text, uuid, text, boolean, integer, integer);
CREATE OR REPLACE FUNCTION public.njhr_ot_list(p_token text, p_from date DEFAULT NULL::date, p_to date DEFAULT NULL::date, p_status text DEFAULT NULL::text, p_dept text DEFAULT NULL::text, p_employee uuid DEFAULT NULL::uuid, p_q text DEFAULT NULL::text, p_mine boolean DEFAULT false, p_limit integer DEFAULT 200, p_offset integer DEFAULT 0)
 RETURNS TABLE(id uuid, ot_date date, start_time time without time zone, end_time time without time zone, spans_next_day boolean, ot_hours numeric, reason text, status text, created_at timestamp with time zone, employee_id uuid, emp_code text, prefix text, emp_name text, nickname text, department text, position_name text, jobs_count integer, is_holiday boolean, files_count integer, total_count bigint, request_no text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
#variable_conflict use_column
declare c record; q text := lower(btrim(coalesce(p_q,''))); st text := upper(btrim(coalesce(p_status,'')));
        has_files boolean := to_regclass('public.njhr_ot_attachments') is not null;
begin
  select * into c from public.njhr_ot_guard(p_token);
  if st <> '' and st not in ('PENDING','APPROVED','REJECTED','CANCELLED') then
    raise exception 'สถานะคำขอไม่ถูกต้อง (%)', p_status using errcode='22023';
  end if;
  if not c.is_manager and c.employee_id is null then
    raise exception 'บัญชีนี้ยังไม่ได้เชื่อมกับข้อมูลพนักงาน' using errcode='28000';
  end if;
  return query
  with base as (
    select o.id oid, o.ot_date od, o.start_time ost, o.end_time oen, o.spans_next_day osp,
           o.ot_hours oh, o.reason orz, o.status::text ostat, o.created_at oca,
           o.request_no orq,                       -- [R3] เลขที่คำขอ
           e.id eid, e.emp_code ec, coalesce(e.prefix,'') epx,
           btrim(coalesce(e.first_name,'')||' '||coalesce(e.last_name,'')) enm,
           coalesce(e.nickname,'') enk, coalesce(e.department_name,'') edept,
           coalesce(e.position_name,'') epos,
           (select count(*)::int from public.njhr_ot_jobs j where j.ot_id = o.id) jc,
           public.njhr_ot_is_holiday(o.ot_date) hol,
           -- njhr_ot_attachments.ot_id อาจเป็น text หรือ uuid แล้วแต่ลำดับที่รัน 47/51 จึงเทียบแบบ text
           case when has_files then
             (select count(*)::int from public.njhr_ot_attachments a where a.ot_id::text = o.id::text)
             else 0 end fc
      from public.ot_requests o
      join public.employees e on e.id = o.employee_id
     where (p_from is null or o.ot_date >= p_from)
       and (p_to is null or o.ot_date <= p_to)
       -- พนักงานทั่วไปเห็นเฉพาะของตนเอง · ผู้ดูแลขอดูเฉพาะของตนเองได้ด้วย p_mine
       and (case when coalesce(p_mine,false) or not c.is_manager
                 then o.employee_id = c.employee_id else true end)
       and (st = '' or o.status::text = st)
       and (p_dept is null or p_dept = '' or e.department_name = p_dept)
       and (p_employee is null or o.employee_id = p_employee)
       and (q = '' or lower(coalesce(e.emp_code,'')) like '%'||q||'%'
            or lower(coalesce(e.first_name,'')||' '||coalesce(e.last_name,'')) like '%'||q||'%'
            or lower(coalesce(e.prefix,'')||coalesce(e.first_name,'')||' '||coalesce(e.last_name,'')) like '%'||q||'%'
            or lower(coalesce(e.nickname,'')) like '%'||q||'%'
            or exists (select 1 from public.njhr_ot_jobs j
                        where j.ot_id = o.id and lower(j.job_code) like '%'||q||'%')))
  select b.oid, b.od, b.ost, b.oen, b.osp, b.oh, b.orz, b.ostat, b.oca,
         b.eid, b.ec, b.epx, b.enm, b.enk, b.edept, b.epos,
         b.jc, b.hol, b.fc, (select count(*) from base), b.orq
    from base b order by b.od desc, b.oca desc
   limit least(greatest(coalesce(p_limit,200),1),1000) offset greatest(coalesce(p_offset,0),0);
end $function$;
revoke all on function public.njhr_ot_list(text, date, date, text, text, uuid, text, boolean, integer, integer) from public;
grant execute on function public.njhr_ot_list(text, date, date, text, text, uuid, text, boolean, integer, integer) to anon, authenticated;

drop function if exists public.njhr_report_all_ot(text, date, date, text, uuid);
CREATE OR REPLACE FUNCTION public.njhr_report_all_ot(p_token text, p_from date DEFAULT NULL::date, p_to date DEFAULT NULL::date, p_dept text DEFAULT NULL::text, p_employee uuid DEFAULT NULL::uuid)
 RETURNS TABLE(id uuid, ot_date date, start_time time without time zone, end_time time without time zone, spans_next_day boolean, ot_hours numeric, status text, employee_id uuid, emp_code text, prefix text, emp_name text, department text, position_name text, approver_name text, request_no text)
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
#variable_conflict use_column
declare c record;
begin
  -- สิทธิ์เดียวกับ njhr_ot_list ทุกประการ (ไม่สร้าง Guard ใหม่)
  select * into c from public.njhr_ot_guard(p_token);

  return query
  select o.id, o.ot_date, o.start_time, o.end_time, o.spans_next_day,
         o.ot_hours, o.status::text,
         o.employee_id, e.emp_code, e.prefix,
         btrim(coalesce(e.first_name, '') || ' ' || coalesce(e.last_name, '')),
         e.department_name, e.position_name,
         /* ผู้อนุมัติจริง: เฉพาะ element ที่ action = 'APPROVE'
            เรียงตาม ordinality = ลำดับขั้นการอนุมัติจริง
            ตัดชื่อซ้ำออกโดยคงลำดับแรกที่พบ · ไม่มีเลย = '—' */
         coalesce(nullif((
           select string_agg(nm, ', ' order by ord)
             from (select min(a.ord) as ord,
                          public.njhr_user_display(a.el->>'by') as nm
                     from jsonb_array_elements(coalesce(o.approvals, '[]'::jsonb))
                          with ordinality as a(el, ord)
                    where upper(coalesce(a.el->>'action', '')) = 'APPROVE'
                      and nullif(btrim(coalesce(a.el->>'by', '')), '') is not null
                    group by public.njhr_user_display(a.el->>'by')) s
         ), ''), '—'),
         o.request_no                              -- [R3] เลขที่คำขอ
    from public.ot_requests o
    join public.employees e on e.id = o.employee_id
   where o.status::text = 'APPROVED'
     and (p_from is null or o.ot_date >= p_from)
     and (p_to   is null or o.ot_date <= p_to)
     and (p_dept is null or e.department_name = p_dept)
     and (p_employee is null or o.employee_id = p_employee)
     /* ขอบเขตการมองเห็นเดียวกับ njhr_ot_list: ผู้ที่ไม่ใช่ผู้อนุมัติเห็นเฉพาะของตนเอง */
     and (c.can_approve or o.employee_id = c.employee_id)
   order by e.emp_code, o.ot_date;
end $function$;
revoke all on function public.njhr_report_all_ot(text, date, date, text, uuid) from public;
grant execute on function public.njhr_report_all_ot(text, date, date, text, uuid) to anon, authenticated;

insert into public.njhr_schema_version(version, note)
values ('v3.3-request-no-expose', 'เพิ่ม request_no ใน returns ของ 5 RPC เพื่อแสดงทุกหน้า')
on conflict (version) do nothing;

commit;

-- ═══ VERIFICATION ═══
select jsonb_pretty(jsonb_object_agg(p.proname, jsonb_build_object(
  'has_request_no', pg_get_function_result(p.oid)::text like '%request_no text%',
  'args', pg_get_function_identity_arguments(p.oid)::text,
  'grants', (select coalesce(jsonb_agg(distinct grantee::text order by grantee::text), '[]'::jsonb)
               from information_schema.routine_privileges rp
              where rp.specific_schema='public' and rp.specific_name = p.proname || '_' || p.oid
                and grantee::text in ('anon','authenticated'))
))) as r3_verification
  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
 where n.nspname='public'
   and p.proname in ('njhr_leave_list','njhr_leave_queue','njhr_leave_detail',
                     'njhr_ot_list','njhr_report_all_ot');

-- ═══ ROLLBACK ═══
-- นำ pg_get_functiondef ของทั้ง 5 ตัวก่อนรันไฟล์นี้กลับมา drop + create
-- (สำเนาอยู่ในบทสนทนา) แล้ว grant to anon, authenticated ใหม่ทุกตัว
-- delete from public.njhr_schema_version where version = 'v3.3-request-no-expose';
