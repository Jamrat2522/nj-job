-- ============================================================
-- NJ HR V2 — R2_request_no_submit.sql  (ส่วนที่ 2: ออกเลขตอนบันทึก)
--
-- แทรกการออกเลข YYMMDD-0001 เข้า njhr_leave_submit และ njhr_ot_submit
-- เนื้อฟังก์ชันคัดลอกจาก pg_get_functiondef ของ Production ทุกบรรทัด
-- แก้เพียง 3 จุดต่อฟังก์ชัน:
--   1) ประกาศตัวแปร v_no text
--   2) เรียก v_no := public.njhr_next_request_no('LEAVE'|'OT') ก่อน insert
--   3) เพิ่มคอลัมน์ request_no ใน insert
--
-- ไม่เปลี่ยน signature · ไม่เปลี่ยน RETURNS TABLE จึงไม่ต้อง DROP
-- ไม่แตะ Validation · Workflow · การแจ้งเตือน · Audit · โควตา · การทับช่วง
--
-- เส้นทาง client_key (กันกดส่งซ้ำ 10 นาที) คืนใบเดิมก่อนถึงจุดออกเลข
-- กดซ้ำด้วย key เดิมจึงไม่สร้างเลขใหม่ ตามข้อกำหนด
--
-- ต้องรัน R1_request_no.sql มาก่อน · รันซ้ำได้
-- ============================================================

do $$
begin
  if not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                  where n.nspname='public' and p.proname='njhr_next_request_no') then
    raise exception 'PREFLIGHT: ไม่พบ njhr_next_request_no — ต้องรัน R1 ก่อน';
  end if;
  if not exists (select 1 from information_schema.columns
                  where table_schema='public' and table_name='leave_requests' and column_name='request_no') then
    raise exception 'PREFLIGHT: leave_requests ไม่มีคอลัมน์ request_no';
  end if;
  if not exists (select 1 from information_schema.columns
                  where table_schema='public' and table_name='ot_requests' and column_name='request_no') then
    raise exception 'PREFLIGHT: ot_requests ไม่มีคอลัมน์ request_no';
  end if;
  raise notice 'PREFLIGHT ผ่าน';
end $$;


CREATE OR REPLACE FUNCTION public.njhr_leave_submit(
  p_token text, p_leave_type text, p_mode text,
  p_start_date date, p_end_date date,
  p_start_time time without time zone DEFAULT NULL::time without time zone,
  p_end_time time without time zone DEFAULT NULL::time without time zone,
  p_reason text DEFAULT ''::text, p_delegate uuid DEFAULT NULL::uuid,
  p_files jsonb DEFAULT NULL::jsonb, p_client_key text DEFAULT NULL::text)
RETURNS TABLE(id uuid, total_days numeric, hours numeric, duplicated boolean, file_count integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
#variable_conflict use_column
declare
  c record; v_type public.leave_type; v_end date; v_days numeric := 0; v_hours numeric := 0;
  v_unit text; v_half boolean := false; v_quota numeric; v_usedpend numeric; v_id uuid; v_dup uuid;
  v_files jsonb := coalesce(p_files, '[]'::jsonb); v_n int := 0; f jsonb;
  v_no text;
begin
  select * into c from public.njhr_ctx(p_token);
  if c.employee_id is null then
    raise exception 'บัญชีนี้ยังไม่ได้เชื่อมกับข้อมูลพนักงาน' using errcode='28000';
  end if;
  if jsonb_typeof(v_files) <> 'array' then
    raise exception 'รูปแบบไฟล์แนบไม่ถูกต้อง' using errcode='22023';
  end if;

  -- กันกดส่งซ้ำ: key เดิมภายใน 10 นาที = คืนใบเดิม ไม่สร้างซ้ำ
  if p_client_key is not null and p_client_key <> '' then
    select r.id into v_dup from public.leave_requests r
     where r.employee_id = c.employee_id
       and r.created_at > now() - interval '10 minutes'
       and r.approvals->0->'meta'->>'client_key' = p_client_key
     limit 1;
    if v_dup is not null then
      return query select v_dup, r.total_days, r.hours, true,
                          (select count(*)::int from public.leave_attachments a where a.leave_id = v_dup)
                     from public.leave_requests r where r.id = v_dup;
      return;
    end if;
  end if;

  begin v_type := upper(p_leave_type)::public.leave_type;
  exception when others then
    raise exception 'ประเภทการลาไม่ถูกต้อง (%)', p_leave_type using errcode='22023';
  end;

  if coalesce(btrim(p_reason),'') = '' then
    raise exception 'กรุณาระบุเหตุผลการลา' using errcode='22023';
  end if;

  v_end := case when upper(p_mode) = 'FULL' then p_end_date else p_start_date end;
  if p_start_date > v_end then
    raise exception 'วันที่เริ่มต้องไม่มากกว่าวันที่สิ้นสุด' using errcode='22023';
  end if;

  if upper(p_mode) = 'FULL' then
    v_unit := 'day';  v_days := public.njhr_leave_workdays(p_start_date, v_end);
    if v_days <= 0 then
      raise exception 'ช่วงวันที่เลือกไม่มีวันทำงาน (ตรงกับวันหยุด)' using errcode='22023';
    end if;
  elsif upper(p_mode) in ('HALF_AM','HALF_PM') then
    v_unit := 'halfday'; v_half := true;
    v_days := case when public.njhr_leave_workdays(p_start_date, p_start_date) > 0 then 0.5 else 0 end;
    if v_days <= 0 then
      raise exception 'ช่วงวันที่เลือกไม่มีวันทำงาน (ตรงกับวันหยุด)' using errcode='22023';
    end if;
  elsif upper(p_mode) = 'HOURLY' then
    v_unit := 'hour';
    if p_start_time is null or p_end_time is null or p_end_time <= p_start_time then
      raise exception 'เวลาสิ้นสุดต้องมากกว่าเวลาเริ่ม' using errcode='22023';
    end if;
    v_hours := round(extract(epoch from (p_end_time - p_start_time))/3600.0, 2);
  else
    raise exception 'รูปแบบการลาไม่ถูกต้อง (%)', p_mode using errcode='22023';
  end if;

  -- ห้ามทับช่วงกับใบที่ยังมีผล
  if exists (select 1 from public.leave_requests r
              where r.employee_id = c.employee_id
                and r.status in ('PENDING','APPROVED')
                and p_start_date <= r.end_date and r.start_date <= v_end) then
    raise exception 'ช่วงวันที่นี้ทับกับคำขอลาเดิมที่ยังมีผลอยู่' using errcode='23505';
  end if;

  -- โควตา: ตรวจเฉพาะประเภทที่มีโควตาจริงใน employees
  v_quota := public.njhr_leave_quota(c.employee_id, v_type::text);
  if v_quota is not null then
    select coalesce(sum(coalesce(r.total_days,0)+coalesce(r.hours,0)/8),0) into v_usedpend
      from public.leave_requests r
     where r.employee_id = c.employee_id and r.leave_type = v_type
       and r.status in ('APPROVED','PENDING')
       and extract(year from r.start_date) = extract(year from p_start_date);
    if v_quota - v_usedpend < v_days + v_hours/8 then
      raise exception 'วันลาคงเหลือไม่เพียงพอ (คงเหลือ % วัน)', round(v_quota - v_usedpend, 2)
        using errcode='23514';
    end if;
  end if;

  -- ตรวจไฟล์แนบ: ต้องมี name และ url จริงทุกไฟล์
  for f in select * from jsonb_array_elements(v_files) loop
    if coalesce(f->>'name','') = '' or coalesce(f->>'url','') = '' then
      raise exception 'ข้อมูลไฟล์แนบไม่ครบ (ต้องมีชื่อไฟล์และที่อยู่ไฟล์)' using errcode='22023';
    end if;
    v_n := v_n + 1;
  end loop;

  -- [P1] กฎ "ลาป่วยต้องแนบเอกสาร" ถูกถอดออกตามข้อกำหนดใหม่ — ไฟล์แนบเป็นตัวเลือกทุกประเภท
  --      เดิม: if v_type = 'SICK' and v_n = 0 then raise exception ... end if;
  --      ไม่แตะ Validation อื่นและไม่แตะ Workflow ใด ๆ

  /* [R2] ออกเลขที่คำขอ YYMMDD-0001 ในธุรกรรมเดียวกับการบันทึกใบลา
     ออกหลังผ่าน Validation ครบทุกข้อ และหลังเส้นทาง client_key แล้ว
     ถ้า insert ล้ม เลขรันถูก Rollback ไปด้วย จึงไม่ขาด */
  v_no := public.njhr_next_request_no('LEAVE');

  insert into public.leave_requests(
    employee_id, leave_type, start_date, end_date, leave_unit,
    start_time, end_time, hours, is_halfday, total_days, reason, status, approvals, request_no)
  values (c.employee_id, v_type, p_start_date, v_end, v_unit,
    case when v_unit='hour' then p_start_time end,
    case when v_unit='hour' then p_end_time end,
    v_hours, v_half, v_days, btrim(p_reason), 'PENDING',
    jsonb_build_array(jsonb_build_object(
      'seq', 1, 'at', to_char(now() at time zone 'Asia/Bangkok','YYYY-MM-DD HH24:MI'),
      'by', c.app_user_id, 'by_name', coalesce(c.emp_name, c.username),
      'action', 'SUBMIT', 'note', '',
      'meta', jsonb_build_object('mode', upper(p_mode), 'delegate', p_delegate,
                                 'client_key', coalesce(p_client_key,'')))), v_no)
  returning leave_requests.id into v_id;

  -- แนบไฟล์ทั้งหมดในธุรกรรมเดียวกับใบลา (สำเร็จทั้งหมดหรือไม่สำเร็จเลย)
  if v_n > 0 then
    insert into public.leave_attachments(leave_id, file_name, file_url, file_size)
    select v_id, x->>'name', x->>'url', nullif(x->>'size','')::int
      from jsonb_array_elements(v_files) x;
  end if;

  insert into public.notifications(user_id, title, body, icon)
  select a.id, 'คำขอลาใหม่',
         coalesce(c.emp_name, c.username) || ' ขอลา ' ||
         case when v_unit='hour' then v_hours || ' ชม.' else v_days || ' วัน' end,
         'leave'
    from public.app_users a
   where a.app_code = 'salary' and coalesce(a.is_active,true)
     and public.njhr_norm_role(a.role::text) in ('SUPER_ADMIN','ADMIN','HR','MANAGER');

  perform public.njhr_leave_audit(c.username, 'LEAVE_REQ', v_id,
    'ส่งใบลา ' || v_type::text || ' ' || p_start_date || ' ถึง ' || v_end ||
    ' (ไฟล์แนบ ' || v_n || ' ไฟล์)');

  return query select v_id, v_days, v_hours, false, v_n;
end $function$;


CREATE OR REPLACE FUNCTION public.njhr_ot_submit(
  p_token text, p_date date, p_start time without time zone,
  p_end time without time zone, p_next_day boolean, p_jobs jsonb,
  p_reason text DEFAULT NULL::text)
RETURNS TABLE(id uuid, ot_date date, ot_hours numeric, jobs_count integer, status text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
#variable_conflict use_column
declare c record; e record; v_id uuid; r jsonb; i int := 0; n int;
        v_mins int; v_hours numeric; v_per numeric; v_used numeric := 0; v_h numeric;
        v_no text;
begin
  select * into c from public.njhr_ot_guard(p_token);
  if c.employee_id is null then
    raise exception 'บัญชีนี้ยังไม่ได้เชื่อมกับข้อมูลพนักงาน จึงขอ OT ไม่ได้' using errcode='28000';
  end if;
  if p_date is null then raise exception 'กรุณาเลือกวันที่' using errcode='22023'; end if;
  if p_start is null or p_end is null then
    raise exception 'กรุณาระบุเวลาเริ่มและเวลาสิ้นสุด' using errcode='22023';
  end if;
  v_mins := (extract(epoch from p_end) - extract(epoch from p_start))::int / 60
            + (case when coalesce(p_next_day,false) then 24 * 60 else 0 end);
  if v_mins <= 0 then
    raise exception 'เวลาสิ้นสุดต้องมากกว่าเวลาเริ่มต้น หรือเลือก "สิ้นสุดวัน = วันถัดไป"' using errcode='22023';
  end if;
  if v_mins > 24 * 60 then
    raise exception 'ช่วงเวลา OT ยาวเกิน 24 ชั่วโมง' using errcode='22023';
  end if;
  if p_jobs is null or jsonb_typeof(p_jobs) <> 'array' or jsonb_array_length(p_jobs) = 0 then
    raise exception 'กรุณาเพิ่มรายการงาน OT อย่างน้อย 1 รายการ' using errcode='22023';
  end if;
  n := jsonb_array_length(p_jobs);
  if n > 50 then raise exception 'เพิ่มรายการงานได้ไม่เกิน 50 รายการต่อคำขอ' using errcode='22023'; end if;

  -- ตรวจข้อมูลบังคับของทุกรายการก่อน แล้วค่อยบันทึก
  for r in select * from jsonb_array_elements(p_jobs) loop
    i := i + 1;
    if coalesce(btrim(r->>'job_code'),'') = '' then
      raise exception 'รายการที่ %: กรุณาระบุเลข JOB', i using errcode='22023'; end if;
    if coalesce(btrim(r->>'detail'),'') = '' then
      raise exception 'รายการที่ %: กรุณาระบุรายละเอียดงาน', i using errcode='22023'; end if;
    if coalesce(btrim(r->>'job_type'),'') = '' then
      raise exception 'รายการที่ %: กรุณาเลือกประเภทงาน', i using errcode='22023'; end if;
  end loop;

  -- ทับช่วงเวลากับคำขอที่ยังมีผลของคนเดียวกัน
  if exists (
    select 1 from public.ot_requests o
     where o.employee_id = c.employee_id
       and o.status in ('PENDING','APPROVED')
       and o.ot_date = p_date
       and tstzrange(
             (o.ot_date::text || ' ' || o.start_time::text)::timestamptz,
             ((o.ot_date + (case when o.spans_next_day then 1 else 0 end))::text || ' ' || o.end_time::text)::timestamptz)
           && tstzrange(
             (p_date::text || ' ' || p_start::text)::timestamptz,
             ((p_date + (case when coalesce(p_next_day,false) then 1 else 0 end))::text || ' ' || p_end::text)::timestamptz)
  ) then
    raise exception 'ช่วงเวลานี้ทับกับคำขอ OT ที่ยังมีผลอยู่' using errcode='22023';
  end if;

  select * into e from public.employees where id = c.employee_id;
  v_hours := round((v_mins / 60.0)::numeric, 2);

  /* [R2] ออกเลขที่คำขอ YYMMDD-0001 ในธุรกรรมเดียวกับการบันทึก OT
     ออกหลังผ่าน Validation ครบทุกข้อ ถ้า insert ล้ม เลขรันถูก Rollback ไปด้วย */
  v_no := public.njhr_next_request_no('OT');

  insert into public.ot_requests (employee_id, ot_date, start_time, end_time,
                                  ot_hours, reason, status, spans_next_day, request_no)
  values (c.employee_id, p_date, p_start, p_end, v_hours,
          nullif(btrim(coalesce(p_reason,'')),''), 'PENDING', coalesce(p_next_day,false), v_no)
  returning ot_requests.id into v_id;

  -- ชั่วโมงหารเฉลี่ยลงแต่ละรายการงาน รายการสุดท้ายรับเศษ ผลรวมจึงเท่ากับช่วงเวลาจริงพอดี
  v_per := round((v_hours / n)::numeric, 2);
  i := 0;
  for r in select * from jsonb_array_elements(p_jobs) loop
    i := i + 1;
    v_h := case when i = n then round((v_hours - v_used)::numeric, 2) else v_per end;
    v_used := v_used + v_h;
    insert into public.njhr_ot_jobs (
      ot_id, job_no, job_code, detail, job_type, job_date, start_time, end_time,
      spans_next_day, ot_hours, dept_snap, position_snap, note, created_by, updated_by)
    values (v_id, i, btrim(r->>'job_code'), btrim(r->>'detail'), btrim(r->>'job_type'),
            p_date, p_start, p_end, coalesce(p_next_day,false), v_h,
            e.department_name, e.position_name,
            nullif(btrim(coalesce(r->>'note','')),''), c.username, c.username);
  end loop;

  perform public.njhr_audit_write(p_token, 'OT_REQ', 'ot', 'ot_requests', v_id::text,
    'ส่งคำขอ OT ' || to_char(p_date,'DD/MM/YYYY') || ' ' || p_start::text || '–' || p_end::text ||
    ' · ' || n || ' รายการ · ' || v_hours || ' ชม.', null, null, null);

  -- แจ้งผู้อนุมัติผ่านตาราง notifications เดิม
  insert into public.notifications(user_id, title, body, icon)
  select u.id, 'คำขอ OT ใหม่',
         coalesce(btrim(coalesce(e.first_name,'') || ' ' || coalesce(e.last_name,'')), c.username) ||
         ' ขอ OT ' || v_hours || ' ชม. (' || n || ' รายการ)', 'timer'
    from public.app_users u
   where u.app_code = 'salary' and coalesce(u.is_active,true)
     and public.njhr_norm_role(u.role::text) in ('SUPER_ADMIN','ADMIN','HR','MANAGER');

  return query select o.id, o.ot_date, o.ot_hours, n, o.status::text
                 from public.ot_requests o where o.id = v_id;
end $function$;

insert into public.njhr_schema_version(version, note)
values ('v3.2-request-no-submit', 'ออกเลข YYMMDD-0001 ใน njhr_leave_submit และ njhr_ot_submit')
on conflict (version) do nothing;

-- ═══ VERIFICATION ═══
select jsonb_pretty(jsonb_build_object(
  'leave_signature', (select pg_get_function_identity_arguments(p.oid)::text from pg_proc p
     join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname='njhr_leave_submit'),
  'leave_returns', (select pg_get_function_result(p.oid)::text from pg_proc p
     join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname='njhr_leave_submit'),
  'ot_signature', (select pg_get_function_identity_arguments(p.oid)::text from pg_proc p
     join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname='njhr_ot_submit'),
  'ot_returns', (select pg_get_function_result(p.oid)::text from pg_proc p
     join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname='njhr_ot_submit'),
  -- ต้องเป็น true ทั้งคู่: มีการออกเลขแล้ว
  'leave_issues_no', (select pg_get_functiondef(p.oid) like '%njhr\_next\_request\_no%'
     from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname='njhr_leave_submit'),
  'ot_issues_no', (select pg_get_functiondef(p.oid) like '%njhr\_next\_request\_no%'
     from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname='njhr_ot_submit'),
  -- Validation เดิมต้องยังอยู่ครบ
  'leave_keeps', jsonb_build_object(
    'reason', (select pg_get_functiondef(p.oid) like '%กรุณาระบุเหตุผลการลา%' from pg_proc p
       join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='njhr_leave_submit'),
    'quota', (select pg_get_functiondef(p.oid) like '%วันลาคงเหลือไม่เพียงพอ%' from pg_proc p
       join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='njhr_leave_submit'),
    'overlap', (select pg_get_functiondef(p.oid) like '%ทับกับคำขอลาเดิม%' from pg_proc p
       join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='njhr_leave_submit'),
    'client_key', (select pg_get_functiondef(p.oid) like '%client_key%' from pg_proc p
       join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='njhr_leave_submit'),
    'sick_doc_removed', (select pg_get_functiondef(p.oid) not like '%ลาป่วยต้องแนบเอกสารประกอบ%' from pg_proc p
       join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='njhr_leave_submit')),
  'ot_keeps', jsonb_build_object(
    'jobs_required', (select pg_get_functiondef(p.oid) like '%อย่างน้อย 1 รายการ%' from pg_proc p
       join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='njhr_ot_submit'),
    'overlap', (select pg_get_functiondef(p.oid) like '%ทับกับคำขอ OT%' from pg_proc p
       join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='njhr_ot_submit'),
    'audit', (select pg_get_functiondef(p.oid) like '%njhr\_audit\_write%' from pg_proc p
       join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='njhr_ot_submit')),
  'seq_state', (select coalesce(jsonb_agg(jsonb_build_object('kind',kind,'ym',ym,'last_no',last_no)
     order by kind, ym), '[]'::jsonb) from public.njhr_request_seq),
  'leave_rows', (select count(*) from public.leave_requests),
  'ot_rows', (select count(*) from public.ot_requests)
)) as r2_verification;

-- ═══ ROLLBACK ═══
-- นำ pg_get_functiondef ของทั้งสองฟังก์ชันก่อนรันไฟล์นี้กลับมา create or replace
-- (สำเนาอยู่ในบทสนทนา / rollback/ ของโปรเจกต์)
-- delete from public.njhr_schema_version where version = 'v3.2-request-no-submit';
