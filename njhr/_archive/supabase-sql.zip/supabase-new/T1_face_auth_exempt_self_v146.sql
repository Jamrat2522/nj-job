-- NJ HR v14.6 — Production sync for the three verified flows
-- 1) Executive exemption is resolved from the current NJHR session only.
-- 2) Face Login enable/disable password verification resolves pgcrypto from extensions schema.
-- 3) Face self re-enroll password verification resolves pgcrypto from extensions schema.

create or replace function public.njhr_hr_exempt_me(p_token text)
returns boolean
language plpgsql
stable
security definer
set search_path = public
as $function$
declare c record;
begin
  select * into c from public.njhr_ctx(p_token);
  if c.employee_id is null then return false; end if;
  return public.njhr_hr_exempt_employee(c.employee_id);
end
$function$;
revoke all on function public.njhr_hr_exempt_me(text) from public;
grant execute on function public.njhr_hr_exempt_me(text) to anon, authenticated, service_role;

create or replace function public.njhr_face_login_set(p_token text,p_password text,p_enable boolean)
returns table(face_login_enabled boolean,message text)
language plpgsql security definer set search_path=public as $function$
#variable_conflict use_column
declare c record; u public.app_users; ok boolean:=false;
begin
  select * into c from public.njhr_face_guard(p_token,false);
  select a.* into u from public.app_users a where a.id=c.app_user_id;
  if not found then raise exception 'ไม่พบบัญชีผู้ใช้นี้' using errcode='28000'; end if;
  if u.password_hash is not null and u.password_hash like '$2%' then
    ok := (u.password_hash = extensions.crypt(p_password,u.password_hash));
  elsif u.password is not null and u.password<>'' then
    ok := (u.password=p_password);
  end if;
  if not ok then raise exception 'รหัสผ่านไม่ถูกต้อง' using errcode='28P01'; end if;
  if p_enable then
    if c.employee_id is null then raise exception 'บัญชีนี้ยังไม่ได้ผูกกับข้อมูลพนักงาน' using errcode='22023'; end if;
    if not exists(select 1 from public.njhr_emp_faces f where f.employee_id=c.employee_id and f.is_active) then
      raise exception 'ยังไม่ได้ลงทะเบียนใบหน้า กรุณาลงทะเบียนใบหน้าก่อนเปิดใช้งาน' using errcode='22023';
    end if;
  end if;
  update public.app_users a set face_login_enabled=p_enable,face_login_set_at=now() where a.id=u.id;
  begin
    perform public.njhr_audit_write(p_token,case when p_enable then 'FACE_LOGIN_ENABLE' else 'FACE_LOGIN_DISABLE' end,
      'security','app_users',u.id::text,case when p_enable then 'เปิดการเข้าสู่ระบบด้วยใบหน้า' else 'ปิดการเข้าสู่ระบบด้วยใบหน้า' end,null,null,null);
  exception when undefined_function then null; end;
  return query select p_enable,(case when p_enable then 'เปิดการเข้าสู่ระบบด้วยใบหน้าแล้ว' else 'ปิดการเข้าสู่ระบบด้วยใบหน้าแล้ว' end)::text;
end $function$;
revoke all on function public.njhr_face_login_set(text,text,boolean) from public;
grant execute on function public.njhr_face_login_set(text,text,boolean) to anon, authenticated, service_role;

create or replace function public.njhr_face_self_reenroll(
  p_token text,p_password text,p_descriptors jsonb,p_quality jsonb default '{}'::jsonb,p_snapshot text default null)
returns table(employee_id uuid,sample_count int,enrolled_at timestamptz)
language plpgsql security definer set search_path=public as $function$
#variable_conflict use_column
declare c record; u public.app_users; e record; ok boolean:=false; v_n int; v_len int; v_need int; v_emp uuid;
begin
  select * into c from public.njhr_face_guard(p_token,false);
  v_emp:=c.employee_id;
  if v_emp is null then raise exception 'บัญชีนี้ยังไม่ได้ผูกกับพนักงาน' using errcode='22023'; end if;
  select a.* into u from public.app_users a where a.id=c.app_user_id;
  if not found then raise exception 'ไม่พบบัญชีผู้ใช้นี้' using errcode='28000'; end if;
  if u.password_hash is not null and u.password_hash like '$2%' then
    ok:=(u.password_hash=extensions.crypt(p_password,u.password_hash));
  elsif u.password is not null and u.password<>'' then
    ok:=(u.password=p_password);
  end if;
  if not ok then raise exception 'รหัสผ่านไม่ถูกต้อง' using errcode='28P01'; end if;
  select * into e from public.employees where id=v_emp;
  if not found then raise exception 'ไม่พบข้อมูลพนักงานของบัญชีนี้' using errcode='P0002'; end if;
  if e.status::text not in('ACTIVE','PROBATION') then raise exception 'ลงทะเบียนใบหน้าได้เฉพาะพนักงานที่ปฏิบัติงานอยู่' using errcode='22023'; end if;
  if not exists(select 1 from public.njhr_emp_faces f where f.employee_id=v_emp) then raise exception 'ยังไม่มีใบหน้าต้นแบบ กรุณาใช้การลงทะเบียนครั้งแรก' using errcode='22023'; end if;
  if p_descriptors is null or jsonb_typeof(p_descriptors)<>'array' then raise exception 'ข้อมูลใบหน้าไม่ถูกต้อง' using errcode='22023'; end if;
  v_n:=jsonb_array_length(p_descriptors);
  v_need:=coalesce((select (s.value)::text::int from public.system_settings s where s.key='face_enroll_samples'),3);
  if v_n<v_need then raise exception 'ต้องเก็บใบหน้าอย่างน้อย % มุม (ได้ % มุม)',v_need,v_n using errcode='22023'; end if;
  select jsonb_array_length(p_descriptors->0) into v_len;
  if coalesce(v_len,0)<64 then raise exception 'เวกเตอร์ใบหน้าสั้นผิดปกติ (% ค่า)',coalesce(v_len,0) using errcode='22023'; end if;
  if exists(select 1 from jsonb_array_elements(p_descriptors)d where jsonb_array_length(d)<>v_len) then raise exception 'เวกเตอร์ใบหน้าแต่ละมุมมีความยาวไม่เท่ากัน' using errcode='22023'; end if;
  update public.njhr_emp_faces f set descriptors=p_descriptors,descriptor_len=v_len,sample_count=v_n,quality=coalesce(p_quality,'{}'::jsonb),
    enroll_snapshot=coalesce(nullif(btrim(coalesce(p_snapshot,'')),''),f.enroll_snapshot),is_active=true,enrolled_at=now(),enrolled_by=c.username,updated_at=now(),updated_by=c.username
    where f.employee_id=v_emp;
  begin
    insert into public.njhr_emp_face_events(employee_id,action,detail,actor)
    values(v_emp,'RE_ENROLL',coalesce(e.emp_code,'-')||' · '||v_n||' มุม · พนักงานทำเองจากมือถือ',c.username);
  exception when undefined_table then null; end;
  begin
    perform public.njhr_audit_write(p_token,'FACE_SELF_RE_ENROLL','attendance','njhr_emp_faces',v_emp::text,
      'พนักงานลงทะเบียนใบหน้าต้นแบบใหม่ด้วยตนเอง · '||v_n::text||' มุม · '||coalesce(e.emp_code,'-'),null,null,null);
  exception when undefined_function then null; end;
  return query select f.employee_id,f.sample_count,f.enrolled_at from public.njhr_emp_faces f where f.employee_id=v_emp;
end $function$;
revoke all on function public.njhr_face_self_reenroll(text,text,jsonb,jsonb,text) from public;
grant execute on function public.njhr_face_self_reenroll(text,text,jsonb,jsonb,text) to anon, authenticated, service_role;
