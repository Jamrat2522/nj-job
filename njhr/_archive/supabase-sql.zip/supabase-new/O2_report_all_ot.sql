-- ============================================================
-- NJ HR V2 — O2_report_all_ot.sql
-- RPC เฉพาะ REPORT ALL: njhr_report_all_ot
--
-- ปัญหาที่แก้:
--   คอลัมน์ "ผู้อนุมัติ OT" (AK) ในไฟล์ REPORT ALL ว่างเปล่ามาตลอด เพราะ
--     1) njhr_ot_list คืน 20 คอลัมน์ ไม่มี approver / approver_name / approvals / timeline
--        (ยืนยันจาก pg_get_function_result บน Production)
--     2) ตัวแปลงฝั่งหน้าเว็บเขียน `approver: o.approver || ''` โดยที่ o.approver ไม่เคยมี
--     3) โค้ดที่ใช้ค่าอ่านจาก o.timeline ซึ่ง "ไม่มีคอลัมน์นี้ในฐานข้อมูลเลย"
--        (ยืนยันจาก information_schema.columns ของ ot_requests)
--
-- ไฟล์นี้:
--   · ไม่แก้ njhr_ot_list แม้แต่บรรทัดเดียว — หน้าคำขอ / หน้าอนุมัติ / หน้า OT ไม่กระทบ
--   · ไม่แก้ njhr_ot_decide · ไม่แก้ตาราง · ไม่แตะข้อมูล · ไม่แตะ RLS
--   · เพิ่ม RPC ใหม่ 1 ตัวที่ใช้เฉพาะ REPORT ALL
--   · ใช้ njhr_ot_guard(p_token) ตัวเดียวกับ njhr_ot_list จึงได้สิทธิ์เท่าเดิมทุกประการ
--
-- แหล่งชื่อผู้อนุมัติ (ตรวจจาก Production แล้ว ไม่ได้เดา):
--   njhr_ot_decide เขียน ot_requests.approvals (jsonb) ต่อท้ายทุกครั้งที่มีการตัดสิน
--     jsonb_build_object('at', now(), 'by', c.username, 'role', c.role,
--                        'action', v_act, 'note', ...)
--   ลำดับใน array = ลำดับขั้นการอนุมัติจริง · action แยก APPROVE / REJECT / CANCEL
--   'by' เก็บ app_users.username จึง join กลับหา app_users.full_name (มีจริง ตรวจแล้ว)
--   ถ้า full_name ว่าง ถอยไปประกอบชื่อจาก employees ผ่าน app_users.employee_id
--
--   ไม่ใช้ ot_requests.approver_id เป็นแหล่งหลัก เพราะเก็บได้คนเดียว (คนที่กดล่าสุด)
--   ไม่รองรับ "หลายขั้นให้รวมชื่อตามลำดับ" ตามข้อกำหนด
--   ไม่ใช้ตาราง njhr_wf_* เพราะเก็บ "ผู้มีสิทธิ์อนุมัติ" ไม่ใช่ "ผู้ที่กดอนุมัติจริง"
--   ซึ่งจะทำให้แสดงผู้อนุมัติที่ยังไม่ถึงขั้น — ขัดข้อกำหนด
--
-- ต้องรัน 41 · 48 · 55 · 65 มาก่อน · รันซ้ำได้
-- ============================================================


-- ════════════════════════════════════════════════════════════
-- 0) PREFLIGHT — ไม่ผ่านให้หยุด ยังไม่สร้างอะไร
-- ════════════════════════════════════════════════════════════
do $$
declare miss text;
begin
  if to_regclass('public.ot_requests') is null then raise exception 'PREFLIGHT: ไม่พบตาราง ot_requests'; end if;
  if to_regclass('public.app_users')   is null then raise exception 'PREFLIGHT: ไม่พบตาราง app_users'; end if;
  if to_regclass('public.employees')   is null then raise exception 'PREFLIGHT: ไม่พบตาราง employees'; end if;

  select string_agg(t || '.' || c, ', ') into miss
    from (values
      ('ot_requests','id'), ('ot_requests','employee_id'), ('ot_requests','ot_date'),
      ('ot_requests','start_time'), ('ot_requests','end_time'), ('ot_requests','ot_hours'),
      ('ot_requests','status'), ('ot_requests','approvals'), ('ot_requests','spans_next_day'),
      ('app_users','username'), ('app_users','full_name'), ('app_users','employee_id'),
      ('app_users','app_code'),
      ('employees','id'), ('employees','emp_code'), ('employees','prefix'),
      ('employees','first_name'), ('employees','last_name'), ('employees','department_name')
    ) v(t, c)
   where not exists (select 1 from information_schema.columns
                      where table_schema = 'public' and table_name = v.t and column_name = v.c);
  if miss is not null then raise exception 'PREFLIGHT: ขาดคอลัมน์ [%]', miss; end if;

  -- approvals ต้องเป็น jsonb เท่านั้น มิฉะนั้นตรรกะดึงชื่อจะผิด
  if (select data_type from information_schema.columns
       where table_schema='public' and table_name='ot_requests' and column_name='approvals') <> 'jsonb' then
    raise exception 'PREFLIGHT: ot_requests.approvals ไม่ใช่ jsonb';
  end if;

  if not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                  where n.nspname='public' and p.proname='njhr_ot_guard') then
    raise exception 'PREFLIGHT: ไม่พบ njhr_ot_guard — ต้องรัน 65_ot.sql ก่อน';
  end if;

  if exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
              where n.nspname='public' and p.proname='njhr_report_all_ot'
                and p.proargtypes::oid[] <> array['text','date','date','text','uuid']::regtype[]::oid[]) then
    raise exception 'PREFLIGHT: มี njhr_report_all_ot signature อื่นอยู่แล้ว — ตรวจก่อนสร้างทับ';
  end if;

  raise notice 'PREFLIGHT ผ่าน';
end $$;


-- ════════════════════════════════════════════════════════════
-- 1) ชื่อผู้อนุมัติจาก username — helper ตัวเล็ก ใช้ซ้ำได้
--    ลำดับการหา: app_users.full_name → employees (prefix+first+last) → username เดิม
-- ════════════════════════════════════════════════════════════
create or replace function public.njhr_user_display(p_username text)
returns text language sql stable security definer set search_path = public as $$
  select coalesce(
           nullif(btrim(coalesce(u.full_name, '')), ''),
           nullif(btrim(coalesce(e.prefix, '') || coalesce(e.first_name, '') || ' ' ||
                        coalesce(e.last_name, '')), ''),
           u.username,
           p_username)
    from public.app_users u
    left join public.employees e on e.id = u.employee_id
   where u.username = p_username and u.app_code = 'salary'
   limit 1
$$;


-- ════════════════════════════════════════════════════════════
-- 2) njhr_report_all_ot — ข้อมูล OT สำหรับ REPORT ALL พร้อมชื่อผู้อนุมัติจริง
--
--    คืนคอลัมน์ชุดเดียวกับที่ REPORT ALL ใช้จาก njhr_ot_list บวก approver_name
--    เฉพาะรายการที่ status = 'APPROVED' เท่านั้น
-- ════════════════════════════════════════════════════════════
create or replace function public.njhr_report_all_ot(
  p_token    text,
  p_from     date default null,
  p_to       date default null,
  p_dept     text default null,
  p_employee uuid default null)
returns table (
  id uuid, ot_date date, start_time time, end_time time, spans_next_day boolean,
  ot_hours numeric, status text,
  employee_id uuid, emp_code text, prefix text, emp_name text,
  department text, position_name text,
  approver_name text)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare c record;
begin
  -- สิทธิ์เดียวกับ njhr_ot_list ทุกประการ (ไม่สร้าง Guard ใหม่)
  select * into c from public.njhr_ot_guard(p_token);

  return query
  select o.id, o.ot_date, o.start_time, o.end_time, o.spans_next_day,
         o.ot_hours, o.status::text,
         o.employee_id, e.emp_code, e.prefix,
         btrim(coalesce(e.first_name, '') || ' ' || coalesce(e.last_name, '')),
         e.department_name, e.position_name,
         /* ผู้อนุมัติจริง: เฉพาะ element ที่ action = 'APPROVE'
            เรียงตาม ordinality = ลำดับขั้นการอนุมัติจริง
            ตัดชื่อซ้ำออกโดยคงลำดับแรกที่พบ · ไม่มีเลย = '—' */
         coalesce(nullif((
           select string_agg(nm, ', ' order by ord)
             from (select min(a.ord) as ord,
                          public.njhr_user_display(a.el->>'by') as nm
                     from jsonb_array_elements(coalesce(o.approvals, '[]'::jsonb))
                          with ordinality as a(el, ord)
                    where upper(coalesce(a.el->>'action', '')) = 'APPROVE'
                      and nullif(btrim(coalesce(a.el->>'by', '')), '') is not null
                    group by public.njhr_user_display(a.el->>'by')) s
         ), ''), '—')
    from public.ot_requests o
    join public.employees e on e.id = o.employee_id
   where o.status::text = 'APPROVED'
     and (p_from is null or o.ot_date >= p_from)
     and (p_to   is null or o.ot_date <= p_to)
     and (p_dept is null or e.department_name = p_dept)
     and (p_employee is null or o.employee_id = p_employee)
     /* ขอบเขตการมองเห็นเดียวกับ njhr_ot_list: ผู้ที่ไม่ใช่ผู้อนุมัติเห็นเฉพาะของตนเอง */
     and (c.can_approve or o.employee_id = c.employee_id)
   order by e.emp_code, o.ot_date;
end $$;


-- ─── สิทธิ์เรียกใช้ (รูปแบบเดียวกับ RPC อื่นในระบบ) ───────────
revoke all on function public.njhr_user_display(text) from public;
grant execute on function public.njhr_user_display(text) to anon, authenticated;
revoke all on function public.njhr_report_all_ot(text, date, date, text, uuid) from public;
grant execute on function public.njhr_report_all_ot(text, date, date, text, uuid) to anon, authenticated;

comment on function public.njhr_report_all_ot(text, date, date, text, uuid) is
  'REPORT ALL — OT ที่อนุมัติแล้ว พร้อม approver_name จาก ot_requests.approvals '
  '(action=APPROVE เรียงตามลำดับขั้น ไม่ซ้ำ) ไม่แตะ njhr_ot_list';


insert into public.njhr_schema_version(version, note)
values ('v2.8-report-all-ot',
        'njhr_report_all_ot — คอลัมน์ผู้อนุมัติ OT ใน REPORT ALL')
on conflict (version) do nothing;


-- ════════════════════════════════════════════════════════════
-- 3) VERIFICATION
-- ════════════════════════════════════════════════════════════
select jsonb_pretty(jsonb_build_object(
  'function_created', exists(
     select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname='public' and p.proname='njhr_report_all_ot'),
  'signature', (select pg_get_function_identity_arguments(p.oid)::text
                  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                 where n.nspname='public' and p.proname='njhr_report_all_ot'),
  'is_security_definer', (select p.prosecdef from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                           where n.nspname='public' and p.proname='njhr_report_all_ot'),
  'search_path', (select array_to_string(p.proconfig, ',') from pg_proc p
                    join pg_namespace n on n.oid=p.pronamespace
                   where n.nspname='public' and p.proname='njhr_report_all_ot'),
  -- ต้องเป็น true: RPC ใหม่ใช้ Guard เดิม ไม่สร้างสิทธิ์ใหม่
  'uses_ot_guard', (select pg_get_functiondef(p.oid) like '%njhr\_ot\_guard%'
                      from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                     where n.nspname='public' and p.proname='njhr_report_all_ot'),
  -- ต้องเป็น false: ห้ามอ่านจาก timeline ที่ไม่มีอยู่จริง
  'uses_timeline', (select pg_get_functiondef(p.oid) like '%timeline%'
                      from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                     where n.nspname='public' and p.proname='njhr_report_all_ot'),
  -- njhr_ot_list ต้องไม่ถูกแก้: ยังคืน 20 คอลัมน์เท่าเดิม
  'ot_list_result_unchanged', (select pg_get_function_result(p.oid)::text not like '%approver_name%'
                      from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                     where n.nspname='public' and p.proname='njhr_ot_list'),
  'grants', (select jsonb_agg(distinct grantee::text order by grantee::text)
               from information_schema.routine_privileges
              where specific_schema='public' and routine_name::text='njhr_report_all_ot'),
  'ot_rows_total', (select count(*) from public.ot_requests),
  'ot_rows_approved', (select count(*) from public.ot_requests where status::text='APPROVED'),
  'ot_rows_with_approvals', (select count(*) from public.ot_requests
                              where approvals is not null and jsonb_array_length(approvals) > 0)
)) as o2_verification;


-- ════════════════════════════════════════════════════════════
-- 4) ROLLBACK
-- ════════════════════════════════════════════════════════════
-- drop function if exists public.njhr_report_all_ot(text, date, date, text, uuid);
-- drop function if exists public.njhr_user_display(text);
-- delete from public.njhr_schema_version where version = 'v2.8-report-all-ot';
-- (ไม่มีตาราง ข้อมูล หรือ RPC เดิมใดถูกแก้ จึงไม่ต้องคืนค่าอย่างอื่น)
