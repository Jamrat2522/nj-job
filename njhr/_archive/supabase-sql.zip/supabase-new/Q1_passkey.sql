-- ============================================================
-- NJ HR V2 — Q1_passkey.sql
-- เพิ่ม Passkey / WebAuthn เป็นช่องทาง Login เพิ่มเติม (ADDITIVE ONLY)
--
-- ไม่แตะของเดิมแม้แต่บรรทัดเดียว:
--   njhr_login · njhr_session_check · njhr_ctx · app_users · employees ·
--   njhr_sessions · njhr_activation_* · Face Attendance ทั้งหมด
--
-- อ้างอิงจาก pg_get_functiondef ของ njhr_login บน Production:
--   · ตรวจ app_code = 'salary'
--   · status 'registration_required' → 28000 กรุณาสมัครสมาชิกครั้งแรก
--   · is_active = false            → 28000 บัญชีถูกปิดใช้งาน
--   · status 'pending'             → 28000 บัญชีรออนุมัติ
--   · status <> 'active'           → 28000 บัญชีไม่พร้อมใช้งาน
--   · employee_id is null          → 28000 ยังไม่ได้เชื่อมกับข้อมูลพนักงาน
--   · TTL = 30 days เมื่อ remember มิฉะนั้น 12 hours
--   · insert njhr_sessions(app_user_id, user_agent, expires_at) returning token, expires_at
--   · คืน 16 คอลัมน์ join employees
-- njhr_passkey_auth_finish ทำตามลำดับเดียวกันทุกข้อ ไม่ลดการตรวจใด ๆ
--
-- ⚠ ความปลอดภัยหลัก
--   การตรวจลายเซ็น WebAuthn (CBOR + COSE + ECDSA P-256) ทำใน plpgsql ไม่ได้
--   จึงต้องทำใน Edge Function เท่านั้น
--   RPC "finish" ทั้งสองตัวจึง revoke จาก anon/authenticated และ grant ให้
--   service_role เท่านั้น — Client เรียกตรงไม่ได้ จึงปลอมผลลัพธ์ไม่ได้
--
-- รันซ้ำได้ · ไม่ drop · ไม่ truncate · ไม่ reset อะไรทั้งสิ้น
-- ============================================================


-- ═══ 0) PREFLIGHT ═══
do $$
declare miss text;
begin
  if to_regclass('public.app_users')     is null then raise exception 'PREFLIGHT: ไม่พบ app_users'; end if;
  if to_regclass('public.employees')     is null then raise exception 'PREFLIGHT: ไม่พบ employees'; end if;
  if to_regclass('public.njhr_sessions') is null then raise exception 'PREFLIGHT: ไม่พบ njhr_sessions'; end if;

  select string_agg(t || '.' || c, ', ') into miss
    from (values
      ('njhr_sessions','token'), ('njhr_sessions','app_user_id'),
      ('njhr_sessions','user_agent'), ('njhr_sessions','expires_at'), ('njhr_sessions','revoked'),
      ('app_users','id'), ('app_users','username'), ('app_users','app_code'),
      ('app_users','status'), ('app_users','is_active'), ('app_users','employee_id')
    ) v(t, c)
   where not exists (select 1 from information_schema.columns
                      where table_schema = 'public' and table_name = v.t and column_name = v.c);
  if miss is not null then raise exception 'PREFLIGHT: ขาดคอลัมน์ [%]', miss; end if;

  if not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                  where n.nspname = 'public' and p.proname = 'njhr_login') then
    raise exception 'PREFLIGHT: ไม่พบ njhr_login';
  end if;
  raise notice 'PREFLIGHT ผ่าน';
end $$;


-- ═══ 1) ตาราง ═══
-- credential_id เก็บเป็น base64url (text) ตามที่ Edge Function ส่งมา
-- public_key เก็บเป็น base64url ของ COSE key — ไม่ใช่ข้อมูล biometric และไม่ใช่ private key
create table if not exists public.njhr_passkeys (
  id            uuid primary key default gen_random_uuid(),
  app_user_id   uuid not null references public.app_users(id) on delete cascade,
  credential_id text not null,
  public_key    text not null,
  sign_count    bigint not null default 0,
  transports    text[],
  label         text,
  aaguid        text,
  status        text not null default 'ACTIVE',
  created_at    timestamptz not null default now(),
  last_used_at  timestamptz,
  revoked_at    timestamptz,
  user_agent    text,
  constraint njhr_passkeys_status_ck check (status in ('ACTIVE','REVOKED','DISABLED'))
);
-- credential_id ต้องไม่ซ้ำทั้งระบบ (กัน Credential เดียวผูกหลาย USER)
create unique index if not exists njhr_passkeys_cred_uidx on public.njhr_passkeys(credential_id);
create index if not exists njhr_passkeys_user_idx on public.njhr_passkeys(app_user_id, status);

-- Challenge: สุ่มฝั่ง Server · ใช้ครั้งเดียว · มีวันหมดอายุ
create table if not exists public.njhr_passkey_challenges (
  challenge    text primary key,
  purpose      text not null,
  app_user_id  uuid references public.app_users(id) on delete cascade,
  created_at   timestamptz not null default now(),
  expires_at   timestamptz not null,
  used_at      timestamptz,
  constraint njhr_passkey_ch_purpose_ck check (purpose in ('REGISTER','AUTH'))
);
create index if not exists njhr_passkey_ch_exp_idx on public.njhr_passkey_challenges(expires_at);

-- ปิด Client ทั้งหมด — เข้าถึงได้ผ่าน RPC/Edge Function เท่านั้น
alter table public.njhr_passkeys            enable row level security;
alter table public.njhr_passkey_challenges  enable row level security;
revoke all on public.njhr_passkeys           from anon, authenticated;
revoke all on public.njhr_passkey_challenges from anon, authenticated;


-- ═══ 2) Helper: ตรวจ Session เดิม (ใช้รูปแบบเดียวกับระบบ) ═══
create or replace function public.njhr_pk_user(p_token text)
returns uuid language plpgsql stable security definer set search_path = public as $$
declare v_id uuid;
begin
  select s.app_user_id into v_id
    from public.njhr_sessions s
    join public.app_users u on u.id = s.app_user_id
   where s.token = p_token and not coalesce(s.revoked,false) and s.expires_at > now()
     and u.app_code = 'salary' and coalesce(u.is_active,true)
   limit 1;
  if v_id is null then
    raise exception 'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่' using errcode='28000';
  end if;
  return v_id;
end $$;


-- ═══ 3) REGISTER — ต้อง Login อยู่จริงเท่านั้น ═══
-- ข้อ 1: ผู้ที่ยังไม่ Login ด้วย Password สำเร็จ ลงทะเบียน Passkey ไม่ได้
create or replace function public.njhr_passkey_reg_begin(p_token text)
returns table (challenge text, expires_at timestamptz, app_user_id uuid, username text)
language plpgsql security definer set search_path = public, extensions as $$
declare v_uid uuid; v_ch text; v_exp timestamptz;
begin
  v_uid := public.njhr_pk_user(p_token);
  if (select employee_id from public.app_users where id = v_uid) is null then
    raise exception 'บัญชีนี้ยังไม่ได้เชื่อมกับข้อมูลพนักงาน' using errcode='28000';
  end if;
  -- Rate limit: ขอ Challenge ได้ไม่เกิน 10 ครั้ง/5 นาที ต่อผู้ใช้
  if (select count(*) from public.njhr_passkey_challenges c
       where c.app_user_id = v_uid and c.created_at > now() - interval '5 minutes') >= 10 then
    raise exception 'ขอรหัสยืนยันบ่อยเกินไป กรุณารอสักครู่' using errcode='53400';
  end if;
  v_ch  := encode(extensions.gen_random_bytes(32), 'base64');
  v_ch  := replace(replace(replace(v_ch,'+','-'),'/','_'),'=','');   -- base64url
  v_exp := now() + interval '3 minutes';
  insert into public.njhr_passkey_challenges(challenge, purpose, app_user_id, expires_at)
  values (v_ch, 'REGISTER', v_uid, v_exp);
  return query select v_ch, v_exp, v_uid, u.username from public.app_users u where u.id = v_uid;
end $$;

-- เรียกได้จาก Edge Function (service_role) เท่านั้น หลัง Verify ลายเซ็นแล้ว
create or replace function public.njhr_passkey_reg_finish(
  p_challenge text, p_credential_id text, p_public_key text,
  p_sign_count bigint default 0, p_transports text[] default null,
  p_label text default null, p_aaguid text default null, p_ua text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare c public.njhr_passkey_challenges; v_id uuid;
begin
  -- Challenge: ต้องมีจริง · ใช้ครั้งเดียว · ยังไม่หมดอายุ · เป็นชนิด REGISTER
  select * into c from public.njhr_passkey_challenges
   where challenge = p_challenge for update;
  if not found                       then raise exception 'รหัสยืนยันไม่ถูกต้อง' using errcode='22023'; end if;
  if c.purpose <> 'REGISTER'         then raise exception 'รหัสยืนยันไม่ถูกต้อง' using errcode='22023'; end if;
  if c.used_at is not null           then raise exception 'รหัสยืนยันถูกใช้ไปแล้ว' using errcode='22023'; end if;
  if c.expires_at < now()            then raise exception 'รหัสยืนยันหมดอายุ' using errcode='22023'; end if;
  if c.app_user_id is null           then raise exception 'รหัสยืนยันไม่ผูกกับผู้ใช้' using errcode='22023'; end if;

  update public.njhr_passkey_challenges set used_at = now() where challenge = p_challenge;

  insert into public.njhr_passkeys(app_user_id, credential_id, public_key, sign_count,
                                   transports, label, aaguid, user_agent)
  values (c.app_user_id, p_credential_id, p_public_key, coalesce(p_sign_count,0),
          p_transports, nullif(btrim(coalesce(p_label,'')),''), p_aaguid, left(coalesce(p_ua,''),200))
  returning id into v_id;
  return v_id;
end $$;


-- ═══ 4) AUTHENTICATION ═══
create or replace function public.njhr_passkey_auth_begin()
returns table (challenge text, expires_at timestamptz)
language plpgsql security definer set search_path = public, extensions as $$
declare v_ch text; v_exp timestamptz;
begin
  v_ch  := encode(extensions.gen_random_bytes(32), 'base64');
  v_ch  := replace(replace(replace(v_ch,'+','-'),'/','_'),'=','');
  v_exp := now() + interval '3 minutes';
  insert into public.njhr_passkey_challenges(challenge, purpose, expires_at)
  values (v_ch, 'AUTH', v_exp);
  return query select v_ch, v_exp;
end $$;

-- เรียกได้จาก Edge Function (service_role) เท่านั้น หลัง Verify ลายเซ็นสำเร็จ
-- คืนคอลัมน์ชุดเดียวกับ njhr_login ทุกตัว เพื่อให้ฝั่งหน้าเว็บใช้ Flow เดิมได้ทันที
create or replace function public.njhr_passkey_auth_finish(
  p_challenge text, p_credential_id text,
  p_sign_count bigint default null, p_ua text default null, p_remember boolean default false)
returns table (session_token text, expires_at timestamptz, user_id uuid, username text,
               internal_username text, email text, full_name text, department text,
               role text, status text, employee_id uuid, emp_code text, emp_name text,
               emp_department text, emp_position text, emp_status text)
language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
declare c public.njhr_passkey_challenges; k public.njhr_passkeys; u public.app_users;
        tok text; exp timestamptz; v_ttl interval;
begin
  -- 4.1 Challenge ต้องถูกต้อง ใช้ครั้งเดียว ยังไม่หมดอายุ
  select * into c from public.njhr_passkey_challenges where challenge = p_challenge for update;
  if not found              then raise exception 'รหัสยืนยันไม่ถูกต้อง' using errcode='22023'; end if;
  if c.purpose <> 'AUTH'    then raise exception 'รหัสยืนยันไม่ถูกต้อง' using errcode='22023'; end if;
  if c.used_at is not null  then raise exception 'รหัสยืนยันถูกใช้ไปแล้ว' using errcode='22023'; end if;
  if c.expires_at < now()   then raise exception 'รหัสยืนยันหมดอายุ' using errcode='22023'; end if;
  update public.njhr_passkey_challenges set used_at = now() where challenge = p_challenge;

  -- 4.2 Credential ต้องมีจริงและยัง ACTIVE (ข้อ 12)
  select * into k from public.njhr_passkeys where credential_id = p_credential_id;
  if not found            then raise exception 'ไม่พบ Passkey นี้ในระบบ' using errcode='28000'; end if;
  if k.status <> 'ACTIVE' then raise exception 'Passkey นี้ถูกเพิกถอนแล้ว' using errcode='28000'; end if;

  -- 4.3 sign counter ต้องไม่ถอยหลัง (กัน Cloned Authenticator) — ข้ามเมื่ออุปกรณ์ส่ง 0
  if p_sign_count is not null and p_sign_count > 0 and p_sign_count <= k.sign_count then
    raise exception 'ตรวจพบการใช้ Passkey ซ้ำ กรุณาเข้าสู่ระบบด้วยรหัสผ่าน' using errcode='28000';
  end if;

  -- 4.4 ตรวจ USER ปัจจุบันด้วยลำดับเดียวกับ njhr_login ทุกข้อ (ข้อ 11)
  select a.* into u from public.app_users a where a.id = k.app_user_id and a.app_code = 'salary';
  if not found then raise exception 'บัญชีนี้ใช้งานไม่ได้' using errcode='28000'; end if;
  if lower(coalesce(u.status,'active')) = 'registration_required' then
    raise exception 'กรุณากดสมัครสมาชิกครั้งแรกเพื่อใช้งานระบบ' using errcode='28000';
  end if;
  if coalesce(u.is_active,true) = false then
    raise exception 'บัญชีถูกปิดใช้งาน' using errcode='28000';
  end if;
  if lower(coalesce(u.status,'active')) = 'pending' then
    raise exception 'บัญชีรออนุมัติ กรุณาติดต่อผู้ดูแลระบบ' using errcode='28000';
  end if;
  if lower(coalesce(u.status,'active')) <> 'active' then
    raise exception 'บัญชีไม่พร้อมใช้งาน (สถานะ: %)', u.status using errcode='28000';
  end if;
  if u.employee_id is null then
    raise exception 'บัญชีนี้ยังไม่ได้เชื่อมกับข้อมูลพนักงาน กรุณาติดต่อผู้ดูแลระบบ' using errcode='28000';
  end if;

  -- 4.5 สร้าง Session ด้วยวิธีเดียวกับ njhr_login ทุกบรรทัด (ข้อ 10 · ข้อ 31)
  v_ttl := case when coalesce(p_remember, false)
                then interval '30 days' else interval '12 hours' end;
  update public.njhr_sessions ss set revoked = true
   where ss.app_user_id = u.id and ss.expires_at < now() and not ss.revoked;
  insert into public.njhr_sessions(app_user_id, user_agent, expires_at)
  values (u.id, left(coalesce(p_ua,''),200), now() + v_ttl)
    returning njhr_sessions.token, njhr_sessions.expires_at into tok, exp;

  update public.njhr_passkeys
     set last_used_at = now(),
         sign_count = greatest(coalesce(p_sign_count, sign_count), sign_count)
   where id = k.id;

  return query
    select tok, exp, u.id, u.username, u.internal_username, u.email, u.full_name, u.department,
           u.role::text, coalesce(u.status,'active'), u.employee_id,
           e.emp_code, (coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,'')),
           e.department_name, e.position_name, e.status::text
      from public.employees e where e.id = u.employee_id;
end $$;


-- ═══ 5) จัดการ Passkey ของตนเอง (ข้อ 14 · 16) ═══
create or replace function public.njhr_passkey_list(p_token text)
returns table (id uuid, label text, status text, transports text[],
               created_at timestamptz, last_used_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
declare v_uid uuid;
begin
  v_uid := public.njhr_pk_user(p_token);
  -- ไม่คืน credential_id / public_key ให้ Client
  return query select k.id, k.label, k.status, k.transports, k.created_at, k.last_used_at
    from public.njhr_passkeys k
   where k.app_user_id = v_uid and k.status <> 'REVOKED'
   order by k.created_at desc;
end $$;

create or replace function public.njhr_passkey_revoke(p_token text, p_id uuid)
returns boolean language plpgsql security definer set search_path = public as $$
declare v_uid uuid;
begin
  v_uid := public.njhr_pk_user(p_token);
  -- ownership: ลบได้เฉพาะของตนเอง
  update public.njhr_passkeys
     set status = 'REVOKED', revoked_at = now()
   where id = p_id and app_user_id = v_uid and status <> 'REVOKED';
  if not found then
    raise exception 'ไม่พบ Passkey นี้ หรือไม่ใช่ของบัญชีคุณ' using errcode='42501';
  end if;
  return true;
end $$;


-- ═══ 6) สิทธิ์เรียกใช้ ═══
-- begin/list/revoke: Client เรียกได้ (มี token guard ในตัว)
revoke all on function public.njhr_pk_user(text) from public;
revoke all on function public.njhr_passkey_reg_begin(text) from public;
revoke all on function public.njhr_passkey_auth_begin() from public;
revoke all on function public.njhr_passkey_list(text) from public;
revoke all on function public.njhr_passkey_revoke(text, uuid) from public;
grant execute on function public.njhr_passkey_reg_begin(text)      to anon, authenticated;
grant execute on function public.njhr_passkey_auth_begin()         to anon, authenticated;
grant execute on function public.njhr_passkey_list(text)           to anon, authenticated;
grant execute on function public.njhr_passkey_revoke(text, uuid)   to anon, authenticated;

-- finish: service_role เท่านั้น — Client เรียกตรงไม่ได้ จึงปลอมผล Verify ไม่ได้ (ข้อ 6 · 36)
revoke all on function public.njhr_passkey_reg_finish(text, text, text, bigint, text[], text, text, text) from public, anon, authenticated;
revoke all on function public.njhr_passkey_auth_finish(text, text, bigint, text, boolean) from public, anon, authenticated;
grant execute on function public.njhr_passkey_reg_finish(text, text, text, bigint, text[], text, text, text) to service_role;
grant execute on function public.njhr_passkey_auth_finish(text, text, bigint, text, boolean) to service_role;


insert into public.njhr_schema_version(version, note)
values ('v3.0-passkey', 'Passkey/WebAuthn เป็นช่องทาง Login เพิ่มเติม — ไม่แตะ njhr_login และ Face Attendance')
on conflict (version) do nothing;


-- ═══ 7) VERIFICATION ═══
select jsonb_pretty(jsonb_build_object(
  'tables', (select jsonb_agg(tablename order by tablename) from pg_tables
              where schemaname='public' and tablename in ('njhr_passkeys','njhr_passkey_challenges')),
  'credential_id_unique', exists(select 1 from pg_indexes
     where schemaname='public' and indexname='njhr_passkeys_cred_uidx'),
  'rls_enabled', (select jsonb_object_agg(relname, relrowsecurity) from pg_class
     where relname in ('njhr_passkeys','njhr_passkey_challenges')),
  -- finish ต้องไม่มี anon/authenticated
  'finish_client_grants', (select coalesce(jsonb_agg(distinct grantee::text), '[]'::jsonb)
     from information_schema.routine_privileges
    where specific_schema='public'
      and routine_name::text in ('njhr_passkey_reg_finish','njhr_passkey_auth_finish')
      and grantee::text in ('anon','authenticated')),
  -- ของเดิมต้องไม่ถูกแตะ
  'njhr_login_untouched', (select pg_get_functiondef(p.oid) like '%ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง%'
     from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname='njhr_login'),
  'sessions_rows', (select count(*) from public.njhr_sessions),
  'app_users_rows', (select count(*) from public.app_users where app_code='salary'),
  'passkeys_rows', (select count(*) from public.njhr_passkeys)
)) as q1_verification;


-- ═══ 8) ROLLBACK ═══
-- drop function if exists public.njhr_passkey_revoke(text, uuid);
-- drop function if exists public.njhr_passkey_list(text);
-- drop function if exists public.njhr_passkey_auth_finish(text, text, bigint, text, boolean);
-- drop function if exists public.njhr_passkey_auth_begin();
-- drop function if exists public.njhr_passkey_reg_finish(text, text, text, bigint, text[], text, text, text);
-- drop function if exists public.njhr_passkey_reg_begin(text);
-- drop function if exists public.njhr_pk_user(text);
-- drop table if exists public.njhr_passkey_challenges;
-- drop table if exists public.njhr_passkeys;
-- delete from public.njhr_schema_version where version = 'v3.0-passkey';
-- (ไม่มีตาราง ข้อมูล หรือ RPC เดิมใดถูกแก้ จึงไม่ต้องคืนค่าอย่างอื่น)
