-- ============================================================
-- NJ HR V2 — 94_wht50_pdf_first.sql
-- เปลี่ยนลำดับงาน 50 ทวิ เป็น PDF-FIRST
--
-- ⚠⚠ ไฟล์นี้ยังไม่ได้รัน — ส่งมาให้ตรวจก่อนเท่านั้น ⚠⚠
--
-- ปัญหาเดิม (พิสูจน์จาก 89_wht50_deliver.sql บรรทัด 133–250)
--   njhr_wht50_send() ทำทุกอย่างในครั้งเดียว:
--     สร้าง njhr_emp_documents (status = 'SENT') → ผูก document_id
--     → send_status = 'SENT' → Notification → Audit
--   แล้ว Frontend ค่อยนำ document_id ไปสร้าง PDF ทีหลัง
--   ผลคือพนักงานได้รับแจ้งเตือนก่อนที่ไฟล์ PDF จะมีจริง
--   ถ้า Render ล้ม เอกสารก็ค้างสถานะ SENT โดยไม่มีไฟล์ให้เปิด
--
-- ลำดับใหม่
--   CONFIRMED → prepare_document (DRAFT) → claim → render → commit
--   → final_pdf_status = READY → send → SENT → Notification → Audit
--
-- สิ่งที่ไฟล์นี้ทำ
--   1. เพิ่ม njhr_wht50_prepare_document()  — สร้างเอกสาร DRAFT อย่างเดียว
--   2. แทนที่ njhr_wht50_send()             — บังคับตรวจ PDF READY ก่อนส่ง
--   3. GRANT ตาม Pattern เดิมของไฟล์ 89 ทุกประการ
--
-- สิ่งที่ไฟล์นี้ "ไม่" ทำ
--   ไม่แตะ njhr_doc_pdf_claim / _commit / _status  (รองรับ DRAFT อยู่แล้ว —
--     90_wht50_pdf.sql ตรวจ w.status='CONFIRMED' ของ njhr_wht50 ไม่ได้ตรวจ d.status)
--   ไม่เพิ่มคอลัมน์ · ไม่แก้ Constraint · ไม่เพิ่ม Status ใหม่
--   ไม่แตะ Payroll · Profile · OT · Leave · RLS อื่น
--   ไม่แก้ Migration เก่าที่รัน Production แล้ว
--
-- ต้องรัน 87 · 88 · 89 · 90 มาก่อน · รันซ้ำได้
-- ============================================================

-- ─── 0) PREFLIGHT ───────────────────────────────────────────
do $$
declare n bigint;
begin
  if to_regclass('public.njhr_wht50') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_wht50 — ต้องรัน 87_wht50.sql ก่อน';
  end if;
  if to_regclass('public.njhr_emp_documents') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_emp_documents';
  end if;
  if to_regprocedure('public.njhr_wht50_guard(text,boolean)') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_wht50_guard — ต้องรัน 87_wht50.sql ก่อน';
  end if;
  if to_regprocedure('public.njhr_wht50_send(text,uuid)') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_wht50_send — ต้องรัน 89_wht50_deliver.sql ก่อน';
  end if;
  if to_regprocedure('public.njhr_doc_pdf_claim(text,uuid)') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_doc_pdf_claim — ต้องรัน 90_wht50_pdf.sql ก่อน';
  end if;
  if not exists (select 1 from information_schema.columns
                  where table_schema='public' and table_name='njhr_emp_documents'
                    and column_name='final_pdf_status') then
    raise exception 'PREFLIGHT: njhr_emp_documents ไม่มี final_pdf_status';
  end if;

  -- ---- ข้อมูลจริงที่อาจได้รับผลกระทบ (อ่านอย่างเดียว) ----
  select count(*) into n from public.njhr_wht50;
  raise notice 'WHT50 ทั้งหมด: %', n;
  select count(*) into n from public.njhr_wht50 where send_status = 'SENT';
  raise notice '  send_status = SENT: %', n;
  select count(*) into n from public.njhr_wht50 where send_status = 'OPENED';
  raise notice '  send_status = OPENED: %', n;
  select count(*) into n from public.njhr_wht50
   where document_id is not null and send_status = 'NOT_SENT';
  raise notice '  document_id ผูกแล้วแต่ยัง NOT_SENT: %  (ของเดิมต้องเป็น 0)', n;
  select count(*) into n
    from public.njhr_wht50 w join public.njhr_emp_documents d on d.id = w.document_id
   where w.send_status in ('SENT','OPENED')
     and coalesce(d.final_pdf_status,'') <> 'READY';
  raise notice '  ส่งแล้วแต่ PDF ยังไม่ READY: %  (ข้อมูลเก่าก่อนใช้ PDF-FIRST)', n;
  raise notice 'PREFLIGHT ผ่าน';
end $$;


begin;

-- ─── 1) เตรียมเอกสาร (DRAFT) โดยยังไม่ส่ง ───────────────────
--  เนื้อหาทุกค่าคัดลอกจาก njhr_wht50_send เดิมทั้งหมด ยกเว้น 3 จุด:
--    status     'SENT'  → 'DRAFT'
--    sent_at    now()   → null
--    sent_by    username→ null
--  และไม่แตะ send_status · ไม่สร้าง Notification · ไม่เขียน event SEND
create or replace function public.njhr_wht50_prepare_document(p_token text, p_id uuid)
returns table (result text, document_id uuid, doc_status text, message text)
language plpgsql security definer set search_path = public as $function$
#variable_conflict use_column
declare c record; w record; e record; d record; v_doc uuid; v_no text; v_title text;
begin
  select * into c from public.njhr_wht50_guard(p_token, true);

  select * into w from public.njhr_wht50 where id = p_id for update;
  if not found then raise exception 'ไม่พบเอกสาร 50 ทวิ นี้' using errcode='P0002'; end if;

  /* ---- มีเอกสารอยู่แล้ว → คืนตัวเดิม ห้ามสร้างซ้ำ ----
     ต้องพิสูจน์ก่อนว่าเป็นเอกสาร WHT50 ของรายการนี้จริง
     ถ้าชี้ผิดเอกสารให้ล้มเลย ห้ามสร้างใหม่ทับเพื่อกลบปัญหา */
  if w.document_id is not null then
    select * into d from public.njhr_emp_documents where id = w.document_id;
    if not found then
      raise exception 'document_id ของ 50 ทวิ นี้ชี้ไปยังเอกสารที่ไม่มีอยู่จริง (%)', w.document_id
        using errcode='P0002';
    end if;
    if d.doc_type <> 'WHT50'
       or d.employee_id is distinct from w.employee_id
       or coalesce(d.doc_meta->>'wht50_id','') <> w.id::text then
      raise exception 'document_id ของ 50 ทวิ นี้ผูกผิดเอกสาร — หยุดเพื่อตรวจสอบ (doc %)', w.document_id
        using errcode='22023';
    end if;
    return query select 'ALREADY_PREPARED'::text, w.document_id, d.status::text,
                        'เตรียมเอกสารไว้แล้ว ไม่สร้างซ้ำ'::text;
    return;
  end if;

  /* ---- เงื่อนไขความพร้อม (ชุดเดียวกับ njhr_wht50_send เดิม) ---- */
  if w.status <> 'CONFIRMED' then
    raise exception 'เตรียมเอกสารได้เฉพาะ 50 ทวิ ที่ยืนยันแล้ว (สถานะปัจจุบัน %)', w.status
      using errcode='22023';
  end if;
  if w.employee_id is null then
    raise exception 'เอกสารนี้ไม่ได้ผูกกับพนักงาน' using errcode='22023';
  end if;
  if coalesce(btrim(w.doc_no),'') = '' then
    raise exception 'เอกสารนี้ยังไม่มีเลขที่เอกสาร' using errcode='22023';
  end if;

  select * into e from public.employees where id = w.employee_id;
  if not found then raise exception 'ไม่พบข้อมูลพนักงานของเอกสารนี้' using errcode='P0002'; end if;
  if coalesce(btrim(e.national_id),'') = '' then
    raise exception 'พนักงาน % ยังไม่มีเลขประจำตัวประชาชน จึงออก 50 ทวิ ไม่ได้',
      coalesce(e.emp_code,'-') using errcode='22023';
  end if;

  v_title := '50 ทวิ ประจำปีภาษี ' || (w.tax_year + 543)::text;
  v_no    := 'WHT50-' || w.tax_year::text || '-' || w.doc_no;

  insert into public.njhr_emp_documents (
    doc_no, version, doc_type, employee_id,
    emp_code_snap, emp_name_snap, dept_snap, position_snap,
    title, body, effective_date, status, requires_signature,
    doc_meta, issued_by, sent_at, sent_by, updated_by)
  values (
    v_no, 1, 'WHT50', w.employee_id,
    e.emp_code,
    btrim(coalesce(e.prefix,'') || coalesce(e.first_name,'') || ' ' || coalesce(e.last_name,'')),
    e.department_name, e.position_name,
    v_title,
    'หนังสือรับรองการหักภาษี ณ ที่จ่าย ปีภาษี ' || (w.tax_year + 543)::text ||
      ' เลขที่ ' || w.doc_no ||
      ' · รายได้รวม ' || to_char(coalesce(w.total_income,0), 'FM999,999,999.00') || ' บาท' ||
      ' · ภาษีหัก ณ ที่จ่าย ' || to_char(coalesce(w.total_tax,0), 'FM999,999,999.00') || ' บาท',
    w.issue_date, 'DRAFT', false,          -- ⚠ DRAFT ไม่ใช่ SENT
    jsonb_build_object(
      'wht50_id',      w.id,
      'tax_year',      w.tax_year,
      'wht50_doc_no',  w.doc_no,
      'amend_seq',     w.amend_seq,
      'form_type',     w.form_type,
      'income_section', w.income_section),
    c.username, null, null, c.username)    -- ⚠ sent_at / sent_by ต้องว่าง
  returning id into v_doc;

  /* ---- ผูกกลับเฉพาะ document_id ---- */
  /*      ห้ามแตะ send_status · sent_at · sent_by · send_count */
  update public.njhr_wht50
     set document_id = v_doc,
         updated_at  = now(),
         updated_by  = c.username
   where id = p_id;

  /* ---- Audit: เป็นการ "เตรียม" ไม่ใช่ "ส่ง" ---- */
  begin
    perform public.njhr_audit_write(p_token, 'WHT50_PREPARE_DOCUMENT', 'wht50',
      'njhr_wht50', w.id::text,
      'เตรียมเอกสาร 50 ทวิ ปีภาษี ' || w.tax_year::text ||
      ' · เลขที่ ' || w.doc_no ||
      ' · พนักงาน ' || coalesce(e.emp_code,'-') ||
      ' · เอกสาร ' || v_doc::text, null, null, null);
  exception when undefined_function then null;
  end;

  return query select 'PREPARED'::text, v_doc, 'DRAFT'::text,
                      'เตรียมเอกสารเรียบร้อย รอสร้าง PDF'::text;
end $function$;


-- ─── 2) ส่ง 50 ทวิ — ต้องมี Final PDF พร้อมก่อนเท่านั้น ─────
--  เปลี่ยนจากของเดิม 3 เรื่อง
--    1. ไม่สร้างเอกสารเองแล้ว — ต้องเรียก prepare_document มาก่อน
--    2. เงื่อนไข "ส่งแล้ว" ใช้ send_status เท่านั้น
--       (เดิมใช้ document_id is not null ซึ่งพัง PDF-FIRST เพราะเอกสาร DRAFT
--        ก็มี document_id แล้ว จะถูกนับเป็น ALREADY_SENT ทั้งที่ยังไม่ได้ส่ง)
--    3. บังคับตรวจ final_pdf_status = READY ก่อนเปลี่ยนสถานะใด ๆ
create or replace function public.njhr_wht50_send(p_token text, p_id uuid)
returns table (result text, document_id uuid, send_status text, message text)
language plpgsql security definer set search_path = public as $function$
#variable_conflict use_column
declare c record; w record; e record; d record; v_uid uuid;
begin
  select * into c from public.njhr_wht50_guard(p_token, true);

  select * into w from public.njhr_wht50 where id = p_id for update;
  if not found then raise exception 'ไม่พบเอกสาร 50 ทวิ นี้' using errcode='P0002'; end if;

  /* ---- กันส่งซ้ำ — ตัดสินจาก send_status เท่านั้น ---- */
  if w.send_status in ('SENT','OPENED') then
    return query select 'ALREADY_SENT'::text, w.document_id, w.send_status,
                        'ส่งแล้ว ไม่ส่งซ้ำ'::text;
    return;
  end if;

  if w.status <> 'CONFIRMED' then
    raise exception 'ส่งได้เฉพาะเอกสารที่ยืนยันแล้ว (สถานะปัจจุบัน %)', w.status using errcode='22023';
  end if;

  /* ---- ต้องเตรียมเอกสารมาก่อน ---- */
  if w.document_id is null then
    raise exception 'ยังไม่สามารถส่ง 50 ทวิ ได้ เนื่องจากยังไม่ได้เตรียมเอกสาร '
                    '(เรียก njhr_wht50_prepare_document ก่อน)' using errcode='22023';
  end if;

  select * into d from public.njhr_emp_documents where id = w.document_id for update;
  if not found then
    raise exception 'ไม่พบเอกสารที่ผูกไว้ (%)', w.document_id using errcode='P0002';
  end if;

  /* ---- ตรวจว่าเอกสารเป็นของรายการนี้จริง ---- */
  if d.doc_type <> 'WHT50'
     or d.employee_id is distinct from w.employee_id
     or coalesce(d.doc_meta->>'wht50_id','') <> w.id::text then
    raise exception 'เอกสารที่ผูกไว้ไม่ตรงกับ 50 ทวิ รายการนี้ — หยุดเพื่อตรวจสอบ'
      using errcode='22023';
  end if;

  /* ---- ⚠ หัวใจของ PDF-FIRST: ไฟล์ต้องพร้อมก่อนเปลี่ยนสถานะใด ๆ ---- */
  if coalesce(d.final_pdf_status,'') <> 'READY'
     or d.final_pdf_path is null
     or coalesce(btrim(d.final_pdf_hash),'') = '' then
    raise exception 'ยังไม่สามารถส่ง 50 ทวิ ได้ เนื่องจาก Final PDF ยังไม่พร้อม '
                    '(สถานะไฟล์ปัจจุบัน %)', coalesce(d.final_pdf_status,'ยังไม่มีไฟล์')
      using errcode='22023';
  end if;

  select * into e from public.employees where id = w.employee_id;
  if not found then raise exception 'ไม่พบข้อมูลพนักงานของเอกสารนี้' using errcode='P0002'; end if;

  /* ---- ผ่านครบแล้วจึงส่งจริง — Transaction เดียวทั้งชุด ---- */
  update public.njhr_emp_documents
     set status     = 'SENT',
         sent_at    = now(),
         sent_by    = c.username,
         updated_at = now(),
         updated_by = c.username
   where id = w.document_id;

  update public.njhr_wht50
     set send_status = 'SENT',
         sent_at     = now(),
         sent_by     = c.username,
         send_count  = coalesce(send_count,0) + 1,
         send_error  = null,
         updated_at  = now(),
         updated_by  = c.username
   where id = p_id;

  begin
    perform public.njhr_doc_event(w.document_id, 'SEND', c.username, c.role,
      'ส่ง 50 ทวิ ปีภาษี ' || (w.tax_year + 543)::text, null);
  exception when undefined_function then null;
  end;

  /* ---- Notification เกิดหลัง PDF READY และหลังสถานะเปลี่ยนครบแล้วเท่านั้น ---- */
  select u.id into v_uid
    from public.app_users u
   where u.employee_id = w.employee_id
     and u.app_code = 'salary' and coalesce(u.is_active,true)
   limit 1;
  if v_uid is not null then
    insert into public.notifications(user_id, title, body, icon)
    values (v_uid, 'เอกสาร 50 ทวิ',
            'มีเอกสาร 50 ทวิ ประจำปีภาษี ' || (w.tax_year + 543)::text || ' ส่งถึงคุณแล้ว',
            'fileText');
  end if;

  begin
    perform public.njhr_audit_write(p_token, 'WHT50_SEND', 'wht50', 'njhr_wht50', w.id::text,
      'ส่ง 50 ทวิ ปีภาษี ' || w.tax_year::text ||
      ' · เลขที่ ' || w.doc_no ||
      ' · พนักงาน ' || coalesce(e.emp_code,'-') ||
      ' · เอกสาร ' || w.document_id::text, null, null, null);
  exception when undefined_function then null;
  end;

  return query select 'SENT'::text, w.document_id, 'SENT'::text, 'ส่งสำเร็จ'::text;
end $function$;


-- ─── 3) สิทธิ์เรียกใช้ — Pattern เดียวกับ 89_wht50_deliver.sql ──
revoke all on function public.njhr_wht50_prepare_document(text, uuid) from public;
grant execute on function public.njhr_wht50_prepare_document(text, uuid) to anon, authenticated;

revoke all on function public.njhr_wht50_send(text, uuid) from public;
grant execute on function public.njhr_wht50_send(text, uuid) to anon, authenticated;

insert into public.njhr_schema_version(version, note)
values ('v3.9-wht50-pdf-first',
        'ลำดับใหม่ 50 ทวิ: prepare_document (DRAFT) → PDF READY → send (SENT + Notification)')
on conflict (version) do nothing;

commit;


-- ════════════════════════════════════════════════════════════
-- VERIFICATION
-- ════════════════════════════════════════════════════════════
select jsonb_pretty(jsonb_build_object(
  'prepare_document มีจริง',
    (to_regprocedure('public.njhr_wht50_prepare_document(text,uuid)') is not null),
  'send ยังมี Signature เดิม',
    (to_regprocedure('public.njhr_wht50_send(text,uuid)') is not null),
  'send บังคับตรวจ READY',
    (select pg_get_functiondef(p.oid) like '%final_pdf_status%READY%'
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname='public' and p.proname='njhr_wht50_send' limit 1),
  'send เลิกใช้ document_id ตัดสินว่าส่งแล้ว',
    (select pg_get_functiondef(p.oid) not like '%w.document_id is not null or w.send_status%'
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname='public' and p.proname='njhr_wht50_send' limit 1),
  'prepare ไม่สร้าง Notification',
    (select pg_get_functiondef(p.oid) not like '%insert into public.notifications%'
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname='public' and p.proname='njhr_wht50_prepare_document' limit 1),
  'prepare ใช้ DRAFT',
    (select pg_get_functiondef(p.oid) like '%''DRAFT'', false%'
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname='public' and p.proname='njhr_wht50_prepare_document' limit 1),
  'claim ไม่ถูกแตะ (ยังรองรับ WHT50)',
    (select pg_get_functiondef(p.oid) like '%WHT50%'
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname='public' and p.proname='njhr_doc_pdf_claim' limit 1),
  'GRANT prepare',
    (select array_to_string(p.proacl,' ') like '%anon=X%'
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname='public' and p.proname='njhr_wht50_prepare_document' limit 1)
)) as report;


-- ════════════════════════════════════════════════════════════
-- ROLLBACK (คืนพฤติกรรมเดิม)
-- ════════════════════════════════════════════════════════════
-- 1. drop function if exists public.njhr_wht50_prepare_document(text, uuid);
-- 2. รัน 89_wht50_deliver.sql ใหม่เพื่อคืน njhr_wht50_send รุ่นเดิม
-- 3. delete from public.njhr_schema_version where version = 'v3.9-wht50-pdf-first';
-- ⚠ ข้อมูลที่ส่งไปแล้วไม่ถูกแตะจากการ Rollback
