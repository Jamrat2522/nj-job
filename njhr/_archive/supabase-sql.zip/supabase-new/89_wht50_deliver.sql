-- ============================================================
-- NJ HR V2 — 89_wht50_deliver.sql
-- เชื่อม njhr_wht50 เข้ากับระบบเอกสารเดิม njhr_emp_documents
--
-- หลักการ: ไม่สร้างระบบเอกสารใหม่ซ้ำ
--   njhr_wht50          = แหล่งความจริงของข้อมูลภาษี (87 · 88)
--   njhr_emp_documents  = ความเป็นเจ้าของ · เอกสารของฉัน · สถานะ · ดาวน์โหลด (60 · 67)
--   เชื่อมกันด้วยคอลัมน์ document_id ที่เพิ่มในไฟล์นี้
--
-- ตรวจแล้วว่าของเดิมมีครบ จึง Reuse ทั้งหมด ไม่แตะแม้แต่บรรทัดเดียว
--   njhr_emp_documents : sent_at · sent_by · viewed_at · doc_meta   (67 บรรทัด 92–100)
--   njhr_doc_view      : ตรวจเจ้าของก่อนนับ "เปิดอ่าน" — ผู้ดูแลเปิดดูไม่นับ (67 บรรทัด 405)
--   njhr_doc_list / njhr_doc_get / njhr_doc_pdf_access : ใช้ของเดิม
--   notifications      : ตารางแจ้งเตือนเดิม
--
-- สถานะแยก 2 แกนตามเดิม ห้ามรวมกัน
--   status      DRAFT · CONFIRMED · CANCELLED · AMENDED   (วงจรเอกสารตามกฎหมาย)
--   send_status NOT_SENT · SENT · OPENED                  (วงจรการส่ง)
--
-- ⚠ แบบฟอร์ม PDF 50 ทวิ ยังไม่พร้อม และ Edge Function njhr-doc-pdf ยังไม่ได้ deploy
--   ไฟล์นี้จึงเตรียม Workflow ไว้ครบ แต่ฝั่งหน้าเว็บยังปิดปุ่มส่งไว้
--   RPC njhr_wht50_send ทำงานได้จริงเมื่อเรียก แต่จะไม่ถูกเรียกจาก UI จนกว่าแบบฟอร์มจะพร้อม
--
-- ต้องรัน 60 · 67 · 87 · 88 มาก่อน · รันซ้ำได้
-- ============================================================

-- ─── 0) PREFLIGHT ───────────────────────────────────────────
do $$
begin
  if to_regclass('public.njhr_wht50') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_wht50 — ต้องรัน 87_wht50.sql ก่อน';
  end if;
  if to_regclass('public.njhr_emp_documents') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_emp_documents — ต้องรัน 60_emp_documents.sql ก่อน';
  end if;
  if not exists (select 1 from information_schema.columns
                  where table_schema='public' and table_name='njhr_wht50'
                    and column_name='send_status') then
    raise exception 'PREFLIGHT: njhr_wht50 ยังไม่มี send_status — ต้องรัน 88_wht50_send.sql ก่อน';
  end if;
  if not exists (select 1 from information_schema.columns
                  where table_schema='public' and table_name='njhr_emp_documents'
                    and column_name='doc_meta') then
    raise exception 'PREFLIGHT: njhr_emp_documents ยังไม่มี doc_meta — ต้องรัน 67_hr_doc_center.sql ก่อน';
  end if;
  if not exists (select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                  where n.nspname='public' and p.proname='njhr_doc_view') then
    raise exception 'PREFLIGHT: ไม่พบ njhr_doc_view — ต้องรัน 67_hr_doc_center.sql ก่อน';
  end if;
  raise notice 'PREFLIGHT ผ่าน';
end $$;


begin;

-- ─── 1) เพิ่มประเภทเอกสาร WHT50 โดยคงของเดิมครบทุกตัว ────────
--  อ่านค่าที่อนุญาตอยู่จริงจาก constraint ปัจจุบัน แล้วเติม WHT50 เข้าไป
--  วิธีนี้ไม่ต้องเดารายชื่อประเภท จึงไม่มีทางทำประเภทเดิมหายแม้ Production
--  จะมีประเภทมากกว่าที่เห็นในไฟล์ 67 (เช่น COE · SALARY_CERT · CONTRACT_PROBATION)
do $$
declare cn text; def text; vals text[]; v text; list text;
begin
  select con.conname, pg_get_constraintdef(con.oid) into cn, def
    from pg_constraint con
    join pg_class r on r.oid = con.conrelid
    join pg_namespace n on n.oid = r.relnamespace
   where n.nspname = 'public' and r.relname = 'njhr_emp_documents'
     and con.contype = 'c' and pg_get_constraintdef(con.oid) ilike '%doc_type%'
   limit 1;

  if cn is null then
    raise exception 'PREFLIGHT: ไม่พบ constraint ของ doc_type — หยุดไว้ก่อน ไม่เดา';
  end if;

  -- ดึงค่าที่อยู่ในเครื่องหมายคำพูดเดี่ยวออกมาทั้งหมด
  select array_agg(distinct m[1]) into vals
    from regexp_matches(def, '''([A-Z0-9_]+)''', 'g') m;

  if vals is null or array_length(vals, 1) < 1 then
    raise exception 'PREFLIGHT: อ่านรายชื่อประเภทเอกสารเดิมไม่ได้ — หยุดไว้ก่อน';
  end if;

  if 'WHT50' = any(vals) then
    raise notice 'มี WHT50 อยู่แล้ว ไม่ต้องแก้ constraint';
    return;
  end if;

  /* ต้องใช้ array_append — เขียน vals || 'WHT50' ไม่ได้
     เพราะ PostgreSQL ตีความ 'WHT50' เป็น array literal แล้วฟ้อง
     ERROR 22P02: malformed array literal */
  vals := array_append(vals, 'WHT50'::text);
  list := '';
  foreach v in array vals loop
    list := list || case when list = '' then '' else ',' end || quote_literal(v);
  end loop;

  execute format('alter table public.njhr_emp_documents drop constraint %I', cn);
  execute format(
    'alter table public.njhr_emp_documents add constraint njhr_empdoc_type_chk check (doc_type in (%s))',
    list);
  raise notice 'เพิ่ม WHT50 แล้ว — ประเภททั้งหมด: %', list;
end $$;


-- ─── 2) เชื่อม njhr_wht50 → njhr_emp_documents ──────────────
alter table public.njhr_wht50
  add column if not exists document_id uuid;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'njhr_wht50_document_fk') then
    alter table public.njhr_wht50
      add constraint njhr_wht50_document_fk
      foreign key (document_id) references public.njhr_emp_documents(id) on delete set null;
  end if;
end $$;

create index if not exists njhr_wht50_document_idx
  on public.njhr_wht50 (document_id) where document_id is not null;

comment on column public.njhr_wht50.document_id is
  'เอกสารใน njhr_emp_documents ที่ส่งเข้า "เอกสารของฉัน" ของพนักงาน — null = ยังไม่ได้ส่ง';


-- ─── 3) ส่ง 50 ทวิ รายคน ────────────────────────────────────
--  ทุกอย่างอยู่ใน Transaction เดียว: สร้างเอกสาร → ผูกกลับ → แจ้งเตือน → Audit
--  ถ้าขั้นใดล้ม ทั้งชุดถูก Rollback — ไม่มีทางที่ send_status เปลี่ยนแต่เอกสารไม่เกิด
--
--  คืนค่า result:
--    SENT          ส่งสำเร็จ
--    ALREADY_SENT  เคยส่งแล้ว — ข้าม ไม่สร้างซ้ำ (ใช้กับ Bulk Send)
--  กรณีอื่นที่ส่งไม่ได้จะ raise exception พร้อมเหตุผลภาษาไทย
create or replace function public.njhr_wht50_send(p_token text, p_id uuid)
returns table (result text, document_id uuid, send_status text, message text)
language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
declare c record; w record; e record; v_doc uuid; v_no text; v_title text; v_uid uuid;
begin
  select * into c from public.njhr_wht50_guard(p_token, true);   -- Role จากฐานข้อมูล

  select * into w from public.njhr_wht50 where id = p_id for update;
  if not found then raise exception 'ไม่พบเอกสาร 50 ทวิ นี้' using errcode='P0002'; end if;

  /* ---- กันส่งซ้ำ: ตรวจก่อนทุกอย่าง แล้วออกแบบเงียบ ๆ ให้ Bulk Send นับเป็น "ข้าม" ---- */
  if w.document_id is not null or w.send_status in ('SENT','OPENED') then
    return query select 'ALREADY_SENT'::text, w.document_id, w.send_status,
                        'ส่งแล้ว ไม่ส่งซ้ำ'::text;
    return;
  end if;

  /* ---- เงื่อนไขความพร้อม ---- */
  if w.status <> 'CONFIRMED' then
    raise exception 'ส่งได้เฉพาะเอกสารที่ยืนยันแล้ว (สถานะปัจจุบัน %)', w.status using errcode='22023';
  end if;
  if w.employee_id is null then
    raise exception 'เอกสารนี้ไม่ได้ผูกกับพนักงาน' using errcode='22023';
  end if;
  if coalesce(btrim(w.doc_no),'') = '' then
    raise exception 'เอกสารนี้ยังไม่มีเลขที่เอกสาร' using errcode='22023';
  end if;

  select * into e from public.employees where id = w.employee_id;
  if not found then raise exception 'ไม่พบข้อมูลพนักงานของเอกสารนี้' using errcode='P0002'; end if;
  if coalesce(btrim(e.national_id),'') = '' then
    raise exception 'พนักงาน % ยังไม่มีเลขประจำตัวประชาชน จึงออก 50 ทวิ ไม่ได้',
      coalesce(e.emp_code,'-') using errcode='22023';
  end if;

  v_title := '50 ทวิ ประจำปีภาษี ' || (w.tax_year + 543)::text;

  /* ---- เลขที่เอกสารของระบบเอกสาร HR — ใช้เลข 50 ทวิ เพื่อสอบทานกลับได้ ---- */
  v_no := 'WHT50-' || w.tax_year::text || '-' || w.doc_no;

  /* ---- สร้างแถวในระบบเอกสารเดิม ----
     body เก็บสรุปสั้น ๆ เพื่อให้หน้ารายการอ่านได้ ไม่ใช่ตัวแบบฟอร์ม
     ตัวแบบฟอร์มจริงจะมาจาก Renderer เฉพาะของ 50 ทวิ (ยังไม่พร้อม)
     ข้อมูลภาษีไม่ duplicate — เก็บ Snapshot ไว้ที่ njhr_wht50 ที่เดียว */
  insert into public.njhr_emp_documents (
    doc_no, version, doc_type, employee_id,
    emp_code_snap, emp_name_snap, dept_snap, position_snap,
    title, body, effective_date, status, requires_signature,
    doc_meta, issued_by, sent_at, sent_by, updated_by)
  values (
    v_no, 1, 'WHT50', w.employee_id,
    e.emp_code,
    btrim(coalesce(e.prefix,'') || coalesce(e.first_name,'') || ' ' || coalesce(e.last_name,'')),
    e.department_name, e.position_name,
    v_title,
    'หนังสือรับรองการหักภาษี ณ ที่จ่าย ปีภาษี ' || (w.tax_year + 543)::text ||
      ' เลขที่ ' || w.doc_no ||
      ' · รายได้รวม ' || to_char(coalesce(w.total_income,0), 'FM999,999,999.00') || ' บาท' ||
      ' · ภาษีหัก ณ ที่จ่าย ' || to_char(coalesce(w.total_tax,0), 'FM999,999,999.00') || ' บาท',
    w.issue_date, 'SENT', false,
    jsonb_build_object(
      'wht50_id',      w.id,
      'tax_year',      w.tax_year,
      'wht50_doc_no',  w.doc_no,
      'amend_seq',     w.amend_seq,
      'form_type',     w.form_type,
      'income_section', w.income_section),
    c.username, now(), c.username, c.username)
  returning id into v_doc;

  /* ---- ผูกกลับ + อัปเดตสถานะการส่ง (Transaction เดียวกัน) ---- */
  update public.njhr_wht50
     set document_id = v_doc,
         send_status = 'SENT',
         sent_at     = now(),
         sent_by     = c.username,
         send_count  = coalesce(send_count,0) + 1,
         send_error  = null,
         updated_at  = now(),
         updated_by  = c.username
   where id = p_id;

  /* ---- Timeline ของระบบเอกสารเดิม ---- */
  begin
    perform public.njhr_doc_event(v_doc, 'SEND', c.username, c.role,
      'ส่ง 50 ทวิ ปีภาษี ' || (w.tax_year + 543)::text, null);
  exception when undefined_function then null;   -- ระบบเก่ากว่าไม่มี event ก็ข้ามได้
  end;

  /* ---- แจ้งเตือนเฉพาะเจ้าของเอกสารคนเดียว ----
     ผูกกับ app_users ของพนักงานคนนั้น ไม่ยิงให้ทุกคน
     ส่ง 1 ครั้งต่อการส่ง 1 ครั้ง — Refresh หน้าเว็บไม่ทำให้เกิดซ้ำ
     เพราะการแจ้งเตือนเกิดตอน insert เท่านั้น ไม่ได้เกิดตอนอ่าน */
  select u.id into v_uid
    from public.app_users u
   where u.employee_id = w.employee_id
     and u.app_code = 'salary' and coalesce(u.is_active,true)
   limit 1;
  if v_uid is not null then
    insert into public.notifications(user_id, title, body, icon)
    values (v_uid, 'เอกสาร 50 ทวิ',
            'มีเอกสาร 50 ทวิ ประจำปีภาษี ' || (w.tax_year + 543)::text || ' ส่งถึงคุณแล้ว',
            'fileText');
  end if;

  /* ---- Audit ---- */
  begin
    perform public.njhr_audit_write(p_token, 'WHT50_SEND', 'wht50', 'njhr_wht50', w.id::text,
      'ส่ง 50 ทวิ ปีภาษี ' || w.tax_year::text ||
      ' · เลขที่ ' || w.doc_no ||
      ' · พนักงาน ' || coalesce(e.emp_code,'-') ||
      ' · เอกสาร ' || v_doc::text, null, null, null);
  exception when undefined_function then null;
  end;

  return query select 'SENT'::text, v_doc, 'SENT'::text, 'ส่งสำเร็จ'::text;
end $$;


-- ─── 4) Sync "เปิดแล้ว" กลับมาที่ njhr_wht50 ────────────────
--  ใช้ Trigger บน njhr_emp_documents เพื่อไม่ต้องแก้ njhr_doc_view
--  (njhr_doc_view เป็นของกลางที่เอกสารทุกชนิดใช้ร่วมกัน — แตะแล้วกระทบเอกสารเดิมทั้งหมด)
--
--  njhr_doc_view ตั้ง status = 'VIEWED' เฉพาะเมื่อ "เจ้าของเอกสารเป็นคนเปิด" เท่านั้น
--  (67 บรรทัด 415: if d.employee_id is distinct from c.employee_id then return)
--  Trigger นี้จึงไม่มีทางถูกจุดจากการที่ผู้ดูแลกด Preview
create or replace function public.njhr_wht50_sync_opened()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.doc_type = 'WHT50'
     and new.status = 'VIEWED' and coalesce(old.status,'') <> 'VIEWED' then
    update public.njhr_wht50
       set send_status = 'OPENED',
           opened_at   = coalesce(new.viewed_at, now()),
           updated_at  = now()
     where document_id = new.id
       and send_status <> 'OPENED';
  end if;
  return new;
end $$;

drop trigger if exists njhr_wht50_opened_trg on public.njhr_emp_documents;
create trigger njhr_wht50_opened_trg
  after update of status on public.njhr_emp_documents
  for each row execute function public.njhr_wht50_sync_opened();

comment on function public.njhr_wht50_sync_opened() is
  'Sync สถานะ "เปิดแล้ว" จาก njhr_emp_documents กลับมาที่ njhr_wht50 — เฉพาะ doc_type = WHT50';


-- ─── 5) สิทธิ์ ──────────────────────────────────────────────
revoke all on function public.njhr_wht50_send(text, uuid) from public;
grant execute on function public.njhr_wht50_send(text, uuid) to anon, authenticated;

insert into public.njhr_schema_version(version, note)
values ('v3.5-wht50-deliver',
        'เชื่อม njhr_wht50 → njhr_emp_documents (document_id · njhr_wht50_send · Trigger sync OPENED)')
on conflict (version) do nothing;

commit;


-- ════════════════════════════════════════════════════════════
-- VERIFICATION
-- ════════════════════════════════════════════════════════════
select jsonb_pretty(jsonb_build_object(
  'WHT50 อยู่ใน doc_type แล้ว',
    (select pg_get_constraintdef(con.oid) ilike '%WHT50%'
       from pg_constraint con join pg_class r on r.oid = con.conrelid
      where r.relname='njhr_emp_documents' and con.contype='c'
        and pg_get_constraintdef(con.oid) ilike '%doc_type%' limit 1),
  'ประเภทเอกสารทั้งหมดที่อนุญาต',
    (select pg_get_constraintdef(con.oid)
       from pg_constraint con join pg_class r on r.oid = con.conrelid
      where r.relname='njhr_emp_documents' and con.contype='c'
        and pg_get_constraintdef(con.oid) ilike '%doc_type%' limit 1),
  'njhr_wht50.document_id',
    (select count(*) = 1 from information_schema.columns
      where table_schema='public' and table_name='njhr_wht50' and column_name='document_id'),
  'FK document_id',
    (select count(*) = 1 from pg_constraint where conname='njhr_wht50_document_fk'),
  'RPC njhr_wht50_send',
    (select count(*) = 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname='njhr_wht50_send'),
  'Trigger sync OPENED',
    (select count(*) = 1 from pg_trigger where tgname='njhr_wht50_opened_trg'),
  'RLS njhr_wht50 ยังเปิด',
    (select relrowsecurity from pg_class where oid='public.njhr_wht50'::regclass),
  'RLS njhr_emp_documents ยังเปิด',
    (select relrowsecurity from pg_class where oid='public.njhr_emp_documents'::regclass),
  'เอกสาร HR เดิมยังอยู่ครบ', (select count(*) from public.njhr_emp_documents),
  'เอกสาร WHT50 ที่ส่งแล้ว',
    (select count(*) from public.njhr_emp_documents where doc_type='WHT50'),
  '50 ทวิ ทั้งหมด', (select count(*) from public.njhr_wht50),
  '50 ทวิ ที่ผูกเอกสารแล้ว',
    (select count(*) from public.njhr_wht50 where document_id is not null)
)) as report;
