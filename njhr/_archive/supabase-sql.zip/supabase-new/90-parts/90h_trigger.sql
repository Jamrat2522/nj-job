-- ============================================================
-- NJ HR V2 — 90 ตอนที่ 8/9 : Trigger บังคับวิธีออกภาษีก่อนยืนยัน
--
-- ⚠ รันตามลำดับเท่านั้น: 90a → 90b → ... → 90i
-- ⚠ ตอนนี้ยังไม่ได้รันบน Production
--
-- รันซ้ำได้ปลอดภัย · ไม่มี begin/commit ในไฟล์
--   (แต่ละคำสั่งเป็นทรานแซกชันของตัวเองอยู่แล้ว)
--
-- เนื้อหาคัดลอกจาก 90_wht50_pdf.sql ทั้งหมด ไม่แก้ตรรกะแม้แต่บรรทัดเดียว
-- ============================================================

-- ─── 6) บังคับให้ระบุวิธีออกภาษีก่อนยืนยันเอกสาร ───────────
--  ใช้ trigger แทนการแก้ njhr_wht50_confirm ทั้งฟังก์ชัน
--  เหตุผล: confirm ของเดิมยาวและมีการออกเลขที่เอกสาร ถ้าคัดลอกมาแก้เสี่ยงพลาด
--  trigger ดักที่จุดเปลี่ยนสถานะเป็น CONFIRMED จึงกันได้ทุกเส้นทาง
--  รวมถึงกรณีมีใครยิง SQL ตรงข้ามหน้าเว็บ
create or replace function public.njhr_wht50_confirm_chk()
returns trigger language plpgsql as $function$
begin
  if new.status = 'CONFIRMED' and coalesce(old.status,'') <> 'CONFIRMED' then
    if coalesce(btrim(coalesce(new.tax_payment_mode,'')),'') = '' then
      raise exception 'กรุณาระบุวิธีออกภาษีก่อนยืนยันเอกสาร' using errcode='22023';
    end if;
    if new.tax_payment_mode = 'OTHER'
       and coalesce(btrim(coalesce(new.tax_payment_mode_other,'')),'') = '' then
      raise exception 'เลือก "อื่น ๆ" ต้องระบุรายละเอียดวิธีออกภาษี' using errcode='22023';
    end if;
  end if;
  return new;
end $function$;

drop trigger if exists njhr_wht50_confirm_chk_trg on public.njhr_wht50;
create trigger njhr_wht50_confirm_chk_trg
  before update on public.njhr_wht50
  for each row execute function public.njhr_wht50_confirm_chk();

revoke all on function public.njhr_wht50_update(text, uuid, jsonb, text) from public;
grant execute on function public.njhr_wht50_update(text, uuid, jsonb, text) to anon, authenticated;

insert into public.njhr_schema_version(version, note)
values ('v3.6-wht50-pdf',
        '50 ทวิ — branch WHT50 ใน pdf claim/commit/status · แยก wht50_id/document_id · วิธีออกภาษี')
on conflict (version) do nothing;

-- ─── ตรวจผลตอนนี้ ───────────────────────────────────────────
select 'ตอนที่ 8 · trigger' as ขั้นตอน,
       (select count(*) from pg_trigger
         where tgname='njhr_wht50_confirm_chk_trg')                        as trigger_ต้องได้_1,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.proname='njhr_wht50_confirm_chk')  as ฟังก์ชัน_ต้องได้_1;
