-- ============================================================
-- NJ HR V2 — 90 ตอนที่ 1/9 : ตรวจก่อนเริ่ม (อ่านอย่างเดียว ไม่แก้อะไร)
--
-- ⚠ รันตามลำดับเท่านั้น: 90a → 90b → ... → 90i
-- ⚠ ตอนนี้ยังไม่ได้รันบน Production
--
-- รันซ้ำได้ปลอดภัย · ไม่มี begin/commit ในไฟล์
--   (แต่ละคำสั่งเป็นทรานแซกชันของตัวเองอยู่แล้ว)
--
-- เนื้อหาคัดลอกจาก 90_wht50_pdf.sql ทั้งหมด ไม่แก้ตรรกะแม้แต่บรรทัดเดียว
-- ============================================================

-- ─── 0) PREFLIGHT ───────────────────────────────────────────
do $$
declare v_def text;
begin
  if to_regclass('public.njhr_wht50') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_wht50 — ต้องรัน 87_wht50.sql ก่อน';
  end if;
  if not exists (select 1 from information_schema.columns
                  where table_schema='public' and table_name='njhr_wht50'
                    and column_name='document_id') then
    raise exception 'PREFLIGHT: njhr_wht50 ยังไม่มี document_id — ต้องรัน 89_wht50_deliver.sql ก่อน';
  end if;
  if not exists (select 1 from information_schema.columns
                  where table_schema='public' and table_name='njhr_wht50'
                    and column_name='seq_no') then
    raise exception 'PREFLIGHT: njhr_wht50 ไม่มีคอลัมน์ seq_no — โครงสร้างไม่ตรงกับที่คาดไว้ หยุดก่อน';
  end if;
  if not exists (select 1 from information_schema.columns
                  where table_schema='public' and table_name='njhr_emp_documents'
                    and column_name='final_pdf_bytes') then
    raise exception 'PREFLIGHT: njhr_emp_documents ไม่มี final_pdf_bytes — ต้องรัน I2_finalpdf.sql ก่อน';
  end if;
  if not exists (select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                  where n.nspname='public' and p.proname='njhr_doc_pdf_claim') then
    raise exception 'PREFLIGHT: ไม่พบ njhr_doc_pdf_claim — ต้องรัน I2_finalpdf.sql ก่อน';
  end if;
  if not exists (select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                  where n.nspname='public' and p.proname='njhr_doc_pdf_status') then
    raise exception 'PREFLIGHT: ไม่พบ njhr_doc_pdf_status — ต้องรัน I2_finalpdf.sql ก่อน';
  end if;
  /* กันแก้ทับของที่เปลี่ยนไปแล้ว: ถ้ามี branch WHT50 อยู่แล้วก็ยังรันซ้ำได้ ไม่เป็นไร */
  select pg_get_functiondef(p.oid) into v_def from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
   where n.nspname='public' and p.proname='njhr_doc_pdf_claim' limit 1;
  if v_def is null then
    raise exception 'PREFLIGHT: อ่านนิยาม njhr_doc_pdf_claim ไม่ได้';
  end if;
  raise notice 'PREFLIGHT ผ่าน';
end $$;

-- ─── ตรวจผลตอนนี้ ───────────────────────────────────────────
select 'ตอนที่ 1 · PREFLIGHT' as ขั้นตอน,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.proname='njhr_doc_pdf_claim')      as claim_ต้องได้_1,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.proname='njhr_doc_pdf_commit')     as commit_ต้องได้_1,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.proname='njhr_doc_pdf_status')     as status_ต้องได้_1,
       (select count(*) from information_schema.columns
         where table_schema='public' and table_name='njhr_wht50'
           and column_name='seq_no')                                       as seq_no_ต้องได้_1,
       (select count(*) from information_schema.columns
         where table_schema='public' and table_name='njhr_emp_documents'
           and column_name='final_pdf_bytes')                              as final_pdf_bytes_ต้องได้_1;
