-- ============================================================
-- NJ HR V2 — 90 ตอนที่ 4/9 : njhr_doc_pdf_commit — เพิ่มทางแยก WHT50
--
-- ⚠ รันตามลำดับเท่านั้น: 90a → 90b → ... → 90i
-- ⚠ ตอนนี้ยังไม่ได้รันบน Production
--
-- รันซ้ำได้ปลอดภัย · ไม่มี begin/commit ในไฟล์
--   (แต่ละคำสั่งเป็นทรานแซกชันของตัวเองอยู่แล้ว)
--
-- เนื้อหาคัดลอกจาก 90_wht50_pdf.sql ทั้งหมด ไม่แก้ตรรกะแม้แต่บรรทัดเดียว
-- ============================================================

-- ─── 2) njhr_doc_pdf_commit — เพิ่มทางแยก WHT50 ─────────────
create or replace function public.njhr_doc_pdf_commit(
  p_token text, p_id uuid, p_path text, p_hash text, p_bytes bigint)
returns table (ok boolean, final_pdf_path text, final_pdf_hash text)
language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
declare c record; d record;
        v_path text := btrim(coalesce(p_path,''));
        v_hash text := lower(btrim(coalesce(p_hash,'')));
begin
  select * into c from public.njhr_ctx(p_token);

  if v_path = '' then raise exception 'ไม่ได้ระบุ storage path' using errcode = '22023'; end if;
  if v_hash !~ '^[0-9a-f]{64}$' then
    raise exception 'final_pdf_hash ต้องเป็น SHA-256 hex 64 ตัว' using errcode = '22023';
  end if;
  if coalesce(p_bytes, 0) <= 0 then
    raise exception 'ขนาดไฟล์ไม่ถูกต้อง' using errcode = '22023';
  end if;

  select * into d from public.njhr_emp_documents where id = p_id for update;
  if not found then raise exception 'ไม่พบเอกสารนี้' using errcode = 'P0002'; end if;
  -- 50 ทวิ บันทึกได้ขณะ SENT / VIEWED โดยไม่ต้อง ACK/SIGN
  -- เอกสารประเภทอื่นใช้เงื่อนไขเดิมทุกประการ
  if d.doc_type = 'WHT50' then
    if d.status not in ('SENT','VIEWED') then
      raise exception 'บันทึก Final PDF ของ 50 ทวิ ได้เมื่อสถานะเป็น SENT หรือ VIEWED (ปัจจุบัน %)', d.status
        using errcode = '22023';
    end if;
  elsif d.status not in ('ACKNOWLEDGED','SIGNED') then
    raise exception 'บันทึก Final PDF ได้เฉพาะเอกสารที่รับทราบ/ลงนามแล้ว' using errcode = '22023';
  end if;
  -- เขียนได้ครั้งเดียวตลอดอายุของ Version นั้น (ข้อ 16)
  if d.final_pdf_path is not null then
    raise exception 'Final PDF ของฉบับนี้ถูกบันทึกไว้แล้ว เขียนทับไม่ได้' using errcode = '42501';
  end if;

  update public.njhr_emp_documents
     set final_pdf_status = 'READY', final_pdf_path = v_path, final_pdf_hash = v_hash,
         final_pdf_bytes = p_bytes, final_pdf_at = now(), final_pdf_error = null
   where njhr_emp_documents.id = p_id;

  perform public.njhr_doc_event(p_id, 'FINAL_PDF_CREATED', c.username, c.role,
    'สร้าง Final PDF สำเร็จ · ' || p_bytes::text || ' bytes · sha256 ' || left(v_hash, 16) || '…', null);
  perform public.njhr_audit_write(p_token, 'FINAL_PDF_CREATED', 'document',
    'njhr_emp_documents', p_id::text,
    d.doc_no || ' v' || d.version::text || ' → Final PDF READY', null, null, null);

  return query select true, x.final_pdf_path, x.final_pdf_hash
    from public.njhr_emp_documents x where x.id = p_id;
end $$;

-- ─── ตรวจผลตอนนี้ ───────────────────────────────────────────
select 'ตอนที่ 4 · commit' as ขั้นตอน,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.prokind='f' and p.proname='njhr_doc_pdf_commit'
           and pg_get_functiondef(p.oid) like '%WHT50%')                   as รองรับ_wht50_ต้องได้_1,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.proname='njhr_doc_pdf_commit')     as มีกี่ตัว_ต้องได้_1,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.prokind='f' and p.proname='njhr_doc_pdf_commit'
           and pg_get_functiondef(p.oid) like '%final_pdf_bytes%')         as ใช้_final_pdf_bytes_ต้องได้_1;
