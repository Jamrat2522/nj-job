-- ============================================================
-- NJ HR V2 — 90 ตอนที่ 6/9 : แยก wht50_id ออกจาก document_id
--
-- ⚠ รันตามลำดับเท่านั้น: 90a → 90b → ... → 90i
-- ⚠ ตอนนี้ยังไม่ได้รันบน Production
--
-- รันซ้ำได้ปลอดภัย · ไม่มี begin/commit ในไฟล์
--   (แต่ละคำสั่งเป็นทรานแซกชันของตัวเองอยู่แล้ว)
--
-- เนื้อหาคัดลอกจาก 90_wht50_pdf.sql ทั้งหมด ไม่แก้ตรรกะแม้แต่บรรทัดเดียว
-- ============================================================

-- ─── 3) แยก wht50_id ออกจาก document_id ในรายการหน้า Admin ───
--  ปัญหาเดิม: njhr_wht50_send_list คืน doc_id ซึ่งเป็น njhr_wht50.id
--  แต่หน้า Admin ต้องใช้ 2 ค่าคนละตัว
--    wht50_id     → njhr_wht50_draft / _get / _update / _confirm / _send
--    document_id  → njhr_doc_pdf_access / njhr_doc_get / ดาวน์โหลด
--  ถ้าใช้ค่าเดียวกันจะเรียก RPC ผิดตัวและเกิดข้อผิดพลาดที่หาสาเหตุยาก
--
--  ⚠ ต้อง DROP ก่อน CREATE เพราะเปลี่ยนชนิดคอลัมน์ที่คืน (RETURNS TABLE)
--    PostgreSQL ไม่อนุญาตให้ CREATE OR REPLACE เปลี่ยนโครงสร้างผลลัพธ์
drop function if exists public.njhr_wht50_send_list(text, int, text, text, text);

create or replace function public.njhr_wht50_send_list(
  p_token text, p_year int, p_q text default null,
  p_send_status text default null, p_dept text default null)
returns table (
  employee_id uuid, emp_code text, full_name text, nickname text,
  national_id_masked text, has_national_id boolean, has_address boolean,
  department_name text, position_name text, emp_status text,
  periods int, total_income numeric, total_tax numeric, total_sso numeric,
  wht50_id uuid, document_id uuid,
  doc_no text, doc_status text, issue_date date, amend_seq int,
  send_status text, sent_at timestamptz, sent_by text, opened_at timestamptz,
  send_count int, is_ready boolean)
language plpgsql stable security definer set search_path = public as $function$
#variable_conflict use_column
declare c record; q text := lower(btrim(coalesce(p_q,'')));
        ss text := nullif(upper(btrim(coalesce(p_send_status,''))),'');
begin
  select * into c from public.njhr_wht50_guard(p_token, false);
  if p_year is null then raise exception 'กรุณาเลือกปีภาษี' using errcode='22023'; end if;
  if ss is not null and ss not in ('NOT_SENT','SENT','OPENED') then
    raise exception 'สถานะการส่งไม่ถูกต้อง (%)', p_send_status using errcode='22023';
  end if;

  return query
  with inc as (
    select p.employee_id eid, count(*)::int n,
           round(coalesce(sum(p.total_income),0),2) ti,
           round(coalesce(sum(p.tax),0),2) tx,
           round(coalesce(sum(p.social_security),0),2) so
      from public.payroll p
     where p.period_year = p_year
       and upper(coalesce(p.status::text,'')) in ('CALCULATED','PAID')
     group by p.employee_id
  ), doc as (
    select d.employee_id eid, d.id wid, d.document_id did, d.doc_no dno, d.status dst,
           d.issue_date idt, d.amend_seq aseq,
           d.send_status sst, d.sent_at sat, d.sent_by sby,
           d.opened_at oat, d.send_count scn
      from public.njhr_wht50 d
     where d.tax_year = p_year and d.status in ('DRAFT','CONFIRMED')
  )
  select e.id, e.emp_code,
         coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,''),
         coalesce(e.nickname,''),
         public.njhr_wht50_mask_id(e.national_id),
         coalesce(btrim(e.national_id),'') <> '',
         coalesce(btrim(e.address),'') <> '',
         coalesce(e.department_name,''), coalesce(e.position_name,''), e.status::text,
         coalesce(inc.n, 0), coalesce(inc.ti, 0), coalesce(inc.tx, 0), coalesce(inc.so, 0),
         doc.wid,                                    -- wht50_id  → draft/confirm/send
         doc.did,                                    -- document_id → pdf access/download
         coalesce(doc.dno,''), coalesce(doc.dst,'NONE'), doc.idt, coalesce(doc.aseq,0),
         coalesce(doc.sst,'NOT_SENT'), doc.sat, coalesce(doc.sby,''), doc.oat,
         coalesce(doc.scn,0),
         (coalesce(doc.dst,'NONE') = 'CONFIRMED'
          and coalesce(doc.sst,'NOT_SENT') = 'NOT_SENT'
          and coalesce(btrim(e.national_id),'') <> '')
    from public.employees e
    left join inc on inc.eid = e.id
    left join doc on doc.eid = e.id
   where coalesce(inc.n,0) > 0
     and (p_dept is null or p_dept = '' or e.department_name = p_dept)
     and (ss is null or coalesce(doc.sst,'NOT_SENT') = ss)
     and (q = '' or lower(coalesce(e.emp_code,'')) like '%'||q||'%'
          or lower(coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,'')) like '%'||q||'%'
          or lower(coalesce(e.nickname,'')) like '%'||q||'%'
          or lower(coalesce(e.department_name,'')) like '%'||q||'%')
   order by e.emp_code;
end $function$;

revoke all on function public.njhr_wht50_send_list(text,int,text,text,text) from public;
grant execute on function public.njhr_wht50_send_list(text,int,text,text,text) to anon, authenticated;

-- ─── ตรวจผลตอนนี้ ───────────────────────────────────────────
select 'ตอนที่ 6 · send_list' as ขั้นตอน,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.proname='njhr_wht50_send_list'
           and pg_get_function_result(p.oid) like '%wht50_id%'
           and pg_get_function_result(p.oid) like '%document_id%')         as แยก_id_ต้องได้_1,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.proname='njhr_wht50_send_list')    as มีกี่ตัว_ต้องได้_1;
