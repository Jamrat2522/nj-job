-- ============================================================
-- NJ HR V2 — 90 ตอนที่ 3/9 : njhr_doc_pdf_claim — เพิ่มทางแยก WHT50
--
-- ⚠ รันตามลำดับเท่านั้น: 90a → 90b → ... → 90i
-- ⚠ ตอนนี้ยังไม่ได้รันบน Production
--
-- รันซ้ำได้ปลอดภัย · ไม่มี begin/commit ในไฟล์
--   (แต่ละคำสั่งเป็นทรานแซกชันของตัวเองอยู่แล้ว)
--
-- เนื้อหาคัดลอกจาก 90_wht50_pdf.sql ทั้งหมด ไม่แก้ตรรกะแม้แต่บรรทัดเดียว
-- ============================================================

-- ─── 1) njhr_doc_pdf_claim — เพิ่มทางแยก WHT50 ──────────────
create or replace function public.njhr_doc_pdf_claim(p_token text, p_id uuid)
returns table (claimed boolean, already_ready boolean, data jsonb)
language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
declare c record; d record; a record; o record; w record; v_mgr boolean;
begin
  select * into c from public.njhr_ctx(p_token);
  v_mgr := c.role in ('SUPER_ADMIN','ADMIN','HR');

  select * into d from public.njhr_emp_documents where id = p_id for update;
  if not found then raise exception 'ไม่พบเอกสารนี้' using errcode = 'P0002'; end if;

  -- เจ้าของเอกสาร หรือผู้มีสิทธิ์บริหารเท่านั้น
  if not v_mgr and d.employee_id is distinct from c.employee_id then
    raise exception 'ดำเนินการได้เฉพาะเอกสารของตนเองเท่านั้น' using errcode = '42501';
  end if;

  -- READY แล้ว = ไม่สร้างซ้ำ ไม่ overwrite (ใช้ร่วมทุกประเภทเอกสาร)
  if d.final_pdf_status = 'READY' and d.final_pdf_path is not null then
    return query select false, true, jsonb_build_object(
      'id', d.id, 'final_pdf_path', d.final_pdf_path, 'final_pdf_hash', d.final_pdf_hash);
    return;
  end if;

  -- ══════════════ ทางแยก WHT50 (50 ทวิ) ══════════════
  -- 50 ทวิ เป็นเอกสารแจ้งให้ทราบ requires_signature = false และไม่มีแถวรับทราบ
  -- จึงไม่บังคับ ACKNOWLEDGED/SIGNED · Snapshot มาจาก njhr_wht50 ไม่ใช่ body
  -- เอกสารประเภทอื่นไม่เข้าทางนี้ และใช้เงื่อนไขเดิมทุกบรรทัดด้านล่าง
  if d.doc_type = 'WHT50' then
    select * into w from public.njhr_wht50 where document_id = p_id;
    if not found then
      raise exception 'เอกสารนี้ไม่ได้ผูกกับข้อมูล 50 ทวิ' using errcode = 'P0002';
    end if;
    if w.status <> 'CONFIRMED' then
      raise exception 'สร้าง Final PDF ได้เฉพาะ 50 ทวิ ที่ยืนยันแล้ว (สถานะปัจจุบัน %)', w.status
        using errcode = '22023';
    end if;

    update public.njhr_emp_documents
       set final_pdf_status = 'PENDING', final_pdf_error = null
     where njhr_emp_documents.id = p_id;

    perform public.njhr_doc_event(p_id, 'FINAL_PDF_CLAIM', c.username, c.role,
      'เริ่มสร้าง Final PDF (50 ทวิ)', null);

    return query select true, false, jsonb_build_object(
      'doc', jsonb_build_object(
        'id', d.id, 'doc_no', d.doc_no, 'version', d.version, 'doc_type', d.doc_type,
        'title', d.title, 'status', d.status,
        'emp_code_snap', coalesce(d.emp_code_snap,''),
        'emp_name_snap', coalesce(d.emp_name_snap,''),
        'doc_meta', d.doc_meta),
      'wht50', jsonb_build_object(
        'id', w.id, 'tax_year', w.tax_year,
        'doc_no', w.doc_no, 'book_no', w.book_no, 'seq_no', w.seq_no,
        'form_type', w.form_type, 'income_section', w.income_section,
        'payer_snapshot', w.payer_snapshot, 'payee_snapshot', w.payee_snapshot,
        'income_final', w.income_final,
        'total_income', w.total_income, 'total_tax', w.total_tax,
        'total_sso', w.total_sso, 'total_pvd', w.total_pvd,
        'issue_date', w.issue_date,
        'tax_payment_mode', w.tax_payment_mode,
        'tax_payment_mode_other', w.tax_payment_mode_other,
        'signer_name', w.signer_name, 'signer_position', w.signer_position,
        'amend_seq', w.amend_seq),
      'storage_path', 'wht50/' || w.tax_year::text || '/' || d.id::text || '.pdf',
      'hash_match', true);
    return;
  end if;
  -- ══════════════ จบทางแยก WHT50 ══════════════

  -- สร้างได้เฉพาะเอกสารที่รับทราบ/ลงนามสำเร็จแล้ว (ข้อ 6 ของ PROMPT 3)
  if d.status not in ('ACKNOWLEDGED','SIGNED') then
    raise exception 'สร้าง Final PDF ได้เฉพาะเอกสารที่รับทราบ/ลงนามแล้ว (สถานะปัจจุบัน %)', d.status
      using errcode = '22023';
  end if;

  select * into a from public.njhr_emp_doc_acks
   where document_id = p_id order by acked_at desc limit 1;
  if not found then
    raise exception 'ไม่พบหลักฐานการรับทราบ/ลงนามของเอกสารนี้' using errcode = 'P0002';
  end if;

  select * into o from public.njhr_org_profile where id = 1;

  update public.njhr_emp_documents
     set final_pdf_status = 'PENDING', final_pdf_error = null
   where njhr_emp_documents.id = p_id;

  perform public.njhr_doc_event(p_id, 'FINAL_PDF_CLAIM', c.username, c.role,
    'เริ่มสร้าง Final PDF', null);

  return query select true, false, jsonb_build_object(
    -- ---- Snapshot ของเอกสาร (ห้ามดึงข้อมูลพนักงานปัจจุบันมาแทน) ----
    'doc', jsonb_build_object(
      'id', d.id, 'doc_no', d.doc_no, 'version', d.version, 'doc_type', d.doc_type,
      'title', d.title, 'body', d.body,
      'effective_date', d.effective_date, 'issued_at', d.issued_at,
      'requires_signature', d.requires_signature, 'status', d.status,
      'emp_code_snap', coalesce(d.emp_code_snap,''),
      'emp_name_snap', coalesce(d.emp_name_snap,''),
      'dept_snap', coalesce(d.dept_snap,''),
      'position_snap', coalesce(d.position_snap,''),
      'doc_meta', d.doc_meta,
      'content_hash', d.content_hash,
      'sent_at', d.sent_at, 'responded_at', d.responded_at, 'locked_at', d.locked_at),
    -- ---- หลักฐานการรับทราบ/ลงนาม (เวลาจาก Server เท่านั้น) ----
    'ack', jsonb_build_object(
      'action', a.action, 'emp_code', coalesce(a.emp_code,''),
      'emp_name', coalesce(a.emp_name,''), 'department', coalesce(a.department,''),
      'acked_at', a.acked_at,
      'acked_at_th', to_char(a.acked_at at time zone 'Asia/Bangkok', 'DD/MM/') ||
                     (extract(year from (a.acked_at at time zone 'Asia/Bangkok'))::int + 543)::text ||
                     to_char(a.acked_at at time zone 'Asia/Bangkok', ' HH24:MI'),
      'doc_version', a.doc_version,
      'doc_hash', coalesce(a.doc_hash,''),
      'confirmation_text', coalesce(a.confirmation_text,''),
      'channel', coalesce(a.channel,''), 'device', coalesce(a.device,'')),
      -- หมายเหตุ: ไม่คืน ip_address / user_agent / signature_path ออกไปสร้าง PDF
      --           และไม่มี password / token ใด ๆ ตามข้อ 25
    'org', coalesce(to_jsonb(o), '{}'::jsonb),
    -- ---- ตรวจความสอดคล้องของ Hash (ข้อ 11) ----
    'hash_match', (a.doc_hash is not distinct from d.content_hash),
    -- ---- ชื่อไฟล์ที่กำหนดฝั่งเซิร์ฟเวอร์ (client กำหนดเองไม่ได้) ----
    'storage_path', d.employee_id::text || '/' ||
      regexp_replace(d.doc_no, '[^A-Za-z0-9_-]+', '_', 'g') || '/v' || d.version::text || '/' ||
      regexp_replace(d.doc_no, '[^A-Za-z0-9_-]+', '_', 'g') || '_v' || d.version::text || '_' ||
      case when a.action = 'SIGN' then 'signed' else 'acknowledged' end || '.pdf');
end $$;

-- ─── ตรวจผลตอนนี้ ───────────────────────────────────────────
select 'ตอนที่ 3 · claim' as ขั้นตอน,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.prokind='f' and p.proname='njhr_doc_pdf_claim'
           and pg_get_functiondef(p.oid) like '%WHT50%')                   as รองรับ_wht50_ต้องได้_1,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.proname='njhr_doc_pdf_claim')      as มีกี่ตัว_ต้องได้_1,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.prokind='f' and p.proname='njhr_doc_pdf_claim'
           and pg_get_functiondef(p.oid) like '%ACKNOWLEDGED%')            as เอกสารเดิมยังบังคับ_ack_ต้องได้_1;
