-- ============================================================
-- NJ HR V2 — 90 ตอนที่ 2/9 : เพิ่มคอลัมน์วิธีออกภาษี + CHECK
--
-- ⚠ รันตามลำดับเท่านั้น: 90a → 90b → ... → 90i
-- ⚠ ตอนนี้ยังไม่ได้รันบน Production
--
-- รันซ้ำได้ปลอดภัย · ไม่มี begin/commit ในไฟล์
--   (แต่ละคำสั่งเป็นทรานแซกชันของตัวเองอยู่แล้ว)
--
-- เนื้อหาคัดลอกจาก 90_wht50_pdf.sql ทั้งหมด ไม่แก้ตรรกะแม้แต่บรรทัดเดียว
-- ============================================================

-- ─── 4) วิธีออกภาษี (ช่อง "ผู้จ่ายเงิน" ตามแบบกรมสรรพากร) ───
--  แบบฟอร์ม 50 ทวิ บังคับให้ทำเครื่องหมายว่าภาษีนี้
--    (1) หัก ณ ที่จ่าย  (2) ออกให้ตลอดไป  (3) ออกให้ครั้งเดียว  (4) อื่น ๆ
--  Production ยังไม่มีคอลัมน์เก็บ Renderer จึงติ๊กไม่ได้และไม่ยอมออกเอกสาร
--  ใช้ text + CHECK ตามแบบเดียวกับ status / form_type ของตารางนี้ (ไม่สร้าง enum ใหม่)
alter table public.njhr_wht50
  add column if not exists tax_payment_mode text,
  add column if not exists tax_payment_mode_other text;

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'njhr_wht50_paymode_chk') then
    alter table public.njhr_wht50
      add constraint njhr_wht50_paymode_chk
      check (tax_payment_mode is null or tax_payment_mode in
             ('WITHHOLD','PAID_CONTINUOUS','PAID_ONCE','OTHER'));
  end if;
end $$;

comment on column public.njhr_wht50.tax_payment_mode is
  'วิธีออกภาษีตามแบบ 50 ทวิ: WITHHOLD=หัก ณ ที่จ่าย · PAID_CONTINUOUS=ออกให้ตลอดไป · PAID_ONCE=ออกให้ครั้งเดียว · OTHER=อื่น ๆ';
comment on column public.njhr_wht50.tax_payment_mode_other is
  'รายละเอียดเมื่อ tax_payment_mode = OTHER';

-- ─── ตรวจผลตอนนี้ ───────────────────────────────────────────
select 'ตอนที่ 2 · คอลัมน์วิธีออกภาษี' as ขั้นตอน,
       (select count(*) from information_schema.columns
         where table_schema='public' and table_name='njhr_wht50'
           and column_name in ('tax_payment_mode','tax_payment_mode_other')) as คอลัมน์_ต้องได้_2,
       (select count(*) from pg_constraint
         where conname='njhr_wht50_paymode_chk')                            as check_ต้องได้_1;
