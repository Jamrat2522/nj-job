-- ============================================================
-- NJ HR V2 — 90 ตอนที่ 7/9 : njhr_wht50_update — รับคีย์วิธีออกภาษี
--
-- ⚠ รันตามลำดับเท่านั้น: 90a → 90b → ... → 90i
-- ⚠ ตอนนี้ยังไม่ได้รันบน Production
--
-- รันซ้ำได้ปลอดภัย · ไม่มี begin/commit ในไฟล์
--   (แต่ละคำสั่งเป็นทรานแซกชันของตัวเองอยู่แล้ว)
--
-- เนื้อหาคัดลอกจาก 90_wht50_pdf.sql ทั้งหมด ไม่แก้ตรรกะแม้แต่บรรทัดเดียว
-- ============================================================

-- ─── 5) njhr_wht50_update — เพิ่ม 2 คีย์ใหม่ ────────────────
--  ⚠ เนื้อหาคัดลอกจาก 87_wht50.sql ทั้งฟังก์ชัน แล้วแทรกเฉพาะ 3 จุดที่ทำเครื่องหมาย ▼
--    Logic เดิมอยู่ครบทุกบรรทัด:
--      · แก้ได้เฉพาะ DRAFT
--      · income_final merge ด้วย ||
--      · ยอดต่างจาก income_source ต้องมี p_reason
--      · คำนวณ total_income / total_tax / total_sso / total_pvd จาก v_final
--      · audit WHT50_EDIT ด้วย njhr_audit_write
--      · updated_at / updated_by
create or replace function public.njhr_wht50_update(
  p_token text, p_id uuid, p_patch jsonb, p_reason text default null)
returns table (id uuid, status text)
language plpgsql security definer set search_path = public as $function$
#variable_conflict use_column
declare c record; d record; oldrow jsonb; v_final jsonb;
        v_reason text := nullif(btrim(coalesce(p_reason,'')),'');
        -- ▼ เพิ่มรอบนี้: วิธีออกภาษี
        v_mode text := nullif(btrim(coalesce(p_patch->>'tax_payment_mode','')),'');
        v_other text;
begin
  select * into c from public.njhr_wht50_guard(p_token, true);
  select * into d from public.njhr_wht50 where njhr_wht50.id = p_id for update;
  if not found then raise exception 'ไม่พบเอกสารนี้' using errcode='P0002'; end if;
  if d.status <> 'DRAFT' then
    raise exception 'เอกสารสถานะ "%" แก้ไขโดยตรงไม่ได้ — ให้ยกเลิกแล้วออกฉบับแก้ไข', d.status
      using errcode='42501';
  end if;
  oldrow := to_jsonb(d);

  /* ▼ เพิ่มรอบนี้: เลือก "อื่น ๆ" ต้องมีรายละเอียด — ตรวจที่ Server ด้วย
     ไม่พึ่งหน้าเว็บอย่างเดียว กันการยิง RPC ตรง */
  v_other := coalesce(nullif(btrim(coalesce(p_patch->>'tax_payment_mode_other','')),''),
                      d.tax_payment_mode_other);
  if coalesce(v_mode, d.tax_payment_mode) = 'OTHER'
     and coalesce(btrim(coalesce(v_other,'')),'') = '' then
    raise exception 'กรุณาระบุรายละเอียดวิธีออกภาษี' using errcode='22023';
  end if;

  v_final := d.income_final || coalesce(p_patch->'income_final', '{}'::jsonb);
  -- ยอดต่างจากต้นทาง = ต้องมีเหตุผลเสมอ
  if v_final is distinct from d.income_source and v_reason is null and d.adjust_reason is null then
    raise exception 'การแก้ยอดเงินต้องระบุเหตุผล' using errcode='22023';
  end if;

  update public.njhr_wht50 set
    form_type       = coalesce(nullif(btrim(p_patch->>'form_type'),''), form_type),
    income_section  = coalesce(nullif(btrim(p_patch->>'income_section'),''), income_section),
    seq_no          = coalesce(nullif(p_patch->>'seq_no','')::int, seq_no),
    book_no         = coalesce(nullif(btrim(p_patch->>'book_no'),''), book_no),
    issue_date      = coalesce(nullif(p_patch->>'issue_date','')::date, issue_date),
    payee_snapshot  = payee_snapshot || coalesce(p_patch->'payee_snapshot', '{}'::jsonb),
    income_final    = v_final,
    total_income    = coalesce(nullif(v_final->>'total_income','')::numeric, total_income),
    total_tax       = coalesce(nullif(v_final->>'tax','')::numeric, total_tax),
    total_sso       = coalesce(nullif(v_final->>'social_security','')::numeric, total_sso),
    total_pvd       = coalesce(nullif(v_final->>'pvd','')::numeric, total_pvd),
    note            = coalesce(p_patch->>'note', note),
    signer_name     = coalesce(nullif(btrim(p_patch->>'signer_name'),''), signer_name),
    signer_position = coalesce(nullif(btrim(p_patch->>'signer_position'),''), signer_position),
    -- ▼ เพิ่มรอบนี้ 2 บรรทัด (บรรทัดอื่นคัดลอกจาก 87_wht50.sql ทั้งหมด)
    tax_payment_mode       = coalesce(v_mode, tax_payment_mode),
    tax_payment_mode_other = case when coalesce(v_mode, tax_payment_mode) = 'OTHER'
                                  then v_other else null end,
    adjust_reason   = coalesce(v_reason, adjust_reason),
    updated_at = now(), updated_by = c.username
   where njhr_wht50.id = p_id;

  perform public.njhr_audit_write(p_token, 'WHT50_EDIT', 'payroll', 'njhr_wht50', p_id::text,
    'แก้ไขร่าง 50 ทวิ' || coalesce(' · เหตุผล: ' || v_reason, ''), oldrow,
    (select to_jsonb(x) from public.njhr_wht50 x where x.id = p_id), null);

  return query select x.id, x.status from public.njhr_wht50 x where x.id = p_id;
end $function$;

-- ─── ตรวจผลตอนนี้ ───────────────────────────────────────────
select 'ตอนที่ 7 · update' as ขั้นตอน,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.prokind='f' and p.proname='njhr_wht50_update'
           and pg_get_functiondef(p.oid) like '%tax_payment_mode%')        as รับคีย์ใหม่_ต้องได้_1,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.prokind='f' and p.proname='njhr_wht50_update'
           and pg_get_functiondef(p.oid) like '%WHT50_EDIT%'
           and pg_get_functiondef(p.oid) like '%การแก้ยอดเงินต้องระบุเหตุผล%'
           and pg_get_functiondef(p.oid) like '%v_final%')                 as logic_เดิมครบ_ต้องได้_1,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.proname='njhr_wht50_update')       as มีกี่ตัว_ต้องได้_1;
