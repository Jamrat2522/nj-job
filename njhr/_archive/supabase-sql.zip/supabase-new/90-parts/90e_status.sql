-- ============================================================
-- NJ HR V2 — 90 ตอนที่ 5/9 : njhr_doc_pdf_status — can_generate ของ WHT50
--
-- ⚠ รันตามลำดับเท่านั้น: 90a → 90b → ... → 90i
-- ⚠ ตอนนี้ยังไม่ได้รันบน Production
--
-- รันซ้ำได้ปลอดภัย · ไม่มี begin/commit ในไฟล์
--   (แต่ละคำสั่งเป็นทรานแซกชันของตัวเองอยู่แล้ว)
--
-- เนื้อหาคัดลอกจาก 90_wht50_pdf.sql ทั้งหมด ไม่แก้ตรรกะแม้แต่บรรทัดเดียว
-- ============================================================

-- ─── 2b) njhr_doc_pdf_status — can_generate ของ WHT50 ───────
--  เดิม can_generate เป็นจริงเฉพาะ ACKNOWLEDGED/SIGNED
--  ทำให้หน้าเว็บเห็นว่า 50 ทวิ สร้าง PDF ไม่ได้ทั้งที่ Pipeline รองรับแล้ว
--  เนื้อหาส่วนอื่นคัดลอกจาก I2_finalpdf.sql มาทั้งหมด ไม่แก้บรรทัดอื่น
create or replace function public.njhr_doc_pdf_status(p_token text, p_id uuid)
returns table (data jsonb)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare c record; d record; v_mgr boolean;
begin
  select * into d from public.njhr_emp_documents where id = p_id;
  if not found then raise exception 'ไม่พบเอกสารนี้' using errcode = 'P0002'; end if;

  select * into c from public.njhr_ctx(p_token);
  v_mgr := c.role in ('SUPER_ADMIN','ADMIN','HR');
  if not v_mgr and d.employee_id is distinct from c.employee_id then
    raise exception 'ดูได้เฉพาะเอกสารของตนเองเท่านั้น' using errcode = '42501';
  end if;

  return query select jsonb_build_object(
    'id', d.id, 'doc_no', d.doc_no, 'version', d.version, 'status', d.status,
    'final_pdf_status', d.final_pdf_status,
    'final_pdf_at', d.final_pdf_at,
    'final_pdf_bytes', d.final_pdf_bytes,
    'final_pdf_hash', d.final_pdf_hash,
    'final_pdf_error', case when v_mgr then d.final_pdf_error else null end,
    -- ควรสั่งสร้างได้ไหม: ตอบแล้วแต่ PDF ยังไม่พร้อม
    -- ══ WHT50: สร้างได้เมื่อ SENT/VIEWED (ไม่ต้อง ACK/SIGN) · อื่น ๆ เงื่อนไขเดิม ══
    'can_generate', (case when d.doc_type = 'WHT50'
                          then d.status in ('SENT','VIEWED')
                          else d.status in ('ACKNOWLEDGED','SIGNED') end
                     and coalesce(d.final_pdf_status,'') <> 'READY'),
    'can_download', (d.final_pdf_status = 'READY' and d.final_pdf_path is not null));
end $$;

-- ─── ตรวจผลตอนนี้ ───────────────────────────────────────────
select 'ตอนที่ 5 · status' as ขั้นตอน,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.prokind='f' and p.proname='njhr_doc_pdf_status'
           and pg_get_functiondef(p.oid) like '%WHT50%')                   as รองรับ_wht50_ต้องได้_1,
       (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
         where n.nspname='public' and p.proname='njhr_doc_pdf_status')     as มีกี่ตัว_ต้องได้_1;
