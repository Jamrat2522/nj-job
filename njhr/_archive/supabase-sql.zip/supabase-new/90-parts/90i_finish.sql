-- ============================================================
-- NJ HR V2 — 90 ตอนที่ 9/9 : บันทึกรุ่นและตรวจผลรวมทั้งหมด
--
-- ⚠ รันเป็นตอนสุดท้าย หลังจาก 90a–90h ผ่านครบแล้วเท่านั้น
-- รันซ้ำได้ปลอดภัย
-- ============================================================

insert into public.njhr_schema_version(version, note)
values ('v3.6-wht50-pdf',
        '50 ทวิ — branch WHT50 ใน pdf claim/commit/status · แยก wht50_id/document_id · วิธีออกภาษี')
on conflict (version) do nothing;


-- ─── ตรวจผลรวมทั้งหมด — ทุกช่องต้องได้ตามที่ระบุ ───────────
select
  (select count(*) from information_schema.columns
    where table_schema='public' and table_name='njhr_wht50'
      and column_name in ('tax_payment_mode','tax_payment_mode_other'))     as ครบ_1_คอลัมน์_ต้องได้_2,

  (select count(*) from pg_constraint where conname='njhr_wht50_paymode_chk') as ครบ_2_check_ต้องได้_1,

  (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.prokind='f' and p.proname='njhr_doc_pdf_claim'
      and pg_get_functiondef(p.oid) like '%WHT50%')                          as ครบ_3_claim_ต้องได้_1,

  (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.prokind='f' and p.proname='njhr_doc_pdf_commit'
      and pg_get_functiondef(p.oid) like '%WHT50%')                          as ครบ_4_commit_ต้องได้_1,

  (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.prokind='f' and p.proname='njhr_doc_pdf_status'
      and pg_get_functiondef(p.oid) like '%WHT50%')                          as ครบ_5_status_ต้องได้_1,

  (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname='njhr_wht50_send_list'
      and pg_get_function_result(p.oid) like '%wht50_id%'
      and pg_get_function_result(p.oid) like '%document_id%')                as ครบ_6_sendlist_ต้องได้_1,

  (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.prokind='f' and p.proname='njhr_wht50_update'
      and pg_get_functiondef(p.oid) like '%tax_payment_mode%')               as ครบ_7_update_ต้องได้_1,

  (select count(*) from pg_trigger where tgname='njhr_wht50_confirm_chk_trg') as ครบ_8_trigger_ต้องได้_1,

  (select count(*) from public.njhr_schema_version
    where version='v3.6-wht50-pdf')                                          as ครบ_9_ledger_ต้องได้_1,

  -- ของเดิมต้องไม่พัง
  (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname='njhr_doc_pdf_commit')            as ไม่ซ้อน_commit_ต้องได้_1,

  (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.prokind='f' and p.proname='njhr_wht50_update'
      and pg_get_functiondef(p.oid) like '%WHT50_EDIT%'
      and pg_get_functiondef(p.oid) like '%การแก้ยอดเงินต้องระบุเหตุผล%'
      and pg_get_functiondef(p.oid) like '%v_final%')                        as logic_เดิมครบ_ต้องได้_1,

  (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.prokind='f' and p.proname='njhr_doc_pdf_claim'
      and pg_get_functiondef(p.oid) like '%ACKNOWLEDGED%')                    as เอกสารเดิมยังบังคับ_ack_ต้องได้_1,

  (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
    where n.nspname='public' and p.proname in
      ('njhr_wht50_send','njhr_wht50_send_summary','njhr_wht50_sync_opened')) as rpc_เชื่อมเดิม_ต้องได้_3,

  (select count(*) from pg_trigger where tgname='njhr_wht50_opened_trg')      as trigger_เดิม_ต้องได้_1;
