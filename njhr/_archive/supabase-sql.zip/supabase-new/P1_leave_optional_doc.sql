-- ============================================================
-- NJ HR V2 — P1_leave_optional_doc.sql
-- ถอดกฎ "ลาป่วยต้องแนบเอกสารประกอบ" ออกจาก njhr_leave_submit
--
-- ที่มาของเนื้อฟังก์ชัน: pg_get_functiondef ของ Production โดยตรง
--   signature: p_token, p_leave_type, p_mode, p_start_date, p_end_date,
--              p_start_time, p_end_time, p_reason, p_delegate,
--              p_files jsonb, p_client_key
--   returns  : TABLE(id uuid, total_days numeric, hours numeric,
--                    duplicated boolean, file_count integer)
--   ตรงกับ supabase-new/46_leave_form.sql ไม่ใช่ 41_leave_rpc.sql (เวอร์ชันเก่า)
--
-- สิ่งเดียวที่เปลี่ยน — ลบ 3 บรรทัดนี้:
--     if v_type = 'SICK' and v_n = 0 then
--       raise exception 'ลาป่วยต้องแนบเอกสารประกอบ' using errcode='22023';
--     end if;
--
-- ไม่แตะ: signature · returns · p_files jsonb · การกันกดส่งซ้ำ (client_key) ·
--         ตรวจเหตุผล · วันที่ · โหมด FULL/HALF/HOURLY · ห้ามทับช่วง · โควตา ·
--         ตรวจ name/url ของไฟล์แนบ · insert leave_requests · leave_attachments ·
--         notifications · njhr_leave_audit · Workflow · สถานะ · สิทธิ์
-- คำขอที่มีไฟล์แนบเดิมไม่ได้รับผลกระทบ (ไม่แตะข้อมูลและไม่แตะตาราง)
-- รันซ้ำได้
-- ============================================================

do $$
begin
  if not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                  where n.nspname='public' and p.proname='njhr_leave_submit'
                    and pg_get_function_identity_arguments(p.oid) like '%p_files%') then
    raise exception 'PREFLIGHT: ไม่พบ njhr_leave_submit เวอร์ชัน p_files — หยุด';
  end if;
  raise notice 'PREFLIGHT ผ่าน';
end $$;

CREATE OR REPLACE FUNCTION public.njhr_leave_submit(
  p_token text, p_leave_type text, p_mode text,
  p_start_date date, p_end_date date,
  p_start_time time without time zone DEFAULT NULL::time without time zone,
  p_end_time time without time zone DEFAULT NULL::time without time zone,
  p_reason text DEFAULT ''::text, p_delegate uuid DEFAULT NULL::uuid,
  p_files jsonb DEFAULT NULL::jsonb, p_client_key text DEFAULT NULL::text)
RETURNS TABLE(id uuid, total_days numeric, hours numeric, duplicated boolean, file_count integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
#variable_conflict use_column
declare
  c record; v_type public.leave_type; v_end date; v_days numeric := 0; v_hours numeric := 0;
  v_unit text; v_half boolean := false; v_quota numeric; v_usedpend numeric; v_id uuid; v_dup uuid;
  v_files jsonb := coalesce(p_files, '[]'::jsonb); v_n int := 0; f jsonb;
begin
  select * into c from public.njhr_ctx(p_token);
  if c.employee_id is null then
    raise exception 'บัญชีนี้ยังไม่ได้เชื่อมกับข้อมูลพนักงาน' using errcode='28000';
  end if;
  if jsonb_typeof(v_files) <> 'array' then
    raise exception 'รูปแบบไฟล์แนบไม่ถูกต้อง' using errcode='22023';
  end if;

  -- กันกดส่งซ้ำ: key เดิมภายใน 10 นาที = คืนใบเดิม ไม่สร้างซ้ำ
  if p_client_key is not null and p_client_key <> '' then
    select r.id into v_dup from public.leave_requests r
     where r.employee_id = c.employee_id
       and r.created_at > now() - interval '10 minutes'
       and r.approvals->0->'meta'->>'client_key' = p_client_key
     limit 1;
    if v_dup is not null then
      return query select v_dup, r.total_days, r.hours, true,
                          (select count(*)::int from public.leave_attachments a where a.leave_id = v_dup)
                     from public.leave_requests r where r.id = v_dup;
      return;
    end if;
  end if;

  begin v_type := upper(p_leave_type)::public.leave_type;
  exception when others then
    raise exception 'ประเภทการลาไม่ถูกต้อง (%)', p_leave_type using errcode='22023';
  end;

  if coalesce(btrim(p_reason),'') = '' then
    raise exception 'กรุณาระบุเหตุผลการลา' using errcode='22023';
  end if;

  v_end := case when upper(p_mode) = 'FULL' then p_end_date else p_start_date end;
  if p_start_date > v_end then
    raise exception 'วันที่เริ่มต้องไม่มากกว่าวันที่สิ้นสุด' using errcode='22023';
  end if;

  if upper(p_mode) = 'FULL' then
    v_unit := 'day';  v_days := public.njhr_leave_workdays(p_start_date, v_end);
    if v_days <= 0 then
      raise exception 'ช่วงวันที่เลือกไม่มีวันทำงาน (ตรงกับวันหยุด)' using errcode='22023';
    end if;
  elsif upper(p_mode) in ('HALF_AM','HALF_PM') then
    v_unit := 'halfday'; v_half := true;
    v_days := case when public.njhr_leave_workdays(p_start_date, p_start_date) > 0 then 0.5 else 0 end;
    if v_days <= 0 then
      raise exception 'ช่วงวันที่เลือกไม่มีวันทำงาน (ตรงกับวันหยุด)' using errcode='22023';
    end if;
  elsif upper(p_mode) = 'HOURLY' then
    v_unit := 'hour';
    if p_start_time is null or p_end_time is null or p_end_time <= p_start_time then
      raise exception 'เวลาสิ้นสุดต้องมากกว่าเวลาเริ่ม' using errcode='22023';
    end if;
    v_hours := round(extract(epoch from (p_end_time - p_start_time))/3600.0, 2);
  else
    raise exception 'รูปแบบการลาไม่ถูกต้อง (%)', p_mode using errcode='22023';
  end if;

  -- ห้ามทับช่วงกับใบที่ยังมีผล
  if exists (select 1 from public.leave_requests r
              where r.employee_id = c.employee_id
                and r.status in ('PENDING','APPROVED')
                and p_start_date <= r.end_date and r.start_date <= v_end) then
    raise exception 'ช่วงวันที่นี้ทับกับคำขอลาเดิมที่ยังมีผลอยู่' using errcode='23505';
  end if;

  -- โควตา: ตรวจเฉพาะประเภทที่มีโควตาจริงใน employees
  v_quota := public.njhr_leave_quota(c.employee_id, v_type::text);
  if v_quota is not null then
    select coalesce(sum(coalesce(r.total_days,0)+coalesce(r.hours,0)/8),0) into v_usedpend
      from public.leave_requests r
     where r.employee_id = c.employee_id and r.leave_type = v_type
       and r.status in ('APPROVED','PENDING')
       and extract(year from r.start_date) = extract(year from p_start_date);
    if v_quota - v_usedpend < v_days + v_hours/8 then
      raise exception 'วันลาคงเหลือไม่เพียงพอ (คงเหลือ % วัน)', round(v_quota - v_usedpend, 2)
        using errcode='23514';
    end if;
  end if;

  -- ตรวจไฟล์แนบ: ต้องมี name และ url จริงทุกไฟล์
  for f in select * from jsonb_array_elements(v_files) loop
    if coalesce(f->>'name','') = '' or coalesce(f->>'url','') = '' then
      raise exception 'ข้อมูลไฟล์แนบไม่ครบ (ต้องมีชื่อไฟล์และที่อยู่ไฟล์)' using errcode='22023';
    end if;
    v_n := v_n + 1;
  end loop;

  -- [P1] กฎ "ลาป่วยต้องแนบเอกสาร" ถูกถอดออกตามข้อกำหนดใหม่ — ไฟล์แนบเป็นตัวเลือกทุกประเภท
  --      เดิม: if v_type = 'SICK' and v_n = 0 then raise exception ... end if;
  --      ไม่แตะ Validation อื่นและไม่แตะ Workflow ใด ๆ

  insert into public.leave_requests(
    employee_id, leave_type, start_date, end_date, leave_unit,
    start_time, end_time, hours, is_halfday, total_days, reason, status, approvals)
  values (c.employee_id, v_type, p_start_date, v_end, v_unit,
    case when v_unit='hour' then p_start_time end,
    case when v_unit='hour' then p_end_time end,
    v_hours, v_half, v_days, btrim(p_reason), 'PENDING',
    jsonb_build_array(jsonb_build_object(
      'seq', 1, 'at', to_char(now() at time zone 'Asia/Bangkok','YYYY-MM-DD HH24:MI'),
      'by', c.app_user_id, 'by_name', coalesce(c.emp_name, c.username),
      'action', 'SUBMIT', 'note', '',
      'meta', jsonb_build_object('mode', upper(p_mode), 'delegate', p_delegate,
                                 'client_key', coalesce(p_client_key,'')))))
  returning leave_requests.id into v_id;

  -- แนบไฟล์ทั้งหมดในธุรกรรมเดียวกับใบลา (สำเร็จทั้งหมดหรือไม่สำเร็จเลย)
  if v_n > 0 then
    insert into public.leave_attachments(leave_id, file_name, file_url, file_size)
    select v_id, x->>'name', x->>'url', nullif(x->>'size','')::int
      from jsonb_array_elements(v_files) x;
  end if;

  insert into public.notifications(user_id, title, body, icon)
  select a.id, 'คำขอลาใหม่',
         coalesce(c.emp_name, c.username) || ' ขอลา ' ||
         case when v_unit='hour' then v_hours || ' ชม.' else v_days || ' วัน' end,
         'leave'
    from public.app_users a
   where a.app_code = 'salary' and coalesce(a.is_active,true)
     and public.njhr_norm_role(a.role::text) in ('SUPER_ADMIN','ADMIN','HR','MANAGER');

  perform public.njhr_leave_audit(c.username, 'LEAVE_REQ', v_id,
    'ส่งใบลา ' || v_type::text || ' ' || p_start_date || ' ถึง ' || v_end ||
    ' (ไฟล์แนบ ' || v_n || ' ไฟล์)');

  return query select v_id, v_days, v_hours, false, v_n;
end $function$;

insert into public.njhr_schema_version(version, note)
values ('v2.9-leave-optional-doc', 'ไฟล์แนบไม่บังคับทุกประเภทการลา — ถอดกฎ SICK ออกจาก njhr_leave_submit')
on conflict (version) do nothing;

-- ═══ VERIFICATION ═══
select jsonb_pretty(jsonb_build_object(
  'signature', (select pg_get_function_identity_arguments(p.oid)::text from pg_proc p
                  join pg_namespace n on n.oid=p.pronamespace
                 where n.nspname='public' and p.proname='njhr_leave_submit'),
  'returns', (select pg_get_function_result(p.oid)::text from pg_proc p
                join pg_namespace n on n.oid=p.pronamespace
               where n.nspname='public' and p.proname='njhr_leave_submit'),
  -- ต้องเป็น false: กฎบังคับแนบไฟล์ถูกถอดออกแล้ว
  'still_requires_sick_doc', (select pg_get_functiondef(p.oid) like '%ลาป่วยต้องแนบเอกสารประกอบ%'
                                from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                               where n.nspname='public' and p.proname='njhr_leave_submit'),
  -- ต้องเป็น true ทั้งหมด: Validation อื่นยังอยู่ครบ
  'keeps_reason_check', (select pg_get_functiondef(p.oid) like '%กรุณาระบุเหตุผลการลา%'
                           from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                          where n.nspname='public' and p.proname='njhr_leave_submit'),
  'keeps_quota_check', (select pg_get_functiondef(p.oid) like '%วันลาคงเหลือไม่เพียงพอ%'
                          from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                         where n.nspname='public' and p.proname='njhr_leave_submit'),
  'keeps_overlap_check', (select pg_get_functiondef(p.oid) like '%ทับกับคำขอลาเดิม%'
                            from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                           where n.nspname='public' and p.proname='njhr_leave_submit'),
  'keeps_file_shape_check', (select pg_get_functiondef(p.oid) like '%ข้อมูลไฟล์แนบไม่ครบ%'
                               from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                              where n.nspname='public' and p.proname='njhr_leave_submit'),
  'keeps_client_key_guard', (select pg_get_functiondef(p.oid) like '%client_key%'
                               from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                              where n.nspname='public' and p.proname='njhr_leave_submit'),
  'leave_requests_rows', (select count(*) from public.leave_requests),
  'leave_attachments_rows', (select count(*) from public.leave_attachments)
)) as p1_verification;

-- ═══ ROLLBACK ═══
-- คืนกฎเดิมโดยเพิ่มบล็อกนี้กลับก่อน insert into public.leave_requests:
--   if v_type = 'SICK' and v_n = 0 then
--     raise exception 'ลาป่วยต้องแนบเอกสารประกอบ' using errcode='22023';
--   end if;
-- delete from public.njhr_schema_version where version = 'v2.9-leave-optional-doc';
