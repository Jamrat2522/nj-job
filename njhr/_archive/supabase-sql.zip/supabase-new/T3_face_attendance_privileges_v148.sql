-- NJ HR v14.8 — RPC privilege hardening after moving executive classification to session-bound helper.
-- Keep internal employee-id exemption helper off the public client surface.
revoke all on function public.njhr_hr_exempt_employee(uuid) from public, anon, authenticated;
grant execute on function public.njhr_hr_exempt_employee(uuid) to service_role;

-- Face attendance remains callable by the web client, but remove the implicit PUBLIC EXECUTE grant
-- and grant only the intended API roles explicitly. The function still validates NJHR token + face/liveness.
revoke all on function public.njhr_att_punch_face(text,text,double precision[],integer,boolean,text,double precision,double precision,double precision,text,jsonb)
  from public, anon, authenticated;
grant execute on function public.njhr_att_punch_face(text,text,double precision[],integer,boolean,text,double precision,double precision,double precision,text,jsonb)
  to anon, authenticated, service_role;
