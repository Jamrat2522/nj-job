-- ============================================================
-- NJ HR V2 — 98_wf_correction_manage.sql
-- เปิดให้ตั้งค่าผังอนุมัติของ "ลงชื่อย้อนหลัง" (CORRECTION) ได้จากหน้าจอ
--
-- ⚠⚠ ไฟล์นี้ยังไม่ได้รัน — ส่งมาให้ตรวจก่อนเท่านั้น ⚠⚠
--
-- Root Cause (ตรวจจากไฟล์จริง ไม่ได้เดา)
--   F3_correction_workflow.sql ทำให้ njhr_wf_route และ njhr_att_correction_submit
--   รองรับ CORRECTION แล้ว และ constraint njhr_wf_reqtype_chk ก็รับค่านี้แล้ว
--   แต่ RPC ฝั่ง "จัดการผัง" ยังกรองเหลือแค่ LEAVE/OT อยู่:
--     88_wf_scope_employee.sql:144  njhr_wf_save      in ('LEAVE','OT')
--     88_wf_scope_employee.sql:287  njhr_wf_list      not in (...,'ALL') → บังคับกลับเป็น LEAVE
--     88_wf_scope_employee.sql:335  njhr_wf_emp_pool  not in ('LEAVE','OT') → fallback LEAVE
--     88_wf_scope_employee.sql:416  njhr_wf_step_save not in ('LEAVE','OT') → ปฏิเสธ
--     86_wf_multi_type.sql:285      njhr_wf_overview  คืนแค่ leave_steps / ot_steps
--     90_wf_route.sql:137           njhr_wf_route_check ตรวจแค่ LEAVE/OT
--   ผลคือสร้างผัง CORRECTION ไม่ได้เลย → njhr_wf_route หา Workflow ไม่เจอ
--   → USER ยื่นลงชื่อย้อนหลังไม่เข้าระบบอนุมัติ
--
-- วิธีแก้ในไฟล์นี้
--   คัดลอกนิยามล่าสุดของทั้ง 6 ฟังก์ชันมาทั้งดุ้น แล้วแก้เฉพาะบรรทัดที่กรองประเภท
--   ตรรกะอื่นไม่เปลี่ยนแม้แต่บรรทัดเดียว → LEAVE / OT ได้ผลเหมือนเดิมทุกประการ
--
-- ⚠ 'BOTH' ยังหมายถึง LEAVE + OT เท่านั้นตามเดิม
--   (Trigger njhr_wf_depts_sync แปลง BOTH → array['LEAVE','OT'])
--   จึงบังคับให้ผังที่มี CORRECTION ต้องเป็นผังของตัวเอง ห้ามเลือกรวมกับประเภทอื่น
--   ไม่ต้องแก้ Trigger เพราะกรณีอื่นใช้ else array[new.request_type] อยู่แล้ว
--
-- ไม่แตะ: njhr_att_correction_submit / _approve / _reject / _list
--         njhr_wf_route · njhr_wf_resolve · njhr_wf_guard · njhr_wf_depts_sync
--         LEAVE · OT · Payroll · Attendance · Role · สิทธิ์ anon
-- ต้องรัน 88 · 86 · 90 · F3 มาก่อน · รันซ้ำได้
-- ============================================================

do $$
declare n int;
begin
  if to_regprocedure('public.njhr_wf_route(text,text,uuid)') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_wf_route';
  end if;
  if not exists (
    select 1 from pg_constraint
     where conname = 'njhr_wf_reqtype_chk'
       and pg_get_constraintdef(oid) like '%CORRECTION%') then
    raise exception 'PREFLIGHT: njhr_wf_reqtype_chk ยังไม่รองรับ CORRECTION — ต้องรัน F3 ก่อน';
  end if;
  select count(*) into n from public.njhr_approval_workflow_depts where request_type='LEAVE';
  raise notice 'Mapping LEAVE: %', n;
  select count(*) into n from public.njhr_approval_workflow_depts where request_type='OT';
  raise notice 'Mapping OT: %', n;
  select count(*) into n from public.njhr_approval_workflow_depts where request_type='CORRECTION';
  raise notice 'Mapping CORRECTION: %  (ก่อนแก้ควรเป็น 0)', n;
  raise notice 'PREFLIGHT ผ่าน';
end $$;


begin;

-- ─── 1) njhr_wf_save — รับ CORRECTION ───
create or replace function public.njhr_wf_save(
  p_token text, p_id uuid default null, p_type text default null,
  p_name text default null, p_scope text default null, p_departments text[] default null,
  p_types text[] default null, p_employees uuid[] default null)
returns table (workflow_id uuid, anchor_dept text, dept_count int, emp_count int, request_type text)
language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
declare c record; v_id uuid; v_anchor text; v_clash text; t text;
        v_scope text := upper(btrim(coalesce(p_scope,'SELECTED')));
        v_depts text[]; v_emps uuid[]; v_types text[]; v_stored text; oldrow jsonb;
begin
  select * into c from public.njhr_wf_guard(p_token);

  select array_agg(distinct upper(btrim(x))) into v_types
    from unnest(coalesce(p_types, case when coalesce(btrim(p_type),'') = ''
                                       then '{}'::text[] else array[p_type] end)) x
   where upper(btrim(x)) in ('LEAVE','OT','CORRECTION');
  if v_types is null or array_length(v_types,1) is null then
    raise exception 'กรุณาเลือกประเภทคำขออย่างน้อย 1 ประเภท (การลางาน / การขอ OT / ลงชื่อย้อนหลัง)'
      using errcode='22023';
  end if;
  /* 'BOTH' สงวนความหมายเดิม = LEAVE + OT เท่านั้น (Trigger njhr_wf_depts_sync แปลง BOTH
     เป็น array['LEAVE','OT']) ถ้ามี CORRECTION ปนอยู่ต้องไม่ยุบเป็น BOTH เด็ดขาด
     จึงบังคับให้ผังหนึ่งอันเลือกได้ทีละ 1 ประเภทเมื่อมี CORRECTION */
  if 'CORRECTION' = any(v_types) and array_length(v_types,1) > 1 then
    raise exception 'ผังอนุมัติของ "ลงชื่อย้อนหลัง" ต้องแยกผังของตัวเอง เลือกรวมกับประเภทอื่นไม่ได้'
      using errcode='22023';
  end if;
  v_stored := case when array_length(v_types,1) = 2 then 'BOTH' else v_types[1] end;

  if v_scope not in ('ALL','SELECTED','EMPLOYEE') then
    raise exception 'ขอบเขตต้องเป็น ALL / SELECTED / EMPLOYEE' using errcode='22023';
  end if;

  if v_scope = 'ALL' then
    v_depts := array['*']; v_emps := null;
  elsif v_scope = 'SELECTED' then
    select array_agg(distinct btrim(t2.x)) into v_depts
      from unnest(coalesce(p_departments, '{}'::text[])) as t2(x)
     where btrim(t2.x) <> '' and btrim(t2.x) <> '*';
    if v_depts is null or array_length(v_depts,1) is null then
      raise exception 'กรุณาเลือกอย่างน้อย 1 แผนก' using errcode='22023';
    end if;
    v_emps := null;
  else
    select array_agg(distinct x) into v_emps
      from unnest(coalesce(p_employees, '{}'::uuid[])) as x
     where x is not null;
    if v_emps is null or array_length(v_emps,1) is null then
      raise exception 'กรุณาเลือกอย่างน้อย 1 พนักงาน' using errcode='22023';
    end if;
    if exists (select 1 from unnest(v_emps) x
                where not exists (select 1 from public.employees e where e.id = x)) then
      raise exception 'มีพนักงานที่เลือกไม่อยู่ในทะเบียนพนักงาน' using errcode='P0002';
    end if;
    v_depts := null;
  end if;

  -- แผนกหลัก (anchor) — RPC ขั้นอนุมัติเดิมค้นด้วยค่านี้ จึงต้องไม่ซ้ำกันทุกชุด
  if v_scope = 'EMPLOYEE' then
    v_anchor := coalesce((select w.department from public.njhr_approval_workflows w
                           where w.id = p_id and w.department like '@EMP:%'),
                         '@EMP:' || replace(gen_random_uuid()::text, '-', ''));
  else
    v_anchor := v_depts[1];
  end if;

  -- ตรวจทับซ้อนก่อนบันทึก แล้วแจ้งให้ชัดว่าชนอะไร
  if v_scope = 'SELECTED' then
    select string_agg(distinct
             (case d.request_type when 'LEAVE' then 'การลางาน' else 'การขอ OT' end)
             || ': ' || d.department, ' · ') into v_clash
      from public.njhr_approval_workflow_depts d
      join public.njhr_approval_workflows w on w.id = d.workflow_id
     where d.request_type = any(v_types) and d.department = any(v_depts)
       and w.deleted_at is null and (p_id is null or d.workflow_id <> p_id);
    if v_clash is not null then
      raise exception 'แผนกนี้ถูกใช้ใน Workflow ชุดอื่นแล้ว — %', v_clash using errcode='23505';
    end if;
  elsif v_scope = 'EMPLOYEE' then
    select string_agg(distinct
             (case m.request_type when 'LEAVE' then 'การลางาน' else 'การขอ OT' end)
             || ': ' || e.emp_code, ' · ') into v_clash
      from public.njhr_approval_workflow_emps m
      join public.njhr_approval_workflows w on w.id = m.workflow_id
      join public.employees e on e.id = m.employee_id
     where m.request_type = any(v_types) and m.employee_id = any(v_emps)
       and w.deleted_at is null and (p_id is null or m.workflow_id <> p_id);
    if v_clash is not null then
      raise exception 'พนักงานรายนี้ถูกใช้ใน Workflow ชุดอื่นแล้ว — %', v_clash using errcode='23505';
    end if;
  elsif v_scope = 'ALL' then
    select string_agg(distinct
             (case d.request_type when 'LEAVE' then 'การลางาน' else 'การขอ OT' end), ' · ') into v_clash
      from public.njhr_approval_workflow_depts d
      join public.njhr_approval_workflows w on w.id = d.workflow_id
     where d.request_type = any(v_types) and d.department = '*'
       and w.deleted_at is null and (p_id is null or d.workflow_id <> p_id);
    if v_clash is not null then
      raise exception 'มีชุด "ทุกแผนก" ของประเภทคำขอนี้อยู่แล้ว — %', v_clash using errcode='23505';
    end if;
  end if;

  if p_id is null then
    insert into public.njhr_approval_workflows
           (request_type, department, scope, name, created_by, updated_by)
    values (v_stored, v_anchor, v_scope, nullif(btrim(coalesce(p_name,'')),''), c.username, c.username)
    returning njhr_approval_workflows.id into v_id;
  else
    select to_jsonb(w) into oldrow from public.njhr_approval_workflows w
     where w.id = p_id and w.deleted_at is null;
    if oldrow is null then raise exception 'ไม่พบ Workflow ชุดนี้' using errcode='P0002'; end if;
    v_id := p_id;
    delete from public.njhr_approval_workflow_depts where workflow_id = v_id;
    delete from public.njhr_approval_workflow_emps  where workflow_id = v_id;
    update public.njhr_approval_workflows
       set request_type = v_stored, department = v_anchor, scope = v_scope,
           name = nullif(btrim(coalesce(p_name,'')),''),
           updated_at = now(), updated_by = c.username
     where njhr_approval_workflows.id = v_id;
  end if;

  if v_scope = 'EMPLOYEE' then
    foreach t in array v_types loop
      insert into public.njhr_approval_workflow_emps (workflow_id, request_type, employee_id, created_by)
      select v_id, t, x, c.username from unnest(v_emps) x
      on conflict (request_type, employee_id) do nothing;
    end loop;
  else
    foreach t in array v_types loop
      insert into public.njhr_approval_workflow_depts (workflow_id, request_type, department, created_by)
      select v_id, t, d, c.username from unnest(v_depts) d
      on conflict (request_type, department) do nothing;
    end loop;
  end if;

  perform public.njhr_audit_write(p_token,
    case when p_id is null then 'WF_ADD' else 'WF_EDIT' end,
    'approval', 'njhr_approval_workflows', v_id::text,
    array_to_string(v_types, '+') || ' · ' ||
    case v_scope when 'ALL' then 'ทุกแผนก'
                 when 'EMPLOYEE' then 'เลือกพนักงาน ' || array_length(v_emps,1) || ' คน'
                 else array_to_string(v_depts, ', ') end,
    oldrow, (select to_jsonb(w) from public.njhr_approval_workflows w where w.id = v_id), null);

  return query
  select v_id, v_anchor,
         (select count(distinct d2.department)::int from public.njhr_approval_workflow_depts d2
           where d2.workflow_id = v_id and d2.department <> '*'),
         (select count(distinct m2.employee_id)::int from public.njhr_approval_workflow_emps m2
           where m2.workflow_id = v_id),
         v_stored;
end $$;


-- ─── 2) njhr_wf_list — เลิกบังคับกลับเป็น LEAVE ───
create or replace function public.njhr_wf_list(p_token text, p_type text default 'LEAVE')
returns table (workflow_id uuid, request_type text, request_types jsonb, wf_name text, scope text,
               anchor_dept text, departments jsonb, dept_count int,
               employees jsonb, emp_count int,
               step_count int, approver_count int, active boolean, updated_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare v_type text := upper(btrim(coalesce(p_type,'LEAVE')));
begin
  perform public.njhr_wf_guard(p_token);
  if v_type not in ('LEAVE','OT','CORRECTION','ALL') then v_type := 'LEAVE'; end if;
  return query
  select w.id, w.request_type,
         case w.request_type when 'BOTH' then '["LEAVE","OT"]'::jsonb
                             else to_jsonb(array[w.request_type]) end,
         coalesce(w.name,''), w.scope, w.department,
         coalesce((select jsonb_agg(distinct d.department)
                     from public.njhr_approval_workflow_depts d
                    where d.workflow_id = w.id and d.department <> '*'), '[]'::jsonb),
         (select count(distinct d2.department)::int from public.njhr_approval_workflow_depts d2
           where d2.workflow_id = w.id and d2.department <> '*'),
         coalesce((select jsonb_agg(jsonb_build_object(
                     'employee_id', e.id, 'emp_code', e.emp_code,
                     'name', coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,''),
                     'nickname', coalesce(e.nickname,''),
                     'department', coalesce(e.department_name,'')) order by e.emp_code)
                     from (select distinct m.employee_id from public.njhr_approval_workflow_emps m
                            where m.workflow_id = w.id) mm
                     join public.employees e on e.id = mm.employee_id), '[]'::jsonb),
         (select count(distinct m2.employee_id)::int from public.njhr_approval_workflow_emps m2
           where m2.workflow_id = w.id),
         (select count(*)::int from public.njhr_approval_steps s
           where s.workflow_id = w.id and s.deleted_at is null),
         (select count(*)::int from public.njhr_approval_step_approvers a
            join public.njhr_approval_steps s2 on s2.id = a.step_id
           where s2.workflow_id = w.id and s2.deleted_at is null),
         w.active, w.updated_at
    from public.njhr_approval_workflows w
   where w.deleted_at is null
     and (v_type = 'ALL' or w.request_type = v_type or w.request_type = 'BOTH')
   order by case w.scope when 'EMPLOYEE' then 0 when 'SELECTED' then 1 else 2 end,
            coalesce(w.name,''), w.department;
end $$;


-- ─── 3) njhr_wf_emp_pool — เลิก fallback เป็น LEAVE ───
create or replace function public.njhr_wf_emp_pool(
  p_token text, p_type text default 'LEAVE', p_q text default null,
  p_exclude_workflow uuid default null, p_limit int default 300)
returns table (employee_id uuid, emp_code text, full_name text, nickname text,
               department_name text, position_name text, taken_by uuid)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare v_type text := upper(btrim(coalesce(p_type,'LEAVE')));
        q text := lower(btrim(coalesce(p_q,'')));
        lim int := least(greatest(coalesce(p_limit,300),1),1000);
begin
  perform public.njhr_wf_guard(p_token);
  if v_type not in ('LEAVE','OT','CORRECTION') then v_type := 'LEAVE'; end if;
  return query
  select e.id, e.emp_code,
         coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,''),
         coalesce(e.nickname,''), coalesce(e.department_name,''), coalesce(e.position_name,''),
         (select m.workflow_id from public.njhr_approval_workflow_emps m
            join public.njhr_approval_workflows w on w.id = m.workflow_id
           where m.request_type = v_type and m.employee_id = e.id and w.deleted_at is null
             and (p_exclude_workflow is null or m.workflow_id <> p_exclude_workflow)
           limit 1)
    from public.employees e
   where e.status::text in ('ACTIVE','PROBATION')
     and (q = '' or lower(coalesce(e.emp_code,'')) like '%'||q||'%'
          or lower(coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,'')) like '%'||q||'%'
          or lower(coalesce(e.nickname,'')) like '%'||q||'%'
          or lower(coalesce(e.department_name,'')) like '%'||q||'%')
   order by e.emp_code
   limit lim;
end $$;


-- ─── 4) njhr_wf_step_save — สร้างขั้นอนุมัติของ CORRECTION ได้ ───
create or replace function public.njhr_wf_step_save(
  p_token text, p_type text, p_dept text, p_step_id uuid default null,
  p_name text default null, p_mode text default null,
  p_cond_type text default null, p_cond_value text default null,
  p_active boolean default null, p_note text default null)
returns table (step_id uuid, step_no int, name text)
language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
declare c record; v_wf uuid; v_id uuid; v_no int; oldrow jsonb;
        v_type text := upper(btrim(coalesce(p_type,'')));
begin
  select * into c from public.njhr_wf_guard(p_token);
  if v_type not in ('LEAVE','OT','CORRECTION') then
    raise exception 'ประเภทคำขอไม่ถูกต้อง' using errcode='22023';
  end if;
  if coalesce(btrim(p_dept),'') = '' then
    raise exception 'กรุณาเลือกแผนก' using errcode='22023';
  end if;
  if p_mode is not null and upper(p_mode) not in ('ANY','ALL') then
    raise exception 'รูปแบบการอนุมัติต้องเป็น ANY หรือ ALL' using errcode='22023';
  end if;

  if p_step_id is null then
    select w.id into v_wf from public.njhr_approval_workflows w
     where (w.request_type = v_type or w.request_type = 'BOTH')
       and w.department = btrim(p_dept) and w.deleted_at is null;
    if v_wf is null then
      insert into public.njhr_approval_workflows(request_type, department, created_by, updated_by)
      values (v_type, btrim(p_dept), c.username, c.username)
      returning njhr_approval_workflows.id into v_wf;
    end if;
    if coalesce(btrim(p_name),'') = '' then
      raise exception 'กรุณาระบุชื่อขั้นอนุมัติ' using errcode='22023';
    end if;
    select coalesce(max(s.step_no),0)+1 into v_no from public.njhr_approval_steps s
     where s.workflow_id = v_wf and s.deleted_at is null;
    insert into public.njhr_approval_steps(workflow_id, step_no, name, mode, cond_type, cond_value,
                                           active, note, created_by, updated_by)
    values (v_wf, v_no, btrim(p_name), upper(coalesce(p_mode,'ANY')),
            upper(coalesce(nullif(btrim(coalesce(p_cond_type,'')),''),'ALL')),
            nullif(btrim(coalesce(p_cond_value,'')),''),
            coalesce(p_active,true), nullif(btrim(coalesce(p_note,'')),''), c.username, c.username)
    returning njhr_approval_steps.id into v_id;

    perform public.njhr_audit_write(p_token, 'WF_STEP_ADD', 'approval', 'njhr_approval_steps',
      v_id::text, v_type || ' · ' || btrim(p_dept) || ' · ขั้นที่ ' || v_no || ' ' || btrim(p_name),
      null, (select to_jsonb(x) from public.njhr_approval_steps x where x.id = v_id), null);
  else
    select to_jsonb(s) into oldrow from public.njhr_approval_steps s
     where s.id = p_step_id and s.deleted_at is null;
    if oldrow is null then raise exception 'ไม่พบขั้นอนุมัตินี้' using errcode='P0002'; end if;
    update public.njhr_approval_steps set
      name       = coalesce(nullif(btrim(coalesce(p_name,'')),''), name),
      mode       = coalesce(upper(nullif(btrim(coalesce(p_mode,'')),'')), mode),
      cond_type  = coalesce(upper(nullif(btrim(coalesce(p_cond_type,'')),'')), cond_type),
      cond_value = case when p_cond_value is null then cond_value
                        else nullif(btrim(p_cond_value),'') end,
      active     = coalesce(p_active, active),
      note       = case when p_note is null then note else nullif(btrim(p_note),'') end,
      updated_at = now(), updated_by = c.username
     where njhr_approval_steps.id = p_step_id;
    v_id := p_step_id;

    perform public.njhr_audit_write(p_token, 'WF_STEP_EDIT', 'approval', 'njhr_approval_steps',
      v_id::text, 'แก้ไขขั้นอนุมัติ', oldrow,
      (select to_jsonb(x) from public.njhr_approval_steps x where x.id = v_id), null);
  end if;

  return query select s.id, s.step_no, s.name from public.njhr_approval_steps s where s.id = v_id;
end $$;


-- ─── 5) njhr_wf_overview — เพิ่ม correction_steps ───
create or replace function public.njhr_wf_overview(p_token text)
returns table (department text, leave_steps int, ot_steps int,
               correction_steps int, employees int)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
begin
  perform public.njhr_wf_guard(p_token);
  return query
  with deps as (
    select distinct e.department_name as dname from public.employees e
     where coalesce(e.department_name,'') <> '' and e.status::text = 'ACTIVE')
  select d.dname,
         coalesce((select count(*)::int from public.njhr_approval_steps s
                     join public.njhr_approval_workflow_depts wd on wd.workflow_id = s.workflow_id
                     join public.njhr_approval_workflows w on w.id = s.workflow_id
                    where wd.request_type = 'LEAVE'
                      and wd.department in (d.dname, '*')
                      and s.deleted_at is null and w.deleted_at is null and s.active), 0),
         coalesce((select count(*)::int from public.njhr_approval_steps s
                     join public.njhr_approval_workflow_depts wd on wd.workflow_id = s.workflow_id
                     join public.njhr_approval_workflows w on w.id = s.workflow_id
                    where wd.request_type = 'OT'
                      and wd.department in (d.dname, '*')
                      and s.deleted_at is null and w.deleted_at is null and s.active), 0),
         coalesce((select count(*)::int from public.njhr_approval_steps s
                     join public.njhr_approval_workflow_depts wd on wd.workflow_id = s.workflow_id
                     join public.njhr_approval_workflows w on w.id = s.workflow_id
                    where wd.request_type = 'CORRECTION'
                      and wd.department in (d.dname, '*')
                      and s.deleted_at is null and w.deleted_at is null and s.active), 0),
         (select count(*)::int from public.employees e2
           where e2.department_name = d.dname and e2.status::text = 'ACTIVE')
    from deps d
   order by d.dname;
end $$;


-- ─── 6) njhr_wf_route_check — ตรวจ coverage ของ CORRECTION ───
create or replace function public.njhr_wf_route_check(p_token text)
returns table (request_type text, department text, employees int,
               status text, detail text)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
begin
  perform public.njhr_wf_guard(p_token);
  return query
  with emp as (
    select e.id, coalesce(e.department_name,'') dept
      from public.employees e where e.status::text in ('ACTIVE','PROBATION')),
  t as (select unnest(array['LEAVE','OT','CORRECTION']) rt),
  pick as (
    select e.id eid, e.dept, t.rt,
           (select c.wid from (
              select w1.id wid, 1 pr from public.njhr_approval_workflow_emps m
                join public.njhr_approval_workflows w1 on w1.id = m.workflow_id
               where m.request_type = t.rt and m.employee_id = e.id and w1.deleted_at is null
              union all
              select w2.id, 2 from public.njhr_approval_workflow_depts d
                join public.njhr_approval_workflows w2 on w2.id = d.workflow_id
               where d.request_type = t.rt and d.department = e.dept and w2.deleted_at is null
              union all
              select w3.id, 3 from public.njhr_approval_workflow_depts d2
                join public.njhr_approval_workflows w3 on w3.id = d2.workflow_id
               where d2.request_type = t.rt and d2.department = '*' and w3.deleted_at is null
            ) c order by c.pr limit 1) wid
      from emp e cross join t)
  select p.rt, nullif(p.dept,''), count(*)::int,
         case when p.wid is null then 'ไม่พบผังการอนุมัติ'
              when (select count(*) from public.njhr_approval_steps s
                     where s.workflow_id = p.wid and s.deleted_at is null and s.active) = 0
                then 'พบผังแต่ไม่มีขั้นอนุมัติ'
              when exists (select 1 from public.njhr_approval_steps s
                            where s.workflow_id = p.wid and s.deleted_at is null and s.active
                              and not exists (select 1 from public.njhr_approval_step_approvers a
                                               join public.employees e2 on e2.id = a.employee_id
                                              where a.step_id = s.id and a.active
                                                and e2.status::text in ('ACTIVE','PROBATION')))
                then 'มีขั้นที่ยังไม่มีผู้อนุมัติ'
              else 'พร้อมใช้งาน' end,
         coalesce((select coalesce(nullif(w.name,''), w.department)
                     from public.njhr_approval_workflows w where w.id = p.wid), '—')
    from pick p
   group by p.rt, p.dept, p.wid
   order by 4 desc, 1, 2;
end $$;

-- ─── สิทธิ์: คงรูปแบบเดิมทุกตัว ไม่เพิ่มสิทธิ์ใหม่ ───
revoke all on function public.njhr_wf_overview(text) from public;
grant execute on function public.njhr_wf_overview(text) to anon, authenticated;

insert into public.njhr_schema_version(version, note)
values ('v15.1-wf-correction-manage',
        'ตั้งค่าผังอนุมัติ CORRECTION ได้จากหน้าจอ (save/list/step_save/emp_pool/overview/route_check)')
on conflict (version) do nothing;

commit;


-- ════════════════════════════════════════════════════════════
-- VERIFICATION
-- ════════════════════════════════════════════════════════════
select jsonb_pretty(jsonb_build_object(
  'save รับ CORRECTION',
    (select pg_get_functiondef(p.oid) like '%''LEAVE'',''OT'',''CORRECTION''%'
       from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname='njhr_wf_save' limit 1),
  'list รับ CORRECTION',
    (select pg_get_functiondef(p.oid) like '%CORRECTION%'
       from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname='njhr_wf_list' limit 1),
  'emp_pool รับ CORRECTION',
    (select pg_get_functiondef(p.oid) like '%CORRECTION%'
       from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname='njhr_wf_emp_pool' limit 1),
  'step_save รับ CORRECTION',
    (select pg_get_functiondef(p.oid) like '%CORRECTION%'
       from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname='njhr_wf_step_save' limit 1),
  'overview มี correction_steps',
    (select pg_get_function_result(p.oid) like '%correction_steps%'
       from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname='njhr_wf_overview' limit 1),
  'route_check ตรวจ CORRECTION',
    (select pg_get_functiondef(p.oid) like '%CORRECTION%'
       from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname='njhr_wf_route_check' limit 1),
  'route เดิมยังอยู่',
    (to_regprocedure('public.njhr_wf_route(text,text,uuid)') is not null),
  'submit เดิมไม่ถูกแตะ',
    (to_regprocedure('public.njhr_att_correction_submit(text,date,time,time,text,uuid,jsonb)') is not null
     or exists (select 1 from pg_proc p join pg_namespace n on n.oid=p.pronamespace
                 where n.nspname='public' and p.proname='njhr_att_correction_submit'))
)) as report;


-- ROLLBACK — รัน 88 → 86 → 90 ใหม่เพื่อคืนนิยามเดิมทั้ง 6 ตัว
-- delete from public.njhr_schema_version where version='v15.1-wf-correction-manage';
