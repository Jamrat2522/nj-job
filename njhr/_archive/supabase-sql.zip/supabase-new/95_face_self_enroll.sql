-- ============================================================
-- NJ HR V2 — 95_face_self_enroll.sql
-- ให้พนักงานลงทะเบียนใบหน้าต้นแบบของ "ตัวเอง" ได้ครั้งแรกจากมือถือ
--
-- ⚠⚠ ไฟล์นี้ยังไม่ได้รัน — ส่งมาให้ตรวจก่อนเท่านั้น ⚠⚠
--
-- ทำไมต้องมีไฟล์นี้ (พิสูจน์จาก 92_face_attendance.sql ของจริง)
--   njhr_face_enroll() บรรทัด 245 เรียก njhr_face_guard(p_token, true)
--   ซึ่งบรรทัด 7–9 ของ guard บังคับ role in ('SUPER_ADMIN','ADMIN','HR')
--   → พนักงานทั่วไปลงทะเบียนใบหน้าตัวเองไม่ได้เลย ต้องให้ HR ทำให้ทีละคน
--   ผลคือกดเข้างานครั้งแรกจะได้ 'ยังไม่ได้ลงทะเบียนใบหน้า กรุณาติดต่อฝ่ายบุคคล'
--   (njhr_face_verify บรรทัด 365) แล้วลงเวลาไม่ได้
--
-- ไฟล์นี้เพิ่ม RPC ใหม่ 1 ตัว ไม่แตะของเดิมแม้แต่ตัวเดียว
--
-- ความปลอดภัย — จุดสำคัญที่ทำให้ปลอดภัยกว่าการเปิดสิทธิ์ njhr_face_enroll
--   1. ไม่มีพารามิเตอร์ p_employee เลย → เลือกลงทะเบียนแทนคนอื่นไม่ได้
--      พนักงานเป้าหมายมาจาก njhr_ctx(token).employee_id เท่านั้น
--   2. ลงได้เฉพาะตอน "ยังไม่มี" ใบหน้าต้นแบบ
--      ถ้ามีแล้วจะปฏิเสธ → ป้องกันคนอื่นเอาหน้าตัวเองมาทับเพื่อลงเวลาแทน
--      การลงทะเบียนใหม่ต้องให้ HR ลบของเดิมก่อน (njhr_face_delete ตามระบบเดิม)
--   3. ตรวจคุณภาพเวกเตอร์ชุดเดียวกับ njhr_face_enroll ทุกข้อ
--   4. ไม่แตะ njhr_emp_faces ของคนอื่น · ไม่คืน descriptor ออกไป
--
-- ไม่แตะ: njhr_face_enroll · njhr_face_verify · njhr_att_punch_face
--         njhr_face_guard · njhr_face_status · njhr_face_delete
--         Attendance · Payroll · Leave · OT · RLS อื่น
-- ต้องรัน 92_face_attendance.sql มาก่อน · รันซ้ำได้
-- ============================================================

-- ─── 0) PREFLIGHT ───────────────────────────────────────────
do $$
declare n bigint;
begin
  if to_regclass('public.njhr_emp_faces') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_emp_faces — ต้องรัน 92_face_attendance.sql ก่อน';
  end if;
  if to_regprocedure('public.njhr_face_guard(text,boolean)') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_face_guard';
  end if;
  if to_regprocedure('public.njhr_face_enroll(text,uuid,jsonb,jsonb,text)') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_face_enroll';
  end if;
  select count(*) into n from public.njhr_emp_faces;
  raise notice 'ใบหน้าต้นแบบที่ลงทะเบียนแล้ว: % คน', n;
  select count(*) into n from public.employees e
   where e.status::text in ('ACTIVE','PROBATION')
     and not exists (select 1 from public.njhr_emp_faces f where f.employee_id = e.id);
  raise notice 'พนักงานที่ยังไม่มีใบหน้าต้นแบบ: % คน', n;
  raise notice 'PREFLIGHT ผ่าน';
end $$;


begin;

-- ─── 1) ลงทะเบียนใบหน้าต้นแบบของตัวเอง ──────────────────────
create or replace function public.njhr_face_self_enroll(
  p_token text, p_descriptors jsonb,
  p_quality jsonb default '{}'::jsonb, p_snapshot text default null)
returns table (employee_id uuid, sample_count int, enrolled_at timestamptz)
language plpgsql security definer set search_path = public as $function$
#variable_conflict use_column
declare c record; e record; v_n int; v_len int; v_need int; v_emp uuid;
begin
  /* p_manage = false — พนักงานทั่วไปผ่านได้ เพราะลงทะเบียนให้ตัวเองเท่านั้น */
  select * into c from public.njhr_face_guard(p_token, false);

  v_emp := c.employee_id;
  if v_emp is null then
    raise exception 'บัญชีนี้ยังไม่ได้ผูกกับพนักงาน จึงลงทะเบียนใบหน้าไม่ได้' using errcode='22023';
  end if;

  select * into e from public.employees where id = v_emp;
  if not found then raise exception 'ไม่พบข้อมูลพนักงานของบัญชีนี้' using errcode='P0002'; end if;
  if e.status::text not in ('ACTIVE','PROBATION') then
    raise exception 'ลงทะเบียนใบหน้าได้เฉพาะพนักงานที่ปฏิบัติงานอยู่' using errcode='22023';
  end if;

  /* ⚠ ลงได้เฉพาะครั้งแรกเท่านั้น — กันการเอาหน้าคนอื่นมาทับเพื่อลงเวลาแทนกัน
     ถ้าต้องลงทะเบียนใหม่ ให้ HR ลบด้วย njhr_face_delete ก่อนตามระบบเดิม */
  if exists (select 1 from public.njhr_emp_faces f where f.employee_id = v_emp) then
    raise exception 'มีใบหน้าต้นแบบอยู่แล้ว หากต้องการลงทะเบียนใหม่ กรุณาติดต่อฝ่ายบุคคล'
      using errcode='22023';
  end if;

  /* ---- ตรวจคุณภาพเวกเตอร์: ชุดเดียวกับ njhr_face_enroll ทุกข้อ ---- */
  if p_descriptors is null or jsonb_typeof(p_descriptors) <> 'array' then
    raise exception 'ข้อมูลใบหน้าไม่ถูกต้อง' using errcode='22023';
  end if;
  v_n := jsonb_array_length(p_descriptors);
  v_need := coalesce((select (s.value)::text::int from public.system_settings s
                       where s.key = 'face_enroll_samples'), 3);
  if v_n < v_need then
    raise exception 'ต้องเก็บใบหน้าอย่างน้อย % มุม (ได้ % มุม)', v_need, v_n using errcode='22023';
  end if;
  select jsonb_array_length(p_descriptors->0) into v_len;
  if coalesce(v_len,0) < 64 then
    raise exception 'เวกเตอร์ใบหน้าสั้นผิดปกติ (% ค่า)', coalesce(v_len,0) using errcode='22023';
  end if;
  if exists (select 1 from jsonb_array_elements(p_descriptors) d
              where jsonb_array_length(d) <> v_len) then
    raise exception 'เวกเตอร์ใบหน้าแต่ละมุมมีความยาวไม่เท่ากัน' using errcode='22023';
  end if;

  insert into public.njhr_emp_faces(employee_id, descriptors, descriptor_len, sample_count,
                                    quality, enroll_snapshot, is_active, enrolled_by, updated_by)
  values (v_emp, p_descriptors, v_len, v_n,
          coalesce(p_quality,'{}'::jsonb), p_snapshot, true, c.username, c.username);

  begin
    perform public.njhr_audit_write(p_token, 'FACE_SELF_ENROLL', 'attendance',
      'njhr_emp_faces', v_emp::text,
      'พนักงานลงทะเบียนใบหน้าต้นแบบของตนเองจากมือถือ · ' || v_n::text || ' มุม · ' ||
      coalesce(e.emp_code,'-'), null, null, null);
  exception when undefined_function then null;
  end;

  return query
    select f.employee_id, f.sample_count, f.enrolled_at
      from public.njhr_emp_faces f where f.employee_id = v_emp;
end $function$;

revoke all on function public.njhr_face_self_enroll(text, jsonb, jsonb, text) from public;
grant execute on function public.njhr_face_self_enroll(text, jsonb, jsonb, text)
  to anon, authenticated;

insert into public.njhr_schema_version(version, note)
values ('v14.2-face-self-enroll',
        'พนักงานลงทะเบียนใบหน้าต้นแบบของตัวเองได้ครั้งแรกจากมือถือ (ผูกกับ session เท่านั้น)')
on conflict (version) do nothing;

commit;


-- ════════════════════════════════════════════════════════════
-- VERIFICATION
-- ════════════════════════════════════════════════════════════
select jsonb_pretty(jsonb_build_object(
  'self_enroll มีจริง',
    (to_regprocedure('public.njhr_face_self_enroll(text,jsonb,jsonb,text)') is not null),
  'ไม่มีพารามิเตอร์ p_employee (เลือกคนอื่นไม่ได้)',
    (select pg_get_function_arguments(p.oid) not like '%p_employee%'
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname='public' and p.proname='njhr_face_self_enroll' limit 1),
  'ใช้ guard แบบไม่ต้องเป็นแอดมิน',
    (select pg_get_functiondef(p.oid) like '%njhr_face_guard(p_token, false)%'
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname='public' and p.proname='njhr_face_self_enroll' limit 1),
  'กันลงทะเบียนทับของเดิม',
    (select pg_get_functiondef(p.oid) like '%มีใบหน้าต้นแบบอยู่แล้ว%'
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname='public' and p.proname='njhr_face_self_enroll' limit 1),
  'njhr_face_enroll เดิมไม่ถูกแตะ (ยังบังคับแอดมิน)',
    (select pg_get_functiondef(p.oid) like '%njhr_face_guard(p_token, true)%'
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname='public' and p.proname='njhr_face_enroll' limit 1),
  'GRANT ถูกต้อง',
    (select array_to_string(p.proacl,' ') like '%authenticated=X%'
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname='public' and p.proname='njhr_face_self_enroll' limit 1)
)) as report;


-- ════════════════════════════════════════════════════════════
-- ROLLBACK
-- ════════════════════════════════════════════════════════════
-- drop function if exists public.njhr_face_self_enroll(text, jsonb, jsonb, text);
-- delete from public.njhr_schema_version where version = 'v14.2-face-self-enroll';
-- ⚠ ใบหน้าที่ลงทะเบียนไปแล้วไม่ถูกลบจากการ Rollback
