-- NJ HR v14.7 — allow request submitters to resolve their own approval route
-- Production fix: njhr_wf_route previously called njhr_wf_guard(), which is an ADMIN/SUPER_ADMIN
-- settings-page guard. That incorrectly blocked normal employees from submitting CORRECTION.
-- This function now validates the NJHR session directly and permits non-managers to inspect
-- only their own route. Approval workflow editing remains protected by njhr_wf_guard().

create or replace function public.njhr_wf_route(p_token text, p_type text, p_employee uuid)
returns table(ok boolean, reason text, data jsonb)
language plpgsql
stable
security definer
set search_path=public
as $function$
#variable_conflict use_column
declare v_type text := upper(btrim(coalesce(p_type,''))); v_dept text;
        w record; v_steps jsonb; v_bad text; c record;
begin
  select * into c from public.njhr_ctx(p_token);
  if p_employee is not null
     and p_employee <> coalesce(c.employee_id,'00000000-0000-0000-0000-000000000000'::uuid)
     and c.role not in ('SUPER_ADMIN','ADMIN','HR','ACCOUNT','MANAGER') then
    raise exception 'คุณดูผังการอนุมัติได้เฉพาะของตนเองเท่านั้น' using errcode='42501';
  end if;
  if v_type not in ('LEAVE','OT','CORRECTION') then
    raise exception 'ประเภทคำขอต้องเป็น LEAVE, OT หรือ CORRECTION' using errcode='22023';
  end if;
  if p_employee is null then
    return query select false, 'ไม่พบพนักงานผู้ยื่นคำขอ'::text, '{}'::jsonb; return;
  end if;
  select e.department_name into v_dept from public.employees e where e.id = p_employee;

  select x.wid, x.sc, x.pr, x.ad, x.nm into w from (
    select w1.id wid, w1.scope sc, 1 pr, w1.department ad, coalesce(w1.name,'') nm
      from public.njhr_approval_workflow_emps m
      join public.njhr_approval_workflows w1 on w1.id = m.workflow_id
     where m.request_type = v_type and m.employee_id = p_employee and w1.deleted_at is null
    union all
    select w2.id, w2.scope, 2, w2.department, coalesce(w2.name,'')
      from public.njhr_approval_workflow_depts d
      join public.njhr_approval_workflows w2 on w2.id = d.workflow_id
     where d.request_type = v_type and d.department = v_dept and w2.deleted_at is null
    union all
    select w3.id, w3.scope, 3, w3.department, coalesce(w3.name,'')
      from public.njhr_approval_workflow_depts d2
      join public.njhr_approval_workflows w3 on w3.id = d2.workflow_id
     where d2.request_type = v_type and d2.department = '*' and w3.deleted_at is null
  ) x order by x.pr limit 1;

  if w.wid is null then
    return query select false,
      ('ยังไม่ได้ตั้งผังการอนุมัติสำหรับ' ||
       case v_type when 'LEAVE' then 'การลางาน'
                   when 'OT' then 'การขอ OT'
                   else 'การลงชื่อย้อนหลัง' end ||
       ' ของแผนก ' || coalesce(nullif(v_dept,''), '(ไม่ระบุแผนก)') ||
       ' — กรุณาติดต่อฝ่ายบุคคล')::text, '{}'::jsonb;
    return;
  end if;

  select jsonb_agg(x order by (x->>'step_no')::int) into v_steps from (
    select jsonb_build_object(
             'step_id', s.id, 'step_no', s.step_no, 'name', s.name, 'mode', s.mode,
             'cond_type', s.cond_type, 'cond_value', s.cond_value,
             'approvers', coalesce((
               select jsonb_agg(jsonb_build_object(
                        'employee_id', e.id, 'emp_code', e.emp_code,
                        'name', coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,''),
                        'position', coalesce(e.position_name,''),
                        'department', coalesce(e.department_name,''))
                      order by e.emp_code)
                 from public.njhr_approval_step_approvers a
                 join public.employees e on e.id = a.employee_id
                where a.step_id = s.id and a.active
                  and e.status::text in ('ACTIVE','PROBATION')), '[]'::jsonb)) x
      from public.njhr_approval_steps s
     where s.workflow_id = w.wid and s.deleted_at is null and s.active) t;

  v_steps := coalesce(v_steps, '[]'::jsonb);
  if jsonb_array_length(v_steps) = 0 then
    return query select false,
      ('ผังการอนุมัติ "' || coalesce(nullif(w.nm,''), w.ad) || '" ยังไม่มีขั้นอนุมัติที่เปิดใช้งาน')::text,
      '{}'::jsonb;
    return;
  end if;

  select string_agg('ขั้นที่ ' || (s->>'step_no') || ' ' || (s->>'name'), ', ') into v_bad
    from jsonb_array_elements(v_steps) s
   where jsonb_array_length(s->'approvers') = 0;
  if v_bad is not null then
    return query select false,
      ('ยังไม่มีผู้อนุมัติใน ' || v_bad || ' — กรุณาติดต่อฝ่ายบุคคล')::text, '{}'::jsonb;
    return;
  end if;

  return query select true, ''::text, jsonb_build_object(
    'workflow_id', w.wid, 'workflow_name', coalesce(nullif(w.nm,''), w.ad),
    'scope', w.sc, 'priority', w.pr, 'request_type', v_type,
    'employee_id', p_employee, 'department', coalesce(v_dept,''),
    'step_count', jsonb_array_length(v_steps),
    'steps', v_steps,
    'resolved_at', to_char(now() at time zone 'Asia/Bangkok', 'YYYY-MM-DD"T"HH24:MI:SS'));
end
$function$;
revoke all on function public.njhr_wf_route(text,text,uuid) from public;
grant execute on function public.njhr_wf_route(text,text,uuid) to anon, authenticated, service_role;
