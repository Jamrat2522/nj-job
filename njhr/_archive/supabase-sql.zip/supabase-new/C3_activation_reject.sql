-- ============================================================
-- NJ HR V2 — C3_activation_reject.sql
-- njhr_activation_reject — เติมให้ Migration Package ครบสำหรับ "ติดตั้งระบบใหม่"
--
-- ⚠⚠ ห้ามรันไฟล์นี้บน Production ที่ใช้งานอยู่ ⚠⚠
--   Production มี Function นี้อยู่แล้ว ไฟล์นี้มีไว้เพื่อให้ Package SQL
--   ตรงกับของจริงเท่านั้น (ติดตั้งระบบใหม่ตั้งแต่ศูนย์)
--   ถ้าเผลอรัน จะมี PREFLIGHT หยุดให้ก่อน (ดูด้านล่าง)
--
-- Definition คัดลอกจาก pg_get_functiondef ของ Production ทุกบรรทัด
--   ไม่แก้ Signature · ไม่แก้ Logic · ไม่เพิ่ม/ลดเงื่อนไขใด
--   Signature: njhr_activation_reject(p_token text, p_request_id uuid, p_reason text)
--   Returns:   TABLE(ok boolean, message text)
--
-- ต้องรัน C2_activation_en.sql (ตาราง njhr_activation_requests + RPC อื่นของชุดนี้) มาก่อน
-- ============================================================

-- ─── 0) PREFLIGHT — กันรันทับของจริงบน Production ────────────
do $$
begin
  if to_regclass('public.njhr_activation_requests') is null then
    raise exception 'PREFLIGHT: ไม่พบตาราง njhr_activation_requests — ต้องรัน C2_activation_en.sql ก่อน';
  end if;

  if exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
              where n.nspname = 'public' and p.proname = 'njhr_activation_reject') then
    raise exception
      'PREFLIGHT: njhr_activation_reject มีอยู่แล้วในฐานข้อมูลนี้ — ไฟล์นี้ใช้สำหรับติดตั้งใหม่เท่านั้น '
      'ห้ามรันทับของจริง (ถ้าตั้งใจติดตั้งใหม่จริง ให้ลบ Function เดิมก่อนด้วยตนเอง)';
  end if;

  raise notice 'PREFLIGHT ผ่าน — ฐานข้อมูลนี้ยังไม่มี njhr_activation_reject จึงติดตั้งได้';
end $$;


begin;

CREATE OR REPLACE FUNCTION public.njhr_activation_reject(
  p_token text,
  p_request_id uuid,
  p_reason text
)
RETURNS TABLE(ok boolean, message text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
#variable_conflict use_column
declare c record; r record;
begin
  select * into c from public.njhr_ctx(p_token);

  if c.role <> 'SUPER_ADMIN' then
    raise exception 'เฉพาะผู้ดูแลระบบสูงสุดเท่านั้นที่ดำเนินการได้'
      using errcode='42501';
  end if;

  if btrim(coalesce(p_reason,'')) = '' then
    raise exception 'กรุณาระบุเหตุผลที่ไม่อนุมัติ'
      using errcode='22023';
  end if;

  select * into r
  from public.njhr_activation_requests
  where id = p_request_id
  for update;

  if not found then
    raise exception 'ไม่พบคำขอนี้'
      using errcode='P0002';
  end if;

  if r.status <> 'PENDING' then
    raise exception 'คำขอนี้ถูกดำเนินการไปแล้ว'
      using errcode='22023';
  end if;

  update public.njhr_activation_requests
     set status = 'REJECTED',
         decided_at = now(),
         decided_by = c.app_user_id,
         reject_reason = btrim(p_reason)
   where id = r.id;

  perform public.njhr_audit_write(
    p_token,
    'ACTIVATION_REJECT',
    'user',
    'njhr_activation_requests',
    r.id::text,
    'ไม่อนุมัติคำขอเปิดใช้งานของ ' || r.emp_code ||
    ' · เหตุผล: ' || btrim(p_reason),
    null,
    null,
    null
  );

  return query
  select true, 'บันทึกการไม่อนุมัติแล้ว'::text;
end
$function$;

revoke all on function public.njhr_activation_reject(text, uuid, text) from public;
grant execute on function public.njhr_activation_reject(text, uuid, text)
  to anon, authenticated, service_role;

comment on function public.njhr_activation_reject(text, uuid, text) is
  'ไม่อนุมัติคำขอเปิดใช้งานบัญชีครั้งแรก (SUPER_ADMIN เท่านั้น) — Definition ตรงกับ Production';

insert into public.njhr_schema_version(version, note)
values ('v2.10-activation-reject-package',
        'njhr_activation_reject — เติม Definition เข้า Package สำหรับติดตั้งใหม่ (ไม่แตะ Production)')
on conflict (version) do nothing;

commit;


-- ─── VERIFICATION ───────────────────────────────────────────
select jsonb_pretty(jsonb_build_object(
  'function_exists', (select count(*) from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                       where n.nspname = 'public' and p.proname = 'njhr_activation_reject') > 0,
  'signature', (select pg_get_function_identity_arguments(p.oid)
                  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                 where n.nspname = 'public' and p.proname = 'njhr_activation_reject'),
  'returns', (select pg_get_function_result(p.oid)
                from pg_proc p join pg_namespace n on n.oid = p.pronamespace
               where n.nspname = 'public' and p.proname = 'njhr_activation_reject'),
  'requests_rows', (select count(*) from public.njhr_activation_requests)
)) as install_report;
