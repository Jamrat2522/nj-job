-- ============================================================
-- NJ HR V2 — 88_wht50_send.sql
-- รายงาน 50 ทวิ — ชั้น "สถานะการส่ง" (ต่อยอดจาก 87_wht50.sql)
--
-- ทำไมต้องแยกไฟล์
--   87_wht50.sql มีวงจร "สถานะเอกสาร" อยู่แล้ว: DRAFT · CONFIRMED · CANCELLED · AMENDED
--   ซึ่งเป็นเรื่องความถูกต้องของเอกสารตามกฎหมาย (ออกเลข · ยกเลิก · ออกฉบับแก้ไข)
--   ส่วนโจทย์ต้องการ "สถานะการส่ง": ยังไม่ส่ง · ส่งแล้ว · เปิดแล้ว
--   สองเรื่องนี้เป็นคนละแกน — เอกสารที่ CONFIRMED แล้วอาจยังไม่ได้ส่ง
--   จึงเก็บทั้งคู่ แยกคอลัมน์ ไม่เอาแกนหนึ่งไปทับอีกแกน (ตามที่ผู้ใช้ยืนยัน)
--
-- ไฟล์นี้ไม่แก้ 87_wht50.sql แม้แต่บรรทัดเดียว — เพิ่มคอลัมน์และ RPC ใหม่เท่านั้น
--
-- แหล่งข้อมูลจริงที่ยืนยันแล้ว (ไม่มีการเดาคอลัมน์)
--   payroll   : employee_id · period_year · status · total_income · tax · social_security
--               (53_payslip.sql บรรทัด 15–22)
--   employees : id · emp_code · prefix · first_name · last_name · nickname
--               national_id · address · department_name · position_name · status
--               (48_employees.sql บรรทัด 18–27)
--   njhr_wht50 : ตารางเอกสารจาก 87_wht50.sql
--
-- กติกาการรวมรายได้ — ใช้ชุดเดียวกับ 87 ทุกประการ
--   นับเฉพาะ payroll ที่ period_year = ปีภาษี และ status ∈ (CALCULATED, PAID)
--   1 พนักงาน × 1 งวด มีแถวเดียว จึงไม่มีทางนับซ้ำ
--
-- ต้องรัน 87_wht50.sql มาก่อน · รันซ้ำได้
-- ============================================================

-- ─── 0) PREFLIGHT ───────────────────────────────────────────
do $$
begin
  if to_regclass('public.njhr_wht50') is null then
    raise exception 'PREFLIGHT: ไม่พบตาราง njhr_wht50 — ต้องรัน 87_wht50.sql ก่อน';
  end if;
  if not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                  where n.nspname = 'public' and p.proname = 'njhr_wht50_guard') then
    raise exception 'PREFLIGHT: ไม่พบ njhr_wht50_guard — ต้องรัน 87_wht50.sql ก่อน';
  end if;
  if to_regclass('public.payroll') is null then
    raise exception 'PREFLIGHT: ไม่พบตาราง payroll';
  end if;
  raise notice 'PREFLIGHT ผ่าน';
end $$;


begin;

-- ─── 1) คอลัมน์สถานะการส่ง ──────────────────────────────────
--  แยกจาก status (สถานะเอกสาร) โดยสิ้นเชิง
--    NOT_SENT = ยังไม่ส่ง · SENT = ส่งแล้ว · OPENED = เปิดแล้ว
alter table public.njhr_wht50
  add column if not exists send_status text not null default 'NOT_SENT',
  add column if not exists sent_at     timestamptz,
  add column if not exists sent_by     text,
  add column if not exists opened_at   timestamptz,
  add column if not exists send_error  text,
  add column if not exists send_count  int not null default 0;   -- จำนวนครั้งที่ส่ง (ส่งซ้ำต้องสั่งชัดเจน)

do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'njhr_wht50_send_status_chk') then
    alter table public.njhr_wht50 add constraint njhr_wht50_send_status_chk
      check (send_status in ('NOT_SENT','SENT','OPENED'));
  end if;
end $$;

create index if not exists njhr_wht50_send_idx
  on public.njhr_wht50 (tax_year, send_status);

comment on column public.njhr_wht50.send_status is
  'สถานะการส่ง NOT_SENT/SENT/OPENED — คนละแกนกับ status (สถานะเอกสาร)';
comment on column public.njhr_wht50.send_count is
  'จำนวนครั้งที่ส่งสำเร็จ — ใช้ยืนยันว่าไม่มีการส่งซ้ำโดยไม่ตั้งใจ';


-- ─── 2) รายชื่อพนักงาน + ยอดรายปี + สถานะเอกสาร + สถานะการส่ง ───
--  ต่อยอดจาก njhr_wht50_employees ของ 87 โดยเพิ่มสถานะการส่งเข้ามา
--  ไม่แก้ของเดิม เพื่อให้สิ่งที่ 87 ทำไว้ยังทำงานเหมือนเดิมทุกอย่าง
--
--  p_send_status: NOT_SENT · SENT · OPENED · null/'' = ทั้งหมด
create or replace function public.njhr_wht50_send_list(
  p_token text, p_year int, p_q text default null,
  p_send_status text default null, p_dept text default null)
returns table (
  employee_id uuid, emp_code text, full_name text, nickname text,
  national_id_masked text, has_national_id boolean, has_address boolean,
  department_name text, position_name text, emp_status text,
  periods int, total_income numeric, total_tax numeric, total_sso numeric,
  doc_id uuid, doc_no text, doc_status text, issue_date date, amend_seq int,
  send_status text, sent_at timestamptz, sent_by text, opened_at timestamptz,
  send_count int, is_ready boolean)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare c record; q text := lower(btrim(coalesce(p_q,'')));
        ss text := nullif(upper(btrim(coalesce(p_send_status,''))),'');
begin
  select * into c from public.njhr_wht50_guard(p_token, false);
  if p_year is null then raise exception 'กรุณาเลือกปีภาษี' using errcode='22023'; end if;
  if ss is not null and ss not in ('NOT_SENT','SENT','OPENED') then
    raise exception 'สถานะการส่งไม่ถูกต้อง (%)', p_send_status using errcode='22023';
  end if;

  return query
  with inc as (
    select p.employee_id eid, count(*)::int n,
           round(coalesce(sum(p.total_income),0),2) ti,
           round(coalesce(sum(p.tax),0),2) tx,
           round(coalesce(sum(p.social_security),0),2) so
      from public.payroll p
     where p.period_year = p_year
       and upper(coalesce(p.status::text,'')) in ('CALCULATED','PAID')
     group by p.employee_id
  ), doc as (
    select d.employee_id eid, d.id did, d.doc_no dno, d.status dst,
           d.issue_date idt, d.amend_seq aseq,
           d.send_status sst, d.sent_at sat, d.sent_by sby,
           d.opened_at oat, d.send_count scn
      from public.njhr_wht50 d
     where d.tax_year = p_year and d.status in ('DRAFT','CONFIRMED')
  )
  select e.id, e.emp_code,
         coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,''),
         coalesce(e.nickname,''),
         public.njhr_wht50_mask_id(e.national_id),
         coalesce(btrim(e.national_id),'') <> '',
         coalesce(btrim(e.address),'') <> '',
         coalesce(e.department_name,''), coalesce(e.position_name,''), e.status::text,
         coalesce(inc.n, 0), coalesce(inc.ti, 0), coalesce(inc.tx, 0), coalesce(inc.so, 0),
         doc.did, coalesce(doc.dno,''), coalesce(doc.dst,'NONE'), doc.idt, coalesce(doc.aseq,0),
         coalesce(doc.sst,'NOT_SENT'), doc.sat, coalesce(doc.sby,''), doc.oat,
         coalesce(doc.scn,0),
         /* พร้อมส่ง = มีเอกสารที่ยืนยันแล้ว + ยังไม่ได้ส่ง + ข้อมูลระบุตัวตนครบ */
         (coalesce(doc.dst,'NONE') = 'CONFIRMED'
          and coalesce(doc.sst,'NOT_SENT') = 'NOT_SENT'
          and coalesce(btrim(e.national_id),'') <> '')
    from public.employees e
    left join inc on inc.eid = e.id
    left join doc on doc.eid = e.id
   where coalesce(inc.n,0) > 0                       -- มีงวดเงินเดือนในปีภาษีนั้นจริงเท่านั้น
     and (p_dept is null or p_dept = '' or e.department_name = p_dept)
     and (ss is null or coalesce(doc.sst,'NOT_SENT') = ss)
     and (q = '' or lower(coalesce(e.emp_code,'')) like '%'||q||'%'
          or lower(coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,'')) like '%'||q||'%'
          or lower(coalesce(e.nickname,'')) like '%'||q||'%'
          or lower(coalesce(e.department_name,'')) like '%'||q||'%')
   order by e.emp_code;
end $$;


-- ─── 3) ตัวเลขสรุปสำหรับกล่องยืนยัน "ส่งทั้งหมด" ─────────────
--  ทุกตัวเลขนับจากข้อมูลจริงชุดเดียวกับรายการด้านบน ไม่ได้นับคนละที่
create or replace function public.njhr_wht50_send_summary(p_token text, p_year int)
returns table (
  total_emp int,        -- พนักงานที่มีงวดเงินเดือนในปีภาษีนี้
  ready int,            -- พร้อมส่ง (เอกสารยืนยันแล้ว · ยังไม่ส่ง · ข้อมูลครบ)
  already_sent int,     -- ส่งแล้ว (รวมที่เปิดแล้ว)
  opened int,           -- เปิดแล้ว
  no_doc int,           -- ยังไม่มีเอกสาร หรือเอกสารยังเป็นร่าง
  incomplete int)       -- ข้อมูลไม่ครบ (ไม่มีเลขประจำตัวประชาชน)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare c record;
begin
  select * into c from public.njhr_wht50_guard(p_token, false);
  if p_year is null then raise exception 'กรุณาเลือกปีภาษี' using errcode='22023'; end if;

  return query
  with r as (
    select * from public.njhr_wht50_send_list(p_token, p_year, null, null, null)
  )
  select count(*)::int,
         count(*) filter (where r.is_ready)::int,
         count(*) filter (where r.send_status in ('SENT','OPENED'))::int,
         count(*) filter (where r.send_status = 'OPENED')::int,
         count(*) filter (where r.doc_status <> 'CONFIRMED')::int,
         count(*) filter (where not r.has_national_id)::int
    from r;
end $$;


-- ─── 4) สิทธิ์ ──────────────────────────────────────────────
--  ตรวจสิทธิ์จริงที่ njhr_wht50_guard (อ่าน Role จากฐานข้อมูล ไม่รับจาก Frontend)
--  RLS ของ njhr_wht50 เปิดอยู่แล้วจาก 87 และไม่มี policy ให้ anon
--  จึงแตะตารางตรง ๆ ไม่ได้ ต้องผ่าน RPC เหล่านี้เท่านั้น
revoke all on function public.njhr_wht50_send_list(text,int,text,text,text) from public;
revoke all on function public.njhr_wht50_send_summary(text,int) from public;
grant execute on function public.njhr_wht50_send_list(text,int,text,text,text) to anon, authenticated;
grant execute on function public.njhr_wht50_send_summary(text,int) to anon, authenticated;

insert into public.njhr_schema_version(version, note)
values ('v3.4-wht50-send', 'รายงาน 50 ทวิ — เพิ่มแกนสถานะการส่ง (NOT_SENT/SENT/OPENED) + RPC รายการและตัวเลขสรุป')
on conflict (version) do nothing;

commit;


-- ════════════════════════════════════════════════════════════
-- VERIFICATION
-- ════════════════════════════════════════════════════════════
select jsonb_pretty(jsonb_build_object(
  'คอลัมน์การส่งครบ',
    (select count(*) = 6 from information_schema.columns
      where table_schema='public' and table_name='njhr_wht50'
        and column_name in ('send_status','sent_at','sent_by','opened_at','send_error','send_count')),
  'สถานะเอกสารเดิมยังอยู่ครบ',
    (select count(*) = 1 from pg_constraint where conname='njhr_wht50_status_chk'),
  'constraint สถานะการส่ง',
    (select count(*) = 1 from pg_constraint where conname='njhr_wht50_send_status_chk'),
  'RPC ใหม่',
    (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname in ('njhr_wht50_send_list','njhr_wht50_send_summary')),
  'RPC เดิมของ 87 ยังครบ',
    (select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname like 'njhr_wht50%'),
  'RLS njhr_wht50 เปิดอยู่',
    (select relrowsecurity from pg_class where oid = 'public.njhr_wht50'::regclass),
  'เอกสารทั้งหมด', (select count(*) from public.njhr_wht50),
  'ยังไม่ส่ง', (select count(*) from public.njhr_wht50 where send_status='NOT_SENT')
)) as report;
