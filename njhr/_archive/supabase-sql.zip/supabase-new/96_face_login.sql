-- ============================================================
-- NJ HR V2 — 96_face_login.sql
-- เข้าสู่ระบบด้วยใบหน้าแทนรหัสผ่าน (เฉพาะมือถือ)
--
-- ⚠⚠ ไฟล์นี้ยังไม่ได้รัน — ส่งมาให้ตรวจก่อนเท่านั้น ⚠⚠
--
-- ต่างจากการสแกนหน้าลงเวลาอย่างไร (สำคัญมาก)
--   njhr_face_verify  = 1:1  รู้อยู่แล้วว่าเป็นใคร (มี token) แค่ยืนยันว่าใช่คนเดิม
--   njhr_face_login   = 1:N  ยังไม่รู้ว่าเป็นใคร ต้องค้นจากพนักงานทุกคน
--   1:N เสี่ยงกว่ามาก เพราะยิ่งมีพนักงานเยอะ โอกาสหน้าคล้ายกันยิ่งสูง
--   จึงต้องเข้มกว่า 1:1 สามชั้น:
--     1. ระยะทางต้องต่ำกว่าเกณฑ์ลงเวลา (ค่าตั้งต้น 0.42 เทียบกับ 0.50 ของลงเวลา)
--     2. ต้องชนะอันดับสองอย่างชัดเจน (margin 0.06) — ถ้าสองคนใกล้เคียงกันให้ปฏิเสธทั้งคู่
--     3. ต้องเปิด face_login_enabled ของบัญชีนั้นไว้เอง
--   ทั้งสามค่าปรับได้ที่ system_settings โดยไม่ต้องแก้ฟังก์ชัน
--
-- ความปลอดภัยอื่น
--   · การเทียบใบหน้าทำฝั่งฐานข้อมูลทั้งหมด ไม่เคยส่ง descriptor ของใครออกไปที่เบราว์เซอร์
--   · บังคับ Liveness เสมอ (ไม่มีทางปิดผ่านพารามิเตอร์)
--   · จำกัดจำนวนครั้งที่ล้มเหลว 10 ครั้ง / 15 นาที ต่อ 1 อุปกรณ์ (p_device_key)
--     เพราะ RPC นี้ไม่มี token จึงกันด้วยคีย์อุปกรณ์ + บันทึกทุกครั้งลง njhr_face_attempts
--   · ไม่แตะรหัสผ่าน — เข้าด้วยรหัสผ่านยังทำได้ตลอดเวลาเป็นระบบสำรอง
--   · สร้าง session ด้วย njhr_sessions ตัวเดิม โครงสร้างเดียวกับ njhr_login
--
-- ไม่แตะ: njhr_login · njhr_face_verify · njhr_att_punch_face · njhr_face_enroll
--         njhr_face_guard · Attendance · GPS · Geofence · Payroll · Leave · OT
-- ต้องรัน 92_face_attendance.sql มาก่อน · รันซ้ำได้
-- ============================================================

-- ─── 0) PREFLIGHT ───────────────────────────────────────────
do $$
begin
  if to_regclass('public.njhr_emp_faces') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_emp_faces — ต้องรัน 92_face_attendance.sql ก่อน';
  end if;
  if to_regclass('public.njhr_sessions') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_sessions — ต้องรัน 31_secure_session.sql ก่อน';
  end if;
  if to_regprocedure('public.njhr_face_distance(jsonb,float8[])') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_face_distance';
  end if;
  if to_regclass('public.njhr_face_attempts') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_face_attempts';
  end if;
  raise notice 'พนักงานที่ลงทะเบียนใบหน้าแล้ว: % คน',
    (select count(*) from public.njhr_emp_faces where is_active);
  raise notice 'PREFLIGHT ผ่าน';
end $$;


begin;

-- ─── 1) สวิตช์เปิด/ปิด Face Login รายบัญชี ──────────────────
--  ค่าเริ่มต้น false — ต้องตั้งค่าเองในหน้าข้อมูลส่วนตัวก่อนจึงใช้ได้
alter table public.app_users
  add column if not exists face_login_enabled boolean not null default false,
  add column if not exists face_login_set_at  timestamptz;

comment on column public.app_users.face_login_enabled is
  'เปิดให้เข้าสู่ระบบด้วยใบหน้าได้หรือไม่ — พนักงานตั้งเองในหน้าข้อมูลส่วนตัว (ยืนยันรหัสผ่านก่อน)';

-- ค่าตั้งต้นของเกณฑ์ 1:N (แก้ได้ภายหลังโดยไม่ต้องแก้ฟังก์ชัน)
insert into public.system_settings(key, value) values
  ('face_login_max_distance', '0.42'::jsonb),
  ('face_login_margin',       '0.06'::jsonb),
  ('face_login_max_fail',     '10'::jsonb)
on conflict (key) do nothing;


-- ─── 2) เปิด/ปิด Face Login ด้วยตนเอง (ต้องยืนยันรหัสผ่าน) ──
create or replace function public.njhr_face_login_set(
  p_token text, p_password text, p_enable boolean)
returns table (face_login_enabled boolean, message text)
language plpgsql security definer set search_path = public as $function$
#variable_conflict use_column
declare c record; u public.app_users; ok boolean := false;
begin
  select * into c from public.njhr_face_guard(p_token, false);
  select a.* into u from public.app_users a where a.id = c.app_user_id;
  if not found then raise exception 'ไม่พบบัญชีผู้ใช้นี้' using errcode='28000'; end if;

  /* ---- ยืนยันรหัสผ่านปัจจุบันเสมอ ทั้งตอนเปิดและตอนปิด ---- */
  if u.password_hash is not null and u.password_hash like '$2%' then
    ok := (u.password_hash = crypt(p_password, u.password_hash));
  elsif u.password is not null and u.password <> '' then
    ok := (u.password = p_password);
  end if;
  if not ok then raise exception 'รหัสผ่านไม่ถูกต้อง' using errcode='28P01'; end if;

  if p_enable then
    if c.employee_id is null then
      raise exception 'บัญชีนี้ยังไม่ได้ผูกกับข้อมูลพนักงาน' using errcode='22023';
    end if;
    if not exists (select 1 from public.njhr_emp_faces f
                    where f.employee_id = c.employee_id and f.is_active) then
      raise exception 'ยังไม่ได้ลงทะเบียนใบหน้า กรุณาลงทะเบียนใบหน้าก่อนเปิดใช้งาน'
        using errcode='22023';
    end if;
  end if;

  update public.app_users a
     set face_login_enabled = p_enable,
         face_login_set_at  = now()
   where a.id = u.id;

  begin
    perform public.njhr_audit_write(p_token,
      case when p_enable then 'FACE_LOGIN_ENABLE' else 'FACE_LOGIN_DISABLE' end,
      'security', 'app_users', u.id::text,
      case when p_enable then 'เปิดการเข้าสู่ระบบด้วยใบหน้า'
           else 'ปิดการเข้าสู่ระบบด้วยใบหน้า' end, null, null, null);
  exception when undefined_function then null;
  end;

  return query select p_enable,
    (case when p_enable then 'เปิดการเข้าสู่ระบบด้วยใบหน้าแล้ว'
          else 'ปิดการเข้าสู่ระบบด้วยใบหน้าแล้ว' end)::text;
end $function$;


-- ─── 3) สถานะ Face Login ของตัวเอง ─────────────────────────
create or replace function public.njhr_face_login_status(p_token text)
returns table (enrolled boolean, face_login_enabled boolean, set_at timestamptz)
language plpgsql stable security definer set search_path = public as $function$
#variable_conflict use_column
declare c record;
begin
  select * into c from public.njhr_face_guard(p_token, false);
  return query
    select exists (select 1 from public.njhr_emp_faces f
                    where f.employee_id = c.employee_id and f.is_active),
           coalesce(a.face_login_enabled,false), a.face_login_set_at
      from public.app_users a where a.id = c.app_user_id;
end $function$;


-- ─── 4) เข้าสู่ระบบด้วยใบหน้า (1:N) ─────────────────────────
--  คืนค่าโครงเดียวกับ njhr_login ทุกคอลัมน์ เพื่อให้ Frontend ใช้เส้นทางเดิมได้เลย
create or replace function public.njhr_face_login(
  p_descriptor float8[], p_faces_found int default 1,
  p_liveness boolean default null, p_liveness_method text default null,
  p_device_key text default null, p_ua text default null)
returns table (
  session_token text, expires_at timestamptz,
  user_id uuid, username text, internal_username text, email text, full_name text,
  department text, role text, status text, employee_id uuid,
  emp_code text, emp_name text, emp_department text, emp_position text, emp_status text
)
language plpgsql security definer set search_path = public as $function$
#variable_conflict use_column
declare
  u public.app_users; best record; second_d numeric;
  v_max numeric; v_margin numeric; v_maxfail int; v_fail int;
  v_key text; tok text; exp timestamptz; v_len int;
begin
  v_max     := coalesce((select (s.value)::text::numeric from public.system_settings s
                          where s.key = 'face_login_max_distance'), 0.42);
  v_margin  := coalesce((select (s.value)::text::numeric from public.system_settings s
                          where s.key = 'face_login_margin'), 0.06);
  v_maxfail := coalesce((select (s.value)::text::int from public.system_settings s
                          where s.key = 'face_login_max_fail'), 10);
  v_key := left(coalesce(nullif(btrim(p_device_key),''), 'unknown'), 80);

  /* ---- จำกัดจำนวนครั้งที่ล้มเหลวต่ออุปกรณ์ (RPC นี้ไม่มี token จึงกันด้วยคีย์อุปกรณ์) ---- */
  select count(*) into v_fail from public.njhr_face_attempts
   where action = 'LOGIN' and passed is not true
     and created_at > now() - interval '15 minutes'
     and coalesce(device,'') = v_key;
  if v_fail >= v_maxfail then
    raise exception 'ลองสแกนใบหน้าผิดหลายครั้งเกินไป กรุณารอสักครู่หรือเข้าสู่ระบบด้วยรหัสผ่าน'
      using errcode='28000';
  end if;

  /* ---- ต้องเป็นบุคคลจริงและมีใบหน้าเดียวเท่านั้น ---- */
  if coalesce(p_faces_found,1) <> 1 then
    insert into public.njhr_face_attempts(action, passed, fail_reason, faces_found, device, browser)
    values ('LOGIN', false, 'พบใบหน้าไม่ใช่ 1 คน', p_faces_found, v_key, left(coalesce(p_ua,''),200));
    raise exception 'ต้องพบใบหน้าเพียง 1 คนในกล้อง' using errcode='22023';
  end if;
  if coalesce(p_liveness,false) is not true then
    insert into public.njhr_face_attempts(action, passed, fail_reason, liveness_passed, device, browser)
    values ('LOGIN', false, 'liveness ไม่ผ่าน', false, v_key, left(coalesce(p_ua,''),200));
    raise exception 'ตรวจไม่พบว่าเป็นบุคคลจริง กรุณาสแกนใหม่' using errcode='22023';
  end if;
  v_len := array_length(p_descriptor, 1);
  if coalesce(v_len,0) < 64 then
    raise exception 'ข้อมูลใบหน้าที่สแกนไม่ถูกต้อง' using errcode='22023';
  end if;

  /* ---- ค้นจากพนักงานทุกคนที่เปิด Face Login ไว้ (ทำในฐานข้อมูลทั้งหมด) ---- */
  select x.employee_id, x.dist into best
    from (select f.employee_id,
                 (select min(public.njhr_face_distance(d, p_descriptor))
                    from jsonb_array_elements(f.descriptors) d) as dist
            from public.njhr_emp_faces f
           where f.is_active
             and f.descriptor_len = v_len
             and exists (select 1 from public.app_users a
                          where a.employee_id = f.employee_id
                            and a.app_code = 'salary'
                            and a.face_login_enabled
                            and coalesce(a.is_active,true))) x
   where x.dist is not null
   order by x.dist asc limit 1;

  if best.employee_id is null then
    insert into public.njhr_face_attempts(action, passed, fail_reason, device, browser)
    values ('LOGIN', false, 'ไม่พบใบหน้าที่ตรงกัน', v_key, left(coalesce(p_ua,''),200));
    raise exception 'ไม่สามารถยืนยันใบหน้าได้ กรุณาเข้าสู่ระบบด้วยรหัสผ่าน' using errcode='28000';
  end if;

  if best.dist > v_max then
    insert into public.njhr_face_attempts(action, passed, fail_reason, face_distance, device, browser)
    values ('LOGIN', false, 'ระยะห่างเกินเกณฑ์', best.dist, v_key, left(coalesce(p_ua,''),200));
    raise exception 'ไม่สามารถยืนยันใบหน้าได้ กรุณาเข้าสู่ระบบด้วยรหัสผ่าน' using errcode='28000';
  end if;

  /* ---- ⚠ ชั้นที่สำคัญที่สุดของ 1:N: ต้องชนะอันดับสองอย่างชัดเจน ----
     ถ้าพนักงานสองคนหน้าคล้ายกันจนระยะใกล้เคียงกัน ให้ปฏิเสธทั้งคู่
     ดีกว่าปล่อยให้เข้าบัญชีผิดคน */
  select min(x.dist) into second_d
    from (select f.employee_id,
                 (select min(public.njhr_face_distance(d, p_descriptor))
                    from jsonb_array_elements(f.descriptors) d) as dist
            from public.njhr_emp_faces f
           where f.is_active
             and f.descriptor_len = v_len
             and f.employee_id <> best.employee_id
             and exists (select 1 from public.app_users a
                          where a.employee_id = f.employee_id
                            and a.app_code = 'salary'
                            and a.face_login_enabled
                            and coalesce(a.is_active,true))) x;

  if second_d is not null and (second_d - best.dist) < v_margin then
    insert into public.njhr_face_attempts(action, passed, fail_reason, face_distance, device, browser)
    values ('LOGIN', false,
            'ใบหน้าใกล้เคียงกับพนักงานคนอื่นเกินไป (อันดับสอง ' || second_d::text || ')',
            best.dist, v_key, left(coalesce(p_ua,''),200));
    raise exception 'ไม่สามารถยืนยันใบหน้าได้ชัดเจนพอ กรุณาเข้าสู่ระบบด้วยรหัสผ่าน'
      using errcode='28000';
  end if;

  /* ---- ตรวจบัญชีตามเงื่อนไขเดียวกับ njhr_login ---- */
  select a.* into u from public.app_users a
   where a.employee_id = best.employee_id and a.app_code = 'salary'
     and a.face_login_enabled and coalesce(a.is_active,true)
   limit 1;
  if not found then
    raise exception 'ไม่พบบัญชีผู้ใช้ที่เปิดการเข้าสู่ระบบด้วยใบหน้า' using errcode='28000';
  end if;
  if lower(coalesce(u.status,'active')) = 'pending' then
    raise exception 'บัญชีรออนุมัติ กรุณาติดต่อผู้ดูแลระบบ' using errcode='28000';
  end if;
  if lower(coalesce(u.status,'active')) <> 'active' then
    raise exception 'บัญชีไม่พร้อมใช้งาน (สถานะ: %)', u.status using errcode='28000';
  end if;
  if not exists (select 1 from public.employees e
                  where e.id = u.employee_id and e.status::text in ('ACTIVE','PROBATION')) then
    raise exception 'พนักงานรายนี้ไม่ได้ปฏิบัติงานอยู่' using errcode='28000';
  end if;

  /* ---- สร้าง session ด้วยกลไกเดิมทุกประการ ---- */
  update public.njhr_sessions ss set revoked = true
   where ss.app_user_id = u.id and ss.expires_at < now() and not ss.revoked;
  insert into public.njhr_sessions(app_user_id, user_agent)
  values (u.id, left(coalesce(p_ua,''),200))
    returning njhr_sessions.token, njhr_sessions.expires_at into tok, exp;

  insert into public.njhr_face_attempts(employee_id, action, passed, face_distance,
                                        liveness_passed, faces_found, device, browser, os)
  values (u.employee_id, 'LOGIN', true, best.dist, true, 1,
          v_key, left(coalesce(p_ua,''),200), left(coalesce(p_liveness_method,''),40));

  return query
    select tok, exp, u.id, u.username, u.internal_username, u.email, u.full_name, u.department,
           u.role::text, coalesce(u.status,'active'), u.employee_id,
           e.emp_code, (coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,'')),
           e.department_name, e.position_name, e.status::text
      from public.employees e where e.id = u.employee_id;
end $function$;


-- ─── 5) สิทธิ์ ──────────────────────────────────────────────
revoke all on function public.njhr_face_login(float8[],int,boolean,text,text,text) from public;
grant execute on function public.njhr_face_login(float8[],int,boolean,text,text,text)
  to anon, authenticated;              -- ต้องเรียกได้ก่อน login จึงให้ anon

revoke all on function public.njhr_face_login_set(text,text,boolean) from public;
grant execute on function public.njhr_face_login_set(text,text,boolean) to anon, authenticated;

revoke all on function public.njhr_face_login_status(text) from public;
grant execute on function public.njhr_face_login_status(text) to anon, authenticated;

insert into public.njhr_schema_version(version, note)
values ('v14.3-face-login',
        'เข้าสู่ระบบด้วยใบหน้า 1:N — เกณฑ์เข้มกว่าลงเวลา + ต้องชนะอันดับสอง + จำกัดครั้งที่ผิด')
on conflict (version) do nothing;

commit;


-- ════════════════════════════════════════════════════════════
-- VERIFICATION
-- ════════════════════════════════════════════════════════════
select jsonb_pretty(jsonb_build_object(
  'njhr_face_login มีจริง',
    (to_regprocedure('public.njhr_face_login(float8[],int,boolean,text,text,text)') is not null),
  'njhr_face_login_set มีจริง',
    (to_regprocedure('public.njhr_face_login_set(text,text,boolean)') is not null),
  'คอลัมน์ face_login_enabled',
    exists (select 1 from information_schema.columns
             where table_schema='public' and table_name='app_users'
               and column_name='face_login_enabled'),
  'ค่าเริ่มต้นปิดอยู่ (ไม่มีใครถูกเปิดอัตโนมัติ)',
    (select count(*) = 0 from public.app_users where face_login_enabled),
  'เกณฑ์ Login เข้มกว่าลงเวลา',
    (coalesce((select (value)::text::numeric from public.system_settings where key='face_login_max_distance'),0.42)
     < coalesce((select (value)::text::numeric from public.system_settings where key='face_match_max_distance'),0.50)),
  'มีชั้นตรวจ margin อันดับสอง',
    (select pg_get_functiondef(p.oid) like '%second_d%'
       from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname='njhr_face_login' limit 1),
  'บังคับ liveness',
    (select pg_get_functiondef(p.oid) like '%liveness,false) is not true%'
       from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname='njhr_face_login' limit 1),
  'njhr_login เดิมไม่ถูกแตะ',
    (to_regprocedure('public.njhr_login(text,text,text)') is not null),
  'njhr_face_verify เดิมไม่ถูกแตะ',
    (to_regprocedure('public.njhr_face_verify(text,float8[],int,boolean,text)') is not null)
)) as report;


-- ════════════════════════════════════════════════════════════
-- ROLLBACK
-- ════════════════════════════════════════════════════════════
-- drop function if exists public.njhr_face_login(float8[],int,boolean,text,text,text);
-- drop function if exists public.njhr_face_login_set(text,text,boolean);
-- drop function if exists public.njhr_face_login_status(text);
-- alter table public.app_users drop column if exists face_login_enabled;
-- alter table public.app_users drop column if exists face_login_set_at;
-- delete from public.system_settings where key like 'face_login_%';
-- delete from public.njhr_schema_version where version = 'v14.3-face-login';
-- ⚠ การเข้าสู่ระบบด้วยรหัสผ่านไม่ได้รับผลกระทบจาก Rollback
