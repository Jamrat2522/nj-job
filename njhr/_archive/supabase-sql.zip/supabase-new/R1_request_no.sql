-- ============================================================
-- NJ HR V2 — R1_request_no.sql  (ส่วนที่ 1: โครงสร้างเลขรัน)
--
-- เพิ่มเลขที่คำขอรูปแบบ YYMMDD-0001 สำหรับใบลาและ OT
--   · YYMMDD  = วันที่ยื่น ตามโซนเวลา Asia/Bangkok
--   · 0001    = เลขรันต่อเนื่องตลอดเดือน เริ่ม 0001 ใหม่เมื่อขึ้นเดือนใหม่
--   · ใบลาและ OT แยกเลขรันกัน (kind = 'LEAVE' / 'OT')
--   · ตัวอย่าง 260811-0001 → 260812-0002 (วันเปลี่ยน เลขรันต่อเนื่อง)
--
-- วิธีออกเลข: ตารางตัวนับ + SELECT ... FOR UPDATE (Row Lock)
--   ไม่ใช้ MAX+1 · ไม่ใช้ LocalStorage · ไม่สุ่ม
--   หลายคนส่งพร้อมกันจะเข้าคิวที่ Row Lock ทีละคน จึงไม่ซ้ำ
--   ถ้า Transaction ล้ม เลขรันถูก Rollback ไปด้วย จึงไม่ขาด
--
-- ไฟล์นี้เป็น ADDITIVE ล้วน
--   · ไม่แก้ njhr_leave_submit / njhr_ot_submit (ทำในส่วนที่ 2)
--   · ไม่แตะข้อมูลเดิม คำขอเก่า request_no = null ตามเดิม
--   · ไม่ DROP · ไม่ TRUNCATE · รันซ้ำได้
-- ============================================================


-- ═══ 0) PREFLIGHT ═══
do $$
begin
  if to_regclass('public.leave_requests') is null then raise exception 'PREFLIGHT: ไม่พบ leave_requests'; end if;
  if to_regclass('public.ot_requests')    is null then raise exception 'PREFLIGHT: ไม่พบ ot_requests'; end if;
  raise notice 'PREFLIGHT ผ่าน';
end $$;


-- ═══ 1) คอลัมน์ request_no (nullable — คำขอเก่าไม่ต้องเปลี่ยนเลข) ═══
alter table public.leave_requests add column if not exists request_no text;
alter table public.ot_requests    add column if not exists request_no text;

-- UNIQUE เฉพาะแถวที่มีเลข — คำขอเก่าที่เป็น null ไม่ถูกบังคับ
create unique index if not exists leave_requests_reqno_uidx
  on public.leave_requests(request_no) where request_no is not null;
create unique index if not exists ot_requests_reqno_uidx
  on public.ot_requests(request_no) where request_no is not null;


-- ═══ 2) ตารางตัวนับรายเดือน ═══
-- ym เก็บเป็น 'YYMM' ตามเวลา Asia/Bangkok · kind แยกใบลากับ OT
create table if not exists public.njhr_request_seq (
  kind       text not null,
  ym         text not null,
  last_no    integer not null default 0,
  updated_at timestamptz not null default now(),
  primary key (kind, ym),
  constraint njhr_request_seq_kind_ck check (kind in ('LEAVE','OT')),
  constraint njhr_request_seq_no_ck   check (last_no >= 0)
);

alter table public.njhr_request_seq enable row level security;
revoke all on public.njhr_request_seq from anon, authenticated;


-- ═══ 3) ฟังก์ชันออกเลข ═══
-- ต้องเรียกจากภายใน Transaction ของ RPC ที่บันทึกคำขอเท่านั้น
-- Row Lock ทำให้คำขอพร้อมกันได้เลขไม่ซ้ำ และ Rollback พร้อมกันเมื่อบันทึกล้ม
create or replace function public.njhr_next_request_no(p_kind text)
returns text language plpgsql security definer set search_path = public as $$
declare v_now  timestamptz := now();
        v_bkk  date;
        v_ym   text;
        v_ymd  text;
        v_no   integer;
begin
  if p_kind not in ('LEAVE','OT') then
    raise exception 'ประเภทคำขอไม่ถูกต้อง (%)', p_kind using errcode='22023';
  end if;

  -- วันที่ยื่นตามเวลาไทย ไม่ใช่ UTC
  v_bkk := (v_now at time zone 'Asia/Bangkok')::date;
  v_ym  := to_char(v_bkk, 'YYMM');
  v_ymd := to_char(v_bkk, 'YYMMDD');

  -- สร้างแถวของเดือนนี้ถ้ายังไม่มี (ไม่ชนกันเพราะ on conflict do nothing)
  insert into public.njhr_request_seq(kind, ym, last_no)
  values (p_kind, v_ym, 0)
  on conflict (kind, ym) do nothing;

  -- Row Lock: คำขอพร้อมกันจะเข้าคิวทีละราย
  select s.last_no into v_no
    from public.njhr_request_seq s
   where s.kind = p_kind and s.ym = v_ym
   for update;

  v_no := v_no + 1;
  update public.njhr_request_seq
     set last_no = v_no, updated_at = now()
   where kind = p_kind and ym = v_ym;

  -- YYMMDD ของวันที่ยื่น + เลขรันของเดือน
  return v_ymd || '-' || lpad(v_no::text, 4, '0');
end $$;

revoke all on function public.njhr_next_request_no(text) from public, anon, authenticated;
grant execute on function public.njhr_next_request_no(text) to service_role;


insert into public.njhr_schema_version(version, note)
values ('v3.1-request-no', 'เลขที่คำขอ YYMMDD-0001 ต่อเนื่องรายเดือน แยกใบลา/OT (โครงสร้าง)')
on conflict (version) do nothing;


-- ═══ 4) VERIFICATION ═══
select jsonb_pretty(jsonb_build_object(
  'leave_has_request_no', exists(select 1 from information_schema.columns
     where table_schema='public' and table_name='leave_requests' and column_name='request_no'),
  'ot_has_request_no', exists(select 1 from information_schema.columns
     where table_schema='public' and table_name='ot_requests' and column_name='request_no'),
  'unique_indexes', (select coalesce(jsonb_agg(indexname order by indexname), '[]'::jsonb)
     from pg_indexes where schemaname='public'
       and indexname in ('leave_requests_reqno_uidx','ot_requests_reqno_uidx')),
  'seq_table', to_regclass('public.njhr_request_seq') is not null,
  'seq_rls', (select relrowsecurity from pg_class where relname='njhr_request_seq'),
  -- ต้องว่าง: Client เรียกออกเลขเองไม่ได้
  'nextno_client_grants', (select coalesce(jsonb_agg(distinct grantee::text), '[]'::jsonb)
     from information_schema.routine_privileges
    where specific_schema='public' and routine_name::text='njhr_next_request_no'
      and grantee::text in ('anon','authenticated')),
  -- ของเดิมต้องไม่ถูกแตะ
  'leave_rows', (select count(*) from public.leave_requests),
  'leave_rows_with_no', (select count(*) from public.leave_requests where request_no is not null),
  'ot_rows', (select count(*) from public.ot_requests),
  'timezone_check', jsonb_build_object(
     'utc_now', to_char(now() at time zone 'UTC', 'YYYY-MM-DD HH24:MI'),
     'bangkok_now', to_char(now() at time zone 'Asia/Bangkok', 'YYYY-MM-DD HH24:MI'),
     'ymd_that_will_be_used', to_char((now() at time zone 'Asia/Bangkok')::date, 'YYMMDD'))
)) as r1_verification;


-- ═══ 5) ROLLBACK ═══
-- drop function if exists public.njhr_next_request_no(text);
-- drop table if exists public.njhr_request_seq;
-- drop index if exists public.leave_requests_reqno_uidx;
-- drop index if exists public.ot_requests_reqno_uidx;
-- alter table public.leave_requests drop column if exists request_no;
-- alter table public.ot_requests    drop column if exists request_no;
-- delete from public.njhr_schema_version where version = 'v3.1-request-no';
-- (ไม่มีข้อมูลเดิมถูกแก้ จึงไม่ต้องคืนค่าอย่างอื่น)
