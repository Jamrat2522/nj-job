-- ============================================================
-- NJ HR V2 — PROPOSED_ot_legacy_migrate.sql
--
-- ⛔⛔ PROPOSED MIGRATION ONLY — ห้ามรันไฟล์นี้ ⛔⛔
--   ไฟล์นี้เป็น "ข้อเสนอ" เพื่อให้ตัดสินใจก่อน ยังไม่ได้รันบน Production
--   และยังไม่ควรรันจนกว่าจะอนุมัติเนื้อหาในไฟล์นี้ทั้งหมด
--   มี PREFLIGHT ที่ raise exception ทันทีเพื่อกันการรันโดยไม่ตั้งใจ (ดูท้ายไฟล์)
--
-- ปัญหาที่ต้องแก้: OT MIGRATION NEEDS LEGACY METADATA SUPPORT
--   njhr_ot_migrate ปัจจุบัน (65_ot.sql) รับเฉพาะ
--     emp_code · date · start · end · next_day · status · reason · jobs[]
--   จึงทำให้ข้อมูลต่อไปนี้ของ OT เดิมใน localStorage "หายถาวร" ถ้า Import ตอนนี้
--     · legacy_request_no   เลขคำขอเดิม เช่น OT-mso...
--     · timeline            ส่งคำขอ/อนุมัติ/ไม่อนุมัติ/ยกเลิก + ผู้ทำ + เวลา + หมายเหตุ
--     · approver            ผู้อนุมัติ
--     · approved_at         เวลาอนุมัติ
--     · created_at          เวลายื่นคำขอเดิม
--     · attachments         ไฟล์แนบเดิมใน bucket ot-attachments
--
-- ข้อเสนอนี้ "เพิ่มอย่างเดียว" — ไม่แก้ njhr_ot_migrate ตัวเดิม
--   1. เพิ่มคอลัมน์เก็บร่องรอยเดิมลง ot_requests (nullable ทั้งหมด)
--   2. สร้าง RPC ใหม่ njhr_ot_migrate_legacy ที่รับ metadata ครบ
--   ตัวเดิมยังอยู่ครบ ผู้เรียกเดิมไม่กระทบ
--
-- ยังไม่ตัดสินใจ 2 เรื่อง ต้องได้คำตอบก่อนจึงจะรันได้
--   ก. เลขคำขอ: เก็บเลขเดิมไว้ที่ legacy_request_no แล้วออกเลขใหม่ให้ request_no
--      หรือใช้เลขเดิมเป็น request_no ไปเลย (เสี่ยงชนกับรูปแบบ YYMMDD-0001)
--   ข. ไฟล์แนบ: ต้องมีตาราง Mapping path เดิม → ot_id ใหม่ ก่อน Import
--      ไฟล์ที่จับคู่ไม่ได้ = UNRESOLVED LEGACY OT ATTACHMENT (ห้ามลบ ห้ามย้าย)
-- ============================================================


-- ─── ⛔ PREFLIGHT — กันการรันโดยไม่ตั้งใจ ────────────────────
do $$
begin
  raise exception
    'PROPOSED MIGRATION ONLY — ไฟล์นี้ยังไม่ได้รับอนุมัติให้รัน '
    'กรุณาตัดสินใจเรื่อง legacy_request_no และ Attachment Mapping ก่อน '
    'แล้วจึงลบบล็อก PREFLIGHT นี้ออกด้วยตนเอง';
end $$;


-- ─── 1) คอลัมน์เก็บร่องรอยของ OT เดิม (เพิ่มอย่างเดียว) ──────
alter table public.ot_requests add column if not exists legacy_request_no text;
alter table public.ot_requests add column if not exists legacy_source     text;
alter table public.ot_requests add column if not exists legacy_payload    jsonb;

comment on column public.ot_requests.legacy_request_no is
  'เลขคำขอเดิมจากระบบ localStorage เช่น OT-mso... — null = คำขอที่เกิดในระบบใหม่';
comment on column public.ot_requests.legacy_source is
  'แหล่งที่มาของข้อมูลเดิม เช่น localStorage:njhr_db_v3';
comment on column public.ot_requests.legacy_payload is
  'สำเนา Payload เดิมทั้งก้อน (timeline · approver · approved_at · attachments) เก็บไว้ตรวจสอบย้อนหลัง';

create index if not exists ot_requests_legacy_no_idx
  on public.ot_requests(legacy_request_no) where legacy_request_no is not null;


-- ─── 2) RPC ใหม่: นำเข้า OT เดิมพร้อม Metadata ครบ ───────────
--   p_rows ตัวอย่าง (ตรงกับไฟล์ที่ปุ่ม "ดาวน์โหลดข้อมูลเดิม (.json)" ส่งออก)
--   [{ "migrate": { emp_code, date, start, end, next_day, status, reason, jobs[] },
--      "legacy":  { legacy_request_no, created_at, approver, approved_at,
--                   timeline[], note, dept_snapshot, position_snapshot, jobs[] } }]
create or replace function public.njhr_ot_migrate_legacy(
  p_token text, p_rows jsonb, p_dry_run boolean default true)
returns table (row_no int, action text, ot_id uuid, legacy_no text, message text)
language plpgsql security definer set search_path = public as $$
#variable_conflict use_column
declare c record; r jsonb; m jsonb; g jsonb; i int := 0;
        v_emp uuid; v_id uuid; v_status text; v_hours numeric; v_mins int;
begin
  select * into c from public.njhr_ot_guard(p_token);
  if c.role not in ('SUPER_ADMIN') then
    raise exception 'เฉพาะผู้ดูแลระบบสูงสุดเท่านั้นที่นำเข้าข้อมูลเดิมได้' using errcode='42501';
  end if;
  if p_rows is null or jsonb_typeof(p_rows) <> 'array' then
    raise exception 'p_rows ต้องเป็น array' using errcode='22023';
  end if;

  for r in select * from jsonb_array_elements(p_rows) loop
    i := i + 1;
    m := r->'migrate';
    g := r->'legacy';

    select e.id into v_emp from public.employees e
     where e.emp_code = btrim(coalesce(m->>'emp_code',''));
    if v_emp is null then
      row_no := i; action := 'ERROR'; ot_id := null;
      legacy_no := g->>'legacy_request_no';
      message := 'ไม่พบพนักงานรหัส ' || coalesce(m->>'emp_code','(ว่าง)');
      return next; continue;
    end if;

    -- กันนำเข้าซ้ำด้วยเลขคำขอเดิม
    if g->>'legacy_request_no' is not null and exists (
         select 1 from public.ot_requests o
          where o.legacy_request_no = g->>'legacy_request_no') then
      row_no := i; action := 'SKIP'; ot_id := null;
      legacy_no := g->>'legacy_request_no';
      message := 'นำเข้าแล้วก่อนหน้านี้';
      return next; continue;
    end if;

    v_status := upper(coalesce(m->>'status','APPROVED'));
    v_mins := (extract(epoch from (m->>'end')::time) - extract(epoch from (m->>'start')::time))::int / 60
              + (case when coalesce((m->>'next_day')::boolean,false) then 1440 else 0 end);
    v_hours := round((v_mins / 60.0)::numeric, 2);

    if p_dry_run then
      row_no := i; action := 'INSERT'; ot_id := null;
      legacy_no := g->>'legacy_request_no';
      message := 'ตรวจผ่าน (ยังไม่บันทึกเพราะเป็น dry run)';
      return next; continue;
    end if;

    insert into public.ot_requests (
      employee_id, ot_date, start_time, end_time, ot_hours, reason, status,
      spans_next_day, created_at, approvals,
      legacy_request_no, legacy_source, legacy_payload)
    values (
      v_emp, (m->>'date')::date, (m->>'start')::time, (m->>'end')::time,
      v_hours, nullif(btrim(coalesce(m->>'reason','')),''), v_status::public.request_status,
      coalesce((m->>'next_day')::boolean,false),
      coalesce((g->>'created_at')::timestamptz, now()),
      coalesce(g->'timeline', '[]'::jsonb),          -- เก็บ Timeline เดิมไว้ทั้งก้อน
      g->>'legacy_request_no', 'localStorage:njhr_db_v3', g)
    returning ot_requests.id into v_id;

    insert into public.njhr_ot_jobs (
      ot_id, job_no, job_code, detail, job_type, job_date, start_time, end_time,
      spans_next_day, ot_hours, dept_snap, position_snap, created_by, updated_by)
    select v_id, (j->>'no')::int, j->>'job_code', j->>'detail', j->>'job_type',
           (m->>'date')::date, (m->>'start')::time, (m->>'end')::time,
           coalesce((m->>'next_day')::boolean,false), (j->>'hours')::numeric,
           g->>'dept_snapshot', g->>'position_snapshot', c.username, c.username
      from jsonb_array_elements(coalesce(g->'jobs', m->'jobs')) j;

    perform public.njhr_audit_write(p_token, 'OT_MIGRATE_LEGACY', 'ot', 'ot_requests',
      v_id::text,
      'นำเข้า OT เดิม ' || coalesce(g->>'legacy_request_no','(ไม่มีเลข)') ||
      ' · ' || (m->>'date') || ' · ' || v_hours || ' ชม.', null, null, null);

    row_no := i; action := 'INSERT'; ot_id := v_id;
    legacy_no := g->>'legacy_request_no';
    message := 'นำเข้าแล้ว';
    return next;
  end loop;
end $$;

revoke all on function public.njhr_ot_migrate_legacy(text, jsonb, boolean) from public;
grant execute on function public.njhr_ot_migrate_legacy(text, jsonb, boolean)
  to authenticated, service_role;

comment on function public.njhr_ot_migrate_legacy(text, jsonb, boolean) is
  'PROPOSED — นำเข้า OT เดิมจาก localStorage พร้อมรักษา legacy_request_no · timeline · '
  'approver · approved_at · created_at (njhr_ot_migrate ตัวเดิมไม่ถูกแตะ)';


-- ─── 3) ยังต้องทำต่อก่อน Import จริง ─────────────────────────
--  ก. Attachment Mapping
--     ไฟล์ใน bucket ot-attachments ถูกอัปโหลดด้วย path ที่ผูกกับ OT id เดิม (ฝั่ง client)
--     ต้องสร้างตาราง Mapping path เดิม → ot_id ใหม่ แล้วจึง insert njhr_ot_attachments
--     ไฟล์ที่จับคู่ไม่ได้ = UNRESOLVED LEGACY OT ATTACHMENT — เก็บไว้ ห้ามลบ ห้ามย้าย
--
--  ข. ตรวจ Enum request_status ว่ารองรับสถานะเดิมทุกค่าที่พบในไฟล์ Export จริง
--
--  ค. รัน p_dry_run = true ก่อนเสมอ แล้วเทียบจำนวนแถวกับไฟล์ Export ให้ตรงทุกรายการ
