-- ============================================================
-- NJ HR V2 — S1_report_menu.sql
-- เมนู "REPORT ลางาน" และ "REPORT OT" (หน้าคอมพิวเตอร์)
--
-- สร้าง RPC ใหม่ 2 ตัว แบบอ่านอย่างเดียว (STABLE) เท่านั้น
--   public.njhr_rpt_leave_list  — คำขอลาทุกสถานะ 1 คำขอ = 1 แถว
--   public.njhr_rpt_ot_list     — คำขอ OT ทุกสถานะ 1 คำขอ = 1 แถว
--
-- ⚠ ไฟล์นี้ "เพิ่มอย่างเดียว" — ไม่มี DROP · ไม่มี ALTER · ไม่มี UPDATE/INSERT/DELETE
--   ไม่แตะฟังก์ชันเดิมแม้แต่ตัวเดียว จึงไม่กระทบ
--     njhr_leave_list · njhr_leave_queue · njhr_leave_detail · njhr_leave_report
--     njhr_ot_list · njhr_ot_get · njhr_report_all_ot · njhr_att_report
--   และไม่กระทบ Workflow การยื่น/อนุมัติ/ยกเลิก ของลางานและ OT
--
-- สิทธิ์: SUPER_ADMIN และ ADMIN เท่านั้น (ตรวจผ่าน njhr_ctx เดิม)
--   Role อื่นเรียกแล้วถูกปฏิเสธด้วย errcode 42501
--
-- รันซ้ำได้ (create or replace) · ไม่ต้องรันไฟล์อื่นก่อน
--   ถ้ายังไม่ได้รัน R1 (leave_requests.request_no) จะหยุดที่ PREFLIGHT
-- ============================================================

-- ─── 0) PREFLIGHT ────────────────────────────────────────────
do $$
begin
  if not exists (select 1 from information_schema.columns
                  where table_schema='public' and table_name='leave_requests' and column_name='request_no') then
    raise exception 'PREFLIGHT: ไม่พบ leave_requests.request_no — ต้องรัน R1_request_no.sql ก่อน';
  end if;
  if not exists (select 1 from information_schema.columns
                  where table_schema='public' and table_name='ot_requests' and column_name='request_no') then
    raise exception 'PREFLIGHT: ไม่พบ ot_requests.request_no — ต้องรัน R1_request_no.sql ก่อน';
  end if;
  if to_regclass('public.njhr_ot_is_holiday') is null
     and not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                      where n.nspname='public' and p.proname='njhr_ot_is_holiday') then
    raise exception 'PREFLIGHT: ไม่พบ njhr_ot_is_holiday() — ต้องรัน 65_ot.sql ก่อน';
  end if;
  raise notice 'PREFLIGHT ผ่าน';
end $$;


begin;

-- ─── 1) ตัวตรวจสิทธิ์ของเมนูรายงานชุดนี้ ─────────────────────
-- ใช้ njhr_ctx เดิมเป็นแหล่งความจริงของ session · ไม่สร้าง session/token ใหม่
create or replace function public.njhr_rptmenu_guard(p_token text)
returns table (app_user_id uuid, username text, role text, employee_id uuid, emp_name text)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare c record;
begin
  select * into c from public.njhr_ctx(p_token);
  if c.role not in ('SUPER_ADMIN','ADMIN') then
    raise exception 'คุณไม่มีสิทธิ์ดูรายงานนี้' using errcode='42501';
  end if;
  return query select c.app_user_id, c.username, c.role, c.employee_id, c.emp_name;
end $$;


-- ─── 2) REPORT ลางาน ─────────────────────────────────────────
-- กรองจาก "ช่วงวันที่ลา" แบบคาบเกี่ยว (start_date <= p_to and end_date >= p_from)
-- ตรรกะ mode_txt และ ui_status คัดลอกจาก njhr_leave_report / njhr_leave_list เดิมทุกบรรทัด
-- p_from / p_to / p_dept / p_q เป็น null หรือค่าว่าง = ไม่กรองเงื่อนไขนั้น
create or replace function public.njhr_rpt_leave_list(
  p_token text,
  p_from  date default null,
  p_to    date default null,
  p_dept  text default null,
  p_q     text default null)
returns table (
  req_id uuid, request_no text,
  emp_code text, prefix text, full_name text, nickname text, department text,
  leave_type text, start_date date, end_date date,
  leave_unit text, mode_txt text, start_time time, end_time time,
  total_days numeric, hours numeric,
  status text, ui_status text, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare q text := lower(btrim(coalesce(p_q,'')));
begin
  perform public.njhr_rptmenu_guard(p_token);
  if p_from is not null and p_to is not null and p_from > p_to then
    raise exception 'วันที่เริ่มต้นต้องไม่เกินวันที่สิ้นสุด' using errcode='22023';
  end if;

  return query
  select r.id,
         r.request_no,
         e.emp_code,
         coalesce(e.prefix,''),
         btrim(coalesce(e.first_name,'') || ' ' || coalesce(e.last_name,'')),
         coalesce(e.nickname,''),
         coalesce(e.department_name,''),
         r.leave_type::text,
         r.start_date, r.end_date,
         coalesce(r.leave_unit,'day'),
         case coalesce(r.leave_unit,'day')
           when 'hour' then 'รายชั่วโมง'
           when 'halfday' then case when coalesce(r.approvals->0->'meta'->>'mode','') = 'HALF_PM'
                                    then 'ครึ่งวันบ่าย' else 'ครึ่งวันเช้า' end
           else case when r.end_date > r.start_date then 'หลายวัน' else 'เต็มวัน' end
         end,
         r.start_time, r.end_time,
         coalesce(r.total_days,0), coalesce(r.hours,0),
         r.status::text,
         case when r.status = 'PENDING'
               and (select x->>'action' from jsonb_array_elements(coalesce(r.approvals,'[]'::jsonb)) x
                     order by (x->>'seq')::int desc limit 1) = 'INFO'
              then 'NEED_MORE_INFO' else r.status::text end,
         r.created_at
    from public.leave_requests r
    join public.employees e on e.id = r.employee_id
   where (p_from is null or r.end_date   >= p_from)
     and (p_to   is null or r.start_date <= p_to)
     and (p_dept is null or p_dept = '' or e.department_name = p_dept)
     and (q = '' or lower(coalesce(e.emp_code,'')) like '%'||q||'%'
          or lower(coalesce(e.first_name,'')) like '%'||q||'%'
          or lower(coalesce(e.last_name,'')) like '%'||q||'%'
          or lower(coalesce(e.first_name,'')||' '||coalesce(e.last_name,'')) like '%'||q||'%'
          or lower(coalesce(e.prefix,'')||coalesce(e.first_name,'')||' '||coalesce(e.last_name,'')) like '%'||q||'%'
          or lower(coalesce(e.nickname,'')) like '%'||q||'%')
   order by r.start_date desc, r.created_at desc;
end $$;


-- ─── 3) REPORT OT ────────────────────────────────────────────
-- กรองจาก "วันที่ทำ OT" (ot_date) · 1 คำขอ = 1 แถว (ไม่กระจายตามรายการงาน)
-- ประเภท = OT วันหยุด / OT ปกติ ตัดสินด้วย njhr_ot_is_holiday() เดิม
create or replace function public.njhr_rpt_ot_list(
  p_token text,
  p_from  date default null,
  p_to    date default null,
  p_dept  text default null,
  p_q     text default null)
returns table (
  req_id uuid, request_no text,
  emp_code text, prefix text, full_name text, nickname text, department text,
  ot_date date, start_time time, end_time time, spans_next_day boolean,
  ot_hours numeric, is_holiday boolean,
  status text, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
#variable_conflict use_column
declare q text := lower(btrim(coalesce(p_q,'')));
begin
  perform public.njhr_rptmenu_guard(p_token);
  if p_from is not null and p_to is not null and p_from > p_to then
    raise exception 'วันที่เริ่มต้นต้องไม่เกินวันที่สิ้นสุด' using errcode='22023';
  end if;

  return query
  select o.id,
         o.request_no,
         e.emp_code,
         coalesce(e.prefix,''),
         btrim(coalesce(e.first_name,'') || ' ' || coalesce(e.last_name,'')),
         coalesce(e.nickname,''),
         coalesce(e.department_name,''),
         o.ot_date, o.start_time, o.end_time, coalesce(o.spans_next_day,false),
         coalesce(o.ot_hours,0),
         public.njhr_ot_is_holiday(o.ot_date),
         o.status::text,
         o.created_at
    from public.ot_requests o
    join public.employees e on e.id = o.employee_id
   where (p_from is null or o.ot_date >= p_from)
     and (p_to   is null or o.ot_date <= p_to)
     and (p_dept is null or p_dept = '' or e.department_name = p_dept)
     and (q = '' or lower(coalesce(e.emp_code,'')) like '%'||q||'%'
          or lower(coalesce(e.first_name,'')) like '%'||q||'%'
          or lower(coalesce(e.last_name,'')) like '%'||q||'%'
          or lower(coalesce(e.first_name,'')||' '||coalesce(e.last_name,'')) like '%'||q||'%'
          or lower(coalesce(e.prefix,'')||coalesce(e.first_name,'')||' '||coalesce(e.last_name,'')) like '%'||q||'%'
          or lower(coalesce(e.nickname,'')) like '%'||q||'%')
   order by o.ot_date desc, o.created_at desc;
end $$;


-- ─── 4) สิทธิ์เรียกใช้ (รูปแบบเดียวกับ RPC อื่นในระบบ) ────────
revoke all on function public.njhr_rptmenu_guard(text) from public;
grant execute on function public.njhr_rptmenu_guard(text) to anon, authenticated;

revoke all on function public.njhr_rpt_leave_list(text, date, date, text, text) from public;
grant execute on function public.njhr_rpt_leave_list(text, date, date, text, text) to anon, authenticated;

revoke all on function public.njhr_rpt_ot_list(text, date, date, text, text) from public;
grant execute on function public.njhr_rpt_ot_list(text, date, date, text, text) to anon, authenticated;

comment on function public.njhr_rpt_leave_list(text, date, date, text, text) is
  'REPORT ลางาน — คำขอลาทุกสถานะ 1 คำขอ = 1 แถว พร้อม request_no · อ่านอย่างเดียว · SUPER_ADMIN/ADMIN';
comment on function public.njhr_rpt_ot_list(text, date, date, text, text) is
  'REPORT OT — คำขอ OT ทุกสถานะ 1 คำขอ = 1 แถว พร้อม request_no และ is_holiday · อ่านอย่างเดียว · SUPER_ADMIN/ADMIN';

insert into public.njhr_schema_version(version, note)
values ('v2.9-report-menu',
        'njhr_rpt_leave_list / njhr_rpt_ot_list — เมนู REPORT ลางาน และ REPORT OT (เพิ่มอย่างเดียว)')
on conflict (version) do nothing;

commit;


-- ════════════════════════════════════════════════════════════
-- 5) VERIFICATION — รันหลัง COMMIT เพื่อยืนยันว่าของเดิมไม่ถูกแตะ
-- ════════════════════════════════════════════════════════════
select jsonb_pretty(jsonb_build_object(
  'functions_created',
    (select jsonb_agg(p.proname order by p.proname)
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname = 'public'
        and p.proname in ('njhr_rptmenu_guard','njhr_rpt_leave_list','njhr_rpt_ot_list')),
  'functions_untouched_still_exist',
    (select jsonb_agg(p.proname order by p.proname)
       from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname = 'public'
        and p.proname in ('njhr_leave_list','njhr_leave_queue','njhr_leave_detail','njhr_leave_report',
                          'njhr_leave_submit','njhr_leave_decide','njhr_leave_cancel',
                          'njhr_ot_list','njhr_ot_get','njhr_ot_decide','njhr_report_all_ot')),
  'leave_requests_rows',  (select count(*) from public.leave_requests),
  'ot_requests_rows',     (select count(*) from public.ot_requests),
  'leave_with_request_no',(select count(*) from public.leave_requests where request_no is not null),
  'ot_with_request_no',   (select count(*) from public.ot_requests where request_no is not null)
));
