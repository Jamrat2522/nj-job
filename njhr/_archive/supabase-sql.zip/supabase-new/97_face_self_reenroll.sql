-- ============================================================
-- NJ HR V2 — 97_face_self_reenroll.sql
-- พนักงานลงทะเบียนใบหน้าต้นแบบ "ใหม่" ของตัวเองจากมือถือ
--
-- ⚠⚠ ไฟล์นี้ยังไม่ได้รัน — ส่งมาให้ตรวจก่อนเท่านั้น ⚠⚠
--
-- ทำไมต้องมีไฟล์นี้
--   95_face_self_enroll.sql ปฏิเสธถ้ามีใบหน้าต้นแบบอยู่แล้ว (โดยตั้งใจ — กันคนอื่นมาทับ)
--   จึงใช้ลงทะเบียนใหม่ไม่ได้ ต้องมี RPC แยกที่บังคับยืนยันรหัสผ่านก่อน
--
-- หลักประกันว่า Template เดิมไม่หายถ้าทำไม่สำเร็จ
--   ทั้งฟังก์ชันอยู่ในทรานแซกชันเดียว และเป็น UPDATE ทับแถวเดิม "ครั้งเดียว"
--   ที่บรรทัดท้าย ๆ หลังตรวจครบทุกข้อแล้ว
--   ถ้าล้มที่ขั้นใดก็ตาม (รหัสผ่านผิด · เวกเตอร์ไม่ครบ · มุมไม่ครบ · ยาวไม่เท่ากัน)
--   PostgreSQL จะ rollback ทั้งชุด → แถวเดิมยังอยู่ครบ ไม่มีสถานะครึ่งกลาง
--   ไม่มีการ DELETE หรือ set is_active=false ก่อนหน้าเลย
--
-- ฝั่งเบราว์เซอร์ก็ต้องไม่ยิง RPC นี้จนกว่าจะเก็บครบ 3 มุมและผ่าน Liveness แล้ว
--
-- ไม่แตะ: njhr_face_enroll · njhr_face_self_enroll · njhr_face_verify
--         njhr_att_punch_face · njhr_face_login · Attendance · GPS · Geofence
-- ต้องรัน 92 และ 95 มาก่อน · รันซ้ำได้
-- ============================================================

do $$
begin
  if to_regclass('public.njhr_emp_faces') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_emp_faces — ต้องรัน 92_face_attendance.sql ก่อน';
  end if;
  if to_regprocedure('public.njhr_face_self_enroll(text,jsonb,jsonb,text)') is null then
    raise exception 'PREFLIGHT: ไม่พบ njhr_face_self_enroll — ต้องรัน 95_face_self_enroll.sql ก่อน';
  end if;
  raise notice 'ใบหน้าต้นแบบปัจจุบัน: % คน',
    (select count(*) from public.njhr_emp_faces);
  raise notice 'PREFLIGHT ผ่าน';
end $$;


begin;

create or replace function public.njhr_face_self_reenroll(
  p_token text, p_password text, p_descriptors jsonb,
  p_quality jsonb default '{}'::jsonb, p_snapshot text default null)
returns table (employee_id uuid, sample_count int, enrolled_at timestamptz)
language plpgsql security definer set search_path = public as $function$
#variable_conflict use_column
declare c record; u public.app_users; e record; ok boolean := false;
        v_n int; v_len int; v_need int; v_emp uuid;
begin
  select * into c from public.njhr_face_guard(p_token, false);

  v_emp := c.employee_id;
  if v_emp is null then
    raise exception 'บัญชีนี้ยังไม่ได้ผูกกับพนักงาน' using errcode='22023';
  end if;

  /* ---- ยืนยันรหัสผ่านปัจจุบัน (ตรรกะเดียวกับ njhr_login) ---- */
  select a.* into u from public.app_users a where a.id = c.app_user_id;
  if not found then raise exception 'ไม่พบบัญชีผู้ใช้นี้' using errcode='28000'; end if;
  if u.password_hash is not null and u.password_hash like '$2%' then
    ok := (u.password_hash = crypt(p_password, u.password_hash));
  elsif u.password is not null and u.password <> '' then
    ok := (u.password = p_password);
  end if;
  if not ok then raise exception 'รหัสผ่านไม่ถูกต้อง' using errcode='28P01'; end if;

  select * into e from public.employees where id = v_emp;
  if not found then raise exception 'ไม่พบข้อมูลพนักงานของบัญชีนี้' using errcode='P0002'; end if;
  if e.status::text not in ('ACTIVE','PROBATION') then
    raise exception 'ลงทะเบียนใบหน้าได้เฉพาะพนักงานที่ปฏิบัติงานอยู่' using errcode='22023';
  end if;

  /* ---- ต้องมีของเดิมอยู่ก่อน ถ้ายังไม่มีให้ใช้ njhr_face_self_enroll ---- */
  if not exists (select 1 from public.njhr_emp_faces f where f.employee_id = v_emp) then
    raise exception 'ยังไม่มีใบหน้าต้นแบบ กรุณาใช้การลงทะเบียนครั้งแรก' using errcode='22023';
  end if;

  /* ---- ตรวจคุณภาพเวกเตอร์ให้ครบก่อน แล้วค่อยแตะข้อมูลเดิม ---- */
  if p_descriptors is null or jsonb_typeof(p_descriptors) <> 'array' then
    raise exception 'ข้อมูลใบหน้าไม่ถูกต้อง' using errcode='22023';
  end if;
  v_n := jsonb_array_length(p_descriptors);
  v_need := coalesce((select (s.value)::text::int from public.system_settings s
                       where s.key = 'face_enroll_samples'), 3);
  if v_n < v_need then
    raise exception 'ต้องเก็บใบหน้าอย่างน้อย % มุม (ได้ % มุม)', v_need, v_n using errcode='22023';
  end if;
  select jsonb_array_length(p_descriptors->0) into v_len;
  if coalesce(v_len,0) < 64 then
    raise exception 'เวกเตอร์ใบหน้าสั้นผิดปกติ (% ค่า)', coalesce(v_len,0) using errcode='22023';
  end if;
  if exists (select 1 from jsonb_array_elements(p_descriptors) d
              where jsonb_array_length(d) <> v_len) then
    raise exception 'เวกเตอร์ใบหน้าแต่ละมุมมีความยาวไม่เท่ากัน' using errcode='22023';
  end if;

  /* ---- ⚠ จุดเดียวที่แตะข้อมูลเดิม — หลังตรวจผ่านครบทุกข้อแล้วเท่านั้น ----
     ไม่ลบ · ไม่ปิด is_active ก่อน · เขียนทับครั้งเดียวในทรานแซกชันเดียวกัน
     enroll_snapshot เดิมคงไว้ถ้ารอบนี้ไม่ได้ส่งรูปมา */
  update public.njhr_emp_faces f
     set descriptors     = p_descriptors,
         descriptor_len  = v_len,
         sample_count    = v_n,
         quality         = coalesce(p_quality,'{}'::jsonb),
         enroll_snapshot = coalesce(nullif(btrim(coalesce(p_snapshot,'')),''), f.enroll_snapshot),
         is_active       = true,
         enrolled_at     = now(),
         enrolled_by     = c.username,
         updated_at      = now(),
         updated_by      = c.username
   where f.employee_id = v_emp;

  begin
    insert into public.njhr_emp_face_events(employee_id, action, detail, actor)
    values (v_emp, 'RE_ENROLL',
            coalesce(e.emp_code,'-') || ' · ' || v_n || ' มุม · พนักงานทำเองจากมือถือ',
            c.username);
  exception when undefined_table then null;
  end;

  begin
    perform public.njhr_audit_write(p_token, 'FACE_SELF_RE_ENROLL', 'attendance',
      'njhr_emp_faces', v_emp::text,
      'พนักงานลงทะเบียนใบหน้าต้นแบบใหม่ด้วยตนเอง · ' || v_n::text || ' มุม · ' ||
      coalesce(e.emp_code,'-'), null, null, null);
  exception when undefined_function then null;
  end;

  return query
    select f.employee_id, f.sample_count, f.enrolled_at
      from public.njhr_emp_faces f where f.employee_id = v_emp;
end $function$;

revoke all on function public.njhr_face_self_reenroll(text, text, jsonb, jsonb, text) from public;
grant execute on function public.njhr_face_self_reenroll(text, text, jsonb, jsonb, text)
  to anon, authenticated;

insert into public.njhr_schema_version(version, note)
values ('v14.4-face-self-reenroll',
        'พนักงานลงทะเบียนใบหน้าต้นแบบใหม่ด้วยตนเอง (ยืนยันรหัสผ่าน · แทนที่แบบ atomic)')
on conflict (version) do nothing;

commit;


-- ════════════════════════════════════════════════════════════
-- VERIFICATION
-- ════════════════════════════════════════════════════════════
select jsonb_pretty(jsonb_build_object(
  'self_reenroll มีจริง',
    (to_regprocedure('public.njhr_face_self_reenroll(text,text,jsonb,jsonb,text)') is not null),
  'บังคับยืนยันรหัสผ่าน',
    (select pg_get_functiondef(p.oid) like '%crypt(p_password%'
       from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname='njhr_face_self_reenroll' limit 1),
  'ไม่มี delete/ปิด is_active ก่อนเขียนใหม่',
    (select pg_get_functiondef(p.oid) not like '%delete from public.njhr_emp_faces%'
       from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname='njhr_face_self_reenroll' limit 1),
  'ไม่มีพารามิเตอร์ p_employee',
    (select pg_get_function_arguments(p.oid) not like '%p_employee%'
       from pg_proc p join pg_namespace n on n.oid=p.pronamespace
      where n.nspname='public' and p.proname='njhr_face_self_reenroll' limit 1),
  'njhr_face_self_enroll เดิมไม่ถูกแตะ',
    (to_regprocedure('public.njhr_face_self_enroll(text,jsonb,jsonb,text)') is not null),
  'njhr_att_punch_face เดิมไม่ถูกแตะ',
    (to_regprocedure('public.njhr_att_punch_face(text,text,float8[],int,boolean,text,double precision,double precision,double precision,text,jsonb)') is not null)
)) as report;


-- ROLLBACK
-- drop function if exists public.njhr_face_self_reenroll(text,text,jsonb,jsonb,text);
-- delete from public.njhr_schema_version where version = 'v14.4-face-self-reenroll';
