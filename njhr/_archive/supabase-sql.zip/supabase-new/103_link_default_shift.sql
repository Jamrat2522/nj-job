-- ============================================================
-- NJ HR V2 — 103_link_default_shift.sql
-- เชื่อมพนักงานสำเร็จ "ครั้งแรก" → ถ้ายังไม่มีกะเลย → Assign NJLOGISTIC 08:30–17:30
--
-- ขอบเขต (แก้เฉพาะจุดนี้จุดเดียว):
--   · เพิ่มฟังก์ชัน Trigger  public.njhr_shift_default_on_link()
--   · เพิ่ม Trigger          njhr_actreq_default_shift_au  บน njhr_activation_requests
--
-- ไม่แตะ:
--   · njhr_activation_link · njhr_activation_submit · njhr_activation_reject
--   · njhr_user_link · njhr_login · njhr_ctx · njhr_shift_assign · njhr_shift_set_active
--   · njhr_shift_state_at · njhr_shift_my_state · njhr_shift_default_new_employee (ของ 102)
--   · Schema ของทุกตาราง · แถวเดิมใน employee_shifts แม้แถวเดียว · ประวัติกะ · Attendance
--
-- ทำไมใช้ Trigger ไม่แก้ njhr_activation_link:
--   CREATE OR REPLACE ต้องเขียน Body ทั้งก้อนใหม่ ซึ่งเสี่ยงย้อน Logic ที่แก้ไว้แล้ว
--   ในฐานข้อมูลจริงกลับไปเป็นรุ่นในไฟล์เก่า  Trigger จึงปลอดภัยกว่าและทำงานได้
--   ไม่ว่า njhr_activation_link ที่ติดตั้งอยู่จริงจะเป็นรุ่นใด
--
-- จุดที่ยึดเป็น "เชื่อมสำเร็จ":
--   njhr_activation_link เป็นเส้นทางเดียวที่ตั้ง njhr_activation_requests.status = 'LINKED'
--   (njhr_user_link ไม่แตะ status ของคำขอ — ตรวจแล้วจาก Source จริง)
--   และ RPC นั้น raise ทิ้งเมื่อ status <> 'PENDING' อยู่แล้ว จึงเข้า LINKED ได้ครั้งเดียว
--
-- อ้างอิง Schema จริง (ยืนยันจาก K1b/K2 · C1/C2 · 102):
--   employee_shifts(id · employee_id · shift_id NULL ได้ · effective_date date
--                   · status text default 'ACTIVE' · assigned_by · assigned_at · created_at)
--     UNIQUE njhr_empshift_uidx (employee_id, effective_date) WHERE ทั้งคู่ NOT NULL
--   njhr_activation_requests(id · employee_id · emp_code · status · decided_at
--                            · decided_by · linked_user_id · ...)
--   work_shifts(id · shift_name · start_time · end_time · is_active · is_overnight)
--
-- Idempotent: รันไฟล์ซ้ำได้ · Trigger ยิงซ้ำก็ไม่เกิดแถวซ้ำ (กัน 3 ชั้น)
-- ============================================================


-- ─── 0) PREFLIGHT — ไม่ผ่าน = หยุดทั้งไฟล์ ยังไม่แตะอะไรเลย ───
DO $$
DECLARE
  v_count integer;
  v_miss  text;
BEGIN
  IF to_regclass('public.employees')                is NULL
     OR to_regclass('public.work_shifts')           is NULL
     OR to_regclass('public.employee_shifts')       is NULL
     OR to_regclass('public.njhr_activation_requests') is NULL THEN
    RAISE EXCEPTION 'PREFLIGHT: ตารางที่ต้องใช้ไม่ครบ (employees · work_shifts · employee_shifts · njhr_activation_requests)';
  END IF;

  -- คอลัมน์ที่ไฟล์นี้เขียนลง employee_shifts ต้องมีจริงทุกตัว
  SELECT string_agg(c, ', ') INTO v_miss FROM unnest(array[
    'employee_id','shift_id','effective_date','status','assigned_by','assigned_at']) c
   WHERE NOT EXISTS (SELECT 1 FROM information_schema.columns
                      WHERE table_schema='public' AND table_name='employee_shifts'
                        AND column_name = c);
  IF v_miss IS NOT NULL THEN
    RAISE EXCEPTION 'PREFLIGHT: employee_shifts ขาดคอลัมน์ [%]', v_miss;
  END IF;

  -- คอลัมน์ที่ Trigger อ่านจากคำขอ
  SELECT string_agg(c, ', ') INTO v_miss FROM unnest(array['employee_id','status']) c
   WHERE NOT EXISTS (SELECT 1 FROM information_schema.columns
                      WHERE table_schema='public' AND table_name='njhr_activation_requests'
                        AND column_name = c);
  IF v_miss IS NOT NULL THEN
    RAISE EXCEPTION 'PREFLIGHT: njhr_activation_requests ขาดคอลัมน์ [%]', v_miss;
  END IF;

  -- กะเริ่มต้นต้องมีอยู่จริงเพียงรายการเดียวและเปิดใช้งาน (กติกาเดียวกับ 102)
  SELECT count(*)::int INTO v_count
    FROM public.work_shifts w
   WHERE lower(btrim(w.shift_name)) = 'njlogistic'
     AND w.start_time = time '08:30'
     AND w.end_time   = time '17:30'
     AND w.is_active IS TRUE;
  IF v_count <> 1 THEN
    RAISE EXCEPTION 'PREFLIGHT: กะเริ่มต้น NJLOGISTIC 08:30–17:30 ต้องมีเพียง 1 รายการและเปิดใช้งาน (พบ %)', v_count;
  END IF;

  -- บันทึกสภาพ employee_shifts ก่อนติดตั้ง ไว้เทียบท้ายไฟล์ (ต้องไม่ถูกแตะเลย)
  CREATE TEMPORARY TABLE IF NOT EXISTS njhr_103_before(rows_before bigint, hash_before text) ON COMMIT DROP;
  DELETE FROM njhr_103_before;
  INSERT INTO njhr_103_before
  SELECT count(*), md5(coalesce(string_agg(t.line, '|' ORDER BY t.line), ''))
    FROM (SELECT es.id::text || ':' || coalesce(es.employee_id::text,'-') || ':' ||
                 coalesce(es.shift_id::text,'-') || ':' || coalesce(es.effective_date::text,'-') || ':' ||
                 coalesce(es.status,'-') AS line
            FROM public.employee_shifts es) t;

  RAISE NOTICE 'PREFLIGHT ผ่าน';
END
$$;


-- ─── 1) ฟังก์ชัน Trigger ─────────────────────────────────────
--  ลำดับการตัดสินใจ (ออกก่อนเสมอเมื่อไม่เข้าเงื่อนไข — ไม่เขียนอะไรทั้งสิ้น):
--    1. ต้องเป็นการเปลี่ยนสถานะ "เข้าสู่" LINKED เท่านั้น
--    2. ต้องมี employee_id
--    3. พนักงานต้องอยู่ในสถานะปฏิบัติงาน (ACTIVE / PROBATION) — กติกาเดียวกับ 102
--    4. ★ ถ้ามีแถวใน employee_shifts อยู่แล้ว "แม้แถวเดียว" → ออกทันที
--       ครอบคลุมทั้ง ACTIVE · REMOVED · NO_SHIFT · แถวประวัติเก่า
--       จึงไม่มีทางเขียนทับกะเดิม ไม่ลบประวัติ และไม่แตะพนักงานเดิมย้อนหลัง
--    5. หากหากะเริ่มต้นไม่เจอ → ข้ามการ Assign แต่ "ไม่ล้ม" การเชื่อมบัญชี
--       (ปัญหาการตั้งค่ากะ ต้องไม่ทำให้ HR เชื่อมพนักงานไม่ได้)
CREATE OR REPLACE FUNCTION public.njhr_shift_default_on_link()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_shift  uuid;
  v_count  integer;
  v_status text;
  v_date   date := (now() at time zone 'Asia/Bangkok')::date;
BEGIN
  -- 1) เฉพาะการ "เข้าสู่" LINKED ครั้งแรกเท่านั้น
  IF upper(coalesce(NEW.status, '')) <> 'LINKED' THEN
    RETURN NEW;
  END IF;
  IF upper(coalesce(OLD.status, '')) = 'LINKED' THEN
    RETURN NEW;
  END IF;

  -- 2) ต้องรู้ว่าเป็นพนักงานคนไหน
  IF NEW.employee_id IS NULL THEN
    RETURN NEW;
  END IF;

  -- 3) พนักงานต้องมีอยู่จริงและอยู่ในสถานะปฏิบัติงาน
  SELECT upper(coalesce(e.status::text, '')) INTO v_status
    FROM public.employees e
   WHERE e.id = NEW.employee_id;
  IF NOT FOUND THEN
    RETURN NEW;
  END IF;
  IF v_status NOT IN ('ACTIVE', 'PROBATION') THEN
    RETURN NEW;
  END IF;

  -- 4) ★ มีกะ/มีประวัติกะอยู่แล้วแม้แถวเดียว = ไม่แตะเด็ดขาด
  IF EXISTS (SELECT 1 FROM public.employee_shifts es
              WHERE es.employee_id = NEW.employee_id) THEN
    RETURN NEW;
  END IF;

  -- 5) หากะเริ่มต้น — ต้องเปิดใช้งานและมีเพียงรายการเดียว
  SELECT count(*)::int INTO v_count
    FROM public.work_shifts w
   WHERE lower(btrim(w.shift_name)) = 'njlogistic'
     AND w.start_time = time '08:30'
     AND w.end_time   = time '17:30'
     AND w.is_active IS TRUE;

  SELECT w.id INTO v_shift
    FROM public.work_shifts w
   WHERE lower(btrim(w.shift_name)) = 'njlogistic'
     AND w.start_time = time '08:30'
     AND w.end_time   = time '17:30'
     AND w.is_active IS TRUE
   LIMIT 1;

  IF v_count <> 1 OR v_shift IS NULL THEN
    RAISE WARNING 'ข้ามการเข้ากะอัตโนมัติของพนักงาน %: ไม่พบกะเริ่มต้น NJLOGISTIC 08:30-17:30 ที่เปิดใช้งานเพียงรายการเดียว (พบ %)',
      NEW.employee_id, v_count;
    RETURN NEW;
  END IF;

  -- 6) เขียนแถวใหม่ มีผลตั้งแต่วันนี้เป็นต้นไป (ไม่ย้อนหลัง)
  --    ON CONFLICT DO NOTHING = กันซ้ำอีกชั้นจาก njhr_empshift_uidx
  INSERT INTO public.employee_shifts(
    employee_id, shift_id, effective_date, status, assigned_by, assigned_at
  ) VALUES (
    NEW.employee_id, v_shift, v_date, 'ACTIVE', 'AUTO_DEFAULT:LINK', now()
  )
  ON CONFLICT DO NOTHING;

  RETURN NEW;
END
$function$;

REVOKE ALL ON FUNCTION public.njhr_shift_default_on_link() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.njhr_shift_default_on_link() FROM anon, authenticated;

COMMENT ON FUNCTION public.njhr_shift_default_on_link() IS
  'เชื่อมบัญชีสำเร็จครั้งแรก (PENDING→LINKED) และพนักงานยังไม่มีแถวกะเลย → Assign NJLOGISTIC 08:30-17:30 ตั้งแต่วันนี้ · ไม่เขียนทับ ไม่ย้อนหลัง ไม่ลบประวัติ';


-- ─── 2) Trigger ──────────────────────────────────────────────
--  WHEN กรองซ้ำอีกชั้นตั้งแต่ระดับ Trigger เพื่อไม่ให้ฟังก์ชันถูกเรียกโดยไม่จำเป็น
DROP TRIGGER IF EXISTS njhr_actreq_default_shift_au ON public.njhr_activation_requests;
CREATE TRIGGER njhr_actreq_default_shift_au
AFTER UPDATE OF status ON public.njhr_activation_requests
FOR EACH ROW
WHEN (upper(coalesce(NEW.status, '')) = 'LINKED'
      AND upper(coalesce(OLD.status, '')) IS DISTINCT FROM 'LINKED')
EXECUTE FUNCTION public.njhr_shift_default_on_link();


-- ─── 3) ตรวจท้ายไฟล์ — ผิดข้อใดข้อหนึ่ง = ROLLBACK ทั้งไฟล์ ───
DO $$
DECLARE
  n_before bigint; h_before text; n_now bigint; h_now text;
BEGIN
  -- 3.1 ฟังก์ชันและ Trigger ต้องถูกติดตั้งจริง
  IF NOT EXISTS (SELECT 1 FROM pg_proc p JOIN pg_namespace ns ON ns.oid = p.pronamespace
                  WHERE ns.nspname = 'public' AND p.proname = 'njhr_shift_default_on_link') THEN
    RAISE EXCEPTION 'ASSERT: ไม่พบฟังก์ชัน njhr_shift_default_on_link';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid
                  JOIN pg_namespace ns ON ns.oid = c.relnamespace
                  WHERE ns.nspname = 'public' AND c.relname = 'njhr_activation_requests'
                    AND t.tgname = 'njhr_actreq_default_shift_au' AND NOT t.tgisinternal) THEN
    RAISE EXCEPTION 'ASSERT: ไม่พบ Trigger njhr_actreq_default_shift_au';
  END IF;

  -- 3.2 Trigger ของ 102 (พนักงานใหม่) ต้องยังอยู่ครบ ไม่ถูกไฟล์นี้ทำหาย
  IF NOT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid
                  JOIN pg_namespace ns ON ns.oid = c.relnamespace
                  WHERE ns.nspname = 'public' AND c.relname = 'employees'
                    AND t.tgname = 'njhr_employee_default_shift_ai' AND NOT t.tgisinternal) THEN
    RAISE WARNING 'เตือน: ไม่พบ Trigger njhr_employee_default_shift_ai ของ 102 (ตรวจว่ารัน 102 แล้วหรือยัง)';
  END IF;

  -- 3.3 ★ ข้อมูลกะเดิมต้องไม่ถูกแตะแม้แถวเดียวจากการติดตั้งไฟล์นี้
  --     (ตารางชั่วคราวอยู่ครบเมื่อรันทั้งไฟล์เป็น Transaction เดียว เช่นใน Supabase SQL Editor)
  IF to_regclass('pg_temp.njhr_103_before') IS NULL THEN
    RAISE NOTICE 'ข้าม 3.3: ไม่พบภาพก่อนติดตั้ง (ไฟล์ถูกรันแบบทีละคำสั่ง ไม่ใช่ Transaction เดียว)';
    RETURN;
  END IF;
  SELECT rows_before, hash_before INTO n_before, h_before FROM njhr_103_before;
  SELECT count(*), md5(coalesce(string_agg(t.line, '|' ORDER BY t.line), ''))
    INTO n_now, h_now
    FROM (SELECT es.id::text || ':' || coalesce(es.employee_id::text,'-') || ':' ||
                 coalesce(es.shift_id::text,'-') || ':' || coalesce(es.effective_date::text,'-') || ':' ||
                 coalesce(es.status,'-') AS line
            FROM public.employee_shifts es) t;
  IF n_now <> n_before OR h_now IS DISTINCT FROM h_before THEN
    RAISE EXCEPTION 'ASSERT: employee_shifts เปลี่ยนไประหว่างติดตั้ง (ก่อน % แถว / หลัง % แถว) — ยกเลิกทั้งหมด',
      n_before, n_now;
  END IF;

  RAISE NOTICE 'ติดตั้งสำเร็จ · employee_shifts % แถว ไม่ถูกแตะ · เชื่อมพนักงานครั้งแรกจะเข้ากะ NJLOGISTIC 08:30-17:30 อัตโนมัติ', n_now;
END
$$;
