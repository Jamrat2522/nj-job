-- ============================================================
-- NJ HR V2 — N1_calendar_rpc.sql
-- RPC เฉพาะหน้า "ปฏิทินองค์กร" (#/calendar) — njhr_calendar_month
--
-- ต้นเหตุที่แก้:
--   หน้า #/calendar เดิมเรียก 4 RPC พร้อมกันใน Promise.all()
--     njhr_dept_list     → perform njhr_emp_guard(p_token,false)
--                          role ที่ผ่านมีเพียง SUPER_ADMIN/ADMIN/HR/MANAGER/ACCOUNT
--                          njhr_ctx() แปลง role 'USER' เป็น 'EMPLOYEE' ด้วย njhr_norm_role()
--                          → USER ทุกคนโดน 'คุณไม่มีสิทธิ์ดูข้อมูลพนักงาน' (42501)
--     njhr_leave_report  → perform njhr_rpt_guard(p_token)  (USER ไม่ผ่านเช่นกัน)
--     njhr_holiday_list  → njhr_ctx() เท่านั้น (ผ่านได้ทุก Role)
--     njhr_ot_list       → njhr_ot_guard()
--   RPC ตัวใดตัวหนึ่ง error → Promise.all() reject → ทั้งหน้าแสดง "เชื่อมต่อฐานข้อมูลไม่สำเร็จ"
--
-- ไฟล์นี้:
--   · ไม่แก้ RPC เดิมแม้แต่ตัวเดียว (njhr_emp_guard · njhr_rpt_guard · njhr_dept_list
--     njhr_leave_report · njhr_ot_list · njhr_holiday_list คงเดิมทุกบรรทัด)
--   · ไม่เปลี่ยนสิทธิ์ของหน้ารายงาน ทะเบียนพนักงาน หรือ Role ใด ๆ
--   · ไม่สร้าง/แก้ตาราง · ไม่แตะข้อมูล · ไม่แตะ RLS
--   · เพิ่ม RPC ใหม่ 1 ตัวที่หน้าปฏิทินใช้ตัวเดียว ไม่มีหน้าอื่นเรียก
--   · ตรวจ Session เองฝั่งเซิร์ฟเวอร์ + บังคับ app_code='salary'
--     อนุญาตทุกบัญชี HR ที่ล็อกอินถูกต้อง (SUPER_ADMIN / ADMIN / USER)
--   · คืนเฉพาะข้อมูลขั้นต่ำที่ใช้วาดปฏิทิน — ไม่มีเหตุผลลา รายละเอียดงาน OT
--     เอกสารแนบ ชั่วโมง/ยอดเงิน OT เลขบัตรประชาชน เบอร์โทร หรือเงินเดือน
--
-- ตรวจก่อนเขียนไฟล์นี้ (จาก Schema จริงที่ Migration เดิมยืนยันไว้):
--   njhr_sessions   : token · app_user_id · expires_at · revoked      (31_secure_session.sql)
--   app_users       : id · app_code · is_active                        (31_secure_session.sql)
--   departments     : id · code · name                                 (55_departments.sql)
--   employees       : id · first_name · last_name · nickname
--                     department_id · department_name                  (48/55)
--   holidays        : id · name · holiday_date                         (58_holidays.sql)
--   leave_requests  : employee_id · start_date · end_date · status     (41_leave_rpc.sql)
--   ot_requests     : employee_id · ot_date · status                   (65_ot.sql)
--   ชื่อ njhr_calendar_month ยังไม่ถูกใช้ในระบบ (ไม่ชนกับ RPC เดิม)
--
-- ต้องรัน 31 · 41 · 48 · 55 · 58 · 65 มาก่อน · รันซ้ำได้
-- ============================================================


-- ════════════════════════════════════════════════════════════
-- 0) PREFLIGHT — ไม่ผ่านให้หยุด ยังไม่สร้างอะไร
-- ════════════════════════════════════════════════════════════
do $$
declare miss text;
begin
  if to_regclass('public.njhr_sessions')  is null then raise exception 'PREFLIGHT: ไม่พบตาราง njhr_sessions'; end if;
  if to_regclass('public.app_users')      is null then raise exception 'PREFLIGHT: ไม่พบตาราง app_users'; end if;
  if to_regclass('public.departments')    is null then raise exception 'PREFLIGHT: ไม่พบตาราง departments'; end if;
  if to_regclass('public.employees')      is null then raise exception 'PREFLIGHT: ไม่พบตาราง employees'; end if;
  if to_regclass('public.holidays')       is null then raise exception 'PREFLIGHT: ไม่พบตาราง holidays'; end if;
  if to_regclass('public.leave_requests') is null then raise exception 'PREFLIGHT: ไม่พบตาราง leave_requests'; end if;
  if to_regclass('public.ot_requests')    is null then raise exception 'PREFLIGHT: ไม่พบตาราง ot_requests'; end if;

  -- คอลัมน์ทุกตัวที่ RPC นี้อ่าน ต้องมีจริง (ห้ามเดาชื่อคอลัมน์)
  select string_agg(t || '.' || c, ', ') into miss
    from (values
      ('njhr_sessions','token'), ('njhr_sessions','app_user_id'),
      ('njhr_sessions','expires_at'), ('njhr_sessions','revoked'),
      ('app_users','id'), ('app_users','app_code'), ('app_users','is_active'),
      ('departments','id'), ('departments','code'), ('departments','name'),
      ('employees','id'), ('employees','first_name'), ('employees','last_name'),
      ('employees','nickname'), ('employees','department_id'), ('employees','department_name'),
      ('holidays','name'), ('holidays','holiday_date'),
      ('leave_requests','employee_id'), ('leave_requests','start_date'),
      ('leave_requests','end_date'), ('leave_requests','status'),
      ('ot_requests','employee_id'), ('ot_requests','ot_date'), ('ot_requests','status')
    ) v(t, c)
   where not exists (select 1 from information_schema.columns
                      where table_schema = 'public' and table_name = v.t and column_name = v.c);
  if miss is not null then
    raise exception 'PREFLIGHT: ขาดคอลัมน์ [%]', miss;
  end if;

  -- ชื่อ RPC ต้องไม่ชนกับของเดิมที่มี signature ต่างกัน
  if exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
              where n.nspname = 'public' and p.proname = 'njhr_calendar_month'
                and pg_get_function_identity_arguments(p.oid) <> 'text, date, date, uuid') then
    raise exception 'PREFLIGHT: มี njhr_calendar_month signature อื่นอยู่แล้ว — ตรวจก่อนสร้างทับ';
  end if;

  raise notice 'PREFLIGHT ผ่าน';
end $$;


-- ไม่สร้าง Index ใหม่: holidays(holiday_date) มี njhr_holiday_date_idx แล้ว (58_holidays.sql)
-- leave_requests มี njhr_leave_emp_range_idx / ot_requests มี njhr_ot_date_idx อยู่ก่อนแล้ว


-- ════════════════════════════════════════════════════════════
-- 1) njhr_calendar_month — ข้อมูลปฏิทินองค์กรทั้งเดือนในคำขอเดียว
--
--    สิทธิ์: ทุกบัญชี app_code='salary' ที่ Session ยังไม่หมดอายุและยังเปิดใช้งาน
--            (SUPER_ADMIN · ADMIN · USER เห็นชุดข้อมูลเดียวกันทั้งหมด)
--            ไม่เรียก njhr_emp_guard และไม่เรียก njhr_rpt_guard โดยเจตนา
--    การจัดการวันหยุด (เพิ่ม/แก้/ลบ) ยังคุมด้วย njhr_holiday_save / njhr_holiday_delete
--    ซึ่งใช้ njhr_emp_guard(p_token, true) เหมือนเดิมทุกประการ — ไฟล์นี้ไม่แตะ
-- ════════════════════════════════════════════════════════════
create or replace function public.njhr_calendar_month(
  p_token text,
  p_from  date,
  p_to    date,
  p_dept  uuid default null)
returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v_uid uuid; v_dept_name text;
begin
  -- 1.1 ช่วงวันที่
  if p_from is null or p_to is null then
    raise exception 'กรุณาระบุช่วงวันที่ของปฏิทิน' using errcode = '22023';
  end if;
  if p_from > p_to then
    raise exception 'วันที่เริ่มต้นต้องไม่เกินวันที่สิ้นสุด' using errcode = '22023';
  end if;
  if (p_to - p_from) > 61 then     -- 61 วันเต็ม = 62 วันนับรวมหัวท้าย
    raise exception 'ช่วงวันที่ของปฏิทินต้องไม่เกิน 62 วัน' using errcode = '22023';
  end if;

  -- 1.2 Session จริงจากฝั่งเซิร์ฟเวอร์ · จำกัดเฉพาะระบบ HR (app_code='salary')
  --     ไม่เชื่อ role/สิทธิ์ใด ๆ ที่ส่งมาจากเบราว์เซอร์
  select u.id into v_uid
    from public.njhr_sessions s
    join public.app_users u on u.id = s.app_user_id
   where s.token = p_token
     and not s.revoked
     and s.expires_at > now()
     and u.app_code = 'salary'
     and coalesce(u.is_active, true)
   limit 1;
  if v_uid is null then
    raise exception 'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่' using errcode = '28000';
  end if;

  -- 1.3 คีย์กรองแผนกคือ Department UUID เสมอ
  --     ชื่อแผนกใช้เป็นตาข่ายรองเฉพาะพนักงานที่ยังไม่ได้ผูก department_id เท่านั้น
  --     (55_departments.sql ยืนยันว่ายังมีพนักงาน ACTIVE ที่ department_id เป็น null ได้)
  if p_dept is not null then
    select d.name into v_dept_name from public.departments d where d.id = p_dept;
  end if;

  return jsonb_build_object(
    'from', p_from,
    'to',   p_to,

    -- แผนกทั้งหมด (เติม Dropdown ตัวกรอง) — id/code/name เท่านั้น
    'departments', coalesce((
      select jsonb_agg(jsonb_build_object(
               'id', d.id, 'code', coalesce(d.code, ''), 'name', d.name)
             order by d.name)
        from public.departments d), '[]'::jsonb),

    -- วันหยุดในช่วง (รวมวันหยุดบริษัทและวันหยุดราชการที่ Apply เข้าตาราง holidays แล้ว)
    'holidays', coalesce((
      select jsonb_agg(jsonb_build_object(
               'holiday_date', h.holiday_date, 'name', h.name)
             order by h.holiday_date)
        from public.holidays h
       where h.holiday_date between p_from and p_to), '[]'::jsonb),

    -- ลาที่อนุมัติแล้ว — ไม่ส่งเหตุผลลา ไฟล์แนบ จำนวนวัน หรือผู้อนุมัติ
    'leaves', coalesce((
      select jsonb_agg(jsonb_build_object(
               'start_date',   r.start_date,
               'end_date',     r.end_date,
               'display_name', coalesce(
                                 nullif(btrim(coalesce(e.nickname, '')), ''),
                                 btrim(coalesce(e.first_name, '') || ' ' || coalesce(e.last_name, ''))),
               'department',   coalesce(e.department_name, ''))
             order by r.start_date, e.id)
        from public.leave_requests r
        join public.employees e on e.id = r.employee_id
       where r.status::text = 'APPROVED'
         and r.start_date <= p_to
         and r.end_date   >= p_from
         and (p_dept is null
              or e.department_id = p_dept
              or (e.department_id is null and v_dept_name is not null
                  and e.department_name = v_dept_name))), '[]'::jsonb),

    -- OT ที่อนุมัติแล้ว — ไม่ส่งรายละเอียดงาน ชั่วโมง ยอดเงิน หรือไฟล์แนบ
    'ot', coalesce((
      select jsonb_agg(jsonb_build_object(
               'ot_date',      o.ot_date,
               'display_name', coalesce(
                                 nullif(btrim(coalesce(e.nickname, '')), ''),
                                 btrim(coalesce(e.first_name, '') || ' ' || coalesce(e.last_name, ''))),
               'department',   coalesce(e.department_name, ''))
             order by o.ot_date, e.id)
        from public.ot_requests o
        join public.employees e on e.id = o.employee_id
       where o.status::text = 'APPROVED'
         and o.ot_date between p_from and p_to
         and (p_dept is null
              or e.department_id = p_dept
              or (e.department_id is null and v_dept_name is not null
                  and e.department_name = v_dept_name))), '[]'::jsonb)
  );
end $$;


-- ─── สิทธิ์เรียกใช้ ───────────────────────────────────────────
revoke all on function public.njhr_calendar_month(text, date, date, uuid) from public;
grant execute on function public.njhr_calendar_month(text, date, date, uuid) to anon, authenticated;

comment on function public.njhr_calendar_month(text, date, date, uuid) is
  'ปฏิทินองค์กร (#/calendar) — แผนก/วันหยุด/ลา APPROVED/OT APPROVED ในคำขอเดียว '
  'ทุกบัญชี app_code=salary ที่ล็อกอินถูกต้องเรียกได้ ไม่ผ่าน njhr_emp_guard / njhr_rpt_guard';


insert into public.njhr_schema_version(version, note)
values ('v2.7-calendar-rpc',
        'njhr_calendar_month — ปฏิทินองค์กรเปิดให้ทุก Role ดูได้ โดยไม่แก้สิทธิ์รายงาน/ทะเบียนพนักงาน')
on conflict (version) do nothing;


-- ════════════════════════════════════════════════════════════
-- 2) VERIFICATION
-- ════════════════════════════════════════════════════════════
select jsonb_pretty(jsonb_build_object(
  'function_created', exists(
     select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname = 'public' and p.proname = 'njhr_calendar_month'),
  'signature', (select pg_get_function_identity_arguments(p.oid)
                  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                 where n.nspname = 'public' and p.proname = 'njhr_calendar_month'),
  'is_security_definer', (select p.prosecdef
                  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                 where n.nspname = 'public' and p.proname = 'njhr_calendar_month'),
  'search_path', (select array_to_string(p.proconfig, ',')
                  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                 where n.nspname = 'public' and p.proname = 'njhr_calendar_month'),
  -- ต้องเป็น false ทั้งคู่: RPC ใหม่ห้ามพึ่ง Guard ที่ USER ไม่ผ่าน
  'uses_emp_guard', (select pg_get_functiondef(p.oid) like '%njhr\_emp\_guard%'
                  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                 where n.nspname = 'public' and p.proname = 'njhr_calendar_month'),
  'uses_rpt_guard', (select pg_get_functiondef(p.oid) like '%njhr\_rpt\_guard%'
                  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                 where n.nspname = 'public' and p.proname = 'njhr_calendar_month'),
  -- RPC เดิมต้องไม่เปลี่ยน: ยังใช้ Guard ตัวเดิมอยู่ครบ
  'dept_list_still_guarded', (select pg_get_functiondef(p.oid) like '%njhr\_emp\_guard%'
                  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                 where n.nspname = 'public' and p.proname = 'njhr_dept_list'),
  'leave_report_still_guarded', (select pg_get_functiondef(p.oid) like '%njhr\_rpt\_guard%'
                  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                 where n.nspname = 'public' and p.proname = 'njhr_leave_report'),
  'emp_guard_unchanged', (select pg_get_functiondef(p.oid) like '%คุณไม่มีสิทธิ์ดูข้อมูลพนักงาน%'
                  from pg_proc p join pg_namespace n on n.oid = p.pronamespace
                 where n.nspname = 'public' and p.proname = 'njhr_emp_guard'),
  'grants', (select jsonb_agg(distinct grantee::text order by grantee::text)
               from information_schema.routine_privileges
              where specific_schema = 'public' and routine_name::text = 'njhr_calendar_month'),
  'active_sessions_salary', (select count(*) from public.njhr_sessions s
                               join public.app_users u on u.id = s.app_user_id
                              where not s.revoked and s.expires_at > now() and u.app_code = 'salary'),
  'roles_in_hr', (select jsonb_object_agg(r, n) from
                   (select public.njhr_norm_role(u.role::text) r, count(*) n
                      from public.app_users u where u.app_code = 'salary' group by 1) x),
  'employees_without_department_id', (select count(*) from public.employees where department_id is null)
)) as n1_verification;


-- ════════════════════════════════════════════════════════════
-- 3) ROLLBACK
-- ════════════════════════════════════════════════════════════
-- drop function if exists public.njhr_calendar_month(text, date, date, uuid);
-- delete from public.njhr_schema_version where version = 'v2.7-calendar-rpc';
-- (ไม่มี Index/ตาราง/ข้อมูลใดถูกสร้างหรือแก้ไข จึงไม่ต้องคืนค่าอย่างอื่น)
