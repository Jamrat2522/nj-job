-- Production sync: employee attendance evidence list
-- Applied to project sytgqjglcnsabcszbngg on 2026-08-14
create or replace function public.njhr_att_punch_evidence_list(
  p_token text, p_employee uuid, p_from date default null, p_to date default null, p_limit integer default 200
)
returns table(
  id uuid, employee_id uuid, emp_code text, emp_name text, work_date date, action text, punched_at timestamptz,
  geofence_name text, lat double precision, lng double precision, distance_m numeric, accuracy_m numeric,
  verify_method text, face_similarity numeric, liveness_passed boolean, liveness_method text, snapshot_path text,
  device text, browser text, os text
)
language plpgsql stable security definer set search_path=public as $function$
#variable_conflict use_column
declare c record;
begin
  select * into c from public.njhr_ctx(p_token);
  if upper(btrim(coalesce(c.role,''))) <> 'SUPER_ADMIN' then
    raise exception 'คุณไม่มีสิทธิ์ดูหลักฐานการลงเวลาของพนักงาน' using errcode='42501';
  end if;
  if p_employee is null then raise exception 'กรุณาระบุพนักงาน' using errcode='22023'; end if;
  if p_from is not null and p_to is not null and p_from > p_to then raise exception 'ช่วงวันที่ไม่ถูกต้อง' using errcode='22023'; end if;
  if not exists(select 1 from public.employees e where e.id=p_employee) then raise exception 'ไม่พบพนักงานรายนี้' using errcode='P0002'; end if;
  return query
  select l.id,l.employee_id,e.emp_code,coalesce(e.prefix,'')||e.first_name||' '||coalesce(e.last_name,''),
         l.work_date,l.action,l.punched_at,coalesce(l.geofence_name,''),l.lat,l.lng,l.distance_m,l.accuracy_m,
         l.verify_method,l.face_similarity,l.liveness_passed,l.liveness_method,l.snapshot_path,l.device,l.browser,l.os
  from public.njhr_att_punch_log l join public.employees e on e.id=l.employee_id
  where l.employee_id=p_employee and (p_from is null or l.work_date>=p_from) and (p_to is null or l.work_date<=p_to)
  order by l.punched_at desc limit least(greatest(coalesce(p_limit,200),1),1000);
end $function$;
revoke all on function public.njhr_att_punch_evidence_list(text,uuid,date,date,integer) from public;
grant execute on function public.njhr_att_punch_evidence_list(text,uuid,date,date,integer) to anon,authenticated,service_role;
