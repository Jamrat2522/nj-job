  /* ============================================================
     หน้าโปรไฟล์มือถือ — ตามภาพอ้างอิงที่อนุมัติแล้ว
     พื้นกรมท่าเต็มหน้า · การ์ดพนักงานขาว · เมนู 6 รายการ
     ใช้ Route จริงชุดเดียวกับ Drawer เดิม ไม่มี Route ใหม่:
       ข้อมูลส่วนตัว    #/profile?sec=detail (การ์ดข้อมูลติดต่อในหน้าเดียวกัน)
       ปฏิทินองค์กร     #/calendar
       เอกสารของฉัน     #/hr-docs
       สลิปเงินเดือน     #/epayslip
       ประวัติการลงเวลา  #/attendance?sec=history
       ออกจากระบบ      doLogout() ตัวเดิม ผ่าน confirmDialog
     บล็อกนี้เป็น .only-mobile — Desktop ไม่เปลี่ยนแม้แต่บรรทัดเดียว
     ============================================================ */
  var PF_MENU = [
    ['detail',       '\u{1F464}', 'ข้อมูลส่วนตัว',     'm-blue',   ''],
    ['#/calendar',   '\u{1F4C5}', 'ปฏิทินองค์กร',      'm-sky',    ''],
    ['#/hr-docs',    '\u{1F4C1}', 'เอกสารของฉัน',      'm-purple', ''],
    ['#/epayslip',   '\u{1F4B5}', 'สลิปเงินเดือน',      'm-green',  ''],
    ['#/attendance?sec=history', '\u{1F553}', 'ประวัติการลงเวลา', 'm-indigo', ''],
    ['logout',       '\u{1F6AA}', 'ออกจากระบบ',        'm-red',    'pf-m-out']
  ];

  /* ============================================================
     รูปโปรไฟล์บนมือถือ
     ------------------------------------------------------------
     ต่อระบบแฟ้มพนักงานเดิมทั้งหมด ไม่สร้าง Storage ใหม่
       Edge Function njhr-emp-file  action = upload-url / download-url
       RPC njhr_empfile_save        เก็บทะเบียนไฟล์ + ทำ Versioning ให้เอง
       category = PERSONAL · doc_kind = PHOTO
     employee_id มาจาก njhr_me_get เท่านั้น (ผูกกับ Token) ไม่รับจาก URL
     ============================================================ */
  var PF_PHOTO_MAX = 10 * 1024 * 1024;        // ตรงกับ EMPF_MAX และ MAX_SIZE ใน Edge Function
  var PF_PHOTO_MIME = ['image/jpeg', 'image/png', 'image/webp'];

  /* ---------- ข้อผิดพลาดของระบบรูปโปรไฟล์ ----------
     ⚠ ห้ามปล่อยข้อความดิบของเบราว์เซอร์ (เช่น "Load failed" ของ Safari/iPhone,
       "Failed to fetch" ของ Chrome) ออกหน้าจอ เพราะผู้ใช้อ่านไม่รู้เรื่อง
       และไม่บอกว่าพังขั้นไหน
     ทุกข้อผิดพลาดจะถูกติดป้ายขั้นตอน (pfStep) ไว้ก่อน แล้วแปลงเป็นข้อความไทยตอนแสดงผล
     รายละเอียดจริงลง Console เท่านั้น และต้องไม่มี token / signed url / key หลุดออกมา */
  /* ข้อความที่ผู้ใช้เห็น — ต้องเป็นภาษาไทยเสมอ
     ถ้าเป็นข้อความอังกฤษดิบของเบราว์เซอร์ ("Load failed" / "Failed to fetch" / "NetworkError")
     ให้แทนด้วยข้อความที่บอกได้ว่าติดที่การเชื่อมต่อบริการอัปโหลด */
  function pfPhotoUserMsg(ex) {
    var m = (ex && ex.message) || '';
    if (/[\u0E00-\u0E7F]/.test(m)) return m;
    return 'ไม่สามารถเชื่อมต่อบริการอัปโหลดรูปได้ กรุณาลองใหม่อีกครั้ง';
  }

  function pfStepErr(step, msg, cause) {
    var e = new Error(msg);
    e.pfStep = step;
    if (cause) e.pfCause = cause;
    return e;
  }

  /* ล้างค่าที่เป็นความลับออกก่อนเขียน Console — กัน Signed URL / token / key รั่ว */
  function pfSafeDetail(x) {
    var t = (x && (x.message || x.error)) ? String(x.message || x.error) : String(x || '');
    return t.replace(/https?:\/\/[^\s"']+/gi, '[url]')
            .replace(/(token|apikey|key|signature|jwt)=[^&\s"']*/gi, '$1=[hidden]')
            .replace(/eyJ[A-Za-z0-9_.-]{10,}/g, '[token]')
            .slice(0, 300);
  }

  function pfEmpFn(body) {
    if (!sbReady()) {
      return Promise.reject(pfStepErr('CONFIG', 'ยังไม่ได้ตั้งค่าการเชื่อมต่อ Supabase'));
    }
    return fetch(SB.url + '/functions/v1/njhr-emp-file', {
      method: 'POST',
      headers: { 'apikey': SB.key, 'Authorization': 'Bearer ' + SB.key, 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.assign({ token: sbToken() }, body || {}))
    })['catch'](function (ne) {
      /* fetch โยน TypeError เมื่อต่อไม่ติด — รวมกรณีที่ Edge Function ยังไม่ถูก Deploy
         Safari แสดงเป็น "Load failed" · Chrome แสดงเป็น "Failed to fetch"
         [Error Monitoring] รายงานก่อนแปลงเป็น pfStepErr — ไม่เปลี่ยน UX ของหน้า Profile */
      njEdgeNet('njhr-emp-file', (body && body.action) || '', ne);
      throw pfStepErr('EDGE_UNREACHABLE',
        'ไม่สามารถเชื่อมต่อบริการอัปโหลดรูปได้ กรุณาลองใหม่อีกครั้ง', ne);
    }).then(function (r) {
      return r.text().then(function (t) {
        var d = {};
        try { d = JSON.parse(t); } catch (e) { d = {}; }
        var act = (body && body.action) || '';
        if (!r.ok) {
          njEdgeFail('njhr-emp-file', act, r.status, d.error);
          throw njEdgeMark(pfStepErr('EDGE_ERROR',
            d.error || 'เข้าถึงไฟล์ไม่สำเร็จ (' + r.status + ')', 'HTTP ' + r.status));
        }
        var miss = njEdgeMissing(act, d) || (t ? '' : 'empty-body');
        if (miss) {
          njEdgeFail('njhr-emp-file', act, r.status, 'invalid response: missing ' + miss.trim());
          throw njEdgeMark(pfStepErr('EDGE_ERROR',
            'เข้าถึงไฟล์ไม่สำเร็จ (' + r.status + ')', 'invalid response'));
        }
        return d;
      });
    });
  }

  function pfPhotoMsg(txt, isErr) {
    var box = document.getElementById('pfm-photo-msg');
    if (!box) return;
    if (!txt) { box.hidden = true; box.textContent = ''; return; }
    box.hidden = false;
    box.className = 'pfm-photo-msg' + (isErr ? ' is-err' : '');
    box.textContent = txt;
  }

  /* หารูปล่าสุดจากแฟ้มพนักงาน
     ⚠ ต้องค้นเสมอ ไม่ดูจาก employees.photo_url เพราะ njhr_empfile_save ไม่ได้เขียนคอลัมน์นั้น */
  function pfFindPhoto(empId) {
    return sbRpc('njhr_empfile_list', { p_token: sbToken(), p_employee: empId })
      .then(function (r) {
        var d = (r && r.data) || {};
        var files = Array.isArray(d.files) ? d.files : [];
        var list = files.filter(function (f) {
          return String(f.category) === 'PERSONAL' && String(f.doc_kind) === 'PHOTO' &&
            !f.deleted_at;
        });
        list.sort(function (a, b) {
          return String(b.updated_at || b.uploaded_at || '')
            .localeCompare(String(a.updated_at || a.uploaded_at || ''));
        });
        return list[0] || null;
      })['catch'](function (er) {
        console.error('[PROFILE] njhr_empfile_list ล้มเหลว:', er);
        return null;                       // หน้าโปรไฟล์ต้องไม่พังเพราะหารูปไม่เจอ
      });
  }

  function pfShowPhoto(url) {
    var box = document.getElementById('pfm-ava');
    if (!box || !url) return;
    var old = box.querySelector('.avatar, .pfm-photo-img');
    var img = document.createElement('img');
    img.className = 'pfm-photo-img';
    img.src = url;
    img.alt = 'รูปโปรไฟล์';
    img.onerror = function () { pfPhotoMsg('เปิดรูปโปรไฟล์ไม่สำเร็จ', true); };
    if (old) box.replaceChild(img, old); else box.insertBefore(img, box.firstChild);
  }

  /* ---------- Preview Local (ยังไม่ได้อัปโหลด) ----------
     ⚠ ต้องแยกให้ชัดจากรูปที่อัปโหลดสำเร็จแล้ว
       Preview ใช้ class เพิ่ม .is-preview + ข้อความกำกับว่ากำลังอัปโหลด
       ถ้าอัปโหลดล้มเหลว ต้องคืนรูปเดิมกลับ ห้ามปล่อยให้ Preview ค้างเหมือนสำเร็จ */
  var pfAvaBak = null;                     // HTML ของรูป/Avatar เดิม ไว้คืนเมื่อล้มเหลว
  var pfPreviewUrl = null;                 // objectURL ที่ต้อง revoke

  function pfShowPreview(file) {
    var box = document.getElementById('pfm-ava');
    if (!box) return;
    var old = box.querySelector('.avatar, .pfm-photo-img');
    pfAvaBak = old ? old.outerHTML : null;
    pfClearPreviewUrl();
    try { pfPreviewUrl = URL.createObjectURL(file); } catch (e) { pfPreviewUrl = null; }
    if (!pfPreviewUrl) return;
    var img = document.createElement('img');
    img.className = 'pfm-photo-img is-preview';
    img.src = pfPreviewUrl;
    img.alt = 'ตัวอย่างรูปที่เลือก (ยังไม่ได้อัปโหลด)';
    if (old) box.replaceChild(img, old); else box.insertBefore(img, box.firstChild);
  }

  function pfClearPreviewUrl() {
    if (!pfPreviewUrl) return;
    try { URL.revokeObjectURL(pfPreviewUrl); } catch (e) {}
    pfPreviewUrl = null;
  }

  /* คืนรูปเดิมกลับเมื่ออัปโหลดล้มเหลว — ไม่ให้ผู้ใช้เข้าใจผิดว่าเปลี่ยนรูปสำเร็จ */
  function pfRestoreAva() {
    var box = document.getElementById('pfm-ava');
    pfClearPreviewUrl();
    if (!box || pfAvaBak == null) { pfAvaBak = null; return; }
    var cur = box.querySelector('.avatar, .pfm-photo-img');
    if (cur) {
      var tmp = document.createElement('div');
      tmp.innerHTML = pfAvaBak;
      if (tmp.firstChild) box.replaceChild(tmp.firstChild, cur);
    }
    pfAvaBak = null;
  }

  var pfPhotoCur = null;                   // ไฟล์ PHOTO ปัจจุบัน ใช้ทำ Versioning ตอนเปลี่ยนรูป
  var pfPhotoBusy = false;

  function pfPhotoLoad(empId) {
    return pfFindPhoto(empId).then(function (f) {
      pfPhotoCur = f;
      if (!f) return null;                 // ไม่มีรูป → ใช้ avatarHTML() เดิมต่อไป
      return pfEmpFn({ action: 'download-url', file_id: f.id })
        .then(function (d) { if (d && d.url) pfShowPhoto(d.url); return d; })
        ['catch'](function (er) {
          console.error('[PROFILE] ขอลิงก์รูปไม่สำเร็จ:', er);
          return null;                     // ล้มเหลว → คงตัวอักษรย่อไว้ ไม่ทำหน้าพัง
        });
    });
  }

  function pfPhotoUpload(file, empId) {
    if (pfPhotoBusy) return;
    if (PF_PHOTO_MIME.indexOf(String(file.type || '').toLowerCase()) < 0) {
      pfPhotoMsg('รับเฉพาะไฟล์รูปภาพ JPG · PNG · WEBP เท่านั้น', true);
      return;
    }
    if (file.size > PF_PHOTO_MAX) {
      pfPhotoMsg('ไฟล์ใหญ่เกิน ' + (PF_PHOTO_MAX / 1048576) + ' MB', true);
      return;
    }

    pfPhotoBusy = true;
    var cam = document.getElementById('pfm-cam');
    if (cam) cam.classList.add('is-busy');
    pfShowPreview(file);                   // Preview หลัง Validate ผ่านแล้วเท่านั้น
    pfPhotoMsg('กำลังอัปโหลดรูป…', false);

    pfEmpFn({
      action: 'upload-url', employee_id: empId,
      category: 'PERSONAL', doc_kind: 'PHOTO',
      file_name: file.name, size: file.size
    }).then(function (d) {
      if (!d.upload_url || !d.path) {
        throw pfStepErr('SIGN_URL', 'ไม่สามารถขอสิทธิ์อัปโหลดรูปได้');
      }
      return fetch(d.upload_url, {
        method: 'PUT',
        headers: { 'Content-Type': file.type || 'application/octet-stream' },
        body: file
      })['catch'](function (ne) {
        /* [Error Monitoring] network/timeout ของ Signed PUT
           ห้าม log: Signed URL · รูป · เนื้อไฟล์ · ชื่อไฟล์ · token
           รายงานก่อนแปลงเป็น pfStepErr เดิม — ข้อความ UX ไม่เปลี่ยน */
        njEdgeNet('njhr-emp-file', 'signed-put', ne);
        throw pfStepErr('PUT_STORAGE', 'อัปโหลดรูปไปยัง Storage ไม่สำเร็จ', ne);
      }).then(function (r) {
        if (!r.ok) return r.text().then(function (t) {
          /* ห้าม log: Signed URL · เนื้อไฟล์ · token · รูปพนักงาน */
          njEdgeFail('njhr-emp-file', 'signed-put', r.status, '');
          throw njEdgeMark(pfStepErr('PUT_STORAGE', 'อัปโหลดรูปไปยัง Storage ไม่สำเร็จ',
            'HTTP ' + r.status + ' ' + String(t).slice(0, 120)));
        });
        return { name: file.name, path: d.path, mime: file.type || '', size: file.size };
      });
    }).then(function (f) {
      /* มีรูปเดิมอยู่แล้ว → ส่ง p_id เดิมเพื่อให้ระบบทำ Versioning
         ไฟล์เก่าจะถูกเก็บใน njhr_emp_file_versions ไม่ถูกลบทิ้ง */
      return sbRpc('njhr_empfile_save', {
        p_token: sbToken(), p_employee: empId,
        p_category: 'PERSONAL', p_doc_kind: 'PHOTO',
        p_file: f, p_id: (pfPhotoCur && pfPhotoCur.id) || null,
        p_document_date: null, p_expiry_date: null, p_note: null
      })['catch'](function (se) {
        /* ไฟล์ขึ้น Storage แล้วแต่ทะเบียนไฟล์ไม่ถูกบันทึก — ต้องบอกให้ตรงความจริง */
        throw pfStepErr('SAVE_RECORD',
          'อัปโหลดไฟล์แล้ว แต่บันทึกข้อมูลรูปโปรไฟล์ไม่สำเร็จ', se);
      });
    }).then(function () {
      return pfPhotoLoad(empId);           // ดึงรูปล่าสุดกลับมาแสดงทันที
    }).then(function () {
      pfAvaBak = null;                     // สำเร็จแล้ว ไม่ต้องคืนรูปเดิม
      pfClearPreviewUrl();                 // รูปจริงจาก Signed URL แทน Preview แล้ว
      pfPhotoMsg('อัปโหลดรูปเรียบร้อย', false);
      toast('เปลี่ยนรูปโปรไฟล์เรียบร้อยแล้ว');
    })['catch'](function (ex) {
      /* Console เห็นขั้นตอนที่พัง + รายละเอียดที่ล้างความลับแล้ว */
      try {
        console.error('[PROFILE] อัปโหลดรูปล้มเหลว · ขั้นตอน=' +
          ((ex && ex.pfStep) || 'UNKNOWN') + ' · ' + pfSafeDetail(ex && ex.pfCause) +
          ' · ' + pfSafeDetail(ex));
      } catch (e2) {}
      pfRestoreAva();                      // ล้มเหลว → คืนรูปเดิม ห้ามค้าง Preview
      pfPhotoMsg(pfPhotoUserMsg(ex), true);
    }).then(function () {
      pfPhotoBusy = false;
      if (cam) cam.classList.remove('is-busy');
      var inp = document.getElementById('pfm-photo');
      if (inp) inp.value = '';             // เลือกไฟล์เดิมซ้ำได้
    });
  }

  function pfPhotoInit(el, mePromise) {
    var cam = el.querySelector('#pfm-cam');
    var inp = el.querySelector('#pfm-photo');
    if (!cam || !inp) return;

    pfPhotoCur = null;
    mePromise.then(function (me) {
      if (!me || !me.id) return;
      pfPhotoLoad(me.id);

      /* อยู่ใน <a> จึงต้องกันไม่ให้ลิงก์ทำงานเมื่อกดปุ่มกล้อง */
      cam.onclick = function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        if (pfPhotoBusy) return;
        inp.click();
      };
      cam.onkeydown = function (ev) {
        if (ev.key !== 'Enter' && ev.key !== ' ') return;
        ev.preventDefault(); ev.stopPropagation();
        inp.click();
      };
      inp.onclick = function (ev) { ev.stopPropagation(); };
      inp.onchange = function () {
        var f = this.files && this.files[0];
        if (f) pfPhotoUpload(f, me.id);
      };
    });
  }

  /* ---------- วันที่แบบ DD/MM/YYYY (ค.ศ.) ----------
     ⚠ ไม่ใช้ empBE() เพราะอันนั้นแปลงเป็น พ.ศ.
       ตรวจรูปแบบเข้มก่อนเสมอ ค่าที่ไม่ใช่วันที่จริงคืน '-' ห้ามให้เกิด Invalid Date */
  function pfDMY(v) {
    var s = String(v == null ? '' : v).slice(0, 10);
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
    if (!m) return '-';
    var y = Number(m[1]), mo = Number(m[2]), d = Number(m[3]);
    if (!isFinite(y) || !isFinite(mo) || !isFinite(d)) return '-';
    if (mo < 1 || mo > 12 || d < 1 || d > 31) return '-';
    return m[3] + '/' + m[2] + '/' + m[1];
  }

  /* ---------- การ์ดข้อมูลส่วนตัวของมือถือ ----------
     ⚠ แยกจาก .pf-legacy ของ Desktop โดยสิ้นเชิง — Desktop จึงไม่เปลี่ยนแม้แต่พิกเซลเดียว
     ทุกช่องเป็นอ่านอย่างเดียว เพราะ njhr_me_save รับแก้เฉพาะ
       nickname · birth_date · national_id · phone · email · address · emergency_phone
     รหัสพนักงาน / แผนก / ตำแหน่ง / วันที่เริ่มงาน มาจาก Employee Master แก้ที่นี่ไม่ได้ */
  var PF_INFO_ROWS = [
    ['name', 'ชื่อ-นามสกุล'], ['code', 'รหัสพนักงาน'], ['dept', 'แผนก'],
    ['pos', 'ตำแหน่ง'], ['start', 'วันที่เริ่มงาน'], ['email', 'อีเมล'], ['phone', 'โทรศัพท์']
  ];

  function pfInfoHtml() {
    return '<section class="pfm-info" id="pfm-info" ' +
      'aria-labelledby="pfm-info-h">' +
      '<div class="pfm-info-h" id="pfm-info-h">' + icon('user', 'ic-sm') +
      '<b>ข้อมูลส่วนตัว</b>' +
      '<button type="button" class="pfm-info-x" id="pfm-info-close" ' +
      'aria-label="ปิดข้อมูลส่วนตัว">' + icon('x') + '</button></div>' +
      PF_INFO_ROWS.map(function (r) {
        return '<div class="pfm-info-r"><span>' + esc(r[1]) + '</span>' +
          '<b id="pfi-' + r[0] + '">—</b></div>';
      }).join('') +
      '<p class="pfm-info-note">ข้อมูลจากทะเบียนพนักงาน · แก้ไขได้ที่ฝ่ายบุคคล</p></section>';
  }

  /* เติมค่าจริงจาก njhr_me_get — ไม่มี RPC ใหม่ ไม่มีการเดาชื่อฟิลด์ */
  function pfFillInfo(me) {
    if (!me) return;
    var v = {
      name: me.full_name || '', code: me.emp_code || '',
      dept: me.department_name || '', pos: me.position_name || '',
      start: pfDMY(me.start_date), email: me.email || '', phone: me.phone || ''
    };
    PF_INFO_ROWS.forEach(function (r) {
      var el = document.getElementById('pfi-' + r[0]);
      if (!el) return;
      var t = String(v[r[0]] == null ? '' : v[r[0]]).trim();
      el.textContent = t === '' ? '-' : t;
    });
    /* หัวการ์ดพนักงานใน Detail ใช้ผลจาก njhr_me_get ชุดเดียวกันเป็นแหล่งจริง */
    var hn = document.getElementById('pfm-emp-name');
    var hc = document.getElementById('pfm-emp-code');
    var hd = document.getElementById('pfm-emp-dept');
    if (hn) hn.textContent = String(v.name || '').trim() || '-';
    if (hc) hc.textContent = String(v.code || '').trim() || '-';
    if (hd) hd.textContent = String(v.dept || '').trim() || '-';
  }

  /* เปิด/ปิด "ข้อมูลส่วนตัว" บนมือถือ
     ⚠ ยังใช้ .pf-show-mobile ตัวเดิมกับ .pf-legacy ไม่แตะกฎ CSS นั้นเลย
       และไม่แตะ .only-desktop เพื่อไม่ให้กระทบหน้าจออื่นทั้งระบบ */
  /* Render เนื้อหา "ข้อมูลส่วนตัว" ครั้งเดียวต่อการเปิดหน้า
     ⚠ กันสร้างซ้ำและกันผูก Event ซ้ำด้วย data-ready
     ตัว init ทั้งสาม (รูป · ข้อมูล · Face Login) จึงถูกเรียกครั้งเดียวเท่านั้น */
  var pfDetailUser = null, pfDetailEmp = null, pfDetailMe = null;

  function pfRenderDetail(el) {
    var box = el.querySelector('#pfm-detail');
    if (!box || box.getAttribute('data-ready') === '1') return false;
    box.innerHTML = pfDetailHtml(pfDetailUser, pfDetailEmp);
    box.setAttribute('data-ready', '1');

    var back = box.querySelector('#pfm-detail-back');
    if (back) back.onclick = function (ev) {
      ev.preventDefault(); pfToggleDetail(el, false);
    };
    var infoX = box.querySelector('#pfm-info-close');
    if (infoX) infoX.onclick = function (ev) {
      ev.preventDefault(); ev.stopPropagation(); pfToggleDetail(el, false);
    };

    /* ใช้ผลลัพธ์ njhr_me_get ก้อนเดิมของหน้า ไม่ยิง RPC ใหม่ */
    if (pfDetailMe) {
      pfDetailMe.then(function (me) { pfFillInfo(me); });
      pfPhotoInit(box, pfDetailMe);
    }
    pfSecInit(box);
    return true;
  }

  function pfToggleDetail(el, force) {
    var det = el.querySelector('#pfm-detail');
    var box = el.querySelector('.pf-legacy');
    var open = (force === undefined) ? (det ? det.hidden : true) : !!force;
    if (open) pfRenderDetail(el);
    if (det) det.hidden = !open;
    if (box) box.classList.toggle('pf-show-mobile', open);
    if (open) {
      var t = det || box;
      if (t && t.scrollIntoView) t.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  /* ---------- ความปลอดภัยและการเข้าสู่ระบบ (มือถือเท่านั้น) ----------
     ⚠ ใช้ Face Template ชุดเดียวกับการลงเวลา (njhr_emp_faces) ไม่สร้างฐานใบหน้าชุดที่สอง
       ถ้าลงทะเบียนใบหน้าไว้แล้วจากการลงเวลา → เปิด Face Login ได้เลย ไม่ต้องถ่าย 3 มุมซ้ำ
       ถ้ายังไม่มี → ถ่าย 3 มุมก่อน แล้วจึงเปิด
     ⚠ ทุกการกระทำต้องยืนยันรหัสผ่านปัจจุบัน (ตรวจฝั่งฐานข้อมูลใน njhr_face_login_set) */
  function pfSecHtml() {
    return '<section class="pfm-info pfm-sec" id="pfm-sec">' +
      '<div class="pfm-info-h">' + icon('shield', 'ic-sm') +
      '<b>ความปลอดภัยและการเข้าสู่ระบบ</b></div>' +
      '<div class="pfm-sec-row">' +
      '<div class="pfm-sec-t"><b>สแกนใบหน้าเข้าสู่ระบบ</b>' +
      '<small id="pfsec-st">กำลังตรวจสอบ…</small></div></div>' +
      '<div class="pfm-sec-act" id="pfsec-act"></div>' +
      '<div class="pfm-sec-msg" id="pfsec-msg" hidden></div></section>';
  }

  function pfSecMsg(t, err) {
    var b = document.getElementById('pfsec-msg');
    if (!b) return;
    b.textContent = t || '';
    b.hidden = !t;
    b.className = 'pfm-sec-msg' + (err ? ' is-err' : '');
  }

  /* ถามรหัสผ่านปัจจุบัน — ฝั่งหน้าจอเป็นเพียงตัวรับค่า ฐานข้อมูลเป็นด่านจริง */
  function pfSecAskPw(title, okLabel) {
    return new Promise(function (resolve) {
      openModal(title,
        '<label class="field"><span>รหัสผ่านปัจจุบัน</span>' +
        '<input type="password" id="pfsec-pw" autocomplete="current-password"></label>' +
        '<div class="form-error" id="pfsec-pwerr" role="alert"></div>',
        '<button class="btn btn-ghost" id="pfsec-no">ยกเลิก</button>' +
        '<button class="btn btn-primary" id="pfsec-yes">' + esc(okLabel) + '</button>');
      document.getElementById('pfsec-no').onclick = function () { closeModal(); resolve(null); };
      document.getElementById('pfsec-yes').onclick = function () {
        var v = String((document.getElementById('pfsec-pw') || {}).value || '');
        if (!v) { document.getElementById('pfsec-pwerr').textContent = 'กรุณากรอกรหัสผ่าน'; return; }
        closeModal(); resolve(v);
      };
      var i = document.getElementById('pfsec-pw');
      if (i) i.focus();
    });
  }

  function pfSecSet(pw, enable) {
    return sbRpc('njhr_face_login_set',
      { p_token: sbToken(), p_password: pw, p_enable: enable });
  }

  function pfSecInit(el) {
    var box = el.querySelector('#pfm-sec');
    if (!box) return;

    function paint(s) {
      var st = document.getElementById('pfsec-st');
      var act = document.getElementById('pfsec-act');
      if (!st || !act) return;
      var on = !!(s && s.face_login_enabled);
      var enrolled = !!(s && s.enrolled);
      st.textContent = on ? 'เปิดใช้งาน' : (enrolled ? 'ปิดใช้งาน' : 'ยังไม่ได้ตั้งค่า');
      st.className = on ? 'is-on' : '';
      /* ปุ่ม "ลงทะเบียนใบหน้าใหม่" แสดงเมื่อมีใบหน้าต้นแบบอยู่แล้วเท่านั้น */
      act.innerHTML =
        (on ? '' : '<button type="button" class="btn btn-dark btn-block" id="pfsec-on">' +
                   icon('camera') + ' ตั้งค่าสแกนใบหน้าเข้าสู่ระบบ</button>') +
        (enrolled ? '<button type="button" class="btn btn-ghost btn-block" id="pfsec-re">' +
                    'ลงทะเบียนใบหน้าใหม่</button>' : '') +
        (on ? '<button type="button" class="btn btn-ghost btn-block" id="pfsec-off">' +
              'ปิดการเข้าสู่ระบบด้วยใบหน้า</button>' : '');
      bind(enrolled);
    }

    function load() {
      var st = document.getElementById('pfsec-st');
      var act = document.getElementById('pfsec-act');
      if (st) { st.textContent = 'กำลังตรวจสอบสถานะ…'; st.className = ''; }
      if (act) act.innerHTML = '';
      pfSecMsg('');
      sbRpc('njhr_face_login_status', { p_token: sbToken() })
        .then(paint)
        ['catch'](function (e) {
          /* ⚠ Error ดิบจากฐานข้อมูล/PostgREST ห้ามโชว์ให้พนักงาน
             แต่ Console ต้องเห็นข้อความจริงเสมอเพื่อให้ตรวจปัญหาได้ */
          try { console.error('[PROFILE] njhr_face_login_status ล้มเหลว:', e); } catch (e2) {}
          var st2 = document.getElementById('pfsec-st');
          var act2 = document.getElementById('pfsec-act');
          if (st2) st2.textContent = 'ไม่สามารถตรวจสอบสถานะได้';
          /* ต้องมีทางออกให้ผู้ใช้เสมอ — ห้ามค้างจนกดอะไรไม่ได้ */
          if (act2) {
            act2.innerHTML = '<button type="button" class="btn btn-ghost btn-block" ' +
              'id="pfsec-retry">ลองใหม่</button>';
            var rb = document.getElementById('pfsec-retry');
            if (rb) rb.onclick = function () { load(); };   // ยิง Request ใหม่จริง
          }
          pfSecMsg('ไม่สามารถตรวจสอบสถานะการสแกนใบหน้าได้ กรุณาลองใหม่', true);
        });
    }

    function bind(enrolled) {
      var on = document.getElementById('pfsec-on');
      var off = document.getElementById('pfsec-off');
      if (on) on.onclick = function () {
        pfSecMsg('');
        pfSecAskPw('ตั้งค่าสแกนใบหน้าเข้าสู่ระบบ', 'ยืนยัน').then(function (pw) {
          if (!pw) return;
          /* มี Face Template อยู่แล้ว → เปิดได้เลย ไม่ต้องถ่าย 3 มุมซ้ำ */
          if (enrolled) return pfSecSet(pw, true).then(function () {
            pfSecMsg('เปิดใช้งานการเข้าสู่ระบบด้วยใบหน้าสำเร็จ', false);
            load();
          });
          /* ยังไม่มี → ถ่าย 3 มุมก่อน แล้วจึงเปิด */
          return pfSecFaceModule().then(function () {
            window.NJHRFace.enroll(null, function () {
              pfSecSet(pw, true).then(function () {
                pfSecMsg('ตั้งค่าสแกนใบหน้าเข้าสู่ระบบสำเร็จ', false);
                load();
              })['catch'](function (e2) {
                pfSecMsg((e2 && e2.message) || 'เปิดใช้งานไม่สำเร็จ', true);
                load();
              });
            });
          });
        })['catch'](function (e) {
          pfSecMsg((e && e.message) || 'ดำเนินการไม่สำเร็จ', true);
        });
      };
      var re = document.getElementById('pfsec-re');
      if (re) re.onclick = function () {
        pfSecMsg('');
        pfSecAskPw('ลงทะเบียนใบหน้าใหม่', 'ยืนยัน').then(function (pw) {
          if (!pw) return;
          /* ⚠ ส่งรหัสผ่านเข้า enroll เพื่อให้ใช้ njhr_face_self_reenroll
             ใบหน้าต้นแบบเดิมจะถูกแทนที่ก็ต่อเมื่อ RPC สำเร็จเท่านั้น
             ถ้ากล้องปิด / Liveness ไม่ผ่าน / มุมไม่ครบ / RPC ล้ม → ของเดิมยังใช้ได้ */
          return pfSecFaceModule().then(function () {
            window.NJHRFace.enroll(null, function () {
              pfSecMsg('ลงทะเบียนใบหน้าใหม่สำเร็จ', false);
              load();
            }, { password: pw });
          });
        })['catch'](function (e) {
          pfSecMsg((e && e.message) || 'ดำเนินการไม่สำเร็จ', true);
        });
      };
      if (off) off.onclick = function () {
        pfSecMsg('');
        pfSecAskPw('ปิดการเข้าสู่ระบบด้วยใบหน้า', 'ปิดใช้งาน').then(function (pw) {
          if (!pw) return;
          return pfSecSet(pw, false).then(function () {
            pfSecMsg('ปิดการเข้าสู่ระบบด้วยใบหน้าแล้ว', false);
            load();
          });
        })['catch'](function (e) {
          pfSecMsg((e && e.message) || 'ดำเนินการไม่สำเร็จ', true);
        });
      };
    }

    function pfSecFaceModule() {
      if (window.NJHRFace) return Promise.resolve();
      return loadScriptOnce('face', njAsset('face.js'), 'NJHRFace');
    }

    load();
  }

  /* ---------- เนื้อหาของ "ข้อมูลส่วนตัว" ----------
     ⚠ ไม่ถูก Render พร้อมหน้าโปรไฟล์หลัก — สร้างเมื่อกดเมนูข้อมูลส่วนตัวเท่านั้น
       (pfRenderDetail) จึงไม่ใช่การซ่อนด้วย CSS
     ประกอบด้วย 3 ส่วนตามลำดับ: การ์ดพนักงาน → pfInfoHtml() → pfSecHtml()
     ทุกส่วนใช้ HTML และ id เดิมทั้งหมด ระบบอัปโหลดรูป/Face Login จึงทำงานเหมือนเดิม */
  function pfDetailHtml(u, e) {
    var name = e ? (e.title + e.firstName + ' ' + e.lastName) : u.username;
    return '<div class="pfm-detail-h">' +
      '<button type="button" class="pfm-detail-back" id="pfm-detail-back" ' +
      'aria-label="กลับ">' + icon('chevL') + '</button>' +
      '<b>ข้อมูลส่วนตัว</b></div>' +

      /* ปุ่มกล้องซ้อนบนรูป — เปิด File Picker ของเครื่อง
         ห่อด้วย <span> ไม่ใช่ <button> เพราะอยู่ใน <a> จะซ้อน element กดไม่ได้
         input[type=file] ซ่อนไว้ รับเฉพาะรูปภาพ (ตรวจซ้ำอีกชั้นตอนเลือกไฟล์) */
      '<div class="pfm-emp">' +
      '<span class="pfm-ava" id="pfm-ava">' + avatarHTML(name, 58) +
      '<span class="pfm-cam" id="pfm-cam" role="button" tabindex="0" ' +
      'aria-label="เปลี่ยนรูปโปรไฟล์" title="เปลี่ยนรูปโปรไฟล์">' + icon('camera') + '</span>' +
      '<input type="file" id="pfm-photo" accept="image/jpeg,image/png,image/webp" hidden></span>' +
      '<div class="grow"><b id="pfm-emp-name">' + esc(name) + '</b>' +
      '<small>รหัสพนักงาน: <i id="pfm-emp-code">' + esc((e && e.code) || '—') + '</i></small>' +
      '<small>แผนก: <i id="pfm-emp-dept">—</i></small></div></div>' +
      '<div class="pfm-photo-msg" id="pfm-photo-msg" hidden></div>' +
      pfInfoHtml() +
      pfSecHtml();
  }

  function pfMobileHtml(u, e) {
    return '<div class="only-mobile pfm">' +
      '<div class="pfm-brand"><span class="pfm-logo">NJL</span>' +
      '<div class="grow"><b>NJL HR</b><small>ระบบบริหารทรัพยากรบุคคล</small></div>' +
      '<button type="button" class="pfm-x" id="pfm-close" aria-label="กลับหน้าหลัก">' +
      icon('x') + '</button></div>' +

      /* กล่องว่างของ "ข้อมูลส่วนตัว" — เนื้อหาถูกใส่ตอนกดเมนูเท่านั้น */
      '<section class="pfm-detail" id="pfm-detail" hidden></section>' +

      '<nav class="pfm-menu">' + PF_MENU.map(function (m) {
        return '<button type="button" class="pfm-item ' + m[4] + '" data-pfm="' + esc(m[0]) + '">' +
          '<span class="pfm-ic ' + m[3] + '">' + m[1] + '</span>' +
          '<span class="grow">' + esc(m[2]) + '</span>' +
          '<span class="pfm-go">' + icon('chevR') + '</span></button>';
      }).join('') + '</nav></div>';
  }

  function viewProfile(el) {
    var u = currentUser(), e = currentEmp();
    el.innerHTML = pfMobileHtml(u, e) +
      '<div class="only-desktop pf-legacy">' +
      '<div class="card profile-card">' + avatarHTML(e ? e.firstName : u.username, 72) +
      '<b>' + esc(e ? e.title + e.firstName + ' ' + e.lastName : u.username) + '</b>' +
      '<small>' + (e ? esc(e.code + ' · ' + e.position + ' · ' + dept(e.deptId)) : '') + '</small>' +
      '<span class="chip chip-info">' + ROLE_TH[u.role] + '</span></div>' +
      (e ? '<div class="card"><div class="card-head"><h3>ข้อมูลติดต่อ</h3></div>' +
        '<form id="pf-f">' +
        '<label class="field"><span>โทรศัพท์</span><input name="phone" value="' + esc(e.phone || '') + '"></label>' +
        '<label class="field"><span>อีเมล</span><input type="email" name="email" value="' + esc(e.email || '') + '"></label>' +
        '<button class="btn btn-primary" type="button" id="pf-save">บันทึกข้อมูลติดต่อ</button></form></div>' : '') +
      '<div class="card"><div class="card-head"><h3>บัญชีผู้ใช้</h3></div>' +
      '<div class="detail-grid">' + dRow('ชื่อผู้ใช้', u.username) + dRow('Login ล่าสุด', u.lastLogin || '—') + '</div>' +
      '<button class="btn btn-danger-ghost" id="pf-logout">' + icon('logout') + ' ออกจากระบบ</button></div>' +
      '</div>';

    /* เมนูมือถือ — ทุกปุ่มไปที่ Route จริง ไม่มีปุ่มหลอก */
    var mnav = el.querySelector('.pfm-menu');
    if (mnav) mnav.onclick = function (ev) {
      var b = ev.target.closest ? ev.target.closest('[data-pfm]') : null;
      if (!b) return;
      var to = b.dataset.pfm;
      if (to === 'logout') {
        confirmDialog('ออกจากระบบ', 'ต้องการออกจากระบบใช่หรือไม่', 'ออกจากระบบ',
          function () { doLogout(false); }, true);
        return;
      }
      if (to === 'detail') {
        /* ข้อมูลส่วนตัว = การ์ดข้อมูลมือถือ + การ์ดข้อมูลติดต่อเดิม (ของเดิม ไม่สร้างหน้าใหม่)
           กดซ้ำ = ปิด · ปุ่ม × ในการ์ดก็ปิดได้ */
        pfToggleDetail(el);
        return;
      }
      window.location.hash = to;
    };
    var cx = document.getElementById('pfm-close');
    if (cx) cx.onclick = function () { window.location.hash = '#/dashboard'; };
    /* การ์ดพนักงานและปุ่มปิดย้ายเข้าไปอยู่ใน "ข้อมูลส่วนตัว" แล้ว
       จึงผูก Event ที่ pfRenderDetail ครั้งเดียว ไม่ผูกซ้ำที่นี่ */

    /* ---------- njhr_me_get ครั้งเดียวต่อการเปิดหน้า ----------
       ทั้งฟอร์มข้อมูลติดต่อและรูปโปรไฟล์ใช้ผลลัพธ์ก้อนเดียวกัน
       employee.id ที่ได้มาจาก Token เท่านั้น ไม่รับจาก URL หรือ localStorage */
    var pfMe = null;
    var pfMePromise = (sbReady() && sbToken())
      ? sbRpc('njhr_me_get', { p_token: sbToken() }).then(function (r) {
          var d = (r && r.data) ? r.data : r;
          pfMe = (d && d.employee) || null;
          return pfMe;
        })['catch'](function (er) {
          console.error('[PROFILE] njhr_me_get ล้มเหลว:', er);
          return null;
        })
      : Promise.resolve(null);

    /* ---------- เก็บบริบทไว้ให้ "ข้อมูลส่วนตัว" ใช้ ----------
       ⚠ ไม่เรียก pfPhotoInit / pfSecInit / pfFillInfo ที่นี่แล้ว
         เพราะการ์ดพนักงาน · pfInfoHtml · pfSecHtml ยังไม่ถูก Render จนกว่าจะกดเมนู
         ทั้งสามตัวถูกเรียกครั้งเดียวใน pfRenderDetail (กันซ้ำด้วย data-ready)
       njhr_me_get ยังยิงครั้งเดียวต่อการเปิดหน้าเหมือนเดิม ไม่เพิ่ม RPC */
    pfDetailUser = u; pfDetailEmp = e; pfDetailMe = pfMePromise;

    /* เปิด Detail อัตโนมัติเมื่อมาด้วยลิงก์ #/profile?sec=detail (ของเดิม) */
    if (/[?&]sec=detail/.test(location.hash)) pfToggleDetail(el, true);

    var saveBtn = document.getElementById('pf-save');
    if (saveBtn) {
      /* ---------- ข้อมูลติดต่อ: แหล่งจริงคือ employees ผ่าน njhr_me_get / njhr_me_save ----------
         เดิมแก้ e.phone / e.email ใน db.employees แล้ว saveDB() ลง localStorage
         ซึ่งเครื่องอื่นมองไม่เห็นและไม่เคยถึงฐานข้อมูลเลย

         ⚠ njhr_me_save เขียนทับครบทั้ง 7 คอลัมน์ของ allowlist ทุกครั้ง
            (nickname · birth_date · national_id · phone · email · address · emergency_phone)
            คีย์ที่ไม่ส่งไปจะกลายเป็น null → ต้องโหลดค่าปัจจุบันจาก njhr_me_get มาก่อน
            แล้วส่งกลับครบทั้ง 7 ค่าโดยแทนที่เฉพาะ phone/email ที่หน้านี้แก้ได้
         Audit ถูกเขียนโดย njhr_me_save แล้ว จึงไม่เรียก audit() ซ้ำ
         ช่องกรอกและหน้าตาเดิมทุกบรรทัด ไม่เพิ่ม/ลดช่องใด */
      /* ใช้ผลจาก njhr_me_get ก้อนเดียวกับรูปโปรไฟล์ — ไม่ยิง RPC ซ้ำ */
      pfMePromise.then(function (me) {
        if (!me) return;
        var fm0 = document.getElementById('pf-f');
        if (!fm0) return;
        fm0.elements.phone.value = me.phone || '';
        fm0.elements.email.value = me.email || '';
      });
      saveBtn.onclick = function () {
        var fm = document.getElementById('pf-f'), btn = this;
        if (!sbReady() || !sbToken()) { toast('ยังไม่ได้เชื่อมต่อ Supabase — บันทึกไม่ได้', 'error'); return; }
        if (!pfMe) { toast('กำลังโหลดข้อมูลเดิม กรุณารอสักครู่แล้วกดใหม่', 'info'); return; }
        if (btn.disabled) return;
        var label = btn.innerHTML;
        btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> กำลังบันทึก…';
        sbRpc('njhr_me_save', {
          p_token: sbToken(),
          p_data: {
            nickname: pfMe.nickname || '',
            birth_date: pfMe.birth_date || '',
            national_id: pfMe.national_id || '',
            phone: fm.elements.phone.value.trim(),
            email: fm.elements.email.value.trim(),
            address: pfMe.address || '',
            emergency_phone: pfMe.emergency_phone || ''
          }
        }).then(function (r) {
          var d = (r && r.data) ? r.data : r;
          if (d && d.employee) pfMe = d.employee;
          if (e) { e.phone = fm.elements.phone.value.trim(); e.email = fm.elements.email.value.trim(); }
          toast('บันทึกข้อมูลติดต่อแล้ว');
        }).catch(function (er) {
          console.error('[PROFILE] njhr_me_save ล้มเหลว:', er);
          toast((er && er.message) || 'บันทึกข้อมูลติดต่อไม่สำเร็จ', 'error');
        }).then(function () { btn.disabled = false; btn.innerHTML = label; });
      };
    }
    document.getElementById('pf-logout').onclick = function () {
      confirmDialog('ออกจากระบบ', 'ต้องการออกจากระบบใช่หรือไม่', 'ออกจากระบบ', function () { doLogout(false); }, true);
    };
  }

