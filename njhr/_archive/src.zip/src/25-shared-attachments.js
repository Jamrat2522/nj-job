  /* ================= SHARED: FILE UPLOAD (Supabase Storage) =================
     ย้ายมาจาก 06-auth-supabase.js โดยไม่แก้เนื้อใน
     Bucket · Prefix · Path · Header · Content-Type · Return Object · Error — เหมือนเดิมทุกตัวอักษร
     ใช้ร่วมกันโดย leave-form · ot-form · compatibility ================= */
  /* [Privacy 104] อัปโหลดผ่านประตูตรวจสิทธิ์เท่านั้น — anon INSERT ถูกถอนแล้ว
     ขั้นตอน (แบบแผนเดียวกับรูปโปรไฟล์ njhr-emp-file ที่ใช้จริงอยู่):
       1) Edge Function njhr-req-file action=upload-url + token
          → ตรวจ token ที่ DB · ออก path ผูกกับ employee_id ของเจ้าของ token
       2) PUT ไฟล์ขึ้น Signed Upload URL ที่ได้
     พารามิเตอร์ (bucket, prefix, file, empId) คงรูปเดิม — empId ไม่ใช้ส่งขึ้นแล้ว
     (ฝั่ง DB ใช้ employee_id จาก token แทน จึงปลอมโฟลเดอร์คนอื่นไม่ได้) */
  function sbUploadFile(bucket, prefix, file, empId) {
    if (!sbReady()) return Promise.reject(new Error('ยังไม่ได้ตั้งค่าการเชื่อมต่อ Supabase'));
    var path = '';
    return fetch(SB.url + '/functions/v1/njhr-req-file', {
      method: 'POST',
      headers: { 'apikey': SB.key, 'Authorization': 'Bearer ' + SB.key, 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: sbToken(), action: 'upload-url',
                             kind: prefix, file_name: file.name })
    }).then(function (r) {
      return r.json()['catch'](function () { return {}; }).then(function (d) {
        if (!r.ok || !d.upload_url || !d.path) {
          njEdgeFail('njhr-req-file', 'upload-url', r.status,
                     (d && d.error) || (r.ok ? ('invalid response: missing ' + njEdgeMissing('upload-url', d)) : ''));
          throw njEdgeMark(new Error((d && d.error) || 'ไม่สามารถขอสิทธิ์อัปโหลดไฟล์แนบได้'));
        }
        path = d.path;
        return fetch(d.upload_url, {
          method: 'PUT',
          headers: { 'Content-Type': file.type || 'application/octet-stream' },
          body: file
        });
      });
    }).then(function (r) {
      if (!r.ok) return r.text().then(function (t) {
        /* ห้าม log: Signed URL · เนื้อไฟล์ · token */
        njEdgeFail('njhr-req-file', 'signed-put', r.status, '');
        throw njEdgeMark(new Error('อัปโหลดไฟล์แนบไม่สำเร็จ: ' + t.slice(0, 160)));
      });
      /* [Privacy 104] ห้ามใช้ Public URL — bucket เป็น private แล้ว
         ช่อง url ส่ง "path" แทน (RPC เดิมรับ text ได้ · Trigger njhr_leaveatt_fill_path
         ฝั่ง DB คัดลอกเข้า file_path ให้เอง) การเปิดไฟล์ทุกครั้งไปที่ reqFileSigned() */
      return { name: file.name, size: file.size, type: file.type || '', path: path,
               url: path };
    })['catch'](function (e) {
      throw njEdgeNet('njhr-req-file', 'upload', e);
    });
  }

  /* ---------- เปิด/ดาวน์โหลดไฟล์แนบใบลา + OT ผ่านประตูตรวจสิทธิ์ ----------
     Edge Function njhr-req-file → RPC njhr_reqfile_access ตรวจสิทธิ์ที่ฐานข้อมูล
     (เจ้าของ | HR | SUPER_ADMIN | ADMIN ใน Workflow) แล้วออก Signed URL อายุ 60 วิ
     รับได้ทั้ง f.path ตรง ๆ และ Public URL เก่าที่ค้างใน DB (ถอด path ให้อัตโนมัติ) */
  function reqFilePath(f) {
    if (!f) return '';
    if (f.path) return String(f.path);
    if (f.file_path) return String(f.file_path);
    var u = String(f.url || f.file_url || '');
    var m = u.match(/\/object\/(?:public|sign)\/(?:leave-attachments|ot-attachments)\/(.+?)(?:\?|$)/);
    if (m) { try { return decodeURIComponent(m[1]); } catch (e) { return m[1]; } }
    if (u && !/^https?:|^data:|^blob:/.test(u)) return u;   // path ถูกเก็บไว้ในช่อง url
    return '';
  }
  function reqFileSigned(f, download) {
    var p = reqFilePath(f);
    if (!p) return Promise.resolve('');
    if (!sbReady()) return Promise.reject(new Error('ยังไม่ได้ตั้งค่าการเชื่อมต่อ Supabase'));
    return fetch(SB.url + '/functions/v1/njhr-req-file', {
      method: 'POST',
      headers: { 'apikey': SB.key, 'Authorization': 'Bearer ' + SB.key, 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: sbToken(), action: 'download-url', path: p,
                             download: download ? 1 : 0 })
    }).then(function (r) {
      return r.json()['catch'](function () { return {}; }).then(function (j) {
        if (!r.ok || !j.url) {
          njEdgeFail('njhr-req-file', 'download-url', r.status,
                     (j && j.error) || (r.ok ? 'invalid response: missing url' : ''));
          throw njEdgeMark(new Error((j && j.error) || 'ไม่มีสิทธิ์เปิดไฟล์นี้ หรือไม่พบไฟล์'));
        }
        return j.url;
      });
    })['catch'](function (e) {
      throw njEdgeNet('njhr-req-file', 'download-url', e);
    });
  }
  /* ตัวช่วยกลาง: มี path → ขอ Signed URL ก่อน · ไม่มี (ไฟล์ local ก่อนบันทึก) → ใช้ค่าเดิม */
  function reqFileOpen(f) {
    var p = reqFilePath(f);
    if (!p) { filePreviewOpen((f && (f.url || f.data)) || '', f && f.name); return; }
    reqFileSigned(f, false).then(function (u) { filePreviewOpen(u, f.name); })
      ['catch'](function (er) { toast((er && er.message) || 'เปิดไฟล์ไม่สำเร็จ', 'error'); });
  }
  function reqFileDownload(f) {
    var p = reqFilePath(f);
    if (!p) { fileDownload((f && (f.url || f.data)) || '', f && f.name); return; }
    reqFileSigned(f, true).then(function (u) { fileDownload(u, f.name); })
      ['catch'](function (er) { toast((er && er.message) || 'ดาวน์โหลดไม่สำเร็จ', 'error'); });
  }

  function sbUploadLeaveFile(file, empId) { return sbUploadFile('leave-attachments', 'leave', file, empId); }

  function sbUploadOtFile(file, empId) { return sbUploadFile('ot-attachments', 'ot', file, empId); }
