  /* ================= CENTRAL ERROR MONITORING (รอบ A) =================
     จับข้อผิดพลาดฝั่ง Client แล้วส่งเข้า RPC njhr_error_log_write

     ครอบคลุม: JS Runtime Error · Unhandled Promise · RPC Failure ·
               Edge Function Failure · Service Worker Error ที่สำคัญ

     ห้ามบันทึก: Password · Token · Face image · Descriptor · พิกัด GPS จริง ·
                เอกสารพนักงาน · ข้อมูลส่วนบุคคล  → njRedact() ตัดทิ้งก่อนส่ง
                (ฝั่ง SQL ยังมี njhr_error_redact() ตัดซ้ำอีกชั้น)

     Performance: ไม่แตะ Critical Path เลย
       · ไม่โหลดไลบรารีใด ๆ  · ไม่ทำงานตอน boot
       · ส่งแบบ fire-and-forget ใน requestIdleCallback (fallback setTimeout)
       · จำกัด 20 รายการ/เซสชัน + กันซ้ำด้วยลายเซ็น + เว้นช่วง 3 วินาที
       · ล้มเหลวเงียบเสมอ ห้ามทำให้แอปพัง
     ================================================================= */
  var NJERR = {
    max: 20, sent: 0, seen: {}, last: 0, ready: false,
    KINDS: { JS: 'JS_ERROR', PROMISE: 'UNHANDLED_REJECTION',
             RPC: 'RPC_FAIL', EDGE: 'EDGE_FAIL', SW: 'SW_ERROR' }
  };

  /* ตัดข้อมูลอ่อนไหวออกก่อนส่ง — ลำดับสำคัญ: ตัดของยาวก่อนของสั้น */
  function njRedact(s) {
    if (s == null) return '';
    var t = String(s);
    try {
      t = t.replace(/https?:\/\/[^\s"']*\/storage\/v1\/[^\s"']*/gi, '[signed-url]')  // Signed URL ทั้งเส้น
           .replace(/\[\s*-?\d+\.\d+(\s*,\s*-?\d+\.\d+){2,}\s*\]/g, '[descriptor]') // Face embedding
           .replace(/data:[a-z/+.-]+;base64,[A-Za-z0-9+/=]+/gi, '[image]')   // รูป/Face base64
           .replace(/eyJ[A-Za-z0-9_.-]{10,}/g, '[token]')                     // JWT
           .replace(/(sb_publishable_|sbp_|sk_)[A-Za-z0-9_-]{6,}/g, '[key]')  // API key
           .replace(/(token|apikey|api_key|key|password|passwd|pwd|secret|signature|descriptor|p256dh|auth)\s*[=:"']+\s*[^\s,&"'}]+/gi, '$1=[hidden]')
           /* ---------- พิกัด GPS ต้องไม่หลุดทุกรูปแบบ ----------
              1) "lat": 13.7563 / "latitude": 13.7563   (JSON)
              2) lat=13.7563 / lng=100.5018 / longitude:13.75
              3) คู่พิกัดคั่นด้วยจุลภาค 13.7563,100.5018
              แทนด้วย [geo] · ไม่แตะตัวเลขอื่นในข้อความ */
           .replace(/("?\b(?:lat|lng|lon|latitude|longitude)\b"?)\s*[=:]\s*"?-?\d{1,3}(?:\.\d+)?"?/gi, '$1=[geo]')
           .replace(/-?\d{1,3}\.\d{4,}\s*,\s*-?\d{1,3}\.\d{4,}/g, '[geo]')
           .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, '[email]')
           .replace(/https?:\/\/[^\s"']+/gi, function (u) {                    // ตัด query string ทิ้ง
             return String(u).split('?')[0];
           });
    } catch (e) { return '[redact-failed]'; }
    return t.slice(0, 1000);
  }

  /* route ต้องไม่พก query/param ที่อาจมีรหัสพนักงาน */
  function njErrRoute() {
    try { return String(location.hash || '').split('?')[0].slice(0, 120); } catch (e) { return ''; }
  }

  function njErrDevice() {
    var ua = '';
    try { ua = String(navigator.userAgent || ''); } catch (e) {}
    var mob = /Android|iPhone|iPad|iPod|Mobile/i.test(ua);
    var br = /Edg\//.test(ua) ? 'Edge' : /Chrome\//.test(ua) ? 'Chrome'
           : /Safari\//.test(ua) ? 'Safari' : /Firefox\//.test(ua) ? 'Firefox' : 'Other';
    var os = /Android/i.test(ua) ? 'Android' : /iPhone|iPad|iPod/i.test(ua) ? 'iOS'
           : /Windows/i.test(ua) ? 'Windows' : /Mac OS X/i.test(ua) ? 'macOS'
           : /Linux/i.test(ua) ? 'Linux' : 'Other';
    return { device: mob ? 'Mobile' : 'Desktop', browser: br, os: os };
  }

  /* ส่งเข้า RPC โดยตรงด้วย fetch — ไม่ผ่าน sbCall() เพื่อไม่ให้เกิดลูป
     (sbCall ล้มเหลว → รายงาน error → sbCall อีก → วนไม่จบ) */
  function njErrPost(kind, source, err, extra) {
    try {
      if (!NJERR.ready || NJERR.sent >= NJERR.max) return;
      /* [Quota] ต้องมี session ก่อนจึงคิดโควตา — Error ก่อน Login ส่งไม่ได้อยู่แล้ว
         จึงห้ามให้กิน sent/seen/last ทั้งที่ไม่เคยส่ง Log จริงแม้แต่รายการเดียว
         (Security ฝั่ง Server ไม่เปลี่ยน — njhr_ctx ยังบังคับ session เหมือนเดิม) */
      var tk = '';
      try { tk = sbToken() || ''; } catch (e) { tk = ''; }
      if (!tk) return;

      var now = Date.now();
      if (now - NJERR.last < 3000) return;                 // เว้นช่วงกันยิงถี่
      var msg = njRedact((err && err.message) || err || '');
      var stk = njRedact((err && err.stack) || '');
      /* [กัน recursive] ถ้า error มาจาก RPC ของตัว Monitoring เอง ให้เงียบสนิท
         (njErrPost ใช้ fetch ตรง ไม่ผ่าน sbCall อยู่แล้ว จึงไม่มีลูปตั้งแต่ต้น
          บรรทัดนี้เป็นชั้นกันที่สองเผื่อมีผู้เรียกอื่นในอนาคต) */
      if (String(source || '').indexOf('njhr_error_log') === 0) return;
      var sig = kind + '|' + (source || '') + '|' + msg.slice(0, 120);
      if (NJERR.seen[sig]) return;                          // กันซ้ำ
      NJERR.seen[sig] = 1; NJERR.sent++; NJERR.last = now;

      var d = njErrDevice();
      var body = {
        p_token: tk,
        p_kind: kind, p_source: njRedact(source).slice(0, 200),
        p_message: msg || '(no message)', p_stack: stk,
        p_route: njErrRoute(),
        p_build: (window.NJHR_BUILD_VERSION || ''),
        p_device: d.device, p_browser: d.browser, p_os: d.os
      };
      if (extra) body.p_message = (body.p_message + ' | ' + njRedact(extra)).slice(0, 1000);

      var idle = window.requestIdleCallback || function (fn) { return setTimeout(fn, 0); };
      idle(function () {
        try {
          fetch(SB.url + '/rest/v1/rpc/njhr_error_log_write', {
            method: 'POST', keepalive: true,
            headers: { 'apikey': SB.key, 'Authorization': 'Bearer ' + SB.key,
                       'Content-Type': 'application/json' },
            body: JSON.stringify(body)
          })['catch'](function () {});                      // ล้มเหลวเงียบเสมอ
        } catch (e) {}
      });
    } catch (e) { /* ห้ามทำให้แอปพังเด็ดขาด */ }
  }

  /* API กลางให้ส่วนอื่นเรียก */
  function njErrReport(kind, source, err, extra) { njErrPost(kind, source, err, extra); }

  function njErrInit() {
    if (NJERR.ready) return;
    if (!sbReady || !sbReady()) return;                     // ยังไม่มี config = ยังไม่เริ่ม
    NJERR.ready = true;
    try {
      window.addEventListener('error', function (ev) {
        if (!ev) return;
        var src = ev.filename ? String(ev.filename).split('/').pop() : '';
        njErrPost(NJERR.KINDS.JS, src + (ev.lineno ? (':' + ev.lineno) : ''),
                  ev.error || { message: ev.message });
      });
      window.addEventListener('unhandledrejection', function (ev) {
        var r = ev && ev.reason;
        njErrPost(NJERR.KINDS.PROMISE, '', (r && r.message) ? r : { message: String(r) });
      });
      /* Service Worker Error ที่สำคัญ — SW ส่ง postMessage มาให้หน้าเว็บรายงานแทน
         (ตัว SW เองไม่มี token/Supabase client จึงไม่ยิง RPC เอง) */
      if (navigator.serviceWorker && navigator.serviceWorker.addEventListener) {
        navigator.serviceWorker.addEventListener('message', function (ev) {
          var d = ev && ev.data;
          if (d && d.njhrSwError) {
            njErrPost(NJERR.KINDS.SW, String(d.scope || 'sw'), { message: String(d.message || '') });
          }
        });
      }
    } catch (e) {}
  }

  /* [Error Monitoring] รายงาน Edge Function ล้มเหลว — ไม่เปลี่ยน UI/Toast/ข้อความเดิม
     บันทึกเฉพาะ ชื่อฟังก์ชัน · action · HTTP status · ข้อความที่ผ่าน Redaction
     ห้าม log: Signed URL · Authorization header · token · เนื้อไฟล์ · รูปใบหน้า · พิกัดจริง */
  /* กัน double-report: ติดธงบน Error ที่รายงานไปแล้วตอน non-2xx/contract
     .catch ชั้นนอก (transport) เช็ค njEdgeDone() ก่อน จึงไม่รายงานซ้ำ */
  function njEdgeMark(e) { try { e.njEdgeReported = 1; } catch (x) {} return e; }
  function njEdgeDone(e) { return !!(e && e.njEdgeReported); }

  /* ตรวจ contract ของ Response ตาม action — คืนชื่อ field ที่ขาด (ว่าง = ผ่าน)
     รายงานเฉพาะ "ชื่อ field" เท่านั้น ห้าม log raw response body */
  function njEdgeMissing(action, d) {
    var a = String(action || '');
    if (!d || typeof d !== 'object') return 'json';
    if (a === 'upload-url') {
      return (!d.upload_url ? 'upload_url ' : '') + (!d.path ? 'path' : '');
    }
    if (a === 'download-url' || a === 'view-url') return d.url ? '' : 'url';
    /* njhr-doc-pdf — contract จริงจาก edge-functions/njhr-doc-pdf/index.ts
       download : { url, file_name, mime_type, expires_in }   → บังคับ url + file_name
       generate : { ok:true, status:'READY', ... }            → บังคับ ok + status
                  (กรณีล้มเหลวจริง Edge คืน HTTP != 2xx พร้อม ok:false จึงถูกจับที่ !r.ok แล้ว) */
    if (a === 'download') {
      return (!d.url ? 'url ' : '') + (!d.file_name ? 'file_name' : '');
    }
    if (a === 'generate') {
      if (d.ok !== true) return 'ok';
      return String(d.status || '') === 'READY' ? '' : 'status';
    }
    return '';
  }

  /* transport failure (Failed to fetch · Load failed · NetworkError · offline · timeout) */
  function njEdgeNet(name, action, e) {
    if (njEdgeDone(e)) return e;                 // non-2xx รายงานไปแล้ว ห้ามซ้ำ
    try {
      njErrReport('EDGE_FAIL', name + (action ? ('/' + action) : ''),
        { message: 'network: ' + ((e && e.message) || 'failed') });
    } catch (x) {}
    return njEdgeMark(e);
  }

  function njEdgeFail(name, action, status, msg) {
    try {
      njErrReport('EDGE_FAIL', name + (action ? ('/' + action) : ''),
        { message: 'HTTP ' + (status == null ? '?' : status) + ' ' + (msg || '') });
    } catch (e) {}
  }
