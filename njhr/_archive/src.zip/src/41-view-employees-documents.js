  /* ================= EMPLOYEE DOCUMENTS =================
     ย้ายมาจาก 30-view-employees.js โดยไม่แก้เนื้อใน
     Bucket · Storage Path · Signed URL · Metadata · File Rule — เหมือนเดิมทุกตัวอักษร
     โหลดเมื่อกด [data-emp-docs] เท่านั้น ================= */
  var EMPF_CATS = [
    { code: 'PERSONAL', em: '🧾', label: 'เอกสารส่วนตัวพนักงาน', kinds: [
      ['ID_CARD', 'บัตรประชาชน'], ['HOUSE_REG', 'ทะเบียนบ้าน'], ['BANK_BOOK', 'สมุดบัญชีธนาคาร'],
      ['EDUCATION', 'วุฒิการศึกษา'], ['DRIVER_LICENSE', 'ใบขับขี่'], ['WORK_PERMIT', 'ใบอนุญาตทำงาน'],
      ['PHOTO', 'รูปถ่าย'], ['OTHER', 'เอกสารอื่น ๆ'] ] },
    { code: 'COMPANY', em: '🏢', label: 'เอกสารจากบริษัท', kinds: [
      ['CONTRACT', 'สัญญาจ้าง'], ['WARNING', 'หนังสือเตือน'], ['SUSPENSION', 'หนังสือพักงาน'],
      ['PROBATION_RESULT', 'หนังสือผ่านทดลองงาน'], ['SALARY_CERT', 'หนังสือรับรองเงินเดือน'],
      ['COE', 'หนังสือรับรองการทำงาน'], ['SEPARATION', 'หนังสือรับรองการทำงานพ้นสภาพ'],
      ['OTHER', 'เอกสารอื่น ๆ'] ] }
  ];

  var EMPF_DOC_KIND = {
    CONTRACT: 'CONTRACT', CONTRACT_PROBATION: 'CONTRACT', WARNING: 'WARNING',
    SUSPENSION: 'SUSPENSION', PROBATION_RESULT: 'PROBATION_RESULT',
    SALARY_CERT: 'SALARY_CERT', COE: 'COE', SEPARATION: 'SEPARATION'
  };

  var EMPF_ACCEPT = '.pdf,.doc,.docx,.xls,.xlsx,image/*';

  var EMPF_MAX = 10 * 1024 * 1024;       // ต้องตรงกับ MAX_SIZE ใน Edge Function

  var empfState = { empId: null, emp: null, perm: null, files: [], hrDocs: [], seq: 0, onClose: null };

  function empfKindLabel(cat, kind) {
    for (var i = 0; i < EMPF_CATS.length; i++) {
      if (EMPF_CATS[i].code !== cat) continue;
      for (var j = 0; j < EMPF_CATS[i].kinds.length; j++) {
        if (EMPF_CATS[i].kinds[j][0] === kind) return EMPF_CATS[i].kinds[j][1];
      }
    }
    return kind;
  }

  function empfSize(n) {
    n = Number(n || 0);
    if (!isFinite(n) || n <= 0) return '—';
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n / 1024).toFixed(1) + ' KB';
    return (n / 1048576).toFixed(2) + ' MB';
  }

  function empfErr(msg) { var b = document.getElementById('empf-err'); if (b) b.textContent = msg || ''; }

  function empfExpiry(iso) {
    if (!iso) return '';
    var d = Date.parse(String(iso).slice(0, 10) + 'T00:00:00');
    if (!isFinite(d)) return '';
    var days = Math.floor((d - Date.parse(new Date().toISOString().slice(0, 10) + 'T00:00:00')) / 86400000);
    if (days < 0) return ' <span class="badge badge-bad">หมดอายุแล้ว</span>';
    if (days <= 30) return ' <span class="badge badge-warn">อีก ' + days + ' วัน</span>';
    return '';
  }

  function empfFn(body) {
    if (!sbReady()) return Promise.reject(new Error('ยังไม่ได้ตั้งค่าการเชื่อมต่อ Supabase'));
    return fetch(SB.url + '/functions/v1/njhr-emp-file', {
      method: 'POST',
      headers: { 'apikey': SB.key, 'Authorization': 'Bearer ' + SB.key, 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.assign({ token: sbToken() }, body || {}))
    }).then(function (r) {
      return r.text().then(function (t) {
        var d = {};
        try { d = JSON.parse(t); } catch (e) { d = {}; }
        var act = (body && body.action) || '';
        if (!r.ok) {
          njEdgeFail('njhr-emp-file', act, r.status, d.error);
          throw njEdgeMark(new Error(d.error || 'เข้าถึงไฟล์ไม่สำเร็จ (' + r.status + ')'));
        }
        var miss = njEdgeMissing(act, d) || (t ? '' : 'empty-body');
        if (miss) {
          njEdgeFail('njhr-emp-file', act, r.status, 'invalid response: missing ' + miss.trim());
          throw njEdgeMark(new Error('เข้าถึงไฟล์ไม่สำเร็จ (' + r.status + ')'));
        }
        return d;
      });
    })['catch'](function (e) {
      throw njEdgeNet('njhr-emp-file', (body && body.action) || '', e);
    });
  }

  function empfOpen(fileId, download) {
    empfErr('');
    return empfFn({ action: 'download-url', file_id: fileId, download: download ? 1 : 0 })
      .then(function (d) {
        if (!d.url) throw new Error('ออกลิงก์ไฟล์ไม่สำเร็จ');
        if (download) {
          var a = document.createElement('a');
          a.href = d.url; a.download = d.file_name || ''; a.rel = 'noopener';
          document.body.appendChild(a); a.click(); document.body.removeChild(a);
        } else {
          window.open(d.url, '_blank', 'noopener');
        }
      }).catch(function (ex) { empfErr(ex.message || 'เข้าถึงไฟล์ไม่สำเร็จ'); });
  }

  function empfUploadOne(file, cat, kind, meta) {
    if (file.size > EMPF_MAX) {
      return Promise.reject(new Error('"' + file.name + '" ใหญ่เกิน ' + (EMPF_MAX / 1048576) + ' MB'));
    }
    return empfFn({
      action: 'upload-url', employee_id: empfState.empId,
      category: cat, doc_kind: kind, file_name: file.name, size: file.size
    }).then(function (d) {
      if (!d.upload_url || !d.path) throw new Error('ขอสิทธิ์อัปโหลดไม่สำเร็จ');
      /* [Error Monitoring] Signed PUT — ห้าม log: Signed URL · เนื้อไฟล์ · token ·
         เอกสารพนักงาน · ชื่อไฟล์จริง (บันทึกเฉพาะ HTTP status / ประเภทความล้มเหลว) */
      return fetch(d.upload_url, {
        method: 'PUT',
        headers: { 'Content-Type': file.type || 'application/octet-stream' },
        body: file
      }).then(function (r) {
        if (!r.ok) return r.text().then(function (t) {
          njEdgeFail('njhr-emp-file', 'signed-put', r.status, '');
          throw njEdgeMark(new Error('อัปโหลด "' + file.name + '" ไม่สำเร็จ: ' + t.slice(0, 120)));
        });
        return { name: file.name, path: d.path, mime: file.type || '', size: file.size };
      })['catch'](function (e) {
        throw njEdgeNet('njhr-emp-file', 'signed-put', e);
      });
    }).then(function (f) {
      return sbRpc('njhr_empfile_save', {
        p_token: sbToken(), p_employee: empfState.empId, p_category: cat, p_doc_kind: kind,
        p_file: f, p_id: (meta && meta.id) || null,
        p_document_date: (meta && meta.document_date) || null,
        p_expiry_date: (meta && meta.expiry_date) || null,
        p_note: (meta && meta.note) || null
      });
    });
  }

  /* p_onClose = callback เมื่อปิดแฟ้ม (หน้า Self Service ใช้รีเฟรชสถานะเอกสาร)
     สิทธิ์เปิด: ผู้มีสิทธิ์บริหาร หรือ "เจ้าของแฟ้ม" (พนักงานเปิดแฟ้มของตัวเอง)
     ตัวจริงที่บังคับคือ njhr_empfile_guard ฝั่งเซิร์ฟเวอร์ ตรงนี้เป็นเพียงการกันกดเปล่า */
  function empFilesOpen(empId, onClose) {
    var me = currentUser() || {};
    var isOwner = !!(me.empId && empId && String(me.empId) === String(empId));
    if (!empCanDocs() && !isOwner) {
      toast('คุณไม่มีสิทธิ์เปิดแฟ้มเอกสารพนักงาน', 'error'); return;
    }
    empfState.empId = empId;
    empfState.onClose = typeof onClose === 'function' ? onClose : null;
    openModal('แฟ้มเอกสารพนักงาน', '<div class="muted">กำลังโหลด…</div>',
      '<button class="btn btn-ghost" id="empf-close">ปิด</button>', { wide: true });
    var cb = document.getElementById('empf-close');
    if (cb) cb.onclick = function () {
      var fn = empfState.onClose; empfState.onClose = null;
      closeModal(); if (fn) fn();
    };
    empfLoad();
  }

  function empfLoad() {
    var seq = ++empfState.seq;
    return sbRpc('njhr_empfile_list', { p_token: sbToken(), p_employee: empfState.empId })
      .then(function (r) {
        if (seq !== empfState.seq) return;
        var d = (r && r.data) || {};
        empfState.emp = d.employee || {};
        empfState.perm = d.perm || {};
        empfState.files = d.files || [];
        empfState.hrDocs = d.hr_docs || [];
        empfRender();
      }).catch(function (ex) {
        if (seq !== empfState.seq) return;
        var body = document.querySelector('#modal-root .modal-body');
        if (body) body.innerHTML = '<div class="form-error">' + esc(ex.message || 'โหลดเอกสารไม่สำเร็จ') + '</div>';
      });
  }

  function empfRender() {
    var body = document.querySelector('#modal-root .modal-body');
    if (!body) return;
    var e = empfState.emp || {}, perm = empfState.perm || {};
    var w = !!perm.can_write, del = !!perm.can_delete;
    // เจ้าของแฟ้ม (ไม่ใช่ผู้มีสิทธิ์บริหาร) แนบได้เฉพาะหมวด PERSONAL
    // หมวด COMPANY คือเอกสารที่บริษัทออกให้ — บังคับซ้ำที่ njhr_empfile_save / _upload_path
    var mgr = (perm.is_manager === undefined) ? w : !!perm.is_manager;

    // จัดกลุ่มไฟล์และหนังสือระบบตามหมวดย่อย
    var byKind = {}, sysByKind = {};
    empfState.files.forEach(function (f) {
      var k = f.category + '|' + f.doc_kind;
      (byKind[k] = byKind[k] || []).push(f);
    });
    empfState.hrDocs.forEach(function (d) {
      var k = 'COMPANY|' + (EMPF_DOC_KIND[d.doc_type] || 'OTHER');
      (sysByKind[k] = sysByKind[k] || []).push(d);
    });

    function fileRow(f) {
      return '<div class="empf-row">' +
        '<div class="empf-main"><b>' + esc(f.file_name) + '</b>' +
        '<small>' + empfSize(f.file_size) +
        ' · อัปโหลด ' + esc(f.uploaded_by || '—') + ' ' + empBE(String(f.uploaded_at || '').slice(0, 10)) +
        (f.version > 1 ? ' · ฉบับที่ ' + f.version : '') + '</small>' +
        '<small>ออกเอกสาร ' + (f.document_date ? empBE(f.document_date) : '—') +
        ' · หมดอายุ ' + (f.expiry_date ? empBE(f.expiry_date) : '—') + empfExpiry(f.expiry_date) + '</small>' +
        (f.note ? '<small class="empf-note">หมายเหตุ: ' + esc(f.note) + '</small>' : '') +
        '</div><div class="empf-act">' +
        '<button class="btn-icon" data-ef-view="' + esc(f.id) + '" aria-label="ดูไฟล์" title="ดูไฟล์">' + icon('eye') + '</button>' +
        '<button class="btn-icon" data-ef-dl="' + esc(f.id) + '" aria-label="ดาวน์โหลด" title="ดาวน์โหลด">' + icon('download') + '</button>' +
        (w ? '<button class="btn-icon" data-ef-edit="' + esc(f.id) + '" aria-label="แก้ไข" title="แก้ไข / เปลี่ยนไฟล์">' + icon('edit') + '</button>' : '') +
        (del ? '<button class="btn-icon ic-red" data-ef-del="' + esc(f.id) + '" aria-label="ลบ" title="ลบ">' + icon('trash') + '</button>' : '') +
        '</div></div>';
    }
    function sysRow(d) {
      return '<div class="empf-row empf-sys">' +
        '<div class="empf-main"><b>' + esc(d.title || d.doc_no) +
        ' <span class="badge badge-info">ออกโดยระบบ</span></b>' +
        '<small>เลขที่ ' + esc(d.doc_no) + ' · ฉบับที่ ' + (d.version || 1) +
        ' · ' + esc(docTypeLabel(d.doc_type)) + '</small>' +
        '<small>วันที่ออก ' + empBE(String(d.issued_at || '').slice(0, 10)) +
        ' · สถานะ ' + esc(docStat(d.status).t) + '</small></div>' +
        '<div class="empf-act"><button class="btn-icon" data-ef-doc="' + esc(d.id) + '" ' +
        'aria-label="เปิดเอกสาร" title="เปิดในศูนย์เอกสาร HR">' + icon('fileText') + '</button></div></div>';
    }

    body.innerHTML =
      '<div class="empf-head">' + avatarHTML(e.full_name || '', 40) +
      '<div class="grow"><b>' + esc(e.full_name || '—') + '</b>' +
      '<small>' + esc(e.emp_code || '—') + ' · ' + esc(e.department_name || '—') +
      ' · ' + esc(e.position_name || '—') + '</small></div>' +
      '<span class="badge badge-mut">' + esc(perm.role || '') + '</span></div>' +
      (w ? '' : '<p class="muted note">คุณเปิดดูได้อย่างเดียว — การแนบ แก้ไข หรือลบเอกสารสงวนไว้สำหรับฝ่ายบุคคลและผู้ดูแลระบบ</p>') +
      EMPF_CATS.map(function (c) {
        return '<div class="empf-cat"><div class="empf-cat-h">' + c.em + ' ' + esc(c.label) + '</div>' +
          c.kinds.map(function (k) {
            var key = c.code + '|' + k[0];
            var list = byKind[key] || [], sys = sysByKind[key] || [];
            var locked = c.code === 'COMPANY' && sys.length > 0;   // มีหนังสือจากระบบแล้ว → ห้ามอัปโหลดซ้ำ
            var canAdd = w && !locked && (mgr || c.code === 'PERSONAL');
            return '<div class="empf-kind"><div class="empf-kind-h">' +
              '<b>' + esc(k[1]) + '</b>' +
              '<span class="badge badge-mut">' + (list.length + sys.length) + '</span>' +
              '<span class="grow"></span>' +
              (canAdd
                ? '<button class="btn btn-ghost btn-sm" data-ef-add="' + c.code + '|' + k[0] + '">' +
                  icon('paperclip') + ' แนบไฟล์</button>'
                : (locked ? '<small class="muted">ระบบออกให้อัตโนมัติ — ไม่ต้องอัปโหลดซ้ำ</small>' : '')) +
              '</div>' +
              (list.length || sys.length
                ? sys.map(sysRow).join('') + list.map(fileRow).join('')
                : '<div class="empf-empty">ยังไม่มีเอกสาร</div>') +
              '</div>';
          }).join('') + '</div>';
      }).join('') +
      '<div class="form-error" id="empf-err" role="alert" style="white-space:pre-line"></div>';

    body.onclick = function (ev) {
      var b = ev.target.closest ? ev.target.closest(
        '[data-ef-add],[data-ef-view],[data-ef-dl],[data-ef-edit],[data-ef-del],[data-ef-doc]') : null;
      if (!b) return;
      var ds = b.dataset;
      if (ds.efAdd) { var p = ds.efAdd.split('|'); empfUploadForm(p[0], p[1]); }
      else if (ds.efView) empfOpen(ds.efView, false);
      else if (ds.efDl) empfOpen(ds.efDl, true);
      else if (ds.efEdit) empfEditForm(ds.efEdit);
      else if (ds.efDel) empfDelete(ds.efDel);
      else if (ds.efDoc) { closeModal(); docState.openId = ds.efDoc; nav('#/hr-docs'); }
    };
  }

  function empfMetaFields(v) {
    v = v || {};
    return '<div class="form-2col">' +
      '<label class="field"><span>วันที่ออกเอกสาร</span>' +
      '<input type="date" id="ef-dd" value="' + esc(v.document_date || '') + '"></label>' +
      '<label class="field"><span>วันที่หมดอายุ</span>' +
      '<input type="date" id="ef-ed" value="' + esc(v.expiry_date || '') + '"></label></div>' +
      '<label class="field"><span>หมายเหตุ</span>' +
      '<textarea id="ef-note" rows="2" placeholder="ระบุรายละเอียดเพิ่มเติม (ถ้ามี)">' + esc(v.note || '') + '</textarea></label>';
  }

  function empfReadMeta() {
    return {
      document_date: document.getElementById('ef-dd').value || null,
      expiry_date: document.getElementById('ef-ed').value || null,
      note: document.getElementById('ef-note').value || null
    };
  }

  function empfUploadForm(cat, kind) {
    openModal('แนบไฟล์ — ' + esc(empfKindLabel(cat, kind)),
      '<label class="field"><span>เลือกไฟล์ (เลือกได้หลายไฟล์) <i class="req">*</i></span>' +
      '<input type="file" id="ef-files" multiple accept="' + EMPF_ACCEPT + '"></label>' +
      '<p class="muted note">รองรับ PDF, Word, Excel และไฟล์รูปภาพ · ไม่เกิน ' + (EMPF_MAX / 1048576) + ' MB ต่อไฟล์</p>' +
      empfMetaFields(null) +
      '<div class="form-error" id="ef-err" role="alert" style="white-space:pre-line"></div>',
      '<button class="btn btn-ghost" id="ef-cancel">ยกเลิก</button>' +
      '<button class="btn btn-primary" id="ef-go">' + icon('paperclip') + ' อัปโหลด</button>');
    document.getElementById('ef-cancel').onclick = function () { empFilesReopen(); };
    document.getElementById('ef-go').onclick = function () {
      var btn = this, err = document.getElementById('ef-err');
      var fl = document.getElementById('ef-files').files;
      if (!fl || !fl.length) { err.textContent = 'กรุณาเลือกไฟล์'; return; }
      var meta = empfReadMeta();
      if (meta.document_date && meta.expiry_date && meta.expiry_date < meta.document_date) {
        err.textContent = 'วันที่หมดอายุต้องไม่น้อยกว่าวันที่ออกเอกสาร'; return;
      }
      if (btn.disabled) return;
      btn.disabled = true; err.textContent = '';
      var list = Array.prototype.slice.call(fl), done = 0;
      btn.innerHTML = '<span class="spinner"></span> กำลังอัปโหลด 0/' + list.length;
      list.reduce(function (chain, f) {
        return chain.then(function () {
          return empfUploadOne(f, cat, kind, meta).then(function () {
            done++; btn.innerHTML = '<span class="spinner"></span> กำลังอัปโหลด ' + done + '/' + list.length;
          });
        });
      }, Promise.resolve()).then(function () {
        toast('แนบเอกสารเรียบร้อยแล้ว ' + done + ' ไฟล์');
        empFilesReopen();
      }).catch(function (ex) {
        btn.disabled = false; btn.innerHTML = icon('paperclip') + ' อัปโหลด';
        err.textContent = (done ? 'อัปโหลดสำเร็จ ' + done + ' ไฟล์ก่อนเกิดข้อผิดพลาด\n' : '') +
          (ex.message || 'อัปโหลดไม่สำเร็จ');
      });
    };
  }

  function empFilesReopen() { empFilesOpen(empfState.empId); }

  function empfFind(id) {
    for (var i = 0; i < empfState.files.length; i++) if (empfState.files[i].id === id) return empfState.files[i];
    return null;
  }

  function empfEditForm(id) {
    var f = empfFind(id);
    if (!f) { toast('ไม่พบเอกสารนี้', 'error'); return; }
    openModal('แก้ไขเอกสาร — ' + esc(empfKindLabel(f.category, f.doc_kind)),
      '<div class="empf-cur"><small>ไฟล์ปัจจุบัน</small><b>' + esc(f.file_name) + '</b>' +
      '<small>' + empfSize(f.file_size) + ' · ฉบับที่ ' + (f.version || 1) + '</small></div>' +
      '<label class="field"><span>เปลี่ยนไฟล์ (เว้นว่างไว้ = ใช้ไฟล์เดิม)</span>' +
      '<input type="file" id="ef-files" accept="' + EMPF_ACCEPT + '"></label>' +
      '<p class="muted note">ไฟล์เดิมจะถูกเก็บไว้ในประวัติเอกสาร ไม่ถูกลบทิ้ง</p>' +
      empfMetaFields({
        document_date: f.document_date ? String(f.document_date).slice(0, 10) : '',
        expiry_date: f.expiry_date ? String(f.expiry_date).slice(0, 10) : '',
        note: f.note || ''
      }) +
      '<div class="form-error" id="ef-err" role="alert" style="white-space:pre-line"></div>',
      '<button class="btn btn-ghost" id="ef-cancel">ยกเลิก</button>' +
      '<button class="btn btn-primary" id="ef-go">' + icon('check') + ' บันทึก</button>');
    document.getElementById('ef-cancel').onclick = function () { empFilesReopen(); };
    document.getElementById('ef-go').onclick = function () {
      var btn = this, err = document.getElementById('ef-err');
      var meta = empfReadMeta();
      if (meta.document_date && meta.expiry_date && meta.expiry_date < meta.document_date) {
        err.textContent = 'วันที่หมดอายุต้องไม่น้อยกว่าวันที่ออกเอกสาร'; return;
      }
      if (btn.disabled) return;
      btn.disabled = true; err.textContent = '';
      btn.innerHTML = '<span class="spinner"></span> กำลังบันทึก…';
      var nf = document.getElementById('ef-files').files;
      var job = (nf && nf.length)
        ? empfUploadOne(nf[0], f.category, f.doc_kind, Object.assign({ id: f.id }, meta))
        : sbRpc('njhr_empfile_save', {
            p_token: sbToken(), p_employee: empfState.empId,
            p_category: f.category, p_doc_kind: f.doc_kind, p_file: null, p_id: f.id,
            p_document_date: meta.document_date, p_expiry_date: meta.expiry_date, p_note: meta.note
          });
      job.then(function () {
        toast('บันทึกข้อมูลเอกสารเรียบร้อยแล้ว');
        empFilesReopen();
      }).catch(function (ex) {
        btn.disabled = false; btn.innerHTML = icon('check') + ' บันทึก';
        err.textContent = ex.message || 'บันทึกไม่สำเร็จ';
      });
    };
  }

  function empfDelete(id) {
    var f = empfFind(id);
    if (!f) { toast('ไม่พบเอกสารนี้', 'error'); return; }
    openModal('ลบเอกสาร',
      '<p class="confirm-msg">ลบ <b>' + esc(f.file_name) + '</b> ออกจากแฟ้มเอกสารของ ' +
      '<b>' + esc((empfState.emp && empfState.emp.full_name) || '') + '</b> ใช่หรือไม่</p>' +
      '<label class="field"><span>เหตุผลการลบ <i class="req">*</i></span>' +
      '<textarea id="ef-why" rows="3" placeholder="ระบุเหตุผล"></textarea></label>' +
      '<div class="form-error" id="ef-err" role="alert"></div>',
      '<button class="btn btn-ghost" id="ef-cancel">ยกเลิก</button>' +
      '<button class="btn btn-danger" id="ef-go">ยืนยันการลบ</button>');
    document.getElementById('ef-cancel').onclick = function () { empFilesReopen(); };
    document.getElementById('ef-go').onclick = function () {
      var btn = this, err = document.getElementById('ef-err');
      var why = String(document.getElementById('ef-why').value || '').trim();
      if (!why) { err.textContent = 'กรุณาระบุเหตุผลการลบ'; return; }
      if (btn.disabled) return;
      btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> กำลังลบ…';
      sbRpc('njhr_empfile_delete', { p_token: sbToken(), p_id: id, p_reason: why })
        .then(function () { toast('ลบเอกสารแล้ว', 'info'); empFilesReopen(); })
        .catch(function (ex) {
          btn.disabled = false; btn.innerHTML = 'ยืนยันการลบ';
          err.textContent = ex.message || 'ลบไม่สำเร็จ';
        });
    };
  }

  /* Public Feature Contract ของ Employee Documents */
  NJHR.features.employeesDocs = { open: empFilesOpen, reopen: empFilesReopen };
