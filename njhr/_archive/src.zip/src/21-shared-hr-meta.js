  /* ================= SHARED: HR DOCUMENT META =================
     ย้ายมาจาก 14-view-profile-hrdocs.js โดยไม่แก้เนื้อใน
     docState เป็น object literal ที่ไม่เคยถูกกำหนดค่าใหม่ จึงแชร์แบบอ้างอิงได้ปลอดภัย
     ใช้ร่วมกันโดย employees · requests-leave · compatibility ================= */
  var DOC_TYPES = [
    { code: 'CONTRACT',         em: '📑', label: 'สัญญาจ้างงาน',                    px: 'EMP' },
    { code: 'WARNING',          em: '⚠️', label: 'หนังสือเตือนพนักงาน',              px: 'WR' },
    { code: 'SUSPENSION',       em: '⏸️', label: 'หนังสือพักงาน',                    px: 'SUS' },
    { code: 'PROBATION_RESULT', em: '✅', label: 'หนังสือแจ้งผลผ่านทดลองงาน',        px: 'PAS' },
    { code: 'COE',              em: '🏢', label: 'หนังสือรับรองการทำงาน',            px: 'COE' },
    { code: 'SALARY_CERT',      em: '💰', label: 'หนังสือรับรองเงินเดือน',           px: 'SAL' },
    { code: 'SEPARATION',       em: '📋', label: 'หนังสือรับรองการทำงาน (พ้นสภาพ)',  px: 'SEP' },
    { code: 'CONTRACT_PROBATION', em: '🤝', label: 'สัญญาจ้างงานและข้อตกลงทดลองงาน',   px: 'CTP' },
    /* 50 ทวิ — ออกจากหน้า "รายงาน 50 ทวิ" ไม่ได้สร้างจากหน้าเอกสาร HR
       แต่ต้องมีในรายการนี้ เพื่อให้ "เอกสารของฉัน" แสดงชื่อและไอคอนถูกต้อง */
    { code: 'WHT50',            em: '🧾', label: '50 ทวิ (หนังสือรับรองการหักภาษี ณ ที่จ่าย)', px: 'WHT' }
  ];

  var DOC_STATUS = {
    DRAFT:            { em: '📝', t: 'Draft',           c: 'badge-mut' },
    PENDING:          { em: '⏳', t: 'รออนุมัติ',        c: 'badge-warn' },
    PENDING_APPROVAL: { em: '⏳', t: 'รออนุมัติ',        c: 'badge-warn' },
    APPROVED:         { em: '✅', t: 'อนุมัติแล้ว',      c: 'badge-info' },
    SENT:             { em: '📤', t: 'ส่งแล้ว',          c: 'badge-info' },
    VIEWED:           { em: '👀', t: 'เปิดอ่านแล้ว',     c: 'badge-info' },
    ACKNOWLEDGED:     { em: '✍️', t: 'รับทราบแล้ว',      c: 'badge-ok' },
    SIGNED:           { em: '✍️', t: 'ลงนามแล้ว',        c: 'badge-ok' },
    REJECTED:         { em: '❌', t: 'ปฏิเสธรับทราบ',    c: 'badge-bad' },
    ARCHIVED:         { em: '📁', t: 'เก็บเข้าประวัติ',   c: 'badge-mut' },
    CANCELLED:        { em: '🚫', t: 'ยกเลิกแล้ว',       c: 'badge-bad' },
    SUPERSEDED:       { em: '🗂', t: 'ถูกแทนที่',        c: 'badge-mut' }
  };

  var docState = {
    q: '', type: '', status: '', dept: '', from: '', to: '',
    empId: '', openId: '', seq: 0, sort: 'issued_at', desc: true, histOpen: false
  };

  function docStat(s) { return DOC_STATUS[s] || { em: '•', t: s || '-', c: 'badge-mut' }; }

  function docTypeDef(code) {
    for (var i = 0; i < DOC_TYPES.length; i++) if (DOC_TYPES[i].code === code) return DOC_TYPES[i];
    return { code: code, em: '📄', label: code, px: 'DOC' };
  }

  function docTypeLabel(code) { return docTypeDef(code).label; }

  function docTS(v) {
    if (!v) return '—';
    var d = new Date(v);
    if (!isFinite(d)) return '—';
    return pad(d.getDate()) + '/' + pad(d.getMonth() + 1) + '/' + (d.getFullYear() + 543) +
      ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  /* ---------- ย้ายมาจาก 11 และ 13 (เนื้อหาเดิมทุกตัวอักษร) ----------
     ใช้ร่วมกันระหว่าง chunk compatibility และ profile-docs
     ต้องอยู่ที่ Shared ตัวเดียว ห้าม Copy ซ้ำเข้าแต่ละ Module */
  var NJ_LOGO_SRC = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAABeCAMAAABCbusGAAADAFBMVEXLICjLICjLICjLICjLICjLICjLICjLICjLICjLICjLICjLICjLICjLICjLICjLICgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMz5BkAAAAEHRSTlMAESIzRFVmd4iZqrvM3e7/dpUBFQAADclJREFUeNrtXIt247YONElJlmSJ+v+/LfEGKNlxkmZ327M6PbfbTWxjSDwGA/jebn+f/+eTUvqP25//ywia+aWUnF5e0J8LEMwfxnFgBOlkODy5PX8ohJTKMN3n+T4iArMSrS7yDAMgvMTAGH/f+Q/Tsj7W5T4QgEQ2NeOHYZz0uU9Tg3B1Dcme3wEgl2nZ9n1b5xGPmDwGjb/Py7Las9wndLR08R7w/BYna589zo/9OPbHPDEAOPsRjX9sDVp7Nnoey3yfLiCAE06TRtEvBjDc170eR93oBsDtW0yA8fteuwfuiWOFXQf/0N6j3dQ8Db/mCvRD0NnhAurRjEMAYD64zvoA44/TU/fHoggEQCInfLAP/nSlTR6AXQADaObPePpX5huC5IpDynAG7Q1WSAM/DiDmCrwAMLZ9/tLcu/n+Ao6vToNGy5/JjR6cr+StWhZbd4BGAH7acTyAxBdAANaWZKZ5ZesPZz8GMt4J/PXeoJasb8VO2IJonYafj+KQrSkFsV3buszzAs7jHIYi99Fy6EPdio+aD0XPoEIMpO/Rjjfqif8xXcCmB0s2BvtbAm0lbr7fW6leVgZnpqL904LIBNaXy1oKz8tfcjWMIwDOGryEzOazF+unRpQaWWq5lRBAuBROQJCBHpQE1LGQNr025RUleYnd/7R9+AgXgDdw+Jils6ejb/UJGATm1xbgO4Yx3ACXbEwCB/9luwHifR8huP7rd+1PWsMmsOhAAOb0ZD4dfTO+iDkZEWwNGSZSoqiUhSsGBlOR3v70Nj3/2PciALkAn/Ex/4CNMx+9vQRurBWJpSEbB7qTxpeWDc7/oCwsVOQNF3oF4PYWALwAdOpqGQevgwgDnD3lSXtFIXo6olPBf2BY1EMuAMpAetuVP0/Mw9tC/qbr788fXIQPP/prcv0BmA+JqfJriAml93Lh7Yt51r8zXUA9PIDKXGFyxDpg5gjF/gYIH5cGtj87+3+wivExcQr1AMgXHsIqxVxx6Zs4OJ5+o9uYkvQ1juGlHy3DyVIokYiOq81KNqGrgU4SE1FmPIXNX7Vmq/3peYL8t3kE1uCly0DEJ7jIEs+YWgmeKJlKYzzi4Te6LXwVfQ5D5sftD/lk7B3oIEKn9sMdNUuxHrRajA+0xjP3OkqVKGbyr+iILRi1ALnTB5qp9nOQQLMMFVkf7hWEMTXM3OE8Pfov40ovWjGswfWoNeSfZv9Qwu9szEbdo5yUnuZzcv6hz/iANLyQNH3O636YujbGHKhSLb0P2u22f1qfsglJ2vUxuir5Z7R6nc5GfQlAekXLk7BoC2GqRd7/E3e6fW8QQgabmPYiBsDGfi+MU0of0eqkJcA7UMifKflrCnWiBwBel0PR/hIAJ2D60vPkCojEHTGEtX7drFTftVbFa+CekzqDIeeQgr5kP1d395zj6hai00UAiSpGJhUA0Oc16BMQDKRxUSw4AN8YOCRmiXd7mDBeA2AhwiLAk8lAV0ljMY0Ccir0x6DZ7a8BvO1IpGNSyVkhzZGKSd3IlVp5qsHBkPaC7Mo1UU4WGDeuCHhE1AmRFpTPKfTtUCAdc5pVxRQpEz7rSoo912A82pVkOQ0fd7cTHQ6fitTkOzHZTfqwLgemF9m8M4fPqJcxsYLOJ8E1aQT7CBA20wMgCOM4qV8KKxpYjnG5S/l2APBBX5ORr0Qtx0kirco3w8L1Sh9cT9k8pK84fZLEUBRkYSrCmrZaKvEQbuK1/YvxwgsIJBmHYUBH4irqPHIBF9m3bwvojyAnViemBADvFCORCVhssnofVU1Hj590AfWUgp734b4p43YOJaJYinrEH9gvct9GGW5lyiUimp6QTpM20j27GvCxkOAHspgKNiYgQ/b4sqtJ5Wkqp0EEpIJdSC1kOIw1ob0U1w5AuugCrAa8E3Pu9FBUFUHR8j6FzMijNVM2uocuEfxfdZAFNDSSAAG79KwYZMmFDGSgrguDFJSv1fenLFcUOZhMjU4R5ZI6g3zEup70agFAwTzAxYRidZTGT9IESuWP1bcoA2fv6l0IzrC41P+sXIaiGAAUNxqkwSD4MLj0ssyXozMAMEg6qZwtS3FZXJTARbMQkdCNIe/0b53M9ABiMEhUemFenFEBiFNsmkmoeLuhmgNQioyGREbz+odVUcAv+VjaSKwQFMo2V+kkhRjMLwDoDaD9c8/9qBiN/eADAEAWOOAN8PivkiDraFmygwhZLTDWlVV1SFNgwM2qTnoGII5GBMAqQi9U57UvSdJ1dghwErpylrmPQ6+jWdjJseF1LGR1w0yaIBexIWvZzM9WIvr8CgA0jRZ2f/HprnerPEOPAHg4CmzQE7aLMproFSPpsNT7QnzTYGanFOQBPB/UacMMnJyucycDzP6jt19nBwGAuMOjw3ZK4zLJFQpHaX+aebaqIfwWgFAHFADSKLa/1nPvxmQrABhG5lJL513Bgc49gOgI0u22/+IQTlEYvynrCU5pCDoA2qUqSQ8aBtSakjyAaUbJZvNMJ15AN8uT8RbqaKNe96YeFAHkbHQg5GeJLQZwMAB1oEN2EoDYPJTmg6d5AEzJ9nUqnf9HbYatQRmr6pyd5yqHc0H362S7NAH3aaIKb8soBGDyADCB8idQ34mTTVtZaEftAch0l8v4NQDNQ8VGYWT/wP2UH67b7zMZ0EUb4ARCCtxvwXAV3gKFIZQJuAdpJz9z8yODTUi3y+hii+HHe4kerPkb51jBfkzYDGChFRu3WsY9pLWoRApW3bShU6F+oJkMWUg4Fs7WCGvhrmFm8tWcxdG6QqrltgoXt7l/EEYSz7Gc/cA5HAtxREYoOjbYu8wupNHYtEMVJrkiEW6GDYV1jl1Hg3KOIi0BZbwXDwBxuWbiliIA65jvswzY+fyLuhTnIH05HCyymZDINR0i5+K2GM6A3rTZUAoc9EY6byCfCX+CJxEBUBLtu6HTGBI3lx7YM9SqpKOosAXrGQ51pmWV/XrR5tDhMQwKRBkAJkIKGMggfPim7mnPGAFIR726vZfUTdi4ui+sQNnskYpyVR5k3ofnL3O7+kQn4M0JvcMZAUygFzGn8UZIeqonAFs9ZOR/LUmT/QwfGdWdY4v7Ys5iLnzKqC3GSQj1EFSZo/wOwQotmFBKB4Drg96AZiGTlfwVOACyGMBZmFoejkACwEmUmB6WAms4dduDlFAne/AOyMbjbZopUOUoYaivMjKmG0i3k4sN2RCxBYvUBTG5g7oPLDMN2qxRFTmoDlKy5c0r+TReVSGd0gqqXkNVKWEhLpc7PUtFKGZI7bM8GZKO2jYsohxDq2+mWKj7c3LmvmDjOig3wDejvj6zVDzLXK/6jRDksptTZHwwSkmhDgHecB5DJeYsrNqksx8bYpQbqxvDmf0KAJKo68Mg5dH+YqVGkOQBZBUymww7OTyWZU0s6lo5Swqv1Xurkbll53fgEUl2pz+Y9x8yhjP7tYjuq2Vh+F/Z3vIBz9vTg822a1A0mJtQR17cM6D5HOqU8SOdnnnLBX40Fl3qobVVfKWNrp1wS7ImS+OLd0vZfQNg/IpwqUQxuMixC4miMIloHefJOpDFYO0aGlYI6Q5Gm6Xrxbl2bihe7tMAgmbydrvQGXqh7ub2kTkBizZDkhqKQKwFzfSH1Xkcqd/XHRmvG5KqNfIegG5h1RpWurOomsIjrwC41avIzj2vrXEvENYFH7xejbqmJlqOQjdA1yKFYezX22beLTRHrd1Kui6J1co0LJ+lqtDjBIGA1Vhp3LtSd/HwEIIWAHIPAHsyKTo7QeeUrZqM7jl7CINVATfXfguAW9M0EC8fWWDoZJVEyqI1oTqW0XcVSclv8fhekGVfS6MBQDkJ41Je7ryjddCnfQhAhK0OgLwXV9p6gs17eyZLGoCpA6A/Ge8uBvJZ3vBk1e3Jnib43rOoopxGdZ4rnO9SgmI6aZLUH6+bbDmU5CcTtkLMdSOMvaXX2TmvtA+wb0hcTcN3GtOpbnieD8SEGU6fR5RnzdzW7Xe36ozT1SL+vRPx6+Q+sF+mcdRbkIxOXGnz2yA7Z6PVDXtTJy3m5I+k33aW/vViWzdTGdNtfxOALDXv8m0ZXz4G0mJYp8LWcZDx+syDWB4PyYKRm7dfAuCOa40TYsN9pZRjEtrr0ScbJlDaPKPnDp4ZaGstpbqodISl14ZDM3dtYe33AoD27FT4TAHR0c7FQjIDqKLr3zwAGxmSvDAJLQDzZLtAizvTJF3DHEalEzaQfTJ2U/ZN3/VyX/ZyGlS6+paX3IApQoHtCHs8KjVec2QGlNfB/pxNSE22z8jPxaz1POSLX7YbTi++/p6aTjncfFfyMk2lhGLVXWKRYtTWkimt9zMD4ypRh386Z3U/zzkuCr1amsZ9/x3NkCpmB6EaWBw970YcQgfTzwyuDvvjjY935uK+WUat6eHWQ5PNYApPEc4Vyc+LSn7+Wd/ciX5nxwW+dQeR7nmQTeA5kKsfhsvhS3F/9Vmf2HKK/35/Vw1r+HgauylbIymseq3/cNsvJafnH/eJdbl+w/ETu3Yvvv3MDGW2xWK3u7MSqUxPzusTTnDzDEUX3K731p6vOzy5UKZsxHlM111Dcb8O4U+5Ub8OdfmN61dfZuo+Mi4I8Z7Zpsr63I0HLr9U96117kRLJF/+emX8eynwSAtwzcyV9mD1D31D79vvRQV+ZGmohNL+J//fA8T266Otpb/P3+e3PP8ATAUtrKQcK2cAAAAASUVORK5CYII=';
  function dRow(k, v) {
    return '<div class="d-row"><small>' + esc(k) + '</small><b>' +
      (v == null || v === '' ? '—' : esc(v)) + '</b></div>';
  }

