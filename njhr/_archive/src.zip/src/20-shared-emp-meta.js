  /* ================= SHARED: EMPLOYEE META =================
     ย้ายมาจาก 08-view-employees.js โดยไม่แก้เนื้อใน
     ใช้ร่วมกันโดย employees · attendance-report · compatibility ================= */
  var EMP_STATUS = [['ACTIVE', 'ปฏิบัติงาน'], ['PROBATION', 'ทดลองงาน'], ['SUSPENDED', 'พักงาน'], ['RESIGNED', 'พ้นสภาพ']];

  var EMP_STATUS_MAP = { ACTIVE: 'ปฏิบัติงาน', PROBATION: 'ทดลองงาน', SUSPENDED: 'พักงาน', RESIGNED: 'พ้นสภาพ' };

  var EMP_TYPE_OPTS = ['พนักงานประจำ', 'พนักงานไม่ประจำ', 'พนักงานรายวัน',
                       'พนักงานสัญญาจ้าง', 'พนักงานทดลองงาน'];

  function empNormType(v) {
    var t = String(v == null ? '' : v).replace(/[\s\u00A0\u200B]+/g, '');
    if (!t) return '';
    for (var i = 0; i < EMP_TYPE_OPTS.length; i++) {
      if (EMP_TYPE_OPTS[i].replace(/\s+/g, '') === t) return EMP_TYPE_OPTS[i];
    }
    var u = t.toUpperCase().replace(/[-_.]/g, '');
    var alias = {
      'ประจำ': 'พนักงานประจำ', 'พนง.ประจำ': 'พนักงานประจำ', 'พนงประจำ': 'พนักงานประจำ',
      'FULLTIME': 'พนักงานประจำ', 'PERMANENT': 'พนักงานประจำ', 'MONTHLY': 'พนักงานประจำ',
      'ไม่ประจำ': 'พนักงานไม่ประจำ', 'พนงไม่ประจำ': 'พนักงานไม่ประจำ',
      'PARTTIME': 'พนักงานไม่ประจำ', 'TEMPORARY': 'พนักงานไม่ประจำ', 'TEMP': 'พนักงานไม่ประจำ',
      'รายวัน': 'พนักงานรายวัน', 'DAILY': 'พนักงานรายวัน',
      'สัญญาจ้าง': 'พนักงานสัญญาจ้าง', 'CONTRACT': 'พนักงานสัญญาจ้าง',
      'ทดลองงาน': 'พนักงานทดลองงาน', 'PROBATION': 'พนักงานทดลองงาน'
    };
    return alias[t] || alias[u] || '';
  }

  function ssoBindForm() {
    var on = document.getElementById('sso-f-on');
    var mode = document.getElementById('sso-f-mode');
    var wrap = document.getElementById('sso-f-wrap');
    var baseWrap = document.getElementById('sso-f-basewrap');
    var baseEl = document.getElementById('sso-f-base');
    var hint = document.getElementById('sso-f-hint');
    var eff = document.getElementById('sso-f-eff');
    var note = document.getElementById('sso-f-note');
    if (!on || !mode) return;

    function sync() {
      var enabled = on.checked;
      var manual = mode.value === 'MANUAL';
      if (wrap) wrap.style.opacity = enabled ? '' : '.5';
      mode.disabled = !enabled;
      if (eff) eff.disabled = !enabled;
      if (note) note.disabled = !enabled;
      if (baseWrap) baseWrap.style.display = (enabled && manual) ? '' : 'none';
      if (baseEl) { baseEl.disabled = !(enabled && manual); baseEl.required = (enabled && manual); }
      if (hint) {
        hint.textContent = !enabled
          ? 'พนักงานรายนี้ไม่เข้าประกันสังคม — ฐานและเงินสมทบเป็น 0.00'
          : (manual ? 'ใช้ฐานที่กำหนดเอง แล้วจำกัดด้วยฐานขั้นต่ำ–สูงสุดตามการตั้งค่าระบบ'
                    : 'คำนวณอัตโนมัติจากรายการค่าจ้างที่ตั้งค่าไว้');
      }
    }
    on.onchange = sync; mode.onchange = sync; sync();
  }

  function ssoFormPayload(empId) {
    var on = document.getElementById('sso-f-on');
    var mode = document.getElementById('sso-f-mode');
    var baseEl = document.getElementById('sso-f-base');
    var eff = document.getElementById('sso-f-eff');
    var note = document.getElementById('sso-f-note');
    var enabled = on ? on.checked : true;
    var m = mode ? mode.value : 'AUTO';
    return {
      p_token: sbToken(), p_employee: empId,
      p_enabled: enabled, p_base_mode: m,
      p_custom_base: (m === 'MANUAL' && baseEl && baseEl.value !== '')
        ? Number(Number(baseEl.value).toFixed(2)) : null,
      p_effective_date: (eff && eff.value) ? eff.value : null,
      p_note: (note && note.value.trim()) ? note.value.trim() : null
    };
  }

