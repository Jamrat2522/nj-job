  /* ================= EMPLOYEE FORM / DETAIL / STATUS / FACE =================
     ย้ายมาจาก 30-view-employees.js โดยไม่แก้เนื้อใน
     โหลดเมื่อกด #emp-add · [data-emp-edit] · [data-emp-view] · [data-emp-status] · [data-emp-face] เท่านั้น ================= */
  var empFaceTried = false;

  function empDetail(id) {
    openModal('ข้อมูลพนักงาน', '<div class="muted">กำลังโหลด…</div>',
      '<button class="btn btn-ghost" id="empd-close">ปิด</button>');
    var cb = document.getElementById('empd-close'); if (cb) cb.onclick = closeModal;
    sbRpc('njhr_emp_get', { p_token: sbToken(), p_id: id }).then(function (r) {
      var body = document.querySelector('#modal-root .modal-body');
      if (!body || !r) return;
      var e = r.data || {};
      function row(k, v) { return '<div class="ep-info"><span>' + k + '</span><span>:</span><b>' + esc(v == null || v === '' ? '—' : v) + '</b></div>'; }
      body.innerHTML =
        '<div class="ep-emp"><div class="ep-emp-head">' + icon('users') + ' ข้อมูลส่วนตัว</div><div class="ep-emp-grid">' +
        '<div>' + row('รหัสพนักงาน', e.emp_code) + row('คำนำหน้า', e.prefix) +
        row('ชื่อ-นามสกุล', ((e.first_name || '') + ' ' + (e.last_name || '')).trim()) + row('ชื่อเล่น', e.nickname) +
        row('ชื่อภาษาอังกฤษ', ((e.first_name_en || '') + ' ' + (e.last_name_en || '')).trim()) + '</div>' +
        '<div>' + row('เพศ', e.gender) + row('วันเกิด', e.birth_date ? empBE(e.birth_date) : '') +
        row('เลขบัตรประชาชน', e.national_id) + row('เบอร์โทร', e.phone) + row('อีเมล', e.email) + '</div>' +
        '</div></div>' +
        '<div class="ep-emp"><div class="ep-emp-head">' + icon('building') + ' ข้อมูลการทำงาน</div><div class="ep-emp-grid">' +
        '<div>' + row('แผนก', e.department_name) + row('ตำแหน่ง', e.position_name) + row('ระดับ', e.level) +
        row('หัวหน้างาน', e.supervisor_name) + '</div>' +
        '<div>' + row('วันที่เริ่มงาน', e.start_date ? empBE(e.start_date) : '') +
        row('ประเภทพนักงาน', e.emp_type) + row('สถานะ', EMP_STATUS_MAP[e.status] || e.status) +
        row('วันที่พ้นสภาพ', e.resign_date ? empBE(e.resign_date) : '') + '</div>' +
        '</div></div>' +
        '<div class="ep-emp"><div class="ep-emp-head">' + icon('calendarOff') + ' สิทธิ์การลา / เวลาทำงาน</div><div class="ep-emp-grid">' +
        '<div>' + row('ลาป่วย', e.leave_sick + ' วัน/ปี') + row('ลากิจ', e.leave_personal + ' วัน/ปี') +
        row('ลาพักร้อน', e.leave_vacation + ' วัน/ปี') + '</div>' +
        '<div>' + row('เวลาเข้างาน', e.work_start) + row('เวลาเลิกงาน', e.work_end) +
        row('ที่อยู่', e.address) + '</div></div></div>' +
        (e.can_salary
          ? '<div class="ep-emp"><div class="ep-emp-head">' + icon('wallet') + ' เงินเดือนและบัญชีธนาคาร</div><div class="ep-emp-grid">' +
            '<div>' + row('เงินเดือนพื้นฐาน', money(e.base_salary || 0)) + row('ค่าตำแหน่ง', money(e.position_allow || 0)) +
            row('ค่าน้ำมัน', money(e.fuel_allow || 0)) + row('ค่าโทรศัพท์', money(e.phone_allow || 0)) +
            row('เบี้ยขยัน', money(e.diligence_allow || 0)) + '</div>' +
            '<div>' + row('ธนาคาร', e.bank_name) + row('สาขา', e.bank_branch) +
            row('เลขที่บัญชี', e.bank_account) + row('ชื่อบัญชี', e.bank_account_name) + '</div></div></div>'
          : '<p class="muted note">ข้อมูลเงินเดือนและบัญชีธนาคารแสดงเฉพาะผู้มีสิทธิ์</p>');
    }).catch(function (er) {
      var body = document.querySelector('#modal-root .modal-body');
      if (body) body.innerHTML = '<div class="form-error">' + esc(er.message || 'โหลดข้อมูลไม่สำเร็จ') + '</div>';
    });
  }

  function empForm(id, listEl) {
    if (!empCanEdit()) { toast('คุณไม่มีสิทธิ์แก้ไขข้อมูลพนักงาน', 'error'); return; }
    var canSalary = ['SUPER_ADMIN', 'HR'].indexOf(currentUser().role) >= 0;
    function build(e) {
      e = e || {};
      function fld(name, label, type, req, val, extra) {
        return '<label class="field"><span>' + label + (req ? ' <i class="req">*</i>' : '') + '</span>' +
          '<input type="' + (type || 'text') + '" name="' + name + '" value="' + esc(val == null ? '' : val) + '"' + (extra || '') + '></label>';
      }
      openModal(id ? 'แก้ไขข้อมูลพนักงาน' : 'เพิ่มพนักงาน',
        '<form id="emp-f" novalidate>' +
        '<div class="emp-sec">ข้อมูลส่วนตัว</div>' +
        '<div class="form-2col">' + fld('emp_code', 'รหัสพนักงาน', 'text', true, e.emp_code) +
        fld('prefix', 'คำนำหน้า', 'text', false, e.prefix) + '</div>' +
        '<div class="form-2col">' + fld('first_name', 'ชื่อ (ภาษาไทย)', 'text', true, e.first_name) +
        fld('last_name', 'นามสกุล (ภาษาไทย)', 'text', true, e.last_name) + '</div>' +
        /* ชื่อภาษาอังกฤษเก็บแยกคนละคอลัมน์กับภาษาไทย (employees.first_name_en / last_name_en)
           ไม่บังคับกรอก · ไม่แปลงตัวพิมพ์ให้อัตโนมัติ · ตัดช่องว่างหัวท้ายอย่างเดียว */
        '<div class="form-2col">' + fld('first_name_en', 'First Name (ภาษาอังกฤษ)', 'text', false, e.first_name_en) +
        fld('last_name_en', 'Last Name (ภาษาอังกฤษ)', 'text', false, e.last_name_en) + '</div>' +
        '<div class="form-2col">' + fld('nickname', 'ชื่อเล่น', 'text', false, e.nickname) +
        fld('birth_date', 'วันเกิด', 'date', false, e.birth_date) + '</div>' +
        '<div class="form-2col">' + fld('national_id', 'เลขบัตรประชาชน (13 หลัก)', 'text', false, e.national_id, ' maxlength="13" inputmode="numeric"') +
        fld('phone', 'เบอร์โทร', 'tel', false, e.phone) + '</div>' +
        fld('email', 'อีเมล', 'email', false, e.email) +
        fld('address', 'ที่อยู่', 'text', false, e.address) +
        '<div class="emp-sec">ข้อมูลการทำงาน</div>' +
        '<div class="form-2col">' +
        '<label class="field"><span>แผนก</span><select name="department_id"><option value="">— ไม่ระบุ —</option>' +
        empDepts.map(function (d) {
          // ข้อมูลที่นำเข้ามาอาจมีแต่ชื่อแผนก (department_name) แต่ยังไม่มีรหัส (department_id)
          // จึงเลือกให้ตรงเมื่อ id ตรง หรือชื่อแผนกตรง
          var on = (e.department_id && e.department_id === d.id) ||
                   (!e.department_id && e.department_name && e.department_name === d.name);
          return '<option value="' + esc(d.id) + '"' + (on ? ' selected' : '') + '>' + esc(d.name) + '</option>';
        }).join('') +
        '</select>' +
        (e.department_name && !empDepts.some(function (d) { return d.name === e.department_name; })
          ? '<small class="t-red">แผนกเดิม "' + esc(e.department_name) + '" ไม่มีในระบบแล้ว — กรุณาเลือกใหม่</small>' : '') +
        '</label>' + fld('position_name', 'ตำแหน่ง', 'text', false, e.position_name) + '</div>' +
        '<div class="form-2col">' + fld('start_date', 'วันที่เริ่มงาน', 'date', true, e.start_date) +
        '<label class="field"><span>ประเภทพนักงาน</span><select name="emp_type">' +
        // ค่าที่นำเข้ามาอาจไม่อยู่ในรายการมาตรฐาน (เช่น "พนักงานไม่ประจำ")
        // ต้องใส่ค่าปัจจุบันเข้าไปด้วย ไม่งั้นเปิดฟอร์มแล้วบันทึกจะทำให้ค่าเดิมหาย
        (function () {
          var opts = [''].concat(EMP_TYPE_OPTS);
          if (e.emp_type && opts.indexOf(e.emp_type) < 0) opts.push(e.emp_type);
          return opts.map(function (t) {
            return '<option value="' + esc(t) + '"' + (e.emp_type === t ? ' selected' : '') + '>' +
              (t || '— ไม่ระบุ —') + '</option>';
          }).join('');
        })() + '</select></label></div>' +
        '<div class="form-2col">' + fld('work_start', 'เวลาเข้างาน', 'time', false, String(e.work_start || '08:30').slice(0, 5)) +
        fld('work_end', 'เวลาเลิกงาน', 'time', false, String(e.work_end || '17:30').slice(0, 5)) + '</div>' +
        '<div class="emp-sec">สิทธิ์การลาต่อปี</div><div class="form-2col">' +
        fld('leave_sick', 'ลาป่วย (วัน)', 'number', false, e.leave_sick == null ? 30 : e.leave_sick, ' min="0"') +
        fld('leave_personal', 'ลากิจ (วัน)', 'number', false, e.leave_personal == null ? 10 : e.leave_personal, ' min="0"') + '</div>' +
        fld('leave_vacation', 'ลาพักร้อน (วัน)', 'number', false, e.leave_vacation == null ? 6 : e.leave_vacation, ' min="0"') +
        (canSalary
          ? '<div class="emp-sec">เงินเดือนและบัญชีธนาคาร</div><div class="form-2col">' +
            fld('base_salary', 'เงินเดือนพื้นฐาน', 'number', false, e.base_salary == null ? 0 : e.base_salary, ' min="0" step="0.01"') +
            fld('position_allow', 'ค่าตำแหน่ง', 'number', false, e.position_allow == null ? 0 : e.position_allow, ' min="0" step="0.01"') + '</div>' +
            '<div class="form-2col">' +
            fld('fuel_allow', 'ค่าน้ำมัน', 'number', false, e.fuel_allow == null ? 0 : e.fuel_allow, ' min="0" step="0.01"') +
            fld('phone_allow', 'ค่าโทรศัพท์', 'number', false, e.phone_allow == null ? 0 : e.phone_allow, ' min="0" step="0.01"') + '</div>' +
            // ---- ประกันสังคม (คอลัมน์จาก 98_sso_base.sql · บันทึกผ่าน njhr_sso_emp_save)
            '<div class="emp-sec">ประกันสังคม</div>' +
            '<label class="check"><input type="checkbox" name="sso_enabled" id="sso-f-on"' +
            (e.social_security_enabled === false ? '' : ' checked') + '>' +
            '<span>เข้าประกันสังคม</span></label>' +
            '<div class="form-2col" id="sso-f-wrap">' +
            '<label class="field"><span>วิธีคำนวณ</span><select name="sso_mode" id="sso-f-mode">' +
            '<option value="AUTO"' + (e.social_security_base_mode === 'MANUAL' ? '' : ' selected') + '>AUTO — คำนวณอัตโนมัติ</option>' +
            '<option value="MANUAL"' + (e.social_security_base_mode === 'MANUAL' ? ' selected' : '') + '>MANUAL — กำหนดฐานเอง</option>' +
            '</select></label>' +
            '<label class="field" id="sso-f-basewrap"><span>ฐานค่าจ้างที่กำหนดเอง (บาท)</span>' +
            '<input type="number" name="sso_base" id="sso-f-base" min="0" step="0.01" value="' +
            (e.social_security_custom_base == null ? '' : esc(String(e.social_security_custom_base))) + '"></label></div>' +
            '<p class="muted note" id="sso-f-hint"></p>' +
            '<div class="form-2col">' +
            '<label class="field"><span>วันที่เริ่มใช้</span>' +
            '<input type="date" name="sso_eff" id="sso-f-eff" value="' +
            esc(String(e.social_security_effective_date || '').slice(0, 10)) + '"></label>' +
            '<label class="field"><span>หมายเหตุ</span>' +
            '<input name="sso_note" id="sso-f-note" value="' + esc(e.social_security_note || '') + '"></label></div>' +
            '<div class="form-2col">' + fld('bank_name', 'ธนาคาร', 'text', false, e.bank_name) +
            fld('bank_account', 'เลขที่บัญชี', 'text', false, e.bank_account) + '</div>'
          : '<p class="muted note">ข้อมูลเงินเดือนแก้ไขได้เฉพาะผู้มีสิทธิ์</p>') +
        '<div class="form-error" id="emp-ferr" role="alert"></div></form>',
        '<button class="btn btn-ghost" id="empf-cancel">ยกเลิก</button><button class="btn btn-primary" id="empf-save">บันทึก</button>',
        { wide: true });

      document.getElementById('empf-cancel').onclick = closeModal;
      if (canSalary) ssoBindForm();
      document.getElementById('empf-save').onclick = function () {
        var btn = this, fm = document.getElementById('emp-f'), ferr = document.getElementById('emp-ferr');
        function fv(n) { var x = fm.querySelector('[name="' + n + '"]'); return x ? String(x.value).trim() : ''; }
        ferr.textContent = '';
        if (!fv('emp_code')) { ferr.textContent = 'กรุณาระบุรหัสพนักงาน'; return; }
        if (!fv('first_name')) { ferr.textContent = 'กรุณาระบุชื่อ'; return; }
        if (!fv('last_name')) { ferr.textContent = 'กรุณาระบุนามสกุล'; return; }
        if (!fv('start_date')) { ferr.textContent = 'กรุณาระบุวันที่เริ่มงาน'; return; }
        if (fv('national_id') && !/^[0-9]{13}$/.test(fv('national_id'))) {
          ferr.textContent = 'เลขบัตรประชาชนต้องเป็นตัวเลข 13 หลัก'; return;
        }
        if (fv('email') && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(fv('email'))) {
          ferr.textContent = 'รูปแบบอีเมลไม่ถูกต้อง'; return;
        }
        if (btn.disabled) return;
        btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> กำลังบันทึก…';
        var data = {};
        ['emp_code', 'prefix', 'first_name', 'last_name', 'first_name_en', 'last_name_en',
         'nickname', 'birth_date', 'national_id',
         'phone', 'email', 'address', 'department_id', 'position_name', 'start_date', 'emp_type',
         'work_start', 'work_end', 'leave_sick', 'leave_personal', 'leave_vacation']
          .forEach(function (k) { data[k] = fv(k); });
        if (canSalary) ['base_salary', 'position_allow', 'fuel_allow', 'phone_allow', 'bank_name', 'bank_account']
          .forEach(function (k) { data[k] = fv(k); });
        // ตรวจฐานที่กำหนดเองก่อนยิง RPC
        if (canSalary) {
          var mEl = document.getElementById('sso-f-mode');
          var bEl = document.getElementById('sso-f-base');
          if (mEl && mEl.value === 'MANUAL') {
            var bv = Number(bEl && bEl.value);
            if (!isFinite(bv) || bv < 0) {
              btn.disabled = false; btn.innerHTML = 'บันทึก';
              ferr.textContent = 'โหมด MANUAL ต้องระบุฐานค่าจ้างตั้งแต่ 0.00 ขึ้นไป'; return;
            }
          }
        }
        sbRpc('njhr_emp_save', { p_token: sbToken(), p_id: id || null, p_data: data })
          .then(function (r) {
            // สร้าง/แก้ไขพนักงานสำเร็จแล้วจึงบันทึกประกันสังคมด้วย employee_id เดียวกัน
            if (!canSalary) return r;
            return sbRpc('njhr_sso_emp_save', ssoFormPayload(r.id || id))
              .then(function () { return r; });
          })
          .then(function (r) {
            closeModal();
            toast((id ? 'บันทึกข้อมูลพนักงานแล้ว: ' : 'เพิ่มพนักงานแล้ว: ') + r.emp_code + ' ' + r.full_name);
            NJHR.features.employees.refresh(listEl);
          }).catch(function (er) {
            btn.disabled = false; btn.innerHTML = 'บันทึก';
            ferr.textContent = (er && er.message) || 'บันทึกไม่สำเร็จ';
          });
      };
    }
    /* ---------- ต้องมีรายชื่อแผนกจริงก่อนสร้างฟอร์มเสมอ ----------
       empDepts เป็น Array ตัวเดียวกับที่หน้ารายชื่อพนักงานใช้ (chunk นี้รับมาตอนโหลด)
       มีข้อมูลอยู่แล้ว = ใช้ค่าเดิม ไม่ยิง RPC ซ้ำ
       ยังว่าง (กดปุ่มก่อนหน้ารายชื่อโหลดแผนกเสร็จ หรือรอบก่อนโหลดไม่สำเร็จ)
       = ยิง njhr_emp_departments ให้สำเร็จก่อน แล้วเติมลง Array ตัวเดิมให้ทุกที่เห็นตรงกัน
       โหลดไม่สำเร็จ = ไม่เปิดฟอร์ม กันบันทึก department_id ผิดเพราะ Dropdown ว่าง */
    function empDeptsReady() {
      if (empDepts.length) return Promise.resolve();
      return sbRpcList('njhr_emp_departments', { p_token: sbToken() }).then(function (ds) {
        empDepts.length = 0;
        Array.prototype.push.apply(empDepts, ds || []);
      }).catch(function (er) {
        try { console.error('[EMPLOYEE] njhr_emp_departments ล้มเหลว:', er); } catch (e2) {}
        throw new Error('โหลดรายชื่อแผนกไม่สำเร็จ กรุณาลองใหม่');
      });
    }
    if (!id) {
      empDeptsReady()
        .then(function () { build(null); })
        .catch(function (er) { toast(er.message || 'โหลดข้อมูลไม่สำเร็จ', 'error'); });
      return;
    }
    // แก้ไข = โหลดข้อมูลพนักงานและรายชื่อแผนกพร้อมกัน ครบทั้งคู่จึงสร้างฟอร์ม
    Promise.all([sbRpc('njhr_emp_get', { p_token: sbToken(), p_id: id }), empDeptsReady()])
      .then(function (rs) { build((rs[0] && rs[0].data) || {}); })
      .catch(function (er) { toast(er.message || 'โหลดข้อมูลไม่สำเร็จ', 'error'); });
  }

  /* ================= ลบพนักงาน (เปลี่ยนสถานะเป็น "พ้นสภาพ") =================
     ตรวจ Source แล้วระบบ "ไม่มี" RPC ลบพนักงาน และ employees มี Foreign Key
     ชี้เข้ามา 35 จุด (CASCADE 24 จุด) — การลบจริงจะทำให้เงินเดือน กะทำงาน
     พื้นที่ลงเวลา และเอกสาร HR ที่ลงนามแล้วหายตามไปด้วย
     จึงใช้ RPC เดิม njhr_emp_status เปลี่ยนสถานะเป็น RESIGNED แทน
     ข้อมูลทั้งหมดยังอยู่ครบ · บัญชีผู้ใช้ไม่กำพร้า · ย้อนกลับได้
     ไม่สร้าง SQL / RPC / DELETE CASCADE ใด ๆ ขึ้นใหม่ ================= */
  function empRemoveForm(id, listEl) {
    if (currentUser().role !== 'SUPER_ADMIN') { toast('เฉพาะ SUPER_ADMIN เท่านั้นที่ใช้คำสั่งลบพนักงานได้', 'error'); return; }
    var cached = empRows.find(function (x) { return x.id === id; });
    if (cached) { empRemoveBuild(id, listEl, cached); return; }
    sbRpc('njhr_emp_get', { p_token: sbToken(), p_id: id }).then(function (r) {
      var d = (r && r.data) || {};
      return {
        id: d.id, emp_code: d.emp_code, status: d.status,
        full_name: ((d.first_name || '') + ' ' + (d.last_name || '')).trim()
      };
    }, function (er) { toast(er.message || 'โหลดข้อมูลไม่สำเร็จ', 'error'); })
      .then(function (row) { if (row) empRemoveBuild(id, listEl, row); });
  }

  function empRemoveBuild(id, listEl, e) {
    e = e || {};
    openModal('ยืนยันการลบพนักงาน',
      '<p class="confirm-msg">ต้องการลบพนักงาน <b>' + esc(e.full_name || '') + '</b> ' +
      'รหัส <b>' + esc(e.emp_code || '') + '</b> หรือไม่?</p>' +
      '<label class="field"><span>วันที่พ้นสภาพ <i class="req">*</i></span>' +
      '<input type="date" id="empdel-date" value="' + esc(todayISO()) + '"></label>' +
      '<label class="field"><span>หมายเหตุ</span>' +
      '<input type="text" id="empdel-note" placeholder="เหตุผล (ถ้ามี)"></label>' +
      '<div class="ot-warn">พนักงานจะถูกย้ายออกจากรายชื่อที่ปฏิบัติงาน ' +
      'ประวัติการลงเวลา เงินเดือน การลา และเอกสารทั้งหมดยังคงอยู่ครบ ' +
      'และเปลี่ยนสถานะกลับได้ภายหลัง</div>' +
      '<div class="form-error" id="empdel-err" role="alert"></div>',
      '<button class="btn btn-ghost" id="empdel-cancel">ยกเลิก</button>' +
      '<button class="btn btn-danger" id="empdel-ok">' + icon('trash') + ' ลบพนักงาน</button>');

    var busy = false;
    var ok = document.getElementById('empdel-ok');
    var cancel = document.getElementById('empdel-cancel');
    var err = document.getElementById('empdel-err');
    cancel.onclick = function () { if (!busy) closeModal(); };

    ok.onclick = function () {
      if (busy) return;                                   // กันกดซ้ำ
      var dt = String(document.getElementById('empdel-date').value || '').trim();
      if (!dt) { err.textContent = 'กรุณาระบุวันที่พ้นสภาพ'; return; }
      busy = true; ok.disabled = true; cancel.disabled = true;
      ok.innerHTML = '<span class="spinner"></span> กำลังลบ…';
      err.textContent = '';
      sbRpc('njhr_emp_status', {
        p_token: sbToken(), p_id: id, p_status: 'RESIGNED',
        p_resign_date: dt,
        p_note: String(document.getElementById('empdel-note').value || '').trim() || null
      }).then(function () {
        closeModal();
        toast('ลบพนักงานเรียบร้อยแล้ว');
        // โหลดรายการใหม่จาก Server เสมอ — จำนวนคนด้านบนอัปเดตตาม
        if (listEl && NJHR.features.employees) NJHR.features.employees.refresh(listEl);
      }, function (ex) {
        // ล้มเหลว = ข้อมูลบนหน้าจอไม่หาย และกดลองใหม่ได้ทันที
        busy = false; ok.disabled = false; cancel.disabled = false;
        ok.innerHTML = icon('trash') + ' ลบพนักงาน';
        err.textContent = (ex && ex.message) || 'ลบพนักงานไม่สำเร็จ';
      });
    };
  }

  /* ---------- ต้องมีข้อมูลพนักงานคนนี้ก่อนเปิด Modal เสมอ ----------
     empRows เป็น Array ตัวเดียวกับหน้ารายชื่อ (chunk นี้รับมาตอนโหลด chunk ครั้งเดียว)
     เจอในรายการแล้ว = ใช้ค่าเดิม ไม่ยิง RPC ซ้ำ
     ไม่เจอ (รายการยังโหลดไม่เสร็จ / เปลี่ยนหน้าไปแล้ว) = ยิง njhr_emp_get ตัวเดิมก่อน
     full_name ประกอบด้วยสูตรเดียวกับ njhr_emp_list คือ first_name + ' ' + last_name */
  function empStatusForm(id, listEl) {
    var cached = empRows.find(function (x) { return x.id === id; });
    if (cached) { empStatusBuild(id, listEl, cached); return; }
    sbRpc('njhr_emp_get', { p_token: sbToken(), p_id: id }).then(function (r) {
      var d = (r && r.data) || {};
      return {
        id: d.id, emp_code: d.emp_code, status: d.status, resign_date: d.resign_date,
        full_name: ((d.first_name || '') + ' ' + (d.last_name || '')).trim()
      };
    }, function (er) { toast(er.message || 'โหลดข้อมูลไม่สำเร็จ', 'error'); })
      .then(function (row) { if (row) empStatusBuild(id, listEl, row); });
  }

  function empStatusBuild(id, listEl, e) {
    e = e || {};
    openModal('เปลี่ยนสถานะพนักงาน',
      '<p class="confirm-msg">' + esc(e.emp_code || '') + ' — <b>' + esc(e.full_name || '') + '</b></p>' +
      '<label class="field"><span>สถานะใหม่ <i class="req">*</i></span><select id="empst-status">' +
      EMP_STATUS.map(function (x) { return '<option value="' + x[0] + '"' + (e.status === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') +
      '</select></label>' +
      '<label class="field" id="empst-rwrap" style="display:none"><span>วันที่พ้นสภาพ <i class="req">*</i></span>' +
      '<input type="date" id="empst-resign" value="' + esc(e.resign_date || todayISO()) + '"></label>' +
      '<label class="field"><span>หมายเหตุ</span><input id="empst-note" placeholder="ไม่บังคับ"></label>' +
      '<p class="muted note">ระบบจะไม่ลบข้อมูลพนักงาน แต่จะเปลี่ยนสถานะและเก็บประวัติไว้</p>' +
      '<div class="form-error" id="empst-err" role="alert"></div>',
      '<button class="btn btn-ghost" id="empst-cancel">ยกเลิก</button><button class="btn btn-primary" id="empst-ok">บันทึก</button>');
    function sync() {
      document.getElementById('empst-rwrap').style.display =
        document.getElementById('empst-status').value === 'RESIGNED' ? '' : 'none';
    }
    document.getElementById('empst-status').onchange = sync; sync();
    document.getElementById('empst-cancel').onclick = closeModal;
    document.getElementById('empst-ok').onclick = function () {
      var btn = this, st = document.getElementById('empst-status').value;
      var err = document.getElementById('empst-err');
      err.textContent = '';
      if (btn.disabled) return;
      btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> กำลังบันทึก…';
      sbRpc('njhr_emp_status', {
        p_token: sbToken(), p_id: id, p_status: st,
        p_resign_date: st === 'RESIGNED' ? document.getElementById('empst-resign').value : null,
        p_note: document.getElementById('empst-note').value.trim() || null
      }).then(function () {
        closeModal(); toast('เปลี่ยนสถานะพนักงานแล้ว', 'info'); NJHR.features.employees.refresh(listEl);
      }).catch(function (er) {
        btn.disabled = false; btn.innerHTML = 'บันทึก';
        err.textContent = er.message || 'บันทึกไม่สำเร็จ';
      });
    };
  }

  function empFaceOpen(empId) {
    if (!empCanDocs()) { toast('คุณไม่มีสิทธิ์จัดการข้อมูลใบหน้าพนักงาน', 'error'); return; }
    sbRpcList('njhr_face_status', { p_token: sbToken(), p_employee: empId, p_q: null })
      .then(function (rows) {
        var f = (rows && rows[0]) || {};
        openModal('ลงทะเบียนใบหน้า',
          '<div class="doc-empinfo"><b>' + esc(f.emp_code || '') + ' · ' + esc(f.full_name || '') + '</b>' +
          '<small>' + esc(f.department_name || '—') + '</small></div>' +
          '<div class="bal-grid" style="margin-top:10px">' +
          '<div class="bal-item"><div class="bal-top"><span>สถานะ</span><b>' +
          (f.enrolled ? '<span class="badge badge-ok">ลงทะเบียนแล้ว</span>'
                      : '<span class="badge badge-warn">ยังไม่ได้ลงทะเบียน</span>') + '</b></div></div>' +
          (f.enrolled
            ? '<div class="bal-item"><div class="bal-top"><span>จำนวนมุมที่เก็บ</span><b>' +
              (f.sample_count || 0) + '</b></div></div>' +
              '<div class="bal-item"><div class="bal-top"><span>ลงทะเบียนเมื่อ</span><b>' +
              empBE(String(f.enrolled_at || '').slice(0, 10)) + '</b></div></div>'
            : '') + '</div>' +
          '<p class="muted note">ระบบจะเก็บใบหน้า 3 มุม (หน้าตรง · หันซ้าย · หันขวา) ' +
          'พร้อมตรวจแสง ความชัด และตรวจว่าเป็นบุคคลจริง</p>' +
          '<div class="form-error" id="ef-face-err" role="alert"></div>',
          '<button class="btn btn-ghost" id="efc-close">ปิด</button>' +
          (f.enrolled && currentUser().role === 'SUPER_ADMIN'
            ? '<button class="btn btn-danger" id="efc-del">ลบข้อมูลใบหน้า</button>' : '') +
          '<button class="btn btn-primary" id="efc-go">' +
          (f.enrolled ? 'ลงทะเบียนใหม่' : 'เริ่มลงทะเบียน') + '</button>');

        document.getElementById('efc-close').onclick = closeModal;
        document.getElementById('efc-go').onclick = function () {
          var run = function () {
            closeModal();
            window.NJHRFace.enroll(empId, function () { toast('ลงทะเบียนใบหน้าเรียบร้อยแล้ว'); });
          };
          if (window.NJHRFace) return run();
          if (empFaceTried) {
            document.getElementById('ef-face-err').textContent = 'โหลดโมดูลสแกนใบหน้าไม่สำเร็จ';
            return;
          }
          empFaceTried = true;
          this.innerHTML = '<span class="spinner"></span> กำลังเตรียมกล้อง…';
          // ตัวโหลดกลาง: Promise cache · timeout · ลองใหม่ได้เมื่อพลาด
          loadScriptOnce('face', njAsset('face.js'), 'NJHRFace')
            .then(run)
            ['catch'](function () {
              empFaceTried = false;            // ให้กดใหม่แล้วลองโหลดอีกครั้ง
              var e2 = document.getElementById('ef-face-err');
              if (e2) e2.textContent = 'โหลด face.js ไม่สำเร็จ';
            });
        };
        var db = document.getElementById('efc-del');
        if (db) db.onclick = function () {
          var why = prompt('ระบุเหตุผลการลบข้อมูลใบหน้า');
          if (!why || !why.trim()) return;
          var self = this;
          withButtonLoading(self, 'กำลังลบ…', function () {
            return sbRpc('njhr_face_delete', { p_token: sbToken(), p_employee: empId, p_reason: why.trim() })
              .then(function () { closeModal(); toast('ลบข้อมูลใบหน้าแล้ว', 'info'); });
          }).catch(function (ex) {
            var eel = document.getElementById('ef-face-err');
            if (eel) eel.textContent = ex.message || 'ลบไม่สำเร็จ';
          });
        };
      }).catch(function (ex) { toast(ex.message || 'โหลดสถานะใบหน้าไม่สำเร็จ', 'error'); });
  }

  /* Public Feature Contract ของ Employee Form — List เรียกผ่านตัวนี้เท่านั้น */
  NJHR.features.employeesForm = {
    open: empForm, detail: empDetail, status: empStatusForm, face: empFaceOpen,
    remove: empRemoveForm
  };
