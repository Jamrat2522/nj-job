  /* ================= ATTENDANCE REPORT (#/reports "รายงานการลงเวลา") =================
     ย้ายมาจาก 12-view-reports-settings.js โดยไม่แก้เนื้อใน ================= */
  var RPT_PREFIX = ['นางสาว', 'นาย', 'นาง', 'ดร.', 'ด.ช.', 'ด.ญ.'];   // เรียงยาว→สั้น กันตัดผิด

  function rptName(e) {
    var title = String(e.title || '').trim();
    var first = String(e.firstName || '').trim();
    var last = String(e.lastName || '').trim();
    if (!title) {
      for (var i = 0; i < RPT_PREFIX.length; i++) {
        if (first.indexOf(RPT_PREFIX[i]) === 0) { title = RPT_PREFIX[i]; first = first.slice(RPT_PREFIX[i].length).trim(); break; }
      }
    }
    return { title: title, name: (first + ' ' + last).trim() };
  }

  function rptVisibleEmployees() { return db.employees.slice(); }

  var rptDeptCache = [];

  function rptDepts() { return rptDeptCache; }

  function rptLoadDepts(el) {
    if (!sbReady() || !sbToken()) return;
    sbRpcList('njhr_emp_departments', { p_token: sbToken() }).then(function (ds) {
      var next = (ds || []).map(function (d) { return { id: d.name, name: d.name, employees: d.employees }; });
      var changed = next.length !== rptDeptCache.length ||
        next.some(function (d, i) { return !rptDeptCache[i] || rptDeptCache[i].name !== d.name; });
      rptDeptCache = next;
      // แผนกที่เลือกไว้หายไปแล้ว = ล้างตัวกรอง
      if (rptState.deptId && !next.some(function (d) { return d.name === rptState.deptId; })) rptState.deptId = '';
      if (changed && el) viewReports(el);
    }).catch(function (er) { console.error('[REPORT] njhr_emp_departments ล้มเหลว:', er); });
  }

  function rptMatch(e, q) {
    if (!q) return true;
    var n = rptName(e);
    var hay = rptNorm([e.code, e.title, e.firstName, e.lastName, n.name, (e.title || '') + (e.firstName || ''),
      (e.title || '') + n.name, e.nickname, dept(e.deptId)].join(' '));
    return rptNorm(q).split(' ').every(function (w) { return hay.indexOf(w) >= 0; });
  }

  function rptEmployees() {
    var s = rptState;
    return rptVisibleEmployees().filter(function (e) {
      if (s.deptId && e.deptId !== s.deptId) return false;
      if (s.empId) return e.id === s.empId;          // เลือกจากรายการ = ยึด Employee ID เท่านั้น
      return rptMatch(e, s.q);
    });
  }

  function rptMinOf(t) { var p = String(t || '').split(':'); return p.length >= 2 ? (+p[0]) * 60 + (+p[1]) : null; }

  function rptLateMin(a, e) {
    var sh = shOfAtt(e, a);
    var lim = rptMinOf(sh.start), cur = rptMinOf(a.in);
    if (lim === null || cur === null) return 0;
    lim += (db.settings.lateGrace || 0);
    return cur > lim ? cur - lim : 0;
  }

  function rptWorkMin(a) {
    var i = rptMinOf(a.in), o = rptMinOf(a.out);
    if (i === null || o === null) return null;
    var m = o - i;
    if (m < 0) m += 24 * 60;
    return m;
  }

  function rptHM(min) {
    if (min === null || !isFinite(min) || min < 0) return { h: '', m: '' };
    return { h: Math.floor(min / 60), m: min % 60 };
  }

  function rptRows() {
    var s = rptState;
    if (!s.from || !s.to || s.from > s.to) return [];
    var emps = rptEmployees();
    var byId = {};
    emps.forEach(function (e) { byId[e.id] = e; });

    var merged = {};
    db.attendance.forEach(function (a) {
      if (!byId[a.empId]) return;                       // กรองด้วย Employee ID จริงเท่านั้น
      if (a.date < s.from || a.date > s.to) return;     // รวมวันเริ่มและวันสิ้นสุด
      var k = a.empId + '|' + a.date;
      var cur = merged[k];
      if (!cur) { merged[k] = { empId: a.empId, date: a.date, in: a.in || null, out: a.out || null, shiftId: a.shiftId, status: a.status }; return; }
      if (a.in && (!cur.in || a.in < cur.in)) cur.in = a.in;    // เข้าแรกสุด
      if (a.out && (!cur.out || a.out > cur.out)) cur.out = a.out; // ออกล่าสุด
      if (!cur.shiftId && a.shiftId) cur.shiftId = a.shiftId;
    });

    var rows = Object.keys(merged).map(function (k) {
      var a = merged[k], e = byId[a.empId], n = rptName(e);
      var lateMin = a.in ? rptLateMin(a, e) : 0;
      var st;
      if (!a.in && !a.out) st = 'ขาดงาน';
      else if (!a.in) st = 'ไม่มีเวลาเข้า';
      else if (!a.out) st = 'ไม่มีเวลาออก';
      else st = lateMin > 0 ? 'มาสาย' : 'ปกติ';
      if (a.in && a.out && lateMin > 0) st = 'มาสาย';
      var work = rptHM(rptWorkMin(a)), late = rptHM(lateMin);
      return {
        empId: e.id, code: e.code || '', date: a.date, title: n.title, name: n.name,
        in: a.in || '—', out: a.out || '—', status: st, lateMin: lateMin,
        wh: work.h, wm: work.m, lh: late.h, lm: late.m
      };
    });

    if (s.type === 'late') rows = rows.filter(function (r) { return r.lateMin > 0; });
    // ใหม่→เก่า ภายในวันเดียวกันเรียงตามรหัสพนักงาน (ลำดับคงที่ทุกครั้งที่ Export)
    rows.sort(function (a, b) {
      return b.date.localeCompare(a.date) || String(a.code).localeCompare(String(b.code), 'th', { numeric: true });
    });
    return rows;
  }

  var rptLeaveRows = [], rptBalRows = [], rptBalTypes = [];

  function rptFetchLeave() {
    var s = rptState;
    return sbRpcList('njhr_leave_report', {
      p_token: sbToken(), p_from: s.from, p_to: s.to,
      p_dept: s.deptId || null,                      // s.deptId เก็บชื่อแผนกจริง (employees.department_name)
      p_q: s.q || null, p_type: s.leaveType || null, p_status: s.status || null
    });
  }

  function rptFetchBalance() {
    var s = rptState;
    return sbRpcList('njhr_leave_balance_report', {
      p_token: sbToken(), p_year: s.year,
      p_dept: s.deptId || null,
      p_q: s.q || null, p_emp_status: s.empStatus || ''
    });
  }

  var RPT_LEAVE_HEAD = ['ลำดับ', 'เลขที่คำขอ', 'รหัสพนักงาน', 'คำนำหน้า', 'ชื่อ-นามสกุล', 'ชื่อเล่น', 'แผนก',
    'ประเภทการลา', 'วันที่เริ่มลา', 'วันที่สิ้นสุด', 'ช่วงเวลา', 'จำนวนวัน', 'จำนวนชั่วโมง', 'เหตุผลการลา',
    'เอกสารแนบ', 'วันที่ยื่นคำขอ', 'สถานะ', 'ผู้อนุมัติ', 'วันที่อนุมัติ', 'หมายเหตุ'];

  function rptLeaveCells(r, i) {
    return [i + 1, lvCode(r.req_id), r.emp_code, r.prefix, r.full_name, r.nickname, r.department,
      lvType(r.leave_type).name, rptDateBE(r.start_date), rptDateBE(r.end_date), r.mode_txt,
      lvNum(r.total_days), lvNum(r.hours), r.reason,
      r.file_count ? (r.file_names + ' (' + r.file_count + ')') : '—',
      String(r.created_at || '').replace('T', ' ').slice(0, 16),
      LV_STATUS_TH[r.status] || r.status, r.approver || '—',
      r.approved_at ? String(r.approved_at).replace('T', ' ').slice(0, 16) : '—', r.note || ''];
  }

  function rptBalPivot(rows) {
    var byEmp = {}, order = [], typeSeen = {};
    rows.forEach(function (r) {
      if (!byEmp[r.employee_id]) { byEmp[r.employee_id] = { e: r, t: {} }; order.push(r.employee_id); }
      byEmp[r.employee_id].t[r.leave_type] = r;
      typeSeen[r.leave_type] = 1;      // แสดงทุกประเภทที่ระบบส่งมา (รองรับประเภทใหม่อัตโนมัติ)
    });
    var known = LEAVE_TYPES.map(function (t) { return t.code; }).filter(function (c) { return typeSeen[c]; });
    // ประเภทที่ไม่รู้จักใน LEAVE_TYPES (เพิ่มใหม่ในฐานข้อมูล) ให้ต่อท้ายอัตโนมัติ
    var extra = Object.keys(typeSeen).filter(function (c) { return known.indexOf(c) < 0; });
    var types = known.concat(extra);
    return { emps: order.map(function (id) { return byEmp[id]; }), types: types };
  }

  /* [106] Hard Quota มีเฉพาะ VACATION — ประเภทอื่นห้ามแสดง "สิทธิ์ต่อปี/ยกมา/คงเหลือ"
     เพราะไม่ได้ถูกบังคับจริง การแสดงจะทำให้เข้าใจผิดว่ามีโควตาจำกัด
     ข้อมูล used/pending ยังแสดงครบทุกประเภท ไม่ลบอะไรทิ้ง */
  function rptBalHasQuota(code) { return String(code || '').toUpperCase() === 'VACATION'; }

  function rptBalHead(types) {
    var h = ['ลำดับ', 'รหัสพนักงาน', 'คำนำหน้า', 'ชื่อ-นามสกุล', 'ชื่อเล่น', 'แผนก', 'วันที่เริ่มงาน', 'สถานะพนักงาน', 'ปีสิทธิ์การลา'];
    types.forEach(function (c) {
      var n = lvType(c).name;
      h = rptBalHasQuota(c)
        ? h.concat([n + ' · สิทธิ์ต่อปี', n + ' · ยกมา', n + ' · ใช้แล้ว', n + ' · รออนุมัติ', n + ' · คงเหลือ'])
        : h.concat([n + ' · ใช้แล้ว', n + ' · รออนุมัติ']);
    });
    return h;
  }

  function rptBalCells(row, types, i) {
    var e = row.e;
    var out = [i + 1, e.emp_code, e.prefix, e.full_name, e.nickname, e.department,
      e.start_date ? rptDateBE(e.start_date) : '—', EMP_STATUS_TH[e.emp_status] || e.emp_status, (e.year + 543)];
    types.forEach(function (c) {
      var t = row.t[c];
      if (!rptBalHasQuota(c)) {                       // [106] ไม่มี Hard Quota → เฉพาะ used/pending
        out = out.concat(t ? [lvNum(t.used), lvNum(t.pending)] : [0, 0]);
        return;
      }
      if (!t) { out = out.concat(['—', 0, 0, 0, '—']); return; }
      var unlimited = t.quota === null || t.quota === undefined;
      out = out.concat([unlimited ? 'ไม่จำกัด' : lvNum(t.quota), lvNum(t.carry_over) + lvNum(t.extra_days),
        lvNum(t.used), lvNum(t.pending), unlimited ? 'ไม่จำกัด' : lvNum(t.remaining)]);
    });
    return out;
  }

  /* ---------- รายงาน OT เดิม (แท็บ "รายงาน OT" ในหน้า #/reports) ----------
     ข้อมูลจริงจาก Supabase — เดิมวน db.ots ใน localStorage
       แถวหลัก (รายรายการงาน)  njhr_ot_report   22 คอลัมน์ ครบทุกช่องของตารางนี้
                               ยกเว้น วันที่ยื่น · ผู้อนุมัติ · วันที่อนุมัติ · ไฟล์แนบ
       วันที่ยื่น               njhr_rpt_ot_list (created_at ระดับคำขอ)
       ผู้อนุมัติ + วันที่อนุมัติ njhr_ot_get     (approvals jsonb) เฉพาะคำขอที่ไม่ใช่ PENDING
       ไฟล์แนบ (ชื่อ + จำนวน)   njhr_ot_attach_list ระดับคำขอ แล้วจับคู่เข้ารายการงานด้วย job_no

     ✔ ไม่ต้องแก้ Return Signature ของ njhr_ot_report — RPC ที่มีอยู่ครอบคลุมครบแล้ว
       (ตรวจตามที่สั่งในข้อ 4: rpt_ot_list + ot_get + attach_list เติมส่วนที่ขาดได้ทั้งหมด)
     ⚠ ต้นทุน: 2 + 2N คำขอ (N = จำนวนคำขอในช่วงที่เลือก) จำกัดด้วย p_limit ของ RPC
     หัวตาราง · ลำดับคอลัมน์ · สูตรสรุป เหมือนเดิมทุกช่อง */
  var rptOtData = [], rptOtLoading = false, rptOtSeq = 0, rptOtErr = '';

  function rptOtRows() { return rptOtData; }

  function rptOtHM(v) { return String(v == null ? '' : v).slice(0, 5); }

  /* ผู้อนุมัติ + วันที่อนุมัติ จาก approvals jsonb — เอา action สุดท้ายที่ไม่ใช่ SUBMIT */
  function rptOtApprover(approvals) {
    var a = (approvals || []).filter(function (x) {
      var act = String(x.action || '').toUpperCase();
      return act === 'APPROVE' || act === 'REJECT' || act === 'CANCEL';
    });
    if (!a.length) return { by: '', at: '' };
    var last = a[a.length - 1];
    return { by: String(last.by || ''), at: String(last.at || '').replace('T', ' ').slice(0, 16) };
  }

  function rptOtLoad(el) {
    var st = rptState, seq = ++rptOtSeq;
    rptOtErr = '';
    if (!st.from || !st.to || st.from > st.to) { rptOtData = []; rptOtLoading = false; return Promise.resolve(); }
    if (!sbReady() || !sbToken()) {
      rptOtData = []; rptOtLoading = false;
      rptOtErr = 'ยังไม่ได้เชื่อมต่อ Supabase — รายงาน OT ต้องใช้ข้อมูลจริงเท่านั้น';
      return Promise.resolve();
    }
    rptOtLoading = true; rptOtData = [];
    var args = { p_token: sbToken(), p_from: st.from, p_to: st.to,
      p_dept: st.deptId || null, p_q: st.q || null };
    return Promise.all([
      sbRpcList('njhr_ot_report', {
        p_token: args.p_token, p_from: args.p_from, p_to: args.p_to, p_status: 'ALL',
        p_dept: args.p_dept, p_employee: st.empId || null, p_q: args.p_q,
        p_limit: 2000, p_offset: 0
      }),
      sbRpcList('njhr_rpt_ot_list', args)['catch'](function () { return []; })
    ]).then(function (res) {
      if (seq !== rptOtSeq) return;
      var jobs = res[0] || [], reqs = res[1] || [];
      var meta = {};
      reqs.forEach(function (r) { meta[String(r.req_id)] = r; });
      var ids = [];
      jobs.forEach(function (j) { if (ids.indexOf(String(j.ot_id)) < 0) ids.push(String(j.ot_id)); });
      /* ไฟล์แนบ + ผู้อนุมัติ ต้องอ่านรายคำขอ (RPC ที่มีอยู่ไม่คืนแบบรวม) */
      /* ---------- Concurrency Pool ----------
         เดิม Promise.all(ids.map(...)) ยิง 2 RPC ต่อ 1 คำขอ "พร้อมกันทั้งหมด"
         คำขอ OT 300 รายการ = 600 Request ระเบิดใส่เบราว์เซอร์และ Supabase ในจังหวะเดียว
         เปลี่ยนเป็นคิวคนงาน 6 ช่อง (= เพดาน Connection ต่อ Origin ของเบราว์เซอร์บน HTTP/1.1
         จึงไม่มี Request ค้างคิวในเบราว์เซอร์ และไม่ burst ใส่เซิร์ฟเวอร์)
         ผลลัพธ์: array เรียงตาม ids เดิมทุกตำแหน่ง · RPC · parameter · การ map ข้อมูล
         เหมือนเดิม 100% — เปลี่ยนเฉพาะจังหวะการยิงเท่านั้น */
      var OT_POOL = 6;
      var otExtra = new Array(ids.length), otNext = 0;
      function otWorker() {
        if (otNext >= ids.length) return Promise.resolve();
        var k = otNext++;
        var id = ids[k];
        return Promise.all([
          sbRpcList('njhr_ot_attach_list', { p_token: sbToken(), p_ot_id: id })['catch'](function () { return []; }),
          sbRpc('njhr_ot_get', { p_token: sbToken(), p_id: id })['catch'](function () { return null; })
        ]).then(function (x) {
          var d = x[1] && x[1].data ? x[1].data : x[1];
          otExtra[k] = { id: id, files: x[0] || [], appr: rptOtApprover(d && d.request && d.request.approvals) };
          return otWorker();
        });
      }
      var otRunners = [];
      for (var w2 = 0; w2 < Math.min(OT_POOL, ids.length); w2++) otRunners.push(otWorker());
      return Promise.all(otRunners).then(function () { return otExtra; }).then(function (extra) {
        if (seq !== rptOtSeq) return;
        var byId = {};
        extra.forEach(function (x) { byId[x.id] = x; });
        rptOtData = jobs.map(function (j) {
          var x = byId[String(j.ot_id)] || { files: [], appr: { by: '', at: '' } };
          var mine = x.files.filter(function (f) { return Number(f.job_no) === Number(j.job_no); });
          var m = meta[String(j.ot_id)] || {};
          return {
            reqId: m.request_no || j.ot_id, no: j.job_no, code: j.emp_code || '',
            name: j.emp_name || '', title: j.prefix || '',
            dept: j.department || '', position: j.position_name || '',
            job: j.job_code || '', detail: j.detail || '', jobType: j.job_type || '',
            date: String(j.job_date || '').slice(0, 10),
            start: rptOtHM(j.start_time), end: rptOtHM(j.end_time),
            endDate: String(j.end_date || '').slice(0, 10), nextDay: !!j.spans_next_day,
            hours: Number(j.job_hours) || 0,
            fileNames: mine.map(function (f) { return f.file_name; }).join(', '),
            fileCount: mine.length,
            status: OT_STATUS_TH[j.status] || j.status,
            createdAt: String(m.created_at || '').replace('T', ' ').slice(0, 16),
            approver: x.appr.by, approvedAt: x.appr.at,
            note: j.reason || '', empId: j.employee_id
          };
        });
        // เรียง: วันที่ OT → เวลาเริ่ม → รหัสพนักงาน → เลขที่คำขอ → ลำดับรายการ
        rptOtData.sort(function (a2, b2) {
          return a2.date.localeCompare(b2.date) || String(a2.start).localeCompare(String(b2.start)) ||
            String(a2.code).localeCompare(String(b2.code), 'th', { numeric: true }) ||
            String(a2.reqId).localeCompare(String(b2.reqId)) || (a2.no - b2.no);
        });
        rptOtLoading = false;
      });
    })['catch'](function (ex) {
      if (seq !== rptOtSeq) return;
      rptOtLoading = false; rptOtData = [];
      console.error('[REPORT] รายงาน OT จาก Supabase ล้มเหลว:', ex);
      rptOtErr = 'โหลดรายงาน OT จาก Supabase ไม่สำเร็จ: ' + ((ex && ex.message) || ex);
    });
  }

  var RPT_OT_HEAD = ['เลขที่คำขอ', 'ลำดับรายการ', 'รหัสพนักงาน', 'ชื่อ–นามสกุล', 'แผนก', 'ตำแหน่ง',
    'JOB', 'รายละเอียดงาน', 'ประเภทงาน', 'วันที่ OT', 'เวลาเริ่มต้น', 'เวลาสิ้นสุด', 'จำนวนชั่วโมง',
    'จำนวนไฟล์แนบ', 'สถานะ', 'วันที่ยื่น', 'ผู้อนุมัติ', 'วันที่อนุมัติ'];

  var RPT_OT_HEAD_XLS = ['เลขที่คำขอ', 'ลำดับรายการ', 'รหัสพนักงาน', 'ชื่อ–นามสกุล', 'แผนก', 'ตำแหน่ง',
    'JOB', 'รายละเอียดงาน', 'ประเภทงาน', 'วันที่ OT', 'เวลาเริ่มต้น', 'เวลาสิ้นสุด', 'จำนวนชั่วโมง',
    'ชื่อไฟล์แนบ', 'จำนวนไฟล์', 'สถานะ', 'ผู้อนุมัติ', 'วันที่อนุมัติ', 'หมายเหตุรวม'];

  function rptOtCells(r) {
    return [r.reqId, r.no, r.code, r.name, r.dept, r.position, r.job, r.detail, r.jobType,
      rptDateBE(r.date), r.start, r.end + (r.nextDay ? ' (+1 วัน)' : ''), r.hours,
      r.fileCount, r.status, r.createdAt, r.approver || '-', r.approvedAt || '-'];
  }

  function rptOtCellsXls(r) {
    return [r.reqId, r.no, r.code, r.name, r.dept, r.position, r.job, r.detail, r.jobType,
      rptDateBE(r.date), r.start, r.end + (r.nextDay ? ' (+1 วัน)' : ''), r.hours,
      r.fileNames, r.fileCount, r.status, r.approver || '-', r.approvedAt || '-', r.note];
  }

  /* เติมตาราง + การ์ดสรุปของรายงาน OT หลังข้อมูลจาก Supabase มาถึง
     หัวตาราง · ลำดับคอลัมน์ · การ์ดสรุป เหมือนเดิมทุกช่อง */
  function rptOtPaint(el) {
    var box = document.getElementById('rpt-table');
    var eb = document.getElementById('rpt-err');
    if (eb) eb.textContent = rptOtErr || '';
    var rows = rptOtRows();
    var sum = rptOtSummary(rows);
    var sb = el.querySelector('.rpt-otsum');
    if (sb) {
      sb.innerHTML = [['คำขอทั้งหมด', sum.reqs], ['รายการงานทั้งหมด', sum.items], ['ชั่วโมงรวม', sum.hours],
        ['จำนวนพนักงาน', sum.emps], ['รออนุมัติ', sum.pend], ['อนุมัติแล้ว', sum.appr]]
        .map(function (x) { return '<div class="bal-item"><div class="bal-top"><span>' + x[0] + '</span><b>' + x[1] + '</b></div></div>'; }).join('');
    }
    var cnt = el.querySelector('.rpt-sum b:last-child');
    if (cnt) cnt.textContent = rows.length + ' รายการ';
    if (!box) return;
    box.innerHTML = rows.length
      ? '<div class="table-wrap"><table><thead><tr>' +
        RPT_OT_HEAD.map(function (h) { return '<th>' + esc(h) + '</th>'; }).join('') + '</tr></thead><tbody>' +
        rows.map(function (r) { return '<tr>' + rptOtCells(r).map(function (c) { return '<td>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') +
        '</tbody></table></div>'
      : emptyState(rptOtErr ? 'ไม่สามารถแสดงข้อมูลได้' : rptEmptyMsg());
  }

  function rptOtSummary(rows) {
    var reqs = {}, emps = {}, hrs = 0, pend = 0, appr = 0;
    rows.forEach(function (r) {
      reqs[r.reqId] = 1; emps[r.empId] = 1; hrs += r.hours;
      if (r.status === 'รออนุมัติ') pend++;
      if (r.status === 'อนุมัติแล้ว') appr++;
    });
    return { reqs: Object.keys(reqs).length, items: rows.length,
      hours: Math.round(hrs * 100) / 100, emps: Object.keys(emps).length, pend: pend, appr: appr };
  }

  var RPT_HEAD = ['วันที่', 'คำนำหน้า', 'พนักงาน', 'แผนก', 'เข้า', 'ออก', 'สถานะ', 'จำนวนชั่วโมง', 'จำนวนนาที'];

  var rptAttRows = [];
  /* ---------- แบ่งหน้าเฉพาะ "การแสดงผล" ของรายงานลงเวลา/มาสาย ----------
     ข้อมูลยังโหลด/เก็บครบตาม p_limit เดิม (สูงสุด 2000) — Export Excel อ่านจาก
     rptAttRows เต็มก้อนเช่นเดิม จึงครบ 100% · เปลี่ยนเฉพาะจำนวนแถวที่วาดลง DOM
     200 แถว/หน้า = DOM สูงสุด ~1,800 <td> ต่อหน้า (จากเดิม 18,000) */
  var RPT_ATT_PER = 200;
  var rptAttPage = 0;

  /* ---------- ตัวกรองสถานะการลงเวลา ----------
     Source of Truth คือค่า status ที่ njhr_att_report คืนมา (attendance.status)
     ห้ามคำนวณสถานะใหม่ในหน้าจอ · ห้ามสร้างค่าใหม่โดยเดา
     rptAttRaw เก็บผลดิบจาก RPC · rptAttRows คือผลหลังกรอง
     ตาราง จำนวนรายการสรุป และ Export Excel อ่านจาก rptAttRows ชุดเดียวกัน */
  var rptAttRaw = [];

  // ตัวเลือกใน Dropdown = ค่าที่พบจริงในผลลัพธ์ปัจจุบันเท่านั้น
  function rptAttStatusOpts() {
    var seen = {}, out = [];
    rptAttRaw.forEach(function (r) {
      var code = r.statusCode || '';
      if (!code || seen[code]) return;
      seen[code] = 1;
      out.push([code, EMP_ATT_STATUS[code] || code]);
    });
    // ค่าที่ผู้ใช้เลือกไว้ต้องอยู่ในรายการเสมอ แม้ผลรอบนี้จะไม่มีแถวนั้น
    var cur = rptState.attStatus;
    if (cur && !seen[cur]) out.push([cur, EMP_ATT_STATUS[cur] || cur]);
    out.sort(function (a, b) { return a[1].localeCompare(b[1], 'th'); });
    return out;
  }

  function rptAttApplyStatus(rows) {
    var f = rptState.attStatus;
    if (!f) return rows;
    return rows.filter(function (r) { return r.statusCode === f; });
  }

  /* คอลัมน์ "แผนก" อ่านจาก r.dept ซึ่ง njhr_att_report คืนมาแล้วใน Query เดียว
     (RPC JOIN employees แล้ว select e.department_name — ไม่มี N+1)
     ไม่มีแผนก = แสดง "-" ห้ามเดาจาก role / username / attendance text
     ตารางและ Export Excel ใช้ฟังก์ชันนี้ร่วมกัน ข้อมูลจึงตรงกันเสมอ */
  /* [108] ป้ายสถานะที่เห็นในตาราง = ค่าหลัง Overlay วันลาที่อนุมัติแล้ว
     ใช้ชุดเดียวกันทั้ง ตาราง · Status Filter · Export → ข้อมูลตรงกันเสมอ
     leave-only row (ไม่มีการลงเวลา) ต้องไม่แสดงสถานะว่าง */
  function rptLeaveLabel(r) {
    if (!r || r.leaveStatus !== 'LEAVE') return '';
    var m = r.leaveMode || '';
    if (m === 'HOURLY') {
      var a = String(r.leaveFrom || '').slice(0, 5), b = String(r.leaveTo || '').slice(0, 5);
      return (a && b) ? ('ลา ' + a + '–' + b) : 'ลา (รายชั่วโมง)';
    }
    if (m === 'HALF_AM') return 'ลา (ครึ่งวันเช้า)';
    if (m === 'HALF_PM') return 'ลา (ครึ่งวันบ่าย)';
    if (m === 'HALF')    return 'ลา (ครึ่งวัน)';
    return 'ลา';
  }
  /* [108] status ที่ได้จาก njhr_att_report เป็น "effective" แล้ว
     FULL Leave → 'LEAVE' → แปลไทยว่า "ลา" ซึ่งซ้ำกับป้ายวันลา จึงห้ามต่อท้ายอีก
     HALF/HOURLY ที่ทำงานช่วงที่เหลือปกติ → "ลา (ครึ่งวันเช้า) · ปกติ" */
  function rptStatusText(r) {
    var lb = rptLeaveLabel(r);
    if (!lb) return r.status;
    var st = String(r.statusCode || '').toUpperCase();
    if (st === 'LEAVE' || !r.in || r.in === '—') return lb;   // ไม่ให้เกิด "ลา · ลา"
    var th = EMP_ATT_STATUS[st] || r.status;
    return th ? (lb + ' · ' + th) : lb;
  }

  function rptCells(r) {
    var late = rptState.type === 'late';
    return [rptDateBE(r.date), r.title, r.name, r.dept || '-', r.in, r.out,
      late ? 'มาสาย' : rptStatusText(r),
      late ? r.lh : r.wh, late ? r.lm : r.wm];
  }

  function rptEmptyMsg() {
    if (rptState.type === 'leave') return 'ไม่พบรายการลาตามช่วงวันที่ แผนก ประเภทการลา และสถานะที่เลือก';
    if (rptState.type === 'balance') return 'ไม่พบพนักงานตามปีสิทธิ์ แผนก และสถานะพนักงานที่เลือก';
    if (rptState.type === 'ot') return 'ไม่พบรายการ OT ตามช่วงวันที่ แผนก และชื่อพนักงานที่เลือก';
    return rptState.type === 'late'
      ? 'ยังไม่มีข้อมูลการมาสายในช่วงวันที่ แผนก และพนักงานที่เลือก'
      : 'ยังไม่มีข้อมูลการลงเวลาในช่วงวันที่ แผนก และพนักงานที่เลือก';
  }

  var rptState = { type: 'attendance', from: '', to: '', deptId: '', q: '', empId: '',
    leaveType: '', status: '', attStatus: '', year: new Date().getFullYear(), empStatus: 'ACTIVE' };

  function rptDefaults() {
    var d = new Date(); d.setDate(d.getDate() - 14);
    return { from: d.toISOString().slice(0, 10), to: todayISO() };
  }

  function viewReports(el) {
    var s = rptState;
    rptAttPage = 0;   // เปลี่ยนตัวกรอง/ค้นหา/ประเภท → กลับหน้าแรกเสมอ (ปุ่มเปลี่ยนหน้าไม่ผ่านจุดนี้)
    if (!s.from) { var dft = rptDefaults(); s.from = dft.from; s.to = dft.to; }
    var types = [['attendance', 'รายงานการลงเวลา'], ['late', 'รายงานมาสาย'],
      ['leave', 'รายงานการลา'], ['balance', 'รายงานวันลาคงเหลือ'], ['ot', 'รายงาน OT']];
    var depts = rptDepts();
    // พนักงานที่เลือกอยู่ต้องอยู่ในแผนกที่เลือก ไม่งั้นล้างทิ้งทันที
    if (s.empId) {
      var picked = emp(s.empId);
      if (!picked || (s.deptId && picked.deptId !== s.deptId)) { s.empId = ''; s.q = ''; }
    }
    var err = '';
    if (!s.from || !s.to) err = 'กรุณาเลือกวันที่เริ่มต้นและวันที่สิ้นสุดให้ครบ';
    else if (s.from > s.to) err = 'วันที่เริ่มต้นต้องไม่เกินวันที่สิ้นสุด';
    var isOt = s.type === 'ot', isLv = s.type === 'leave', isBal = s.type === 'balance';
    var isAtt = s.type === 'attendance' || s.type === 'late';
    // รายงานลงเวลา · มาสาย · ลา · วันลาคงเหลือ ดึงจาก Supabase ทั้งหมด (โหลดแบบ async)
    /* รายงาน OT ย้ายมาอ่านจาก Supabase แล้ว จึงเข้าเส้นทางโหลดแบบ async เดียวกับรายงานอื่น */
    var isSb = isLv || isBal || isAtt || isOt;
    if (isBal) err = '';                            // รายงานคงเหลือใช้ "ปี" ไม่ใช้ช่วงวันที่
    var rows = (err || isSb) ? [] : (isOt ? rptOtRows() : rptRows());
    var head = isOt ? RPT_OT_HEAD : RPT_HEAD;
    var cellsOf = isOt ? rptOtCells : rptCells;
    var otSum = isOt ? rptOtSummary(rows) : null;
    var seq = ++rptSeq;

    var pickedName = s.empId ? (s.q || 'พนักงานที่เลือก') : (s.q ? s.q : 'ทุกคน');

    el.innerHTML =
      '<div class="toolbar rpt-filters">' +
      '<select id="rpt-type">' + types.map(function (t) { return '<option value="' + t[0] + '"' + (s.type === t[0] ? ' selected' : '') + '>' + t[1] + '</option>'; }).join('') + '</select>' +
      (isBal
        ? '<select id="rpt-year">' + rptYears().map(function (y) {
            return '<option value="' + y + '"' + (s.year === y ? ' selected' : '') + '>ปีสิทธิ์ ' + (y + 543) + '</option>';
          }).join('') + '</select>' +
          '<select id="rpt-estatus">' + [['ACTIVE', 'ปฏิบัติงาน'], ['PROBATION', 'ทดลองงาน'], ['RESIGNED', 'พ้นสภาพ'], ['', 'ทุกสถานะ']]
            .map(function (x) { return '<option value="' + x[0] + '"' + (s.empStatus === x[0] ? ' selected' : '') + '>' + x[1] + '</option>'; }).join('') + '</select>'
        : '<input type="date" id="rpt-from" value="' + esc(s.from) + '"><span class="muted">ถึง</span><input type="date" id="rpt-to" value="' + esc(s.to) + '">') +
      (isLv
        ? '<select id="rpt-ltype"><option value="">ทุกประเภทการลา</option>' +
          LEAVE_TYPES.map(function (t) { return '<option value="' + t.code + '"' + (s.leaveType === t.code ? ' selected' : '') + '>' + esc(t.name) + '</option>'; }).join('') + '</select>' +
          '<select id="rpt-status"><option value="">ทุกสถานะ</option>' +
          Object.keys(LV_STATUS_TH).map(function (k) { return '<option value="' + k + '"' + (s.status === k ? ' selected' : '') + '>' + LV_STATUS_TH[k] + '</option>'; }).join('') + '</select>'
        : '') +
      '<select id="rpt-dept"><option value="">ทุกแผนก</option>' +
      depts.map(function (d2) { return '<option value="' + esc(d2.name) + '"' + (s.deptId === d2.name ? ' selected' : '') + '>' + esc(d2.name) + '</option>'; }).join('') + '</select>' +
      /* ตัวกรองสถานะการลงเวลา — ตัวเลือกสร้างจากค่า status ที่ njhr_att_report คืนมาจริง
         ไม่ hardcode และไม่คำนวณสถานะใหม่ในหน้าจอ */
      (isAtt
        ? '<select id="rpt-astatus"><option value="">ทุกสถานะ</option>' +
          rptAttStatusOpts().map(function (o2) {
            return '<option value="' + esc(o2[0]) + '"' + (s.attStatus === o2[0] ? ' selected' : '') +
              '>' + esc(o2[1]) + '</option>';
          }).join('') + '</select>'
        : '') +
      '<span class="search-box rpt-emp-box">' + icon('search', 'ic-sm') +
      '<input id="rpt-q" autocomplete="off" placeholder="ค้นหาชื่อ นามสกุล ชื่อเล่น หรือรหัสพนักงาน" value="' + esc(s.q) + '">' +
      '<div class="rpt-ac" id="rpt-ac" hidden></div></span>' +
      '<button class="btn btn-ghost" id="rpt-clear">ล้างตัวกรอง</button>' +
      '<span class="grow"></span>' +
      '<button class="btn btn-primary" id="rpt-export">' + icon('download') + ' Export Excel</button></div>' +
      '<p class="muted note rpt-sum">ประเภทรายงาน: <b>' + esc(types.filter(function (t) { return t[0] === s.type; })[0][1]) + '</b>' +
      (isBal ? ' · ปีสิทธิ์การลา: <b>' + (s.year + 543) + '</b> · สถานะพนักงาน: <b>' +
        esc(({ ACTIVE: 'ปฏิบัติงาน', PROBATION: 'ทดลองงาน', RESIGNED: 'พ้นสภาพ' })[s.empStatus] || 'ทุกสถานะ') + '</b>'
        : ' · ช่วงวันที่: <b>' + esc(rptDateBE(s.from)) + ' – ' + esc(rptDateBE(s.to)) + '</b>') +
      (isLv ? ' · ประเภทการลา: <b>' + esc(s.leaveType ? lvType(s.leaveType).name : 'ทุกประเภท') + '</b>' +
        ' · สถานะ: <b>' + esc(s.status ? LV_STATUS_TH[s.status] : 'ทุกสถานะ') + '</b>' : '') +
      ' · แผนก: <b>' + esc(s.deptId || 'ทุกแผนก') + '</b>' +
      (isAtt ? ' · สถานะ: <b>' +
        esc(s.attStatus ? (EMP_ATT_STATUS[s.attStatus] || s.attStatus) : 'ทุกสถานะ') + '</b>' : '') +
      ' · พนักงาน: <b>' + esc(pickedName) + '</b>' +
      ' · จำนวนรายการ: <b>' + rows.length + ' รายการ</b></p>' +
      (otSum ? '<div class="bal-grid rpt-otsum">' +
        [['คำขอทั้งหมด', otSum.reqs], ['รายการงานทั้งหมด', otSum.items], ['ชั่วโมงรวม', otSum.hours],
         ['จำนวนพนักงาน', otSum.emps], ['รออนุมัติ', otSum.pend], ['อนุมัติแล้ว', otSum.appr]]
          .map(function (x) { return '<div class="bal-item"><div class="bal-top"><span>' + x[0] + '</span><b>' + x[1] + '</b></div></div>'; }).join('') +
        '</div>' : '') +
      (err ? '<div class="form-error" role="alert">' + esc(err) + '</div>' : '') +
      '<div class="card p0" id="rpt-table">' + (isSb
        ? '<div class="muted" style="padding:18px">กำลังโหลดข้อมูลจาก Supabase…</div>'
        : (rows.length
          ? '<div class="table-wrap"><table><thead><tr>' + head.map(function (h) { return '<th>' + esc(h) + '</th>'; }).join('') + '</tr></thead><tbody>' +
            rows.map(function (r) { return '<tr>' + cellsOf(r).map(function (c) { return '<td>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table></div>'
          : emptyState(err || rptEmptyMsg()))) + '</div>' +
      '<div class="toolbar" id="rpt-att-pager"></div>' +
      '<div class="form-error" id="rpt-err" role="alert" style="white-space:pre-line"></div>';

    document.getElementById('rpt-type').onchange = function () { s.type = this.value; viewReports(el); };
    // รายงานวันลาคงเหลือใช้ "ปีสิทธิ์" แทนช่วงวันที่ จึงอาจไม่มีช่องเหล่านี้
    var fEl = document.getElementById('rpt-from');
    if (fEl) fEl.onchange = function () { s.from = this.value; viewReports(el); };
    var tEl = document.getElementById('rpt-to');
    if (tEl) tEl.onchange = function () { s.to = this.value; viewReports(el); };
    var yEl = document.getElementById('rpt-year');
    if (yEl) yEl.onchange = function () { s.year = parseInt(this.value, 10); viewReports(el); };
    var esEl = document.getElementById('rpt-estatus');
    if (esEl) esEl.onchange = function () { s.empStatus = this.value; viewReports(el); };
    var ltEl = document.getElementById('rpt-ltype');
    if (ltEl) ltEl.onchange = function () { s.leaveType = this.value; viewReports(el); };
    var stEl = document.getElementById('rpt-status');
    if (stEl) stEl.onchange = function () { s.status = this.value; viewReports(el); };
    document.getElementById('rpt-dept').onchange = function () {
      s.deptId = this.value;
      var p = s.empId ? emp(s.empId) : null;
      if (p && s.deptId && p.deptId !== s.deptId) { s.empId = ''; s.q = ''; }   // ล้างพนักงานที่ไม่ได้อยู่แผนกใหม่
      viewReports(el);
    };
    var asEl = document.getElementById('rpt-astatus');
    if (asEl) asEl.onchange = function () { s.attStatus = this.value; viewReports(el); };
    document.getElementById('rpt-clear').onclick = function () {
      var dft2 = rptDefaults();
      rptState = { type: 'attendance', from: dft2.from, to: dft2.to, deptId: '', q: '', empId: '',
        leaveType: '', status: '', attStatus: '', year: new Date().getFullYear(), empStatus: 'ACTIVE' };
      viewReports(el);
    };

    // ---- ค้นหาชื่อพนักงาน + Autocomplete (ใช้รูปแบบเดิมของระบบ ไม่เพิ่มไลบรารี)
    var qEl = document.getElementById('rpt-q'), acEl = document.getElementById('rpt-ac');
    // อ้างอิงสด ๆ ทุกครั้ง เพราะ viewReports() วาดใหม่แล้ว element เดิมจะหลุดจาก DOM
    function acBox() { return document.getElementById('rpt-ac'); }
    function closeAc() { var b = acBox(); if (b) { b.hidden = true; b.innerHTML = ''; } }
    function openAc() {
      var box = acBox(), inp = document.getElementById('rpt-q');
      if (!box || !inp) return;
      var q = inp.value.trim();
      if (!q) { closeAc(); return; }
      // รายชื่อพนักงานมาจากตาราง employees จริงผ่าน njhr_emp_list (ไม่ใช้ db.employees)
      sbRpcList('njhr_emp_list', {
        p_token: sbToken(), p_q: q, p_dept: s.deptId || null, p_status: null,
        p_sort: 'emp_code', p_desc: false, p_limit: 8, p_offset: 0
      }).then(function (pool) {
        var b2 = acBox();
        if (!b2) return;
        if (!pool || !pool.length) { closeAc(); return; }
        b2.innerHTML = pool.map(function (e2) {
          return '<button type="button" class="rpt-ac-item" data-eid="' + esc(e2.id) + '">' +
            esc(e2.emp_code || '-') + ' — ' + esc((e2.prefix || '') + (e2.full_name || '')) +
            (e2.nickname ? ' (' + esc(e2.nickname) + ')' : '') +
            ' — ' + esc(e2.department_name || '-') + '</button>';
        }).join('');
        b2.hidden = false;
      }).catch(function (er) { console.error('[REPORT] njhr_emp_list ล้มเหลว:', er); closeAc(); });
    }
    qEl.oninput = debounce(function () {
      s.q = qEl.value; s.empId = '';        // พิมพ์เอง = ค้นหาแบบข้อความ ยังไม่ผูก Employee ID
      viewReports(el);
      var q2 = document.getElementById('rpt-q');
      q2.focus(); q2.setSelectionRange(q2.value.length, q2.value.length);
      openAc();
    }, 300);
    acEl.onmousedown = function (ev) {
      var b = ev.target.closest ? ev.target.closest('[data-eid]') : null;
      if (!b) return;
      ev.preventDefault();
      s.empId = b.dataset.eid;              // เลือกจากรายการ = ยึด Employee ID (กันชื่อซ้ำเลือกผิดคน)
      // ใช้ข้อความจากปุ่มที่เลือก (มาจากตาราง employees จริง) ไม่อ่านจาก db.employees
      s.q = (b.textContent || '').split(' — ').slice(0, 2).join(' — ');
      viewReports(el);
    };
    qEl.onblur = function () { setTimeout(closeAc, 120); };

    document.getElementById('rpt-export').onclick = function () { rptExport(this); };

    if (!rptDeptCache.length) rptLoadDepts(el);
    if (isOt) {
      rptOtLoad(el).then(function () {
        if (seq !== rptSeq) return;
        rptOtPaint(el);
      });
    } else if (isSb) rptLoadSb(el, seq);
  }

  var rptSeq = 0;

  function rptYears() {
    var y = new Date().getFullYear(), out = [];
    for (var i = y - 3; i <= y + 1; i++) out.push(i);
    return out;
  }

  var _rptAttInflight = null, _rptAttKey = '';

  function rptFetchAtt() {
    var s = rptState;
    var args = {
      p_token: sbToken(), p_from: s.from, p_to: s.to,
      p_type: s.type === 'late' ? 'LATE' : 'ATTEND',
      p_dept: s.deptId || null, p_employee: s.empId || null,
      // เลือกพนักงานจากรายการแล้ว = ยึด Employee ID อย่างเดียว ไม่กรองซ้ำด้วยข้อความ
      p_q: s.empId ? null : (s.q || null),
      p_limit: 2000, p_offset: 0
    };
    var key = JSON.stringify([args.p_from, args.p_to, args.p_type, args.p_dept,
                              args.p_employee, args.p_q, args.p_limit, args.p_offset]);
    if (_rptAttInflight && _rptAttKey === key) return _rptAttInflight;
    _rptAttKey = key;
    _rptAttInflight = sbRpcList('njhr_att_report', args);
    _rptAttInflight['catch'](function () {}).then(function () {
      if (_rptAttKey === key) { _rptAttInflight = null; _rptAttKey = ''; }
    });
    return _rptAttInflight;
  }

  function rptAttRow(r) {
    function hm(t) { return t ? new Date(t).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'Asia/Bangkok' }) : '—'; }
    // คอลัมน์ "จำนวนชั่วโมง/นาที" ในรายงานคือช่วงเวลาเข้า→ออก (เหมือนเดิมทุกประการ)
    // ส่วน work_hours ในฐานข้อมูลเป็นชั่วโมงสุทธิหักพักแล้ว ใช้กับเงินเดือน จึงไม่นำมาแสดงตรงนี้
    var mins = (r.check_in && r.check_out)
      ? Math.max(0, Math.round((new Date(r.check_out) - new Date(r.check_in)) / 60000)) : null;
    return {
      date: String(r.work_date).slice(0, 10),
      title: r.prefix || '', name: r.emp_name || '',
      in: hm(r.check_in), out: hm(r.check_out),
      statusCode: r.status || '',
      /* [108] ข้อมูลวันลาที่อนุมัติแล้ว — คอลัมน์ที่ njhr_att_report เพิ่มต่อท้าย
         ชื่อคอลัมน์ตรงกับ Migration 108: leave_status/leave_type/leave_mode/
         leave_start_time/leave_end_time
         Build ที่ยังไม่ได้รัน 108 จะได้ undefined ทั้งหมด = พฤติกรรมเดิมทุกประการ
         status เดิม (r.status) ไม่ถูกแตะ → Payroll / REPORT ALL อ่านค่าเดิมได้เหมือนเดิม */
      leaveStatus: r.leave_status || '',
      leaveType: r.leave_type || '',
      leaveMode: r.leave_mode || '',
      leaveFrom: r.leave_start_time || '', leaveTo: r.leave_end_time || '',
      /* [108] ค่าดิบก่อน Overlay — เก็บไว้ตรวจสอบย้อนหลัง ไม่นำไปแสดง/คำนวณ */
      rawStatus: r.raw_status || '', rawLateMin: (r.raw_late_min == null ? null : Number(r.raw_late_min)),
      status: EMP_ATT_STATUS[r.status] || r.status || '',
      wh: mins == null ? '' : Math.floor(mins / 60), wm: mins == null ? '' : mins % 60,
      lh: r.late_min ? Math.floor(r.late_min / 60) : (r.late_min === 0 ? 0 : ''),
      lm: r.late_min ? r.late_min % 60 : (r.late_min === 0 ? 0 : ''),
      dept: r.department || '', empCode: r.emp_code || ''
    };
  }

  /* วาดตารางลงเวลา/มาสายเฉพาะหน้าปัจจุบัน + แถบเปลี่ยนหน้า
     ปุ่มเปลี่ยนหน้าเรียกฟังก์ชันนี้ซ้ำโดยไม่โหลดข้อมูลใหม่และไม่ล้างตัวกรอง
     (Pattern เดียวกับ lv-pager ใน views/leave/main.js ที่ใช้อยู่แล้ว) */
  function rptAttPaint(el) {
    var box = document.getElementById('rpt-table');
    var pg = document.getElementById('rpt-att-pager');
    if (!box) return;
    var total = rptAttRows.length;
    var pages = Math.ceil(total / RPT_ATT_PER) || 1;
    if (rptAttPage >= pages) rptAttPage = pages - 1;
    if (rptAttPage < 0) rptAttPage = 0;
    var start = rptAttPage * RPT_ATT_PER;
    var cells = rptAttRows.slice(start, start + RPT_ATT_PER).map(rptCells);
    box.innerHTML = cells.length
      ? '<div class="table-wrap"><table><thead><tr>' +
        RPT_HEAD.map(function (h) { return '<th>' + esc(h) + '</th>'; }).join('') + '</tr></thead><tbody>' +
        cells.map(function (r) { return '<tr>' + r.map(function (c) { return '<td>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') +
        '</tbody></table></div>'
      : emptyState(rptEmptyMsg());
    if (!pg) return;
    pg.innerHTML = pages > 1
      ? '<button class="btn btn-ghost btn-sm" id="rpt-att-prev"' + (rptAttPage === 0 ? ' disabled' : '') + '>ก่อนหน้า</button>' +
        '<span class="muted">หน้า ' + (rptAttPage + 1) + ' / ' + pages +
        ' · แสดง ' + (start + 1) + '–' + Math.min(start + RPT_ATT_PER, total) + ' จาก ' + total + ' รายการ</span>' +
        '<button class="btn btn-ghost btn-sm" id="rpt-att-next"' + (rptAttPage + 1 >= pages ? ' disabled' : '') + '>ถัดไป</button>'
      : '';
    if (pages > 1) {
      document.getElementById('rpt-att-prev').onclick = function () {
        if (rptAttPage > 0) { rptAttPage--; rptAttPaint(el); }
      };
      document.getElementById('rpt-att-next').onclick = function () {
        if (rptAttPage + 1 < pages) { rptAttPage++; rptAttPaint(el); }
      };
    }
  }

  function rptLoadSb(el, seq) {
    var s = rptState, isBal = s.type === 'balance';
    var isAtt = s.type === 'attendance' || s.type === 'late';
    if (isAtt) {
      rptFetchAtt().then(function (rows) {
        if (seq !== rptSeq) return;
        rptAttRaw  = (rows || []).map(rptAttRow);
        rptAttRows = rptAttApplyStatus(rptAttRaw);
        rptAttPaint(el);
        var sum = el.querySelector('.rpt-sum');
        if (sum) sum.innerHTML = sum.innerHTML.replace(/จำนวนรายการ: <b>\d+ รายการ<\/b>/,
          'จำนวนรายการ: <b>' + rptAttRows.length + ' รายการ</b>');
      }).catch(function (er) {
        if (seq !== rptSeq) return;
        console.error('[REPORT] njhr_att_report ล้มเหลว:', er);
        var box = document.getElementById('rpt-table');
        if (box) box.innerHTML = '<div class="ep-state ep-state-bad"><b>โหลดรายงานไม่สำเร็จ</b>' +
          '<small class="muted">' + esc(er.message || '') + '</small></div>';
      });
      return;
    }
    (isBal ? rptFetchBalance() : rptFetchLeave()).then(function (rows) {
      if (seq !== rptSeq) return;
      var box = document.getElementById('rpt-table');
      if (!box) return;
      var head, cells, n;
      if (isBal) {
        var pv = rptBalPivot(rows);
        rptBalRows = pv.emps; rptBalTypes = pv.types;
        head = rptBalHead(pv.types);
        cells = pv.emps.map(function (r, i) { return rptBalCells(r, pv.types, i); });
        n = pv.emps.length;
      } else {
        rptLeaveRows = rows;
        head = RPT_LEAVE_HEAD;
        cells = rows.map(rptLeaveCells);
        n = rows.length;
      }
      box.innerHTML = cells.length
        ? '<div class="table-wrap"><table><thead><tr>' + head.map(function (h) { return '<th>' + esc(h) + '</th>'; }).join('') + '</tr></thead><tbody>' +
          cells.map(function (r) { return '<tr>' + r.map(function (c) { return '<td>' + esc(c) + '</td>'; }).join('') + '</tr>'; }).join('') + '</tbody></table></div>'
        : emptyState(rptEmptyMsg());
      var sum = el.querySelector('.rpt-sum');
      if (sum) sum.innerHTML = sum.innerHTML.replace(/จำนวนรายการ: <b>\d+ รายการ<\/b>/,
        'จำนวนรายการ: <b>' + n + ' รายการ</b>');
    }).catch(function (er) {
      if (seq !== rptSeq) return;
      rptLeaveRows = []; rptBalRows = [];
      var box = document.getElementById('rpt-table');
      if (box) box.innerHTML = emptyState('โหลดข้อมูลไม่สำเร็จ');
      var e2 = document.getElementById('rpt-err');
      if (e2) e2.textContent = 'โหลดข้อมูลจาก Supabase ไม่สำเร็จ: ' + (er.message || er);
    });
  }

  function rptExportLeave(btn, isBal) {
    var s = rptState, errEl = document.getElementById('rpt-err');
    var head, cells, n;
    if (isBal) {
      if (!rptBalRows.length) { errEl.textContent = rptEmptyMsg(); return; }
      head = rptBalHead(rptBalTypes);
      cells = rptBalRows.map(function (r, i) { return rptBalCells(r, rptBalTypes, i); });
      n = rptBalRows.length;
    } else {
      if (!rptLeaveRows.length) { errEl.textContent = rptEmptyMsg(); return; }
      head = RPT_LEAVE_HEAD;
      cells = rptLeaveRows.map(rptLeaveCells);
      n = rptLeaveRows.length;
    }
    if (btn.disabled) return;
    var label = btn.innerHTML;
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> กำลังสร้างไฟล์…';

    var deptTxt = s.deptId || 'ทุกแผนก';
    var now = new Date();
    var stamp = rptDateBE(now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate())) +
      ' ' + pad(now.getHours()) + ':' + pad(now.getMinutes());
    var sheetName, fname, title;
    if (isBal) {
      sheetName = 'วันลาคงเหลือ';
      fname = 'รายงานวันลาคงเหลือ_ปี_' + (s.year + 543) + '.xlsx';
      title = [db.settings.companyName, 'รายงานวันลาคงเหลือ',
        'ปีสิทธิ์การลา: ' + (s.year + 543), 'แผนก: ' + deptTxt,
        'สถานะพนักงาน: ' + (({ ACTIVE: 'ปฏิบัติงาน', PROBATION: 'ทดลองงาน', RESIGNED: 'พ้นสภาพ' })[s.empStatus] || 'ทุกสถานะ'),
        'พนักงานทั้งหมด: ' + n + ' คน', 'วันที่ Export: ' + stamp];
    } else {
      sheetName = 'รายงานการลา';
      fname = 'รายงานการลา_' + rptDateBE(s.from).replace(/\//g, '-') + '_ถึง_' + rptDateBE(s.to).replace(/\//g, '-') + '.xlsx';
      var sumD = rptLeaveRows.reduce(function (a2, r) { return a2 + lvNum(r.total_days); }, 0);
      var sumH = rptLeaveRows.reduce(function (a2, r) { return a2 + lvNum(r.hours); }, 0);
      title = [db.settings.companyName, 'รายงานการลา',
        'ช่วงวันที่: ' + rptDateBE(s.from) + ' – ' + rptDateBE(s.to), 'แผนก: ' + deptTxt,
        'ประเภทการลา: ' + (s.leaveType ? lvType(s.leaveType).name : 'ทุกประเภท'),
        'สถานะ: ' + (s.status ? LV_STATUS_TH[s.status] : 'ทุกสถานะ'),
        'จำนวนรายการรวม: ' + n + ' รายการ · จำนวนวันลารวม: ' + (Math.round(sumD * 100) / 100) +
        ' วัน · จำนวนชั่วโมงลารวม: ' + (Math.round(sumH * 100) / 100) + ' ชม.',
        'วันที่ Export: ' + stamp];
    }
    var widths = head.map(function (h) { return Math.min(Math.max(String(h).length + 4, 10), 30); });

    rptLoadZip().then(function () {
      return rptBuildXlsx(sheetName, head, cells, widths, title);
    }).then(function (blob) {
      var a3 = document.createElement('a');
      a3.href = URL.createObjectURL(blob);
      a3.download = rptSafeName(fname.replace('.xlsx', '')) + '.xlsx';
      document.body.appendChild(a3); a3.click(); a3.remove();
      setTimeout(function () { URL.revokeObjectURL(a3.href); }, 4000);
      audit('EXPORT', 'Export ' + sheetName + ' ' + n + ' รายการ');
      toast('ดาวน์โหลด ' + sheetName + ' แล้ว ' + n + ' รายการ');
    }).catch(function (ex) {
      if (errEl) errEl.textContent = 'สร้างไฟล์ Excel ไม่สำเร็จ: ' + ((ex && ex.message) || ex);
    }).then(function () { btn.disabled = false; btn.innerHTML = label; });
  }

  function rptExport(btn) {
    var s = rptState, errEl = document.getElementById('rpt-err');
    if (errEl) errEl.textContent = '';
    if (s.type !== 'balance') {
      if (!s.from || !s.to) { errEl.textContent = 'กรุณาเลือกวันที่เริ่มต้นและวันที่สิ้นสุดให้ครบ'; return; }
      if (s.from > s.to) { errEl.textContent = 'วันที่เริ่มต้นต้องไม่เกินวันที่สิ้นสุด'; return; }
    }
    var isOt = s.type === 'ot', isLv = s.type === 'leave', isBal = s.type === 'balance';
    if (isLv || isBal) { rptExportLeave(btn, isBal); return; }
    // รายงานลงเวลา/มาสาย ใช้แถวชุดเดียวกับที่แสดงบนหน้าจอ (มาจาก Supabase)
    var rows = isOt ? rptOtRows() : rptAttRows;
    if (!rows.length) { errEl.textContent = rptEmptyMsg(); return; }   // ไม่สร้างไฟล์เปล่า
    if (btn.disabled) return;
    var label = btn.innerHTML;
    btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> กำลังสร้างไฟล์…';

    var late = s.type === 'late';
    var sheetName = isOt ? 'รายงาน OT' : (late ? 'รายงานมาสาย' : 'รายงานการลงเวลา');
    var who = s.q ? rptSafeName(s.q) : 'ทุกคน';
    var stName = (!isOt && s.attStatus)
      ? '_' + rptSafeName(EMP_ATT_STATUS[s.attStatus] || s.attStatus) : '';
    var fname = rptSafeName(sheetName) + '_' + rptSafeName(s.deptId || 'ทุกแผนก') + stName + '_' + who +
      '_' + rptDateBE(s.from).replace(/\//g, '-') + '_ถึง_' + rptDateBE(s.to).replace(/\//g, '-') + '.xlsx';

    rptLoadZip().then(function () {
      return isOt
        ? rptBuildXlsx(sheetName, RPT_OT_HEAD_XLS, rows.map(rptOtCellsXls),
            [14, 11, 13, 24, 18, 18, 14, 28, 16, 13, 11, 13, 12, 26, 10, 12, 16, 14, 24])
        : rptBuildXlsx(sheetName, RPT_HEAD, rows.map(rptCells), [13, 10, 26, 22, 9, 9, 14, 14, 12]);
    }).then(function (blob) {
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = fname;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
      audit('EXPORT', 'Export ' + sheetName + ' ' + rows.length + ' รายการ (' + s.from + ' ถึง ' + s.to + ')');
      toast('ดาวน์โหลด ' + sheetName + ' แล้ว ' + rows.length + ' รายการ');
    }).catch(function (ex) {
      if (errEl) errEl.textContent = 'สร้างไฟล์ Excel ไม่สำเร็จ: ' + ((ex && ex.message) || ex);
    }).then(function () { btn.disabled = false; btn.innerHTML = label; });
  }

  var LV_STATUS_TH = { PENDING: 'รออนุมัติ', APPROVED: 'อนุมัติแล้ว', REJECTED: 'ไม่อนุมัติ', CANCELLED: 'ยกเลิก' };

  var OT_STATUS_TH = { PENDING: 'รออนุมัติ', APPROVED: 'อนุมัติแล้ว', REJECTED: 'ไม่อนุมัติ', CANCELLED: 'ยกเลิก' };

  var EMP_STATUS_TH = { ACTIVE: 'ปฏิบัติงาน', PROBATION: 'ทดลองงาน', RESIGNED: 'พ้นสภาพ', SUSPENDED: 'พักงาน' };

  var EMP_ATT_STATUS = { NORMAL: 'ปกติ', LATE: 'มาสาย', ABSENT: 'ขาดงาน', LEAVE: 'ลา', HOLIDAY: 'วันหยุด' };
  /* [108] ป้ายช่วงเวลาลา — ใช้กับคอลัมน์ leave_period ที่ njhr_att_report คืนมา
     'HALF' = ครึ่งวันที่พิสูจน์ช่วงไม่ได้ (ใบเก่าไม่มี metadata) → ไม่เดาว่าเช้าหรือบ่าย */
  var LEAVE_MODE_TH = { FULL: 'เต็มวัน', HALF_AM: 'ครึ่งวันเช้า', HALF_PM: 'ครึ่งวันบ่าย',
                        HOURLY: 'รายชั่วโมง', HALF: 'ครึ่งวัน (ไม่ระบุช่วง)' };
