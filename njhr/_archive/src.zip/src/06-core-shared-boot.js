  /* ================= CORE SHARED (ย้ายมาจาก View Module) =================
     ฟังก์ชันในบล็อกนี้ถูกย้ายเข้ามาโดยไม่แก้เนื้อในแม้แต่ตัวอักษรเดียว
     เหตุผลของแต่ละตัวระบุใน RUNTIME_SPLIT_REPORT.md §Shared Function

       emptyState / statusBadge  (เดิม 07)  — 7 และ 2 chunk อื่นเรียกใช้
       startLiveClock + clockTimer (เดิม 07) — dashboard และ compat เรียกทั้งคู่
       empBE                     (เดิม 08)  — dashboard เรียก จึงข้ามขอบเขต chunk
       shGet/shOf/shTime/shOfAtt/shAttToday (เดิม 12) — dashboard เรียก shAttToday
       shMigrate                 (เดิม 12)  — njhrBootOnce() เรียกตอน boot
       refreshNotifyBadge + _ntUnread (เดิม 13) — njhrStartAfterSession() เรียกตอน boot
                                                  และ refreshMenuBadge() (05) อ่าน _ntUnread
     ตัวแก้ไข Shift (shRender/shMigrateTool/viewShifts) ยังอยู่ใน compat ตามเดิม
     ================================================================= */
  var clockTimer = null;
  var _ntUnread = 0;
  var _docPending = 0;          // Badge "เอกสารของฉัน" — มาจาก njhr_doc_my_pending เท่านั้น

  /* ---------- กลุ่มยกเว้นผู้บริหาร (MANAGING DIRECTOR / SUPER_ADMIN) ----------
     Browser ถามเฉพาะ RPC njhr_hr_exempt_me() ด้วย Session Token ของผู้ใช้ปัจจุบัน
     ห้ามส่ง employee_id จากหน้าจอเพื่อใช้ตัดสินสิทธิ์ — Backend เป็นผู้หา employee_id,
     department_name / position_name / role จาก Session + Database เองทั้งหมด

     ค่านี้เป็นเพียงตัวช่วยฝั่งหน้าจอ (ไม่เปิดกล้อง / เลือกข้อความ)
     สิทธิ์จริงถูกบังคับซ้ำใน njhr_att_punch_exempt() เสมอ ปลอมค่านี้ไม่มีผล */
  var _exCache = { key: '', val: null, loading: null };

  function njExemptKey() { return String(sbToken() || ''); }

  function njExemptReset() { _exCache = { key: '', val: null, loading: null }; }

  /* คืน Promise<boolean> — ถามเซิร์ฟเวอร์ครั้งเดียวต่อ Session แล้วจำไว้ */
  function njExemptCheck() {
    var k = njExemptKey();
    if (!k) return Promise.resolve(false);
    if (_exCache.key === k && _exCache.val !== null) return Promise.resolve(_exCache.val);
    if (_exCache.key === k && _exCache.loading) return _exCache.loading;
    _exCache = { key: k, val: null, loading: null };
    _exCache.loading = sbRpc('njhr_hr_exempt_me', { p_token: k })
      .then(function (v) {
        /* sbCall คืน null เมื่อคำขอถูกยกเลิก — ห้ามตีความว่า "ไม่ใช่ผู้บริหาร" แล้วจำไว้ */
        if (v !== true && v !== false) throw new Error('ตรวจสิทธิ์ยกเว้นไม่สำเร็จ');
        if (_exCache.key === k) { _exCache.val = v; _exCache.loading = null; }
        return v;
      }, function (e) {
        if (_exCache.key === k) _exCache.loading = null;   // ไม่จำค่าเมื่อผิดพลาด กดใหม่แล้วถามซ้ำได้
        throw e;
      });
    return _exCache.loading;
  }


  function emptyState(msg) { return '<div class="empty">' + icon('info') + '<p>' + esc(msg) + '</p></div>'; }
  function statusBadge(st) {
    var map = {
      PENDING: ['รออนุมัติ', 'warn'], APPROVED: ['อนุมัติแล้ว', 'ok'], REJECTED: ['ไม่อนุมัติ', 'bad'],
      CANCELLED: ['ยกเลิกแล้ว', 'mut'], COMPLETED: ['เสร็จสิ้น', 'info'], NEED_MORE_INFO: ['ขอข้อมูลเพิ่ม', 'info'],
      ACTIVE: ['ทำงานอยู่', 'ok'], SUSPENDED: ['พักงาน', 'warn'], RESIGNED: ['ลาออกแล้ว', 'mut'],
      PRESENT: ['ปกติ', 'ok'], LATE: ['มาสาย', 'warn'], DRAFT: ['แบบร่าง', 'mut'],
      CALCULATED: ['คำนวณแล้ว', 'info'], CONFIRMED: ['ยืนยันแล้ว', 'ok'], PAID: ['จ่ายแล้ว', 'ok']
    };
    var m = map[st] || [st, 'mut'];
    return '<span class="badge badge-' + m[1] + '">' + m[0] + '</span>';
  }
  function startLiveClock() {
    clearInterval(clockTimer);
    function tick() {
      var elC = document.getElementById('live-clock');
      if (!elC) { clearInterval(clockTimer); return; }
      var d = new Date();
      elC.textContent = pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
    }
    tick(); clockTimer = setInterval(tick, 1000);
  }
  function empBE(iso) {
    var p2 = String(iso || '').split('-');
    return p2.length === 3 ? p2[2] + '/' + p2[1] + '/' + (parseInt(p2[0], 10) + 543) : '—';
  }
  function shGet(id) { return (db.shifts || []).find(function (x) { return x.id === id; }); }
  function shOf(e) { // อ่านกะของพนักงาน (fallback ปลอดภัย ไม่ error)
    return (e && shGet(e.shiftId)) || (db.shifts && db.shifts[0]) ||
      { id: '', name: 'กะปกติ', start: '08:30', end: '17:30', breakMins: 60, overnight: false, active: true };
  }
  function shTime(sh) { return sh.start + '–' + sh.end + (sh.overnight ? ' (วันถัดไป)' : ''); }
  function shOfAtt(e, att) { return (att && att.shiftId && shGet(att.shiftId)) || shOf(e); }
  function shAttToday(e) { // record สำหรับหน้าลงเวลา: วันนี้ หรือของเมื่อวานที่ยังไม่ปิด (กะข้ามวัน)
    var t = todayISO();
    var att = db.attendance.find(function (a) { return a.empId === e.id && a.date === t; });
    if (!att && shOf(e).overnight) {
      var y = new Date(t + 'T00:00:00');
      y.setDate(y.getDate() - 1);
      var yIso = y.getFullYear() + '-' + ('0' + (y.getMonth() + 1)).slice(-2) + '-' + ('0' + y.getDate()).slice(-2);
      att = db.attendance.find(function (a) { return a.empId === e.id && a.date === yIso && a.in && !a.out; }) || att;
    }
    return att;
  }
  function shMigrate() { // idempotent: รันซ้ำได้ ข้อมูลพนักงานเดิมไม่หาย
    if (!db.shifts) {
      var before = db.employees.length;
      db.shifts = [];
      var seen = {};
      db.employees.forEach(function (e) {
        var str = e.shift || '08:30-17:30';
        if (!seen[str]) {
          var p = str.split('-');
          seen[str] = {
            id: 'SH' + ('0' + (db.shifts.length + 1)).slice(-2),
            name: str === '08:30-17:30' ? 'กะปกติ' : 'กะ ' + str, // กะเดิมของระบบ = "กะปกติ"
            start: p[0] || '08:30', end: p[1] || '17:30', breakMins: 60, overnight: false,
            active: true, updatedAt: nowStamp(), updatedBy: 'migration'
          };
          db.shifts.push(seen[str]);
        }
      });
      if (!db.shifts.length) db.shifts.push({ id: 'SH01', name: 'กะปกติ', start: '08:30', end: '17:30', breakMins: 60, overnight: false, active: true, updatedAt: nowStamp(), updatedBy: 'migration' });
      db.employees.forEach(function (e) { e.shiftId = (seen[e.shift || '08:30-17:30'] || db.shifts[0]).id; });
      if (db.employees.length !== before) throw new Error('shift migration: จำนวนพนักงานเปลี่ยน');
      audit('SHIFT_MIGRATE', 'สร้างกะจากข้อมูลเดิม ' + db.shifts.length + ' กะ / ผูกพนักงาน ' + before + ' คน');
      saveDB();
    }
    if (db.shifts && db.shifts.length) {   // บั๊กเดิม: ถ้าไม่มีกะเลยจะอ่าน db.shifts[0].id ไม่ได้
      db.employees.forEach(function (e) { if (!e.shiftId) e.shiftId = db.shifts[0].id; }); // กันพนักงานตกหล่น
    }
    if (!db.shiftMoves) db.shiftMoves = [];   // ประวัติการย้ายกะ (เพิ่มใหม่ ข้อมูลเดิมไม่กระทบ)
    bumpIdx();
  }
  /* ---------- Badge "เอกสารของฉัน" ----------
     นับจาก njhr_doc_my_pending(p_token) ของจริงใน DB (สร้างใน H2)
     employee_id มาจาก token ฝั่งเซิร์ฟเวอร์ ไม่ส่งจาก browser
     ไม่นับจาก array ใด ๆ ใน browser และไม่เก็บลง localStorage */
  function refreshDocPending() {
    if (!sbToken() || !sbReady()) return Promise.resolve();
    return sbRpcList('njhr_doc_my_pending', { p_token: sbToken() }).then(function (rows) {
      var r = (rows && rows[0]) || {};
      var v = Number(r.pending) || 0;
      if (v === _docPending) return;
      _docPending = v;
      refreshMenuBadge();
    })['catch'](function () { /* โหลดไม่ได้ = ไม่แตะ Badge เดิม */ });
  }

  /* ================= ระบบแจ้งเตือน (ใช้ njhr_notify_* เดิมทั้งหมด) =================
     Production ตรวจแล้ว: publication supabase_realtime ไม่มี public.notifications
     จึงใช้ Polling ตามข้อกำหนด fallback ไม่ใช้ Realtime
     ป้ายแดงทุกจุดอ่านจาก _ntUnread ตัวเดียว (njhr_notify_unread) จึงไม่มีทางนับซ้ำ */
  var NT_BELLS = '#btn-bell, .att-mb-bell, .req-mb-bell';
  var NT_POLL_MS = 45000;
  var _ntTimer = null, _ntBusy = false, _ntSeen = null, _ntPrimed = false;

  function ntBadgeText(n) { return n > 99 ? '99+' : String(n); }

  /* วาดป้ายแดงลงกระดิ่งทุกตัวที่มีอยู่บนหน้าจอขณะนั้น */
  function ntPaintBadges() {
    var v = _ntUnread, txt = ntBadgeText(v);
    var list = document.querySelectorAll(NT_BELLS);
    Array.prototype.forEach.call(list, function (bell) {
      var b = bell.querySelector('.bell-badge');
      if (v > 0) {
        if (b) b.textContent = txt;
        else bell.insertAdjacentHTML('beforeend', '<span class="bell-badge">' + txt + '</span>');
      } else if (b) { b.remove(); }
    });
    /* PWA App Badge — เบราว์เซอร์ที่ไม่รองรับต้องไม่ทำให้พัง */
    try {
      if (navigator.setAppBadge) {
        if (v > 0) navigator.setAppBadge(v)['catch'](function () {});
        else if (navigator.clearAppBadge) navigator.clearAppBadge()['catch'](function () {});
      }
    } catch (e) {}
  }

  /* ---------- เสียงแจ้งเตือน: สร้างจาก WebAudio ในเครื่อง ไม่มีไฟล์ ไม่มี CDN ---------- */
  var _ntAudio = null, _ntAudioOK = false;
  function ntSoundOn() {
    try { return localStorage.getItem('njhr_nt_sound') !== 'off'; } catch (e) { return true; }
  }
  function ntSetSound(on) {
    try { localStorage.setItem('njhr_nt_sound', on ? 'on' : 'off'); } catch (e) {}
    if (on) ntUnlockAudio();
  }
  /* ปลดล็อกหลังผู้ใช้แตะหน้าจอครั้งแรกหรือหลัง Login — ข้อจำกัด Autoplay ของมือถือ */
  function ntUnlockAudio() {
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      if (!_ntAudio) _ntAudio = new AC();
      if (_ntAudio.state === 'suspended') _ntAudio.resume()['catch'](function () {});
      _ntAudioOK = true;
    } catch (e) { _ntAudioOK = false; }
  }
  function ntDing() {
    if (!ntSoundOn() || !_ntAudioOK || !_ntAudio) return;
    try {
      var t = _ntAudio.currentTime, o = _ntAudio.createOscillator(), g = _ntAudio.createGain();
      o.type = 'sine'; o.frequency.setValueAtTime(880, t);
      o.frequency.exponentialRampToValueAtTime(1320, t + 0.08);
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.18, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);
      o.connect(g); g.connect(_ntAudio.destination);
      o.start(t); o.stop(t + 0.36);
    } catch (e) { /* เบราว์เซอร์ไม่อนุญาต = เงียบ ไม่พัง */ }
  }

  /* ---------- ข้อความเด้งด้านบน: หัวข้อ · เนื้อหา · เวลา · กดไปหน้าปลายทาง ---------- */
  function ntTimeText(ts) {
    var m = /T(\d{2}):(\d{2})/.exec(String(ts || ''));
    return m ? m[1] + ':' + m[2] + ' น.' : '';
  }
  function ntToast(item) {
    var wrap = document.getElementById('toasts');
    if (!wrap) return;
    var el = document.createElement('div');
    el.className = 'toast toast-nt';
    el.setAttribute('role', 'status');
    el.innerHTML = '<span class="nt-ic">' + icon('bell') + '</span>' +
      '<div class="nt-body"><b>' + esc(item.title || 'แจ้งเตือนใหม่') + '</b>' +
      (item.body ? '<small>' + esc(item.body) + '</small>' : '') +
      '<i>' + esc(ntTimeText(item.created_at)) + '</i></div>' +
      '<button type="button" class="nt-x" aria-label="ปิด">' + icon('x') + '</button>';
    el.onclick = function (ev) {
      if (ev.target.closest && ev.target.closest('.nt-x')) { el.remove(); return; }
      /* ทำเครื่องหมายอ่านก่อนแล้วค่อยเปิดหน้าปลายทาง */
      if (item.id) {
        sbRpc('njhr_notify_read', { p_token: sbToken(), p_id: item.id })
          ['catch'](function () {})
          .then(function () { refreshNotifyBadge(true); });
      }
      el.remove();
      location.hash = item.link || '#/notifications';
    };
    wrap.appendChild(el);
    setTimeout(function () { el.classList.add('show'); }, 10);
    setTimeout(function () {
      el.classList.remove('show');
      setTimeout(function () { el.remove(); }, 300);
    }, 7000);
  }

  /* ดึงรายการใหม่มาแสดง — เรียกเฉพาะตอนตัวเลขเพิ่มขึ้นจริง จึงไม่ดังซ้ำตอน render */
  function ntAnnounceNew() {
    sbRpc('njhr_notify_list', { p_token: sbToken(), p_limit: 5, p_offset: 0 })
      .then(function (rows) {
        var arr = Array.isArray(rows) ? rows : (rows ? [rows] : []);
        var fresh = [];
        arr.forEach(function (r) {
          if (!r || !r.id || r.is_read) return;
          if (_ntSeen[r.id]) return;
          _ntSeen[r.id] = 1;
          fresh.push(r);
        });
        if (!fresh.length) return;
        ntDing();                               // ดังครั้งเดียวต่อรอบ แม้มีหลายรายการ
        fresh.slice(0, 3).forEach(function (r) { ntToast(r); });
      })['catch'](function () {});
  }

  /* ---------- ตรวจจำนวนที่ยังไม่อ่าน ---------- */
  function refreshNotifyBadge(silent) {
    if (!sbToken() || !sbReady()) return;
    if (_ntBusy) return;                        // กัน RPC ซ้อนกัน
    _ntBusy = true;
    sbRpc('njhr_notify_unread', { p_token: sbToken() }).then(function (n) {
      _ntBusy = false;
      var v = Number(n) || 0;
      var prev = _ntUnread;
      _ntUnread = v;
      ntPaintBadges();
      /* รอบแรกหลัง Login ถือเป็นการตั้งค่าเริ่มต้น ไม่ต้องเด้งของเก่าทั้งกอง */
      if (!_ntPrimed) {
        _ntPrimed = true; _ntSeen = _ntSeen || Object.create(null);
        sbRpc('njhr_notify_list', { p_token: sbToken(), p_limit: 5, p_offset: 0 })
          .then(function (rows) {
            (Array.isArray(rows) ? rows : []).forEach(function (r) { if (r && r.id) _ntSeen[r.id] = 1; });
          })['catch'](function () {});
        return;
      }
      if (!silent && v > prev) ntAnnounceNew();
    })['catch'](function () { _ntBusy = false; /* โหลดไม่ได้ = ไม่แตะ Badge เดิม */ });
  }

  /* ================= REALTIME (Broadcast แบบสัญญาณเปล่า) =================
     ตรวจ Production แล้ว postgres_changes ใช้ไม่ได้:
       · notifications ไม่อยู่ใน publication supabase_realtime
       · RLS = ON แต่ policy = 0 · ระบบใช้ custom token → auth.uid() = NULL
       → เขียน policy จับคู่ user ไม่ได้ · ถ้าใช้ using(true) จะรั่วทั้งระบบ

     จึงใช้ Broadcast แบบ Session-scoped แทน (topic = njhr:s:<SHA-256 ของ session token>)
       · payload = {"t":"nt"} ไม่มีเนื้อหาแจ้งเตือนเลย
       · ได้สัญญาณแล้วจึงเรียก njhr_notify_unread/list ด้วย token ของตัวเอง
       → การตรวจสิทธิ์ยังอยู่ที่ RPC เดิมทุกประการ ไม่มีทางเห็นของคนอื่น

     ใช้ WebSocket ตรง ไม่โหลด supabase-js เพิ่ม (Bundle ไม่โต)
     ล้มเหลวเมื่อใดก็ตาม → Polling 45 วินาทีเดิมยังทำงานเป็น fallback เสมอ */
  /* [RUN-02] Session-scoped topic — เดาไม่ได้ · ผูกกับ session ไม่ใช่ user
     topic = 'njhr:s:' + SHA-256(session token) เป็น hex

     ทำไมไม่ใช้ app_user_id: ใครรู้ UUID ของคนอื่น + มี anon key → join topic นั้นได้
     (private=false ไม่มีการตรวจสิทธิ์ join) — ดู Root Cause ใน RUN-02

     ทำไมปลอดภัยขึ้น: ต้องมี session token ของคนนั้นถึงจะคำนวณ topic ได้
       ซึ่งถ้ามี token ก็เข้าระบบเป็นคนนั้นได้อยู่แล้ว = ไม่ได้เพิ่มความเสี่ยงใหม่
     Logout / revoke / หมดอายุ → Server เลิกส่งให้ topic นั้นทันที (กรองที่ trigger)

     ⚠ ห้ามใช้ raw token เป็น topic เด็ดขาด — ต้อง hash ก่อนเสมอ
       Web Crypto (crypto.subtle) ให้ค่าเดียวกับ pgcrypto digest() ยืนยันแล้ว */
  var RT = { ws: null, tok: '', topic: '', ref: 0, hb: null, retry: 0,
             reconn: null, joined: false, gen: 0, hashing: false };
  var RT_MAX_BACKOFF = 30000;

  function rtHasCrypto() {
    try { return !!(window.crypto && window.crypto.subtle && window.crypto.subtle.digest); }
    catch (e) { return false; }
  }
  /* คืน Promise<string> = hex ของ SHA-256(token) · ล้มเหลว = คืน '' (ใช้ Polling ต่อ) */
  function rtTopicFor(token) {
    if (!token || !rtHasCrypto() || typeof TextEncoder === 'undefined') {
      return Promise.resolve('');
    }
    try {
      var buf = new TextEncoder().encode(String(token));
      return window.crypto.subtle.digest('SHA-256', buf).then(function (d) {
        var b = new Uint8Array(d), s = '';
        for (var i = 0; i < b.length; i++) s += ('0' + b[i].toString(16)).slice(-2);
        return 'njhr:s:' + s;
      })['catch'](function () { return ''; });
    } catch (e) { return Promise.resolve(''); }
  }
  function rtTopic() { return RT.topic; }

  function rtClearTimers() {
    if (RT.hb) { clearInterval(RT.hb); RT.hb = null; }
    if (RT.reconn) { clearTimeout(RT.reconn); RT.reconn = null; }
  }

  /* ปิดการเชื่อมต่อทั้งหมด — ใช้ตอน Logout / Subscribe ใหม่ / ปิดหน้า
     ขึ้น gen ทุกครั้ง → callback ของ socket เก่าที่มาช้าจะถูกทิ้ง (กัน memory leak + ซ้ำซ้อน) */
  function rtStop() {
    RT.gen++;
    rtClearTimers();
    RT.joined = false;
    RT.tok = ''; RT.topic = '';        // [RUN-02] Logout = ทิ้ง topic ของ session นั้น
    RT.hashing = false;
    var w = RT.ws; RT.ws = null;
    if (w) {
      try { w.onopen = w.onmessage = w.onerror = w.onclose = null; } catch (e) {}
      try { w.close(); } catch (e) {}
    }
  }

  function rtSend(obj) {
    try { if (RT.ws && RT.ws.readyState === 1) RT.ws.send(JSON.stringify(obj)); } catch (e) {}
  }

  function rtScheduleReconnect() {
    if (RT.reconn) return;
    RT.retry++;
    var wait = Math.min(1000 * Math.pow(2, Math.min(RT.retry, 5)), RT_MAX_BACKOFF);
    RT.reconn = setTimeout(function () { RT.reconn = null; rtStart(); }, wait);
  }

  function rtStart() {
    var tok = sbToken();
    if (!tok || !sbReady()) return;
    if (typeof WebSocket === 'undefined') return;          // เบราว์เซอร์ไม่รองรับ = ใช้ Polling
    if (!rtHasCrypto()) return;                             // ไม่มี Web Crypto = ใช้ Polling
    if (RT.ws && RT.tok === tok &&
        (RT.ws.readyState === 0 || RT.ws.readyState === 1)) return;   // มีอยู่แล้ว ห้ามซ้ำ
    if (RT.hashing) return;                                 // กำลังคำนวณ topic อยู่ ห้ามซ้อน

    RT.hashing = true;
    rtTopicFor(tok).then(function (topic) {
      RT.hashing = false;
      if (!topic) return;                                   // hash ไม่ได้ = ไม่ subscribe
      if (sbToken() !== tok) return;                        // เปลี่ยน session ระหว่างคำนวณ = ทิ้ง
      rtConnect(tok, topic);
    })['catch'](function () { RT.hashing = false; });
  }

  function rtConnect(tok, topic) {
    rtStop();
    RT.tok = tok; RT.topic = topic;
    var myGen = RT.gen;
    var url;
    try {
      url = String(SB.url).replace(/^http/, 'ws') +
            '/realtime/v1/websocket?apikey=' + encodeURIComponent(SB.key) + '&vsn=1.0.0';
    } catch (e) { return; }

    var w;
    try { w = new WebSocket(url); } catch (e) { rtScheduleReconnect(); return; }
    RT.ws = w;

    w.onopen = function () {
      if (myGen !== RT.gen) { try { w.close(); } catch (e) {} return; }
      RT.retry = 0;
      rtSend({ topic: 'realtime:' + rtTopic(), event: 'phx_join',
               payload: { config: { broadcast: { self: false }, private: false } },
               ref: String(++RT.ref) });
      RT.hb = setInterval(function () {
        if (myGen !== RT.gen) return;
        rtSend({ topic: 'phoenix', event: 'heartbeat', payload: {}, ref: String(++RT.ref) });
      }, 25000);
    };

    w.onmessage = function (ev) {
      if (myGen !== RT.gen) return;
      var m = null;
      try { m = JSON.parse(ev.data); } catch (e) { return; }
      if (!m) return;
      if (m.event === 'phx_reply' && m.topic === 'realtime:' + rtTopic()) {
        RT.joined = !!(m.payload && m.payload.status === 'ok');
        return;
      }
      /* ได้สัญญาณ → ดึงข้อมูลจริงด้วย RPC เดิม (ตรวจสิทธิ์ฝั่งเซิร์ฟเวอร์เหมือนเดิม) */
      if (m.event === 'broadcast') { refreshNotifyBadge(); }
    };

    w.onerror = function () { if (myGen === RT.gen) { rtStop(); rtScheduleReconnect(); } };
    w.onclose = function () {
      if (myGen !== RT.gen) return;
      rtClearTimers(); RT.ws = null; RT.joined = false;
      /* ต่อใหม่เฉพาะเมื่อยังเป็น session เดิม — Logout แล้วห้ามต่อกลับ */
      if (sbToken() && sbToken() === tok) rtScheduleReconnect();
    };
  }

  /* ================= WEB PUSH (ทางเลือก B) =================
     ตรวจ Production แล้ว pg_net / pg_cron ไม่ได้ติดตั้ง → DB ยิง HTTP เองไม่ได้
     จึงใช้ dispatch จากฝั่ง client ที่ออนไลน์อยู่ (piggyback บน ntTick)
     Edge Function njhr-push-dispatch ตรวจ token ผู้เรียกก่อนเสมอ
     และไม่คืนข้อมูลของใครกลับมา — คืนแค่จำนวน

     Push ที่ส่งออกไม่มี payload → ไม่มีข้อมูลแจ้งเตือนบนเส้นทาง Push
     ผู้ใช้กดแล้วเปิดแอปไปอ่านด้วย njhr_notify_list ของตัวเอง

     ห้ามขอสิทธิ์อัตโนมัติ — ต้องให้ผู้ใช้กดจากหน้าการแจ้งเตือนเท่านั้น */
  var PUSH = { busy: false, lastDispatch: 0, subscribing: false };
  var PUSH_DISPATCH_GAP = 20000;    // กันยิง dispatch ถี่เกินจำเป็น

  function pushSupported() {
    try {
      return !!(navigator.serviceWorker && window.PushManager &&
                window.Notification && window.isSecureContext);
    } catch (e) { return false; }
  }
  function pushPermission() {
    try { return (window.Notification && Notification.permission) || 'default'; }
    catch (e) { return 'default'; }
  }
  function pushVapidKey() {
    var k = window.NJHR_VAPID_PUBLIC_KEY || '';
    return (typeof k === 'string' && k.length > 40) ? k : '';
  }
  function pushB64ToU8(b64) {
    var s = String(b64).replace(/-/g, '+').replace(/_/g, '/');
    s += '='.repeat((4 - (s.length % 4)) % 4);
    var raw = atob(s), out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }

  /* ขอสิทธิ์ + สมัครรับ Push — เรียกจากปุ่มที่ผู้ใช้กดเท่านั้น
     คืน Promise<{ok:boolean, reason:string}> */
  function pushEnable() {
    if (!pushSupported()) return Promise.resolve({ ok: false, reason: 'อุปกรณ์/เบราว์เซอร์นี้ไม่รองรับการแจ้งเตือนแบบ Push' });
    if (!pushVapidKey()) return Promise.resolve({ ok: false, reason: 'ระบบยังไม่ได้ตั้งค่า Push (VAPID)' });
    if (!sbToken()) return Promise.resolve({ ok: false, reason: 'กรุณาเข้าสู่ระบบก่อน' });
    if (PUSH.subscribing) return Promise.resolve({ ok: false, reason: 'กำลังดำเนินการอยู่' });
    PUSH.subscribing = true;
    return Promise.resolve()
      .then(function () { return Notification.requestPermission(); })
      .then(function (perm) {
        if (perm !== 'granted') throw new Error('คุณยังไม่ได้อนุญาตการแจ้งเตือน');
        return navigator.serviceWorker.ready;
      })
      .then(function (reg) {
        return reg.pushManager.getSubscription().then(function (sub) {
          if (sub) return sub;
          return reg.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: pushB64ToU8(pushVapidKey())
          });
        });
      })
      .then(function (sub) {
        var j = sub.toJSON() || {}, keys = j.keys || {};
        if (!j.endpoint || !keys.p256dh || !keys.auth) throw new Error('ข้อมูลการสมัครรับไม่ครบ');
        var ua = '';
        try { ua = String(navigator.userAgent || '').slice(0, 300); } catch (e) {}
        return sbRpc('njhr_push_subscribe', {
          p_token: sbToken(), p_endpoint: j.endpoint,
          p_p256dh: keys.p256dh, p_auth: keys.auth,
          p_user_agent: ua, p_device: /Mobi|Android|iPhone/i.test(ua) ? 'Mobile' : 'Desktop'
        });
      })
      .then(function () { PUSH.subscribing = false; return { ok: true, reason: '' }; })
      ['catch'](function (e) {
        PUSH.subscribing = false;
        return { ok: false, reason: (e && e.message) || 'เปิดการแจ้งเตือนไม่สำเร็จ' };
      });
  }

  /* ยกเลิกรับ Push บนอุปกรณ์นี้ — เรียกตอน Logout และตอนผู้ใช้กดปิดเอง */
  function pushDisable() {
    if (!pushSupported()) return Promise.resolve();
    var tk = sbToken();
    return navigator.serviceWorker.ready
      .then(function (reg) { return reg.pushManager.getSubscription(); })
      .then(function (sub) {
        if (!sub) return null;
        var ep = sub.endpoint;
        return sub.unsubscribe()['catch'](function () {}).then(function () {
          /* แจ้งเซิร์ฟเวอร์ด้วย token เดิม (ต้องทำก่อน token ถูกล้าง) */
          if (tk && ep) {
            return sbRpc('njhr_push_unsubscribe', { p_token: tk, p_endpoint: ep })
              ['catch'](function () {});
          }
        });
      })['catch'](function () {});
  }

  /* อุปกรณ์นี้สมัครรับอยู่ไหม (ไม่ขอสิทธิ์ ไม่มี side effect) */
  function pushIsSubscribed() {
    if (!pushSupported() || pushPermission() !== 'granted') return Promise.resolve(false);
    return navigator.serviceWorker.ready
      .then(function (reg) { return reg.pushManager.getSubscription(); })
      .then(function (sub) { return !!sub; })['catch'](function () { return false; });
  }

  /* [สำคัญ] ปิดช่อง "สลับผู้ใช้บนเครื่องเดิม"
     ถ้า USER A เคยเปิด Push แล้ว Logout ตอนออฟไลน์ → njhr_push_unsubscribe ไปไม่ถึง
     แถวใน njhr_push_subs จะยังผูกกับ A อยู่ · พอ B เข้าใช้เครื่องเดิม
     B อาจได้รับ Push ของ A

     pushSync() เรียกทุกครั้งที่เริ่มใช้งาน (ntStartPoll):
       ถ้าเบราว์เซอร์มี subscription อยู่แล้ว และสิทธิ์เป็น granted
       → ส่ง njhr_push_subscribe ด้วย token ปัจจุบัน
       → RPC ทำ on conflict(endpoint) do update set app_user_id = <ผู้ใช้ปัจจุบัน>
       → endpoint นี้ย้ายมาผูกกับผู้ใช้คนใหม่ทันที A ไม่ได้รับอีก
     ไม่ขอสิทธิ์ใหม่ · ไม่แสดง prompt · ล้มเหลวเงียบ */
  function pushSync() {
    if (!pushSupported() || pushPermission() !== 'granted' || !sbToken()) return;
    navigator.serviceWorker.ready
      .then(function (reg) { return reg.pushManager.getSubscription(); })
      .then(function (sub) {
        if (!sub) return;
        var j = sub.toJSON() || {}, keys = j.keys || {};
        if (!j.endpoint || !keys.p256dh || !keys.auth) return;
        var ua = '';
        try { ua = String(navigator.userAgent || '').slice(0, 300); } catch (e) {}
        return sbRpc('njhr_push_subscribe', {
          p_token: sbToken(), p_endpoint: j.endpoint,
          p_p256dh: keys.p256dh, p_auth: keys.auth,
          p_user_agent: ua, p_device: /Mobi|Android|iPhone/i.test(ua) ? 'Mobile' : 'Desktop'
        });
      })['catch'](function () {});
  }

  /* piggyback: ให้ client ที่ออนไลน์อยู่ช่วยผลัก Push ที่ค้างคิว
     ไม่บล็อก UI · ล้มเหลวเงียบ · เว้นช่วงกันยิงถี่ */
  function pushDispatch() {
    if (!sbToken() || !sbReady()) return;
    if (PUSH.busy) return;
    var now = Date.now();
    if (now - PUSH.lastDispatch < PUSH_DISPATCH_GAP) return;
    PUSH.busy = true; PUSH.lastDispatch = now;
    var idle = window.requestIdleCallback || function (fn) { return setTimeout(fn, 0); };
    idle(function () {
      try {
        fetch(SB.url + '/functions/v1/njhr-push-dispatch', {
          method: 'POST', keepalive: true,
          headers: { 'apikey': SB.key, 'Authorization': 'Bearer ' + SB.key,
                     'Content-Type': 'application/json' },
          body: JSON.stringify({ token: sbToken() })
        })['catch'](function () {}).then(function () { PUSH.busy = false; });
      } catch (e) { PUSH.busy = false; }
    });
  }

  /* ---------- Polling + เหตุการณ์กลับเข้าแอป ---------- */
  function ntTick() {
    if (!sbToken() || !sbReady()) { ntStopPoll(); return; }
    if (document.visibilityState !== 'visible') return;   // อยู่เบื้องหลัง = ไม่ยิง
    refreshNotifyBadge();
    pushDispatch();          // [Push B] ช่วยผลักคิว Push ที่ค้าง (ล้มเหลวเงียบ)
  }
  function ntStartPoll() {
    rtStart();                                   // [Realtime] Login/กลับเข้าแอป = subscribe
    pushSync();                                  // [Push] ย้าย subscription เดิมมาผูกผู้ใช้ปัจจุบัน
    if (_ntTimer) return;
    _ntSeen = _ntSeen || Object.create(null);
    _ntTimer = setInterval(ntTick, NT_POLL_MS);  // คง Polling ไว้เป็น fallback เสมอ
  }
  function ntStopPoll() {
    if (_ntTimer) { clearInterval(_ntTimer); _ntTimer = null; }
  }
  function ntReset() {                          // ออกจากระบบ
    try { pushDisable(); } catch (e) {}          // [Push] ยกเลิกรับ Push บนอุปกรณ์นี้
    rtStop();                                    // [Realtime] Logout = unsubscribe + ล้าง timer
    ntStopPoll();
    _ntUnread = 0; _ntSeen = null; _ntPrimed = false; _ntBusy = false;
    ntPaintBadges();
  }
  function ntWake() {
    if (!sbToken() || !sbReady()) return;
    if (document.visibilityState !== 'visible') return;
    ntStartPoll();
    refreshNotifyBadge();
  }
  document.addEventListener('visibilitychange', ntWake);
  window.addEventListener('focus', ntWake);
  window.addEventListener('online', ntWake);
  /* [Realtime] เน็ตหลุด = ปิด socket ทิ้ง · กลับมาแล้ว ntWake จะ subscribe ใหม่เอง
     ปิดหน้า/ปิดแท็บ = ปิด socket กัน connection ค้างฝั่งเซิร์ฟเวอร์ */
  window.addEventListener('offline', rtStop);
  window.addEventListener('pagehide', rtStop);
  /* ปลดล็อกเสียงหลังผู้ใช้แตะหน้าจอครั้งแรก (ครั้งเดียวพอ) */
  ['pointerdown', 'keydown'].forEach(function (ev) {
    window.addEventListener(ev, function once() {
      ntUnlockAudio();
      window.removeEventListener(ev, once);
    }, { once: true });
  });

  NJHR.notify = {
    refresh: refreshNotifyBadge, paint: ntPaintBadges,
    start: ntStartPoll, stop: ntStopPoll, reset: ntReset,
    soundOn: ntSoundOn, setSound: ntSetSound, unlockAudio: ntUnlockAudio,
    badgeText: ntBadgeText,
    /* [Realtime] สำหรับตรวจสอบ/ทดสอบ — ไม่มีผลต่อ Logic */
    rtStart: rtStart, rtStop: rtStop,
    /* [Push] เรียกจากปุ่มที่ผู้ใช้กดเท่านั้น — ห้ามขอสิทธิ์อัตโนมัติ */
    pushSupported: pushSupported, pushPermission: pushPermission,
    pushEnable: pushEnable, pushDisable: pushDisable,
    pushIsSubscribed: pushIsSubscribed, pushSync: pushSync,
    rtState: function () {
      /* ไม่คืน topic เต็มและไม่คืน token — คืนแค่ 8 ตัวแรกไว้ตรวจสอบ */
      return { connected: !!(RT.ws && RT.ws.readyState === 1), joined: RT.joined,
               topicHint: RT.topic ? RT.topic.slice(0, 16) + '…' : '',
               retry: RT.retry };
    }
  };


  /* ---------- Compatibility Adapter: สถานะที่ Core และ Feature Chunk เขียนร่วมกัน ----------
     3 ตัวนี้ถูกกำหนดค่าใหม่ (reassign) หลัง chunk โหลดไปแล้ว
     การส่งเข้า chunk แบบคัดลอกค่าจะได้ค่าค้าง จึงต้องอ่าน/เขียนผ่าน accessor ตัวเดียวกัน
     รายการจุดที่แก้ใน Feature Chunk ระบุครบใน RUNTIME_SPLIT_REPORT.md */
  Object.defineProperty(NJHR.state, 'sbUser',    { get: function () { return sbUser; } });
  Object.defineProperty(NJHR.state, 'lvPending', { get: function () { return _lvPending; }, set: function (v) { _lvPending = v; } });
  Object.defineProperty(NJHR.state, 'ntUnread',  { get: function () { return _ntUnread; }, set: function (v) { _ntUnread = v; } });
  Object.defineProperty(NJHR.state, 'docPending', { get: function () { return _docPending; }, set: function (v) { _docPending = v; } });
  NJHR.layout.refreshDocPending = refreshDocPending;

  /* ================= INIT ================= */
  /* [Error Monitoring] เริ่มหลัง Config พร้อม · ไม่โหลดอะไรเพิ่ม · ล้มเหลวเงียบ
     วางไว้ก่อน hashchange เพื่อให้จับ error ตั้งแต่ render แรก */
  try {
    njErrInit();
    NJHR.errReport = function (kind, source, err, extra) {
      try { njErrReport(kind, source, err, extra); } catch (e) {}
    };
  } catch (e) {}

  /* [ข้อ 5] ออกจากหน้าลงเวลาขณะ Face Attendance เปิดอยู่ = ต้อง Cleanup ทันที
     cancelAttendance() ปิดเฉพาะโหมด ATTENDANCE (closeCam + cancelAnimationFrame +
     clearWatch + invalidate attempt id) — Face Login อยู่คนละโหมด จึงไม่ถูกปิดโดยไม่ตั้งใจ
     ต้องทำ "ก่อน" render() เพื่อไม่ให้กล้อง/GPS ทำงานค้างข้ามหน้า */
  window.addEventListener('hashchange', function () {
    try {
      if (window.NJHRFace && window.NJHRFace.cancelAttendance) window.NJHRFace.cancelAttendance();
    } catch (e) {}
    render();
  });
  window.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && document.body.classList.contains('sidebar-open') && window.njhrCloseDrawer) window.njhrCloseDrawer();
  });
  window.addEventListener('resize', function () {
    if (window.innerWidth > 900 && document.body.classList.contains('sidebar-open') && window.njhrCloseDrawer) window.njhrCloseDrawer();
  });
  /* เริ่มระบบเมื่อ DOM พร้อม
     index.html โหลด app.js แบบ dynamic script (async = false) แทน document.write
     สคริปต์แบบนี้ **ไม่บล็อก DOMContentLoaded** จึงมีโอกาสที่ event ยิงไปก่อน app.js ทำงาน
     ต้องตรวจ document.readyState ด้วย ไม่งั้นระบบจะไม่เริ่มเลยและได้หน้าจอว่าง
     ตัวแปร njhrBooted กันไม่ให้เริ่มซ้ำสองรอบ */
  var njhrBooted = false;
  function njhrBootOnce() {
    if (njhrBooted) return;
    njhrBooted = true;
    loadDB(); fillDbGaps(); loadSession(); loadUI(); shMigrate(); njFixCompanyName();
    holLoad();          // อุ่นแคชวันหยุดตั้งแต่เปิดแอป ให้ตัวคำนวณแบบ synchronous ใช้ได้ทันที
    if (storageBlocked) setTimeout(function () {
      toast('เบราว์เซอร์บล็อกการบันทึกข้อมูลในเครื่อง — ใช้งานได้ปกติ แต่ Refresh แล้วข้อมูลทดลองจะรีเซ็ต', 'info');
    }, 600);
    njhrBoot();
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', njhrBootOnce);
  } else {
    njhrBootOnce();                       // DOM พร้อมแล้ว เริ่มทันที
  }

  // ลำดับเริ่มระบบ: อ่านค่า Supabase → ทดสอบการเชื่อมต่อ → เข้าสู่ระบบ/ตรวจ session → แสดงหน้าหลัก
  // แยกเป็นฟังก์ชันเพื่อให้ปุ่ม "ลองเชื่อมต่ออีกครั้ง" เรียกซ้ำได้โดยไม่ Refresh
  // (event listener ผูกไว้ระดับโมดูลแล้ว เรียกซ้ำจึงไม่เกิด listener ซ้ำ)
  function njhrBoot() {
    /* PERF: เดิมเป็น sbConnCheck() → sbSessionCheck() เรียงกันเป็นทอด
       บนเน็ตจริงจึงเสียเวลา 2 รอบเดินทางก่อนเห็นหน้าจอ
       เปลี่ยนเป็นยิงขนานกันเมื่อมี token — เงื่อนไขการผ่านเหมือนเดิมทุกประการ
       คือต้องผ่านทั้ง healthcheck และ session_check ก่อน render
       ต่างกันแค่เวลารวมลดจาก (A + B) เหลือ max(A, B) */
    var hasToken = sbToken() && sbReady();
    if (!hasToken) { sbConnCheck().then(njhrStart, renderConnError); return; }

    var connErr = null, sessErr = null, done = 0;
    function finish() {
      if (++done < 2) return;
      if (connErr) { renderConnError(connErr); return; }     // ปัญหาเชื่อมต่อมาก่อนเสมอ
      if (sessErr) {                                          // เชื่อมต่อได้ แต่ session ใช้ไม่ได้
        sbSetToken(''); sbClearUser(); session = null; saveSession();
        if (sessErr.message !== 'NO_SESSION') sbLoginMsg = sessErr.message;
        renderLogin();
        return;
      }
      njhrStartAfterSession();
    }
    sbConnCheck().then(function () { connErr = null; }, function (e) { connErr = e; }).then(finish);
    sbSessionCheck().then(function () { sessErr = null; }, function (e) { sessErr = e; }).then(finish);
  }
  /* ไม่มี token — เส้นทางเดิมทุกประการ */
  function njhrStart() {
    if (session && session.src === 'supabase') {
      session = null; saveSession(); sbClearUser();   // ไม่มี token = ไม่ถือว่ามีสิทธิ์
    }
    // ถ้าต้อง set hash ให้ hashchange เป็นผู้เรียก render (กัน render ซ้ำ 2 รอบ)
    if (!location.hash) location.hash = session ? '#/dashboard' : '#/login';
    else render();
  }

  /* มี token และผ่านทั้ง healthcheck + session_check แล้ว */
  function njhrStartAfterSession() {
    /* เปิดแอปด้วย session เดิม = ถือเป็นการเข้าใช้งานครั้งใหม่ของเครื่องนี้
       จึงนับรออนุมัติครบสามประเภทจาก Supabase และ Hydrate ตั้งค่าลง db.settings หนึ่งครั้ง */
    render(); refreshPendingAll(); refreshNotifyBadge(); refreshDocPending(); hydrateSettings();
    ntStartPoll(); ntUnlockAudio();   // เริ่มตรวจแจ้งเตือน + ปลดล็อกเสียงหลัง Login
    if (!location.hash) location.hash = session ? '#/dashboard' : '#/login';
  }
