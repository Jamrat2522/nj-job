# เปลี่ยนรูปแบบวันที่เป็น DD/MM/YYYY (ปี ค.ศ.)

Build: **`njhr-v2-11c34f35`** · ก่อนหน้า **`njhr-v2-9ff9d43b`**

## 1. ตัวแปลงกลางตัวเดียวของระบบ

เพิ่ม `fmtDateDMY()` ไว้ที่ **`src/01-core-icons-utils.js`** (runtime/core.js) ที่เดียว
ทุกหน้าในขอบเขตเรียกตัวนี้ตัวเดียว จึงไม่มีทางแสดงไม่ตรงกัน

```js
function fmtDateDMY(v) {
  var p = String(v == null ? '' : v).slice(0, 10).split('-');
  if (p.length !== 3) return '—';
  var y = parseInt(p[0], 10), m = parseInt(p[1], 10), d = parseInt(p[2], 10);
  if (!isFinite(y) || !isFinite(m) || !isFinite(d)) return '—';
  return pad(d) + '/' + pad(m) + '/' + y;
}
```

**เรื่อง Timezone** — ตัดสตริงตรง ๆ ด้วย `slice(0, 10)` **ไม่ผ่าน `new Date()` เลย**
วันที่จึงไม่มีทางเลื่อน ±1 วัน รับได้ทั้ง `'2026-08-11'` และ `'2026-08-11T17:00:00Z'`
(ค่าหลังนี้ถ้าใช้ `new Date()` จะกลายเป็น 12 ส.ค. ตามเวลาไทย — จึงไม่ใช้)

`pad()` เป็นฟังก์ชันเดิมในไฟล์เดียวกัน จึงได้ 2 หลักเสมอ เช่น `01/08/2026`

## 2. จุดที่เปลี่ยน (แสดงผลอย่างเดียว)

| ขอบเขตที่สั่ง | ไฟล์ · ฟังก์ชัน | เดิม → ใหม่ |
|---|---|---|
| 1. ลางาน / คำขอลาของฉัน (Desktop) | `34` · `lvDeskRow()` | `fmtDate` → `fmtDateDMY` |
| 1. ลางาน (Mobile การ์ด) | `34` · `leaveCard()` | `fmtDate` → `fmtDateDMY` |
| 2. OT / คำขอ OT ของฉัน (Desktop) | `35` · `otDeskRow()` | `fmtDate` → `fmtDateDMY` |
| 2. OT (Mobile การ์ด) | `35` · `viewOT()` การ์ด `.only-mobile` | `fmtDate` → `fmtDateDMY` |
| 3–4. รายการคำขอลา+OT (Mobile `#/requests`) | `34` · `reqThaiDate()` | เปลี่ยนไส้ในเป็น `return fmtDateDMY(v)` |
| 3–4. ประวัติลางานและ OT (`#/req-history`) | `34` · `rhRender()` | `empBE` → `fmtDateDMY` |
| 4. Modal รายละเอียด OT | `44` · `rhOtHtml()` | `empBE` → `fmtDateDMY` |
| 4. รายการงาน OT ใน Timeline | `23` · `otDMY()` | เปลี่ยนไส้ในเป็น `return fmtDateDMY(iso)` |
| 5. REPORT ลางาน (ตาราง + Excel) | `37` · `rptmLeaveCells()` | `fmtDate` → `fmtDateDMY` |
| 6. REPORT OT (ตาราง + Excel) | `37` · `rptmOtCells()` | `fmtDate` → `fmtDateDMY` |
| 5–6. บรรทัดสรุปช่วงวันที่ | `37` · `rptmPaint()` | `rptDateBE` → `fmtDateDMY` |
| 5–6. ชื่อไฟล์ Excel | `37` · `rptmExport()` | `rptDateBE` → `fmtDateDMY` |

`rptmLeaveCells()` / `rptmOtCells()` เป็นฟังก์ชันเดียวที่ป้อนทั้ง **ตารางบนหน้าจอ**
และ **ไฟล์ Excel** วันที่ในไฟล์ Export จึงเป็น `DD/MM/YYYY` ตรงกับตารางโดยโครงสร้าง

## 3. Modal รายละเอียดใบลา

`rhLeaveHtml()` ใน `src/44-view-request-detail.js` และ `lvShowTimeline()` ใน `src/34`
**ไม่มีการแสดงวันที่ของใบลาอยู่แล้ว** (แสดงเลขที่คำขอ · ประเภท · ผู้ยื่น · สถานะ ·
เหตุผล · ไฟล์แนบ · Timeline การอนุมัติ) จึงไม่มีอะไรต้องแก้ ไม่ได้เพิ่มฟิลด์ใหม่

## 4. สิ่งที่ไม่แตะ

| รายการ | สถานะ |
|---|---|
| `fmtDate()` เดิม | คงอยู่ไม่แก้ — ยังใช้ที่ Dashboard · ลงเวลา · ปฏิทิน · เงินเดือน · พนักงาน · เอกสาร HR (นอกขอบเขต) |
| `empBE()` · `rptDateBE()` · `fmtMonthYear()` | คงอยู่ไม่แก้ — ยังใช้ที่หน้าอื่น |
| SQL · RPC · ชนิดข้อมูล DATE/TIMESTAMP | ไม่แตะเลย |
| ค่าที่ส่งไป RPC (`p_from` · `p_to`) | ยังเป็น ISO `YYYY-MM-DD` |
| `<input type="date">` | ยังเก็บค่า ISO ตามมาตรฐาน HTML |
| การกรอง · ค้นหา · เรียงลำดับ | ไม่แตะ — เรียงด้วย `created_at` / `start_date` ดิบเหมือนเดิม |
| การยื่นลา · ยื่น OT · Workflow อนุมัติ/ยกเลิก | ไม่แตะ |
| CSS | `src/css/styles.css` และ `mobile.css` **diff 0 บรรทัด** |
| โครงสร้างหน้า · ขนาดตาราง | ไม่เปลี่ยน — แก้เฉพาะค่าข้อความในเซลล์เดิม |

## 5. ผลตรวจสอบ

| ชุด | ผล |
|---|---|
| `node build.js --check` | ตรงกัน — deploy = src |
| `node harness/check-all-js.js` | CHECK PASSED · DEPLOY_MD5 39 ค่า |
| `node harness/date_format_test.js .` | **PASS 45 · FAIL 0** |
| `node harness/desk_table_test.js .` | PASS 48 · FAIL 0 |
| `node harness/report_menu_test.js .` | PASS 61 · FAIL 0 |
| `node harness/dash_leave_test.js .` | PASS 27 · FAIL 0 |
| `node harness/dash_leave_xcheck.js .` | PASS 8 · FAIL 0 |
| `node harness/desk_table_mobile_diff.js .` | PASS 6 · FAIL 0 |

### `date_format_test.js` — ชุดใหม่ ครอบคลุมทุกข้อที่สั่ง

**ตัวแปลงกลาง** (14 เคส) — ดึงโค้ด `fmtDateDMY` ออกจากไฟล์จริงมารันตรง ๆ

| กรณี | ผล |
|---|---|
| `2026-08-11` | `11/08/2026` |
| `2026-08-01` (วัน 1 หลัก) | `01/08/2026` |
| `2026-01-05` (เดือน 1 หลัก) | `05/01/2026` |
| `2026-12-31` · `2026-01-01` | `31/12/2026` · `01/01/2026` |
| `2026-08-11T00:00:00Z` | `11/08/2026` — ไม่ถอย 1 วัน |
| `2026-08-11T23:59:59+07:00` | `11/08/2026` — ไม่บวก 1 วัน |
| `2026-08-11T17:00:00Z` (= เที่ยงคืนไทยวันถัดไป) | `11/08/2026` — **ไม่เลื่อน** |
| `''` · `null` · `undefined` | `—` |
| ประกาศไว้ที่เดียวใน core · ไม่ใช้ `new Date()` | ยืนยันจากไฟล์จริง |

**หน้าจอจริง** — โหลด chunk ที่ build แล้วลง jsdom

| หน้า | ตรวจ | ผล |
|---|---|---|
| OT Desktop | เซลล์วันที่ในตาราง | `11/08/2026` |
| OT Mobile | การ์ด `.only-mobile` | `11/08/2026` |
| ลางาน Desktop | ช่วงวันที่ | `10/08/2026 – 12/08/2026` |
| ลางาน Mobile | ช่วงวันที่ | `10/08/2026 – 12/08/2026` |
| รายการคำขอ Mobile (`#/requests`) | วันที่บนแถว | `10/08/2026 · 12/08/2026` |
| Modal รายละเอียด OT | วันที่ทำ OT | `11/08/2026` |
| REPORT ลางาน | คอลัมน์วันที่ | `10/08/2026 – 12/08/2026` |
| REPORT ลางาน Excel | แถวเดียวกับตาราง | `10/08/2026 – 12/08/2026` |
| REPORT OT | คอลัมน์วันที่ | `11/08/2026` |
| REPORT OT Excel | แถวเดียวกับตาราง | `11/08/2026` |

ทุกหน้าข้างต้นตรวจซ้ำว่า **ไม่เหลือชื่อเดือนไทย** (`ส.ค.` ฯลฯ) และ **ไม่เหลือปี พ.ศ.** (`25xx`)
รวมถึงในเนื้อไฟล์ Excel ด้วย

**ไม่กระทบการทำงานเดิม**

- เปลี่ยนตัวกรอง "วันที่เริ่มต้น" แล้วตรวจ payload ที่ส่งไป RPC → `p_from = "2026-08-01"` (ISO)
- `<input type="date">` ยังเก็บ `2026-08-01`
- ตรวจว่าไฟล์ในขอบเขตทั้ง 5 ไฟล์ไม่เหลือการเรียก `fmtDate` / `empBE` / `rptDateBE` แล้ว

### `desk_table_mobile_diff.js` — ปรับให้สะท้อนงานรอบนี้

เดิมพิสูจน์ว่า "การ์ดมือถือเหมือนเดิมทุกไบต์" ตอนนี้รูปแบบวันที่เปลี่ยนโดยเจตนา
จึงเปลี่ยนเป็นพิสูจน์ 2 เรื่องแทน — ทั้งคู่ผ่าน

1. HTML การ์ดมือถือ **เหมือนเดิมทุกไบต์เมื่อแทนวันที่ด้วย token** (ยาว 1,147 / 1,154 อักขระ)
   → ไม่มีอะไรบนมือถือเปลี่ยนนอกจากรูปแบบวันที่
2. การ์ดมือถือใช้ `DD/MM/YYYY` แล้ว และไม่เหลือ พ.ศ./เดือนไทย

### ข้อจำกัด

ยังไม่ได้ทดสอบกับ Production จริงและถ่าย Screenshot ไม่ได้ (สภาพแวดล้อม build บล็อก
การดาวน์โหลด Chromium) การทดสอบทั้งหมดรัน chunk ที่ build แล้วจริงบน jsdom

## 6. ไฟล์ที่เปลี่ยน

**ต้นทาง 6 ไฟล์** `src/01-core-icons-utils.js` · `src/23-shared-requests.js` ·
`src/34-view-requests-leave.js` · `src/35-view-ot.js` · `src/37-view-report-menu.js` ·
`src/44-view-request-detail.js`

**Deploy 10 ไฟล์** `asset-manifest.js` · `config.js` · `index.html` · `sw.js` ·
`runtime/core.js` · `runtime/shared/requests.js` · `views/leave/main.js` ·
`views/leave/detail.js` · `views/ot/main.js` · `views/reports/menu.js`

อีก 29 ไฟล์ MD5 เท่าเดิม รวมถึง `styles.css` · `mobile.css` · `compat/app-legacy.js` ·
`views/dashboard.js` · `views/attendance/report.js`

## 7. การย้อนกลับ

`rollback/before_date_dmy/` พร้อม `ROLLBACK.md` — คัดลอก `src/` 6 ไฟล์ทับของเดิม
แล้วรัน `node build.js` ไม่ต้องย้อนฐานข้อมูล
