# แก้การ์ด "คำขอลาล่าสุด" บน Dashboard

Build: **`njhr-v2-9ff9d43b`** · ก่อนหน้า **`njhr-v2-05a9f65a`**

## 1. สาเหตุจริง (ยืนยันจากโค้ด)

**ไฟล์** `src/07-view-dashboard.js` · **ฟังก์ชัน** `dashAdmin()`

โค้ดเดิม 2 จุด

```js
// จุดที่ 1 — แหล่งข้อมูล
var recentLeaves = db.leaves.slice()
  .sort(function (a, b) { return b.createdAt.localeCompare(a.createdAt); })
  .slice(0, 5);

// จุดที่ 2 — เรนเดอร์
(recentLeaves.length ? '<div class="list">' + recentLeaves.map(...) + '</div>'
                     : emptyState('ยังไม่มีคำขอลา'))
```

`db.leaves` คือ **localStorage** ไม่ใช่ Supabase — ยืนยันจาก `src/02-store.js`

| หลักฐาน | บรรทัด | เนื้อหา |
|---|---:|---|
| คีย์ที่เก็บ | 3 | `var DB_KEY = 'njhr_db_v3'` |
| อ่าน | 60 | `var raw = lsGet(DB_KEY)` → `localStorage.getItem` |
| เขียน | 90 | `function saveDB() { ... lsSet(DB_KEY, JSON.stringify(db)) }` |
| โครงว่าง | 30 | `function emptyDB()` คืน `leaves: []` |

**บน Production `db.leaves` ไม่เคยถูกเติมจาก Supabase** — ตรวจทั้งโปรเจกต์แล้วไม่มีจุดใดเขียน
`db.leaves` จากผลลัพธ์ RPC เลย (`src/34-view-requests-leave.js` บรรทัด 17 ระบุไว้เองว่า
"ไม่อ่านและไม่เขียน `db.leaves` / `db.balances` / `db.leaveTypes` อีกต่อไป")

ผลคือ `recentLeaves.length === 0` เสมอ → แสดง `emptyState('ยังไม่มีคำขอลา')` ทุกครั้ง
แม้ใน Supabase จะมีคำขอลาอยู่จริง

อาการเดียวกันนี้ยังปรากฏบน KPI ใบเดียวกัน (`พนักงานทั้งหมด 0` ในภาพหน้าจอ) ซึ่งอ่าน
`db.employees` เช่นกัน — **แต่อยู่นอกขอบเขตที่สั่งในรอบนี้ จึงไม่แตะ**

## 2. RPC ที่เลือกใช้ และเหตุผล

ตรวจ RPC ลางานที่มีอยู่จริงทั้งหมดก่อนเลือก

| RPC | ขอบเขต | ปัญหาต่อการ์ดนี้ |
|---|---|---|
| `njhr_leave_list` | เฉพาะคำขอของตนเอง (`r.employee_id = c.employee_id`) | ผู้ดูแลจะไม่เห็นคำขอของพนักงานคนอื่น |
| `njhr_leave_queue` | ผู้อนุมัติ แต่ `where r.status = 'PENDING'` และ `order by created_at **asc**` | เห็นเฉพาะรออนุมัติ และเรียงเก่า→ใหม่ ขัดกับ "ล่าสุด" |
| `njhr_leave_report` | ทุกสถานะ แต่ **บังคับ** `p_from` / `p_to` (`raise exception` เมื่อเป็น null) | ต้องกำหนดช่วงวันที่เอง = เดา และเสี่ยงซ่อนคำขอนอกช่วง |
| **`njhr_rpt_leave_list`** | ทุกสถานะ · ทุกพนักงาน · ตัวกรอง null ได้ทั้งหมด · มี `created_at` | **ตรงตามเงื่อนไขครบ** |

จึงใช้ `njhr_rpt_leave_list` ซึ่งเป็น RPC เดียวกับที่หน้า **REPORT ลางาน (`#/rpt-leave`)** ใช้อยู่
(ติดตั้งด้วย `supabase-new/S1_report_menu.sql` ในรอบที่แล้ว)

**ไม่มีการแก้ฐานข้อมูลในรอบนี้** — ไม่สร้าง ไม่แก้ ไม่ลบ RPC หรือตารางใด

### สิทธิ์การมองเห็นตาม Role เดิม

`njhr_rpt_leave_list` เรียก `njhr_rptmenu_guard(p_token)` ซึ่งตรวจ
`c.role not in ('SUPER_ADMIN','ADMIN') → raise exception 42501`

การ์ดนี้อยู่ใน `dashAdmin()` ซึ่งถูกเรียกเมื่อ `u.role !== 'USER'` เท่านั้น
(`viewDashboard()` บรรทัด 4: `if (u.role === 'USER') dashEmployee(el); else dashAdmin(el);`)
ชุดสิทธิ์จึงตรงกันพอดี และการตรวจสิทธิ์เกิดที่เซิร์ฟเวอร์ ไม่ใช่ที่เบราว์เซอร์

## 3. สิ่งที่แก้

**ไฟล์เดียว** `src/07-view-dashboard.js`

| จุด | เดิม | ใหม่ |
|---|---|---|
| `dashAdmin()` | `var recentLeaves = db.leaves...` | ลบทิ้ง แทนด้วยคอมเมนต์ชี้ไป `dashLeaveBody()` |
| `dashAdmin()` เนื้อการ์ด | เรนเดอร์ `recentLeaves` แบบ sync | เรียก `dashLeaveBody()` |
| เพิ่มใหม่ | — | `var dashLv = { seq: 0 }` · `dashLeaveErr()` · `dashLeaveBody()` |

ลบทั้งหมด **7 บรรทัด** เพิ่มบล็อกใหม่ 1 บล็อก · ไม่แตะส่วนอื่นของ Dashboard

**ไฟล์ประกอบ** `build.js` — เพิ่ม dep `shared-leave-meta` ให้ chunk `dashboard`
เพราะการ์ดต้องใช้ `lvType()` แปลงรหัสประเภทการลาที่ RPC ส่งมา (`SICK`) เป็นชื่อไทย (`ลาป่วย`)
เดิมแปลงด้วย `leaveType(l.typeId)` ซึ่งอ่านจาก `db.leaveTypes` ใน localStorage

`dashLeaveBody()` ใช้รูปแบบเดียวกับ `dashNotifyCard()` ที่มีอยู่แล้วในไฟล์เดียวกัน —
คืน HTML ว่างพร้อม `id` แล้วเติมเนื้อหาแบบ async

```js
sbRpcList('njhr_rpt_leave_list', {
  p_token: sbToken(), p_from: null, p_to: null, p_dept: null, p_q: null
}).then(function (rows) {
  var top = (rows || []).slice().sort(function (a, b) {
    return String(b.created_at || '').localeCompare(String(a.created_at || ''));
  }).slice(0, 5);
  ...
})
```

### ไม่เปลี่ยน UI/CSS

- โครงสร้าง DOM ต่อแถวเหมือนเดิมทุกคลาส: `.list` > `.list-row` > `avatarHTML(..., 36)` +
  `.grow` (`<b>` ชื่อ + `<small>` ประเภท · วันที่) + `statusBadge(...)`
- `.form-error` และ `.empty` เป็นคลาสที่มีอยู่แล้ว
- `src/css/styles.css` และ `src/css/mobile.css` — **diff 0 บรรทัด**
- `dashMobileHome()` (หน้าหลักมือถือ) ไม่ถูกแตะ — การ์ดนี้อยู่ใน `.only-desktop dash-legacy`

### ปุ่ม "ดูทั้งหมด"

`<a class="link" href="#/approvals">ดูทั้งหมด</a>` — **ไม่แก้แม้แต่ตัวอักษรเดียว**
ยังเปิดหน้าอนุมัติรายการ → แท็บ "คำขอลา" ซึ่งเป็นหน้ารายการลางานฝั่งผู้ดูแลเดิม

### พฤติกรรมเมื่อผิดพลาด

| กรณี | ผลลัพธ์ |
|---|---|
| RPC คืนรายการว่างจริง | `emptyState('ยังไม่มีคำขอลา')` |
| RPC โยน error | `<div class="form-error" role="alert">โหลดคำขอลาล่าสุดไม่สำเร็จ: <ข้อความจากเซิร์ฟเวอร์></div>` + `console.error('[DASHBOARD] njhr_rpt_leave_list ล้มเหลว:', ex)` |
| ยังไม่มี token / ยังไม่เชื่อม Supabase | `<div class="form-error">ยังไม่ได้เชื่อมต่อ Supabase — โหลดคำขอลาล่าสุดไม่ได้</div>` |
| ระหว่างโหลด | `กำลังโหลด…` |

**ไม่มี fallback ไป `db.*` หรือ localStorage ในทุกกรณี**

## 4. ก่อน–หลัง

| | ก่อน | หลัง |
|---|---|---|
| แหล่งข้อมูล | `db.leaves` (localStorage) | `njhr_rpt_leave_list` (Supabase) |
| ผลบน Production | `ยังไม่มีคำขอลา` เสมอ | แสดง 5 คำขอล่าสุดจริง |
| การเรียงลำดับ | `createdAt` (ฟิลด์ที่ไม่มีข้อมูล) | `created_at` จาก RPC ใหม่→เก่า |
| ชื่อผู้ลา | `empName(l.empId)` จาก `db.employees` (ว่าง → `—`) | `prefix + full_name` จาก RPC |
| ประเภทการลา | `leaveType(l.typeId)` จาก `db.leaveTypes` (ว่าง) | `lvType(r.leave_type)` |
| สถานะ | `l.status` | `r.ui_status \|\| r.status` |
| เมื่อ RPC ล้ม | — (ไม่เคยเรียก RPC) | ข้อความผิดพลาด + console.error |
| เปิดจากอีกเครื่อง | ไม่เห็นข้อมูล (ผูกกับเบราว์เซอร์) | เห็นเหมือนกันทุกเครื่อง |

## 5. ผลทดสอบ

| ชุด | ผล |
|---|---|
| `node build.js --check` | ตรงกัน — deploy = src |
| `node harness/check-all-js.js` | CHECK PASSED · DEPLOY_MD5 39 ค่า |
| `node harness/dash_leave_test.js .` | **PASS 27 · FAIL 0** |
| `node harness/dash_leave_xcheck.js .` | **PASS 7 · FAIL 0** |
| `node harness/report_menu_test.js .` | **PASS 61 · FAIL 0** (ไม่ถดถอย) |
| `node harness/desk_table_test.js .` | **PASS 48 · FAIL 0** (ไม่ถดถอย) |
| `node harness/desk_table_mobile_diff.js .` | **PASS 4 · FAIL 0** (ไม่ถดถอย) |

### `dash_leave_test.js` — ครอบคลุมทั้ง 5 ข้อที่สั่ง

ทดสอบด้วย `db.*` ว่างเปล่าเหมือน Production จริง ถ้าการ์ดยังอ่าน localStorage จะขึ้น
"ยังไม่มีคำขอลา" ทันทีและตกทดสอบ

| ข้อที่สั่ง | การตรวจ | ผล |
|---|---|---|
| 1. แสดงคำขอลาล่าสุดได้ | ป้อน 6 คำขอจาก RPC → แสดง 5 แถว | PASS |
| 1. เรียงใหม่→เก่า | จงใจสลับลำดับ `created_at` ใน response แล้วตรวจลำดับชื่อที่เรนเดอร์ | PASS |
| 2. ตรงกับหน้ารายการลางาน | เทียบข้ามหน้าใน `dash_leave_xcheck.js` | PASS |
| 3. รีเฟรช/อีกเครื่อง | เรนเดอร์ซ้ำ → ยิง RPC ใหม่ (1 → 2 ครั้ง) ไม่แคชค้าง · `db.leaves` ว่างแต่ยังแสดงได้ | PASS |
| 4. RPC Error | ไม่ขึ้น "ยังไม่มีคำขอลา" · มี `.form-error[role=alert]` · ข้อความมีสาเหตุจริง · มี `console.error` | PASS |
| 5. ปุ่มดูทั้งหมด | `href="#/approvals"` และข้อความ "ดูทั้งหมด" เท่าเดิม | PASS |

ตรวจเพิ่ม: ส่งตัวกรอง `p_from/p_to/p_dept/p_q` เป็น `null` ทั้งหมด (ไม่จำกัดช่วงวันที่) ·
ส่ง `p_token` ของผู้ล็อกอิน · ไม่มี token = ไม่ยิง RPC และไม่ขึ้น empty ·
RPC คืน `[]` จริงจึงขึ้น "ยังไม่มีคำขอลา" · โค้ดการ์ดไม่อ้าง `db.leaves`

### `dash_leave_xcheck.js` — ข้อมูลตรงกับหน้ารายการลางาน

ป้อนแถวชุดเดียวกันให้ `views/dashboard.js` และ `views/reports/menu.js` แล้วเทียบทีละคำขอ

| ฟิลด์ | ผลเทียบ |
|---|---|
| ชื่อผู้ลา | ตรงกันทั้ง 3 คำขอ |
| ประเภทการลา | ลาป่วย · ลากิจ · ลาพักร้อน |
| วันที่ | 2026-08-10 · 2026-08-03 – 2026-08-04 · 2026-07-01 – 2026-07-05 |
| สถานะ | รออนุมัติ · อนุมัติแล้ว · ยกเลิกแล้ว |

### ข้อจำกัดที่ต้องระบุตรง ๆ

- **ยังไม่ได้ทดสอบกับบัญชีจริงบน Production** — ผมไม่มีสิทธิ์เข้าถึงฐานข้อมูลและถูกห้าม
  แตะ Production การทดสอบทั้งหมดเป็นการรัน chunk ที่ build แล้วจริงบน jsdom โดยจำลอง
  ชั้น RPC ไว้ภายนอก จึงพิสูจน์ได้ว่า **โค้ดอ่านจาก RPC และเรนเดอร์ค่าที่ได้ถูกต้อง**
  แต่ยังไม่ได้พิสูจน์ว่า RPC บน Production คืนข้อมูลครบ
- ถ่าย Screenshot ไม่ได้เพราะสภาพแวดล้อม build บล็อกการดาวน์โหลด Chromium
- **เงื่อนไขสำคัญ**: ต้องรัน `supabase-new/S1_report_menu.sql` แล้วเท่านั้น การ์ดจึงทำงาน
  ถ้ายังไม่รัน การ์ดจะขึ้นข้อความผิดพลาด (ไม่ใช่ "ยังไม่มีคำขอลา") ตามที่ออกแบบไว้

## 6. ไฟล์ Deploy ที่เปลี่ยน

**5 ไฟล์** `asset-manifest.js` · `config.js` · `index.html` · `sw.js` · `views/dashboard.js`
อีก 34 ไฟล์ MD5 เท่าเดิม รวมถึง `styles.css` · `mobile.css` · `compat/app-legacy.js` ·
`views/leave/main.js` · `views/ot/main.js` · `views/reports/menu.js`

## 7. หมายเหตุด้านประสิทธิภาพ

`njhr_rpt_leave_list` ไม่มีพารามิเตอร์ `limit` จึงคืนคำขอลาทั้งหมดที่ผ่านตัวกรอง
แล้วหน้าจอตัดเหลือ 5 รายการ เมื่อข้อมูลสะสมมากขึ้นการโหลด Dashboard จะหนักขึ้นตาม

ทางเลือกที่ไม่ต้องแก้ฐานข้อมูลไม่มีตัวใดให้ทั้ง "ทุกสถานะ + ทุกพนักงาน + ไม่จำกัดช่วงวันที่ +
เรียงใหม่→เก่า" ได้พร้อมกัน จึงเลือกตัวนี้ตามเงื่อนไข "ห้ามแก้ฐานข้อมูลหากยังไม่ยืนยันว่า
RPC เดิมขาดข้อมูล"

ถ้าต้องการให้เบาลง ทางแก้คือเพิ่มพารามิเตอร์ `p_limit` ให้ `njhr_rpt_leave_list`
ซึ่งเป็นการแก้ฐานข้อมูล — **รอคำสั่งจากคุณก่อน ยังไม่ได้ทำ**

## 8. การย้อนกลับ

`rollback/before_dash_leave/` พร้อม `ROLLBACK.md` — คัดลอก `src/07-view-dashboard.js`
และ `build.js` ทับของเดิมแล้วรัน `node build.js` ไม่ต้องย้อนฐานข้อมูล
