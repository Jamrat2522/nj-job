# Bundle Size Report — build 0fd6ed5f

| ไฟล์ | raw | gzip -9 | hash |
|---|---:|---:|---|
| `index.html` | 15429 | 5129 | `—` |
| `config.js` | 5378 | 1882 | `—` |
| `asset-manifest.js` | 5499 | 1250 | `fc4d95c3` |
| `runtime/namespace.js` | 5281 | 2075 | `815b8995` |
| `runtime/core.js` | 79654 | 23313 | `d48e9db8` |
| `styles.css` | 96861 | 18569 | `7cce639b` |
| `mobile.css` | 73807 | 13415 | `65bc9fcb` |
| `views/dashboard.js` | 28109 | 8693 | `5b419f6b` |
| `runtime/shared/emp-meta.js` | 4264 | 1394 | `3436375a` |
| `runtime/shared/hr-meta.js` | 8910 | 5213 | `781668be` |
| `runtime/shared/report-export.js` | 6079 | 2000 | `711627a7` |
| `runtime/shared/requests.js` | 9570 | 3533 | `cd184aff` |
| `runtime/shared/leave-meta.js` | 1499 | 739 | `91d7979b` |
| `runtime/shared/attachments.js` | 1436 | 805 | `5f532921` |
| `views/employees/list.js` | 19301 | 5613 | `09904fbe` |
| `views/attendance/main.js` | 28558 | 8427 | `0ec76b22` |
| `views/leave/main.js` | 25931 | 7592 | `59e48451` |
| `views/ot/main.js` | 5255 | 2135 | `18cccd8f` |
| `views/attendance/report.js` | 31840 | 8922 | `449208f4` |
| `views/employees/form.js` | 23942 | 6208 | `3d311a5b` |
| `views/employees/documents.js` | 18377 | 5701 | `527abd01` |
| `views/employees/import.js` | 16876 | 5337 | `95dd7594` |
| `views/employees/export.js` | 3197 | 1490 | `a4410fd1` |
| `views/attendance/correction.js` | 3967 | 1726 | `81cf3343` |
| `views/leave/form.js` | 12118 | 4299 | `ba744d65` |
| `views/leave/detail.js` | 4387 | 1785 | `b6236590` |
| `views/ot/form.js` | 16317 | 5561 | `28ba72f0` |
| `views/profile/main.js` | 137623 | 33104 | `496b043f` |
| `views/calendar/main.js` | 27745 | 8138 | `20368fcd` |
| `views/notifications/main.js` | 4050 | 1637 | `153dedba` |
| `compat/app-legacy.js` | 415055 | 96965 | `47d7d6ca` |
| `sw.js` | 5370 | 2207 | `—` |
