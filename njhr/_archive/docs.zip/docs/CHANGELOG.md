# HR V2 — CHANGELOG

## Role Consolidation — เสร็จสิ้น (ฐานข้อมูล)

**ผลลัพธ์**

```
USER        : 105
ADMIN       :   4
SUPER_ADMIN :   2
รวม         : 111
```

**Mapping ที่เกิดขึ้น**

| Role เดิม | Role ใหม่ | บัญชี |
|-----------|-----------|-------|
| `USER` | `USER` | 95 |
| `ACCOUNT` | **`USER`** | 9 |
| `EMPLOYEE` | **`USER`** | 1 |
| `ADMIN` | `ADMIN` | 4 |
| `SUPER_ADMIN` | `SUPER_ADMIN` | 2 |

**ยืนยันว่าไม่กระทบแอปอื่น** — เทียบก่อน/หลังแล้วเหมือนเดิมทุกค่า

```
amend:user 104 · amend:admin 6 · amend:super_admin 2
advance:USER 92 · advance:ACCOUNT 11 · advance:ADMIN 7 · advance:SUPER_ADMIN 2
billing:user 9 · billing:admin 2 · billing:admin_mid 1
transport:user 9 · transport:super_admin 2
timeline:SUPER_ADMIN 3 · pdf:super_admin 1
```

`advance:ACCOUNT 11` และ `billing:admin_mid 1` ยังอยู่ครบ — พิสูจน์ว่าเงื่อนไข `app_code = 'salary'`
ในทุก `UPDATE` ทำงานถูกต้อง และ **ไม่ได้แตะ enum `user_role`**

---

## Pre-migration Backup — พบแล้ว

ตรวจฐานข้อมูลครบทุกแหล่งแล้วพบตารางสำรองก่อนแปลง **2 ตัว**

| ตาราง | `USER` | `ACCOUNT` | `ADMIN` | `SUPER_ADMIN` | รวม |
|-------|--------|-----------|---------|----------------|-----|
| `njhr_appusers_backup_20260727` | 96 | **9** | 4 | 2 | 111 |
| `njhr_bk_app_users_20260802` | 96 | **9** | 4 | 2 | 111 |

ระบุบัญชีที่เคยเป็น `ACCOUNT` ได้ครบทั้ง 9 รายการ · ทุกบัญชี `is_active = true` และผูกพนักงานครบ

**ผลกระทบจริงมีเพียง 1 บัญชี** — มี session ภายใน 90 วันแค่รายเดียว อีก 8 รายไม่ได้เข้าใช้งานเลย

Migration รันเมื่อ `2026-08-05 10:15:37 UTC`

### แก้ข้อความที่เคยบันทึกผิด

CHANGELOG ฉบับก่อนหน้าระบุว่า "ไม่มี Pre-migration Backup" และ "ระบุ ACCOUNT 9 คนไม่ได้"
**ทั้งสองข้อไม่ถูกต้อง** — เกิดจากการตรวจเฉพาะตารางที่สร้างขึ้นระหว่างงานและ `audit_log`
โดยยังไม่ได้ค้นหาตารางสำรองอื่นในฐานข้อมูล

### หมายเหตุเรื่อง `ACCOUNT`

`ACCOUNT` เป็น **ชื่อแผนก** ไม่ใช่ Role — ระบบใช้ Role เพียง `SUPER_ADMIN` · `ADMIN` · `USER`

### ตารางสำรองที่ต้องเก็บไว้

`njhr_appusers_backup_20260727` และ `njhr_bk_app_users_20260802` — **ห้ามลบ**
RLS เปิดอยู่แล้ว แต่ `anon` ยังมีสิทธิ์ระดับตาราง ควร `revoke` เพิ่มอีกชั้น

`njhr_role_snapshot_post_consolidation_v1` เป็น Snapshot หลังแปลง ใช้ย้อน Role ไม่ได้
ปิดสิทธิ์และใส่ COMMENT เรียบร้อยแล้ว

---

## Frontend — รองรับ 3 Role แล้ว

| จุด | ค่า |
|-----|-----|
| `ROLE_TH` | `SUPER_ADMIN` · `ADMIN` · `USER` |
| `ALL` | `['SUPER_ADMIN','ADMIN','USER']` |
| `US_ROLES` (Dropdown) | 3 ค่า |
| `normRole()` | `SUPER_ADMIN`/`ADMIN` คงเดิม · ค่าอื่นทั้งหมด → `USER` |
| อาเรย์สิทธิ์ | 37 จุด — `['SUPER_ADMIN','ADMIN','USER']` 2 · `['SUPER_ADMIN','ADMIN']` 34 · `['SUPER_ADMIN']` 1 |

**ค้นหา `ACCOUNT` `EMPLOYEE` `STAFF` `HR` `MANAGER` ทั้งโปรเจกต์** — เหลือ 8 จุดและ
**ไม่ใช่ Role แม้แต่จุดเดียว**

| จุด | คืออะไร |
|-----|---------|
| `08-view-employees.js:534` | `department_name: 'ACCOUNT'` — ชื่อแผนกในเทมเพลตนำเข้า |
| `12-view-reports-settings.js` 7 จุด | `w.scope === 'EMPLOYEE'` — ขอบเขตของ Workflow |

---

## สถานะ

| รายการ | สถานะ |
|--------|--------|
| Role Migration (Database) | **DONE** |
| Frontend รองรับ 3 Role | **DONE — ยังไม่ Deploy** |
| ช่องโหว่ตารางสำรอง | **ปิดแล้ว** |
| Pre-migration Backup | **มีอยู่ 2 ตัว** — `njhr_appusers_backup_20260727` · `njhr_bk_app_users_20260802` |
| ระบุบัญชีที่เคยเป็น `ACCOUNT` 9 คน | **ทำได้** — กระทบผู้ใช้จริง 1 บัญชี |
| ทดสอบ Login 3 Role | **NOT TESTED** |
| Production Real Data | **NOT TESTED** |

---


## Build `e0a4f943` — หน้าลงเวลามือถือตามภาพอ้างอิง (#/attendance)

**ไฟล์ที่เปลี่ยน**

`src/33-view-attendance.js` · `src/05-layout-shell.js` · `src/css/mobile.css` ·
`harness/ui_shot.js` · `harness/mh_fixtures.js`

**บั๊กข้อมูลพนักงานที่แก้ (ยืนยันจาก Source)**

`attRenderEmpCard()` เดิมอ่าน `currentUser().emp_code` · `.department_name` · `.emp_name`
แต่ `currentUser()` (`src/02-store.js:148`) คืนเฉพาะ
`{ id, username, role, empId, active, fullName, department, sb }`
สามฟิลด์นั้นไม่มีอยู่จริง หน้าจึงขึ้น `รหัสพนักงาน: —` และ `แผนก: —` เสมอ
`attLoad()` ยังกรองประวัติด้วย `currentUser().employee_id` ซึ่งก็ไม่มี → ค่าเป็น `undefined`
ผู้ดูแลจึงเห็นประวัติของ **ทุกคน** ปนกับของตัวเอง

แก้ด้วย `attMe()` ที่ไล่จากแหล่งจริง Session → app_users → employees
`u.empId || u.sb.employee_id || currentEmp().id` · `u.sb.emp_code || e.code` ·
`u.sb.emp_department || u.department || e.deptName || dept(e.deptId)`
ไม่มี `employee_id` = `ok:false` → ปิดปุ่มลงเวลาทั้งสองปุ่ม แสดงข้อความชัดเจน
และ `attPunch()` หยุดก่อนเรียก Action ทุกกรณี **ไม่มีการส่งค่า fallback**

**หน้าลงเวลามือถือ (.att-mb)**

- พื้นกรมท่าไล่เฉด `#0A1B3D → #102A55 → #0A1B3D` + radial 2 ชั้น (CSS ล้วน ไม่มีภาพ ไม่มี CDN)
- หัวแถบในหน้า: โลโก้ NJL · `NJL HR` · `ระบบบริหารทรัพยากรบุคคล` · กระดิ่ง
  `#/attendance` ย้ายจาก `MB_MID_ROUTES` ไป `MB_HIDE_ROUTES` (Pattern เดียวกับหน้าโปรไฟล์)
  ชื่อหน้า `ลงเวลา` อยู่กึ่งกลาง
- นาฬิกาอนาล็อก SVG ล้วน (`attMbClockSVG`) มี Gradient + เงา เข็มหมุนตามเวลาจริงทุกวินาที
- เวลาปัจจุบัน 42px · วันที่ไทย พ.ศ. · `กะเวลา: 08:30–17:30` จาก `njhr_att_today` จริง
  ไม่มีข้อมูลกะ → `ยังไม่กำหนดกะ`
- การ์ด GPS: `กำลังตรวจตำแหน่ง` → `อยู่ในพื้นที่บริษัท / GPS พร้อม` (เขียว) ·
  `อยู่นอกพื้นที่ลงเวลา` · `ไม่อนุญาตตำแหน่ง` · `GPS ไม่พร้อม`
  ขึ้นเขียวได้ก็ต่อเมื่อได้พิกัดจริงและ `njhr_gf_check` คืน `pass` เท่านั้น
  ไม่มีการเขียนพิกัดลง Console หรือ DOM
- การ์ดใบหน้า: อ่านจาก `NJHRFace.isReady()` ตัวจริง ไม่เปิดกล้องเอง ไม่แตะ Face Workflow เดิม
- ปุ่ม `เข้างาน` แดงเต็ม · `ออกงาน` ขาวขอบแดง · สูง 60px · `data-busy` กันกดซ้ำ + สปินเนอร์
  ทั้งสองปุ่มเรียก `attPunch()` ตัวเดิม ไม่มีการบันทึกซ้ำหรือยิง RPC ใหม่
- ประวัติวันนี้: ใช้ผล `njhr_att_today` ที่โหลดมาแล้ว ไม่ยิง RPC เพิ่ม
- แถบเมนูล่างพื้นกรมท่าเฉพาะ Route นี้ (`.bottom-nav.bn-att`) หน้าอื่นคงสีขาวเดิม
- ไอคอน SVG ทั้งหมด ไม่มี Emoji · รองรับ 360/375/390/430px

**Desktop**

มาร์กอัปเดิมของหน้าลงเวลาคงทุกบรรทัด เพิ่มเพียงคลาส `.only-desktop`
ที่ `.clock-card` · `.att-hcard` · `#att-mig` ไม่มีการห่อ element ใหม่

**ผลทดสอบ (harness/ui_shot.js · Prompt จากไฟล์ในเครื่อง · เวลาตรึง · ปิด animation)**

| สถานการณ์ | ปุ่มเข้า | ปุ่มออก | GPS | กะ |
|-----------|---------|---------|-----|----|
| ยังไม่เข้างาน | เปิด | ปิด | อยู่ในพื้นที่บริษัท | 08:30–17:30 |
| เข้างานแล้ว | ปิด | เปิด | อยู่ในพื้นที่บริษัท | 08:30–17:30 |
| ลงเวลาครบ | ปิด | ปิด | อยู่ในพื้นที่บริษัท | 08:30–17:30 |
| อยู่นอกพื้นที่ | เปิด | ปิด | อยู่นอกพื้นที่ลงเวลา | 08:30–17:30 |
| ไม่อนุญาตตำแหน่ง | เปิด | ปิด | ไม่อนุญาตตำแหน่ง | 08:30–17:30 |
| ไม่มีข้อมูลกะ | เปิด | ปิด | อยู่ในพื้นที่บริษัท | ยังไม่กำหนดกะ |
| SUPER_ADMIN | เปิด | ปิด | อยู่ในพื้นที่บริษัท | 08:30–17:30 |

ทุกกรณี: `รหัสพนักงาน 0004` · `แผนก MANAGER` · ไม่มี Horizontal Overflow ·
ไม่มี Emoji · `bn-att` ติด · เมนู `ลงเวลา` Active · `console.error`/`pageerror` = 0 ·
`njhr_att_today` ถูกเรียก **1 ครั้ง** ต่อการเปิดหน้า

กดปุ่มเข้างานรัว 3 ครั้ง → จำนวน RPC ไม่เพิ่มแม้แต่รายการเดียว ปุ่มเข้าสถานะ `busy`
เปลี่ยน Route → `#att-mb` · `#attmb-time` · `#attmb-face` หายครบ ไม่มี `<video>` ค้าง

**Pixel Diff เทียบ Checkpoint `e86ff36b`**

| หน้า | USER | SUPER_ADMIN |
|------|------|-------------|
| หน้าหลักมือถือ 390×844 | 0 px (0.0000%) | 0 px (0.0000%) |
| Desktop 1440×900 (`#/dashboard`) | 0 px (0.0000%) | 0 px (0.0000%) |
| Desktop 1440×900 (`#/attendance`) | 0 px (0.0000%) | 0 px (0.0000%) |

**ไม่แตะ**

SQL · RPC · RLS · Workflow · Edge Function · Member Cutover · หน้าคำขอ · หน้าโปรไฟล์ ·
Bottom Navigation ของหน้าหลัก · การโหลด Google Fonts ของ Production ·
ไม่มี Dependency หรือ CDN ใหม่

**ยังไม่ผ่าน / ทำไม่ได้ในรอบนี้**

| หัวข้อ | สถานะ |
|--------|-------|
| บัญชีไม่มี Employee Mapping | ทดสอบผ่าน UI ไม่ได้ — `njhr_session_check` ปฏิเสธ Login ตั้งแต่ต้น (`31_secure_session.sql:90`) เส้นทาง `.att-mb-block` จึงเป็นด่านป้องกันชั้นสอง ยังไม่ได้พิสูจน์ด้วยภาพ |
| สถานะ "ยังไม่ได้ลงทะเบียนใบหน้า" / "กล้องไม่ได้รับอนุญาต" | `NJHRFace` เปิดเผยเฉพาะ `isReady()` ไม่มี API บอกสถานะการลงทะเบียนหรือสิทธิ์กล้อง และห้ามแก้ Face API เดิม จึงยังไม่แสดง 2 สถานะนี้ |
| รัน `N1_calendar_rpc.sql` บน Production | ยังไม่ได้รัน |
| Login จริง 3 Role บน Production | NOT TESTED |

---


## Build `0fd6ed5f` — เลขที่คำขอ YYMMDD-0001 + ลบช่องผู้รับงานแทน

**ไฟล์ที่เปลี่ยน**

`src/23-shared-requests.js` · `src/11-view-approvals-payroll.js` ·
`src/34-view-requests-leave.js` · `src/35-view-ot.js` · `src/43-view-leave-form.js`

**SQL ที่รันบน Production แล้ว 3 ไฟล์**

| ไฟล์ | ทำอะไร |
|------|--------|
| `R1_request_no.sql` | คอลัมน์ `request_no` + UNIQUE partial index + ตาราง `njhr_request_seq` + `njhr_next_request_no()` |
| `R2_request_no_submit.sql` | แทรกการออกเลขใน `njhr_leave_submit` และ `njhr_ot_submit` |
| `R3_request_no_expose.sql` | เพิ่ม `request_no` เข้า RETURNS ของ 5 RPC |

**กลไกออกเลข**

`YYMMDD-0001` โดย `YYMMDD` = วันที่ยื่นตาม `Asia/Bangkok` และ `0001` = เลขรัน
ต่อเนื่องตลอดเดือน เริ่มใหม่เมื่อขึ้นเดือน · ใบลาและ OT แยกเลขรัน (`kind`)

ใช้ `SELECT ... FOR UPDATE` บนตาราง `njhr_request_seq` — ไม่ใช้ `MAX+1`
ไม่ใช้ LocalStorage ไม่สุ่ม · หลายคนส่งพร้อมกันเข้าคิวที่ Row Lock จึงไม่ซ้ำ
UNIQUE index บน `request_no` เป็นด่านสุดท้าย
ถ้า Transaction ล้ม เลขรันถูก Rollback ไปด้วย จึงไม่ขาด
เส้นทาง `client_key` (กันกดส่งซ้ำ 10 นาที) คืนใบเดิม **ก่อน** ถึงจุดออกเลข
กดซ้ำด้วย key เดิมจึงไม่สร้างเลขใหม่

**ยืนยันด้วยข้อมูลจริงบน Production**

| ใบ | `request_no` | หมายเหตุ |
|----|--------------|----------|
| `49f5ea20…` | `260811-0001` | ยื่น 10:19 UTC = 17:19 ไทย → `260811` ถูกต้อง |
| อีก 3 ใบ | `null` | คำขอเก่า ไม่ถูกเปลี่ยนเลข |

`njhr_request_seq` = `LEAVE / 2608 / 1`

**ฝั่งหน้าเว็บ**

`lvCode()` เขียนใหม่ให้อ่าน `request_no` ก่อน แล้ว fallback เป็น `LV-XXXXXX` เดิม
รับได้ทั้ง object ของคำขอและ id เดี่ยว จึงไม่ต้องแก้จุดเรียกทุกจุด
ส่ง object แล้ว 6 จุด — หน้าอนุมัติ 4 (Modal มือถือ · แถว Desktop · การ์ด · ยืนยันอนุมัติ)
และหน้าลางาน 2 (การ์ดมือถือ · แถว Desktop)

**ลบช่อง "ผู้รับงานแทน (ไม่บังคับ)"**

ลบ Markup และ `<select name="delegate">` ออกจากฟอร์มขอลางานทั้งคอมและมือถือ
`p_delegate` ส่ง `null` เสมอ — ไม่แก้ SQL signature ยังเหมือนเดิม
เอกสารแนบเลื่อนขึ้นมาต่อจากเหตุผลการลาทันที
`grep "delegate"` ทั้งโปรเจกต์เหลือแค่คอมเมนต์ · ไฟล์ build นับ "ผู้รับงานแทน" ได้ 0 ครั้ง

**ผลตรวจ**

`build.js --check` ตรงกัน · `check-all-js.js` PASSED · `calendar_test.js` PASSED
จอไม่ล้นแนวนอน · Console Error 0 ทั้งมือถือ 390 และ Desktop 1366

**ยังไม่เสร็จ — 5 จุดที่ยังแสดงรูปแบบเดิม**

| จุด | เหตุผล |
|-----|--------|
| หน้ารายการ OT | อ่านจาก `db.ots` (local store) ยังหาไม่เจอว่าที่ใดเติมข้อมูล จึงยังไม่แมป `request_no` |
| Timeline (`showTimeline` · `lvShowTimeline`) | ยังส่ง id เดี่ยว |
| ปุ่มไม่อนุมัติ / ขอข้อมูลเพิ่ม | ยังส่ง id เดี่ยว |
| REPORT ALL Export | `lvCode(r.req_id)` ยังส่ง id เดี่ยว |
| แจ้งเตือน | ยังไม่ได้ตรวจว่าแสดงเลขที่คำขอหรือไม่ |

**ยังไม่ได้ทดสอบบนหน้าจอจริง** ว่าใบที่มีเลข `260811-0001` แสดงเลขนี้แทน `LV-49F5EA`

---


## Build `133f9b44` — ทุกปุ่มบนมือถือกดได้ ≥ 44×44 ทุกหน้า

**ไฟล์ที่เปลี่ยน** `src/17-view-calendar.js` · `src/css/mobile.css`
CSS ใหม่ทั้งหมดอยู่ใน `@media (max-width: 900px)` — Desktop ไม่ถูกแตะ

**วิธีตรวจ** วัด `getBoundingClientRect()` ของ `button` · `a[href]` · `[role=button]` ·
`input` · `select` · `textarea` ที่มองเห็นได้จริง ครบ 10 หน้าบนเบราว์เซอร์จริง
ไม่ได้ประมาณจากภาพ

**8 จุดที่พบว่าเล็กกว่า 44px และแก้แล้ว**

| จุด | วัดได้ | แก้เป็น |
|-----|--------|---------|
| `.btn.btn-sm` (รายละเอียด/Timeline · ยกเลิกคำขอ) | 42px | 44px |
| `.toolbar select` / `input` (`lv-filter`) | 43px | 44px |
| `#hamburger` | 38×38 | 44×44 |
| `.topbar-user` | 34×34 | 44×44 |
| `.tabs .tab` (แท็บหน้าอนุมัติ 3 ตัว) | 40px | 44px |
| `.seg-btn` (`cal-mv` · `cal-lv`) | 36px | 44px |
| `#cal-prev` · `#cal-next` | 38×38 | 44×44 |
| `#cal-dept` | กว้าง 25.6px ที่ 430px | 120×44 |

**เพิ่ม `aria-label` + `title`**

`#cal-prev` = `เดือนก่อนหน้า` · `#cal-next` = `เดือนถัดไป` · `#cal-dept` = `เลือกแผนก`
เดิมเป็นปุ่มไอคอนล้วนไม่มีคำอธิบายสำหรับ Screen Reader

**ผลตรวจ 10 หน้าบนมือถือ 390px หลังแก้**

dashboard · attendance · requests · profile · leave · ot · approvals ·
calendar · notifications · reportall

| หัวข้อ | ผล |
|--------|-----|
| ปุ่ม < 44×44 | **0 ทุกหน้า** |
| Horizontal Overflow | **ไม่มีทุกหน้า** (`scrollWidth = clientWidth = 390`) |
| ปุ่มไร้ Handler | **0** |
| ปุ่มไอคอนไร้ `aria-label` | **0** |
| Console / Page Error | **0 ทุกหน้า** |

หมายเหตุ: `rp-from` · `rp-to` · `rp-dept` · `rp-q` ในหน้า REPORT ALL ถูกรายงานว่า
"ไร้ Handler" เพราะเป็น `input`/`select` ที่ใช้ `onchange` ไม่ใช่ `onclick`
ยืนยันจาก `src/12-view-reports-settings.js:72–74` ว่ามี `.onchange` ครบทุกตัว — ไม่ใช่ปุ่มเสีย

**Desktop Regression (เทียบ commit `d188e53b`)**

| หน้า | 1366 USER | 1366 SA | 1920 USER | 1920 SA |
|------|-----------|---------|-----------|---------|
| Dashboard | 0 px | 0 px | 0 px | 0 px |
| ปฏิทินองค์กร | 0 px | 0 px | 0 px | 0 px |

**คะแนนประสิทธิภาพที่วัดได้**

| ด้าน | Mobile | Desktop |
|------|--------|---------|
| Responsiveness (ปุ่มกดได้) | **10** | **10** |
| Rendering · JS execution · Memory | 9 | 9 |
| Loading speed | 8 | 8 |
| Network | 7 | 7 |
| Scalability | 7 | 8 |
| Maintainability | 7 | 7 |

**คอขวดที่ยังไม่แก้ (ต้องแตะสถาปัตยกรรม)**

1. หน้าหลักยิง 13 RPC ต่อการเปิด 1 ครั้ง — FCP 648ms เทียบหน้าอื่น 250ms
2. CSS 149 KB render-blocking — เคยลอง `media` attr แล้ว Desktop เพี้ยน 2.74%
   เพราะ `mobile.css` มี 626 rules ที่ Desktop ก็ใช้
3. ฟอนต์ Prompt 8 ไฟล์ 124 KB — `font-weight:500` ใช้จริง 24 จุด ตัดไม่ได้
4. `compat/app-legacy.js` 392 KB ก้อนเดียว
5. `njhr_leave_list`/`njhr_ot_list` ดึง 100 แถวมาเรียงฝั่ง Client

---


## Build `d188e53b` — หน้าคำขอและอนุมัติบนมือถือตามภาพอ้างอิง

**ไฟล์ที่เปลี่ยน**

`src/11-view-approvals-payroll.js` · `src/43-view-leave-form.js` · `src/45-view-ot-form.js` ·
`src/42-view-attendance-correction.js` · `src/34-view-requests-leave.js` · `src/css/mobile.css`

CSS ใหม่ทั้งหมดอยู่ใน `@media (max-width: 767px)` หรือ `(max-width: 768px)` เท่านั้น
`src/css/styles.css` (Desktop) ไม่เปลี่ยนแม้แต่ไบต์เดียว

**หน้าคำขอ (ขอลางาน · ขอ OT · ลงชื่อย้อนหลัง)**

- เพิ่มการ์ดพนักงานบนหัวฟอร์ม (`.fm-emp`) — Avatar · ชื่อ · `รหัส · แผนก`
  ข้อมูลจาก `currentEmp()` ไม่ hardcode · แผนกไม่มีข้อมูลจริงแสดง `ไม่ระบุ`
- ซ่อน 3 ช่องที่ซ้ำในกล่องผู้ยื่นคำขอเดิม (`.ri-dup`) เฉพาะมือถือ
  คงไว้ `ตำแหน่ง` · `วันที่ยื่นคำขอ` · `เลขที่คำขอ` — Desktop ยังครบ 6 ช่อง ไม่มีข้อมูลหาย
- ฟอร์มลงชื่อย้อนหลังเปลี่ยนเป็นหน้าเต็มจอ (`fullMobile: true`) และตัด Emoji ออกจากชื่อหน้า
- เพิ่มหน้าจอ "ส่งคำขอสำเร็จ" หลังบันทึกใบลา — ปุ่ม `ยื่นคำขอใหม่` และ `กลับหน้าคำขอ`
  ไม่แตะ Logic การส่ง เป็นหน้าจอหลังบันทึกสำเร็จเท่านั้น

**หน้าลางาน (มือถือ)**

การ์ดสิทธิ์ลาป่วย/ลากิจ/พักร้อนเพิ่ม `.only-desktop` — มือถือดูได้ที่หน้าคำขอ
(`#/requests` มีการ์ด "สรุปสิทธิ์การลา" อยู่แล้ว) ไม่ลบ Logic คำนวณสิทธิ์ใด ๆ

**หน้าอนุมัติรายการ (มือถือ) — ใหม่**

`apMobileDetail(it, el, kind)` เปิดหน้าเต็มจอเมื่อ `apIsMobile()` เป็นจริง
Desktop ยังใช้ Timeline เดิมทุกประการ

| ส่วน | รายละเอียด |
|------|-----------|
| การ์ดพนักงาน | Avatar · ชื่อ · `รหัส · แผนก` |
| ป้ายสถานะ | `statusBadge()` เดิม |
| รายละเอียด | Label/Value 7 แถว ปรับตามประเภท (ลางาน · OT · ลงชื่อย้อนหลัง) |
| Timeline | ขั้นที่ทำแล้วจุดแดง/เขียว · ขั้นที่ยังไม่ถึงจุดเทา (`tl-wait`) |
| ปุ่ม | `ไม่อนุมัติ` ขอบแดงพื้นขาว · `อนุมัติ` พื้นเขียว `#16A34A` |

ปุ่มอนุมัติ/ไม่อนุมัติใช้ `relay()` กดปุ่มจริงในรายการต่อ
**Handler และ Workflow เดิมทำงานทุกบรรทัด ไม่มี Workflow ซ้อน**

**Guard ที่เพิ่ม**

- ต้องมี `itm && itm.id` จริงจึงเปิดหน้ามือถือ ไม่งั้นตกไปหน้ารายละเอียดเดิม
- `done` เป็นจริงเฉพาะเมื่อสถานะไม่ว่างและอยู่ใน
  `APPROVED / REJECTED / CANCELLED / COMPLETED` — สถานะว่างไม่ซ่อนปุ่ม

**ผลทดสอบ**

| หัวข้อ | ผล |
|--------|-----|
| ใบลา PENDING | 7 แถวครบ · Timeline 3 ขั้น · ปุ่ม ไม่อนุมัติ/อนุมัติ |
| ใบลา APPROVED | 7 แถวครบ · ปุ่ม `ปิด` เท่านั้น |
| OT PENDING | 7 แถวครบ · ปุ่ม ไม่อนุมัติ/อนุมัติ |
| Horizontal Overflow 390 / 430 | ไม่มี |
| Console Error | 0 |
| `check-all-js.js` · `calendar_test.js` | PASSED |
| Desktop Regression `#/approvals` SUPER_ADMIN 1366/1920 | 0 px |
| Desktop Regression `#/leave` 1366/1920 ทั้ง 2 Role | 0 px |

**ยังไม่ได้ทดสอบ**

- OT และลงชื่อย้อนหลังสถานะ "จบแล้ว" — Logic เดิมกรองเฉพาะ `PENDING` /
  `NEED_MORE_INFO` รายการที่จบแล้วไม่ปรากฏในหน้าอนุมัติ (ไม่ได้แก้ Workflow)
- ภาพหน้าลงชื่อย้อนหลัง (ฟอร์ม) และหน้าส่งคำขอสำเร็จ — ต้องกดผ่าน Flow จริง
- `desk1366/1920 USER` วัดได้ 4,239 px แบบไม่เสถียร (บางรอบ 0 px)
  bbox อยู่มุมขวาบนของแถบหัว · USER ไม่มีสิทธิ์หน้านี้จึงถูก Router เด้งไป `#/dashboard`
  `styles.css` ไม่เปลี่ยน — เป็นจังหวะ redirect ของ Harness

---


## Build `8f31326e` — Dashboard Desktop ตามแบบอ้างอิง

**ไฟล์ที่เปลี่ยน** `src/07-view-dashboard.js` · `src/css/styles.css`
CSS ใหม่ทั้งหมด Scope ใต้ `.dash-legacy` และอยู่ใน `@media (min-width: 1024px)` เท่านั้น

**KPI 8 ใบ**

`kpi()` รับพารามิเตอร์ไอคอนเพิ่ม ใช้ `icon()` ชุด SVG ของระบบ ไม่เพิ่ม Library
ไอคอนซ้าย ข้อความขวา · กล่องไอคอน 48×48 แยกสี 6 โทน
`users` `checkSquare` `clock` `calendarOff` `ban` `timer` `fileText` `wallet`
ค่าและ Route เดิมทุกใบ ไม่ hardcode ตัวเลข

**ต้นเหตุที่การ์ดเคยเรียงแนวตั้ง (วัดจาก computed style ไม่ได้เดา)**

`styles.css:194` ตั้ง `.kpi { display: flex; flex-direction: column; }`
กฎใหม่เขียนแค่ `display: flex` จึงไม่ทับ `flex-direction` ค่า `column` ยังชนะ
การ์ดสูง 155px แก้โดยเขียน `flex-direction: row` ตรง ๆ **ไม่ใช้ `!important`**
พร้อม `height: 92px` และ `transform: none` ยกเลิก `translateY` ของ `.kpi:hover` เดิม

**เนื้อหา**

`max-width: 1440px` + `margin-inline: auto` — ที่ 1366px ยังไม่ถึงจึงเต็มพื้นที่หลังหัก Sidebar
ที่ 1920/2048 ถูกจำกัดและจัดกึ่งกลาง

**การ์ดประกาศ** (`.dash-ann`)

แต่ละรายการเป็นกล่องมีกรอบ + ไอคอนในกล่องสี 44×44
ไอคอนเลือกจากข้อมูลจริงที่มี: ปักหมุด = `pin` · ที่เหลือ = `megaphone`
ไม่มีฟิลด์ประเภทประกาศในข้อมูล จึงไม่เดาไอคอนจากเนื้อหาข้อความ
เพิ่ม Empty State `ยังไม่มีประกาศ` (เดิมปล่อยกรอบว่าง)

**การ์ดแจ้งเตือน** (`.dash-nt-grid`)

ย้ายออกจากคอลัมน์ขวามาเต็มความกว้างล่างสุด (`.dash-notify-full`)
3 คอลัมน์เฉพาะหน้าผู้ดูแล · ไอคอนแยกสีตาม `module` ที่ RPC ส่งมาจริง
(`leave` น้ำเงิน · `ot` ม่วง · `approval` เขียว) ไม่เดาจากข้อความ
จุดแดงยังไม่อ่านและลิงก์ `href` เดิมทั้งหมด

**ปัญหาจอล้นที่พบและแก้ (วัดจาก element ที่ right > clientWidth)**

| อาการ | ต้นเหตุ | การแก้ |
|-------|---------|--------|
| 1366 ล้น 1370/1366 | `.list-row .grow` ไม่มี `min-width: 0` ข้อความยาวดันคอลัมน์ Grid | เพิ่ม `min-width: 0` |
| 1280/1366 หน้าพนักงานล้น | การ์ดแจ้งเตือนบนหน้าพนักงานอยู่ในคอลัมน์แคบ แต่ได้ Grid 3 คอลัมน์ | จำกัด 3 คอลัมน์ไว้เฉพาะ `.dash-notify-full` |

**ผลทดสอบ — 28 ชุด (7 ความกว้าง × 2 Role × มีข้อมูล/ไม่มีข้อมูล)**

1024 · 1280 · 1366 · 1440 · 1920 · 2048 · มือถือ 390

| หัวข้อ | ผล |
|--------|-----|
| Horizontal Scroll | ไม่มีทุกชุด |
| Console / Page Error | 0 ทุกชุด |
| ชุดที่มีปัญหา | **0 จาก 28** |
| Regression มือถือ 390px | **0 px** ทั้ง USER และ SUPER_ADMIN |

**ทดสอบข้อมูลจริงผ่าน store เดิม (`localStorage['njhr_db_v3']`) ไม่ hardcode ใน UI**

คำขอลา: ป้อน 6 ใบ แสดง 5 ใบ เรียงใหม่→เก่า ชื่อ/ประเภท/วันที่/สถานะถูกต้อง
ประกาศ: ป้อน 4 (Active 3) แสดง 3 กรอง `active` ถูกต้อง วันที่และผู้ประกาศครบ
แจ้งเตือน: `njhr_notify_list` แสดง 3 รายการ ลิงก์ `#/leave` `#/approvals` `#/announcements` จุดยังไม่อ่านครบ
KPI 8 ใบ · กราฟ 4 แถว · ปฏิทิน 37 ช่อง วันนี้ไฮไลต์

**ไม่แตะ** `dashMobileHome` · Role · Route · SQL · RPC · Supabase · ไม่เพิ่ม Library

---


## Build `f1b136c1` — ไฟล์แนบไม่บังคับทุกประเภทการลาและ OT

**ไฟล์ที่เปลี่ยน**

`src/43-view-leave-form.js` · `src/45-view-ot-form.js` ·
`supabase-new/P1_leave_optional_doc.sql` (ใหม่ · รันบน Production แล้ว)

**ต้นเหตุที่พบ — บล็อก 2 ชั้น**

| ชั้น | จุด | เงื่อนไข |
|------|-----|---------|
| หน้าเว็บ | `src/43-view-leave-form.js:192` | `lt.needDoc && !files.length` |
| ฐานข้อมูล | `njhr_leave_submit` | `if v_type = 'SICK' and v_n = 0 then raise exception 'ลาป่วยต้องแนบเอกสารประกอบ'` |

ถอดเงื่อนไขหน้าเว็บอย่างเดียวไม่พอ เพราะ RPC ยังปฏิเสธ

**สิ่งสำคัญที่ตรวจพบระหว่างทาง**

`pg_get_functiondef` บน Production ยืนยันว่า `njhr_leave_submit` ใช้ signature
`p_files jsonb` ตรงกับ `supabase-new/46_leave_form.sql` **ไม่ใช่** `41_leave_rpc.sql`
ที่ใช้ `p_file_url` (เวอร์ชันเก่า) การเขียน Migration จากไฟล์ 41 จะลดรุ่น RPC
และทำลายคำขอที่มีไฟล์แนบหลายไฟล์ จึงสร้าง Migration จาก definition จริงของ Production

**SQL — `P1_leave_optional_doc.sql`**

สร้างจาก `pg_get_functiondef` ของ Production ทุกบรรทัด ลบเฉพาะ 3 บรรทัด:
`if v_type = 'SICK' and v_n = 0 then ... end if;`
มี PREFLIGHT ตรวจว่าเป็นเวอร์ชัน `p_files` ก่อนสร้างทับ · มี VERIFICATION 6 จุด · มี ROLLBACK
ไม่มี `DROP` / `ALTER` / `DELETE` / `UPDATE` / `TRUNCATE` / `GRANT` / `REVOKE` แม้แต่คำสั่งเดียว

**ผล VERIFICATION จาก Production หลังรันจริง**

| หัวข้อ | ค่า |
|--------|-----|
| `still_requires_sick_doc` | **false** |
| `keeps_reason_check` · `keeps_quota_check` · `keeps_overlap_check` | true ทั้งหมด |
| `keeps_file_shape_check` · `keeps_client_key_guard` | true ทั้งคู่ |
| `signature` / `returns` | เหมือนเดิมทุกตัวอักษร |
| `leave_requests_rows` / `leave_attachments_rows` | 2 / 1 — ข้อมูลเดิมไม่ถูกแตะ |

**หน้าเว็บ**

- ลบ `if (lt.needDoc && !files.length)` ออกจาก `src/43-view-leave-form.js`
- ข้อความเปลี่ยนเป็น `ไฟล์แนบไม่บังคับ · ไฟล์ละไม่เกิน 5MB` (เดิมขึ้น "ลาป่วย ต้องแนบเอกสารประกอบ")
- ฟอร์ม OT เพิ่มข้อความ `ไฟล์แนบไม่บังคับ` ที่ปุ่มแนบไฟล์และข้อความว่าง
- **ฟอร์ม OT ไม่มีเงื่อนไขบังคับแนบไฟล์อยู่แล้ว** ทั้งฝั่งหน้าเว็บและ `65_ot.sql`
  ตรวจแล้วไม่พบคำว่า "ต้องแนบ" หรือเงื่อนไขนับไฟล์ใด ๆ

**Validation ที่คงไว้ครบ**

เหตุผลการลา · วันที่ · ลำดับวันที่ · จำนวนวันทำงาน · ชั่วโมง · สิทธิ์คงเหลือ ·
ห้ามทับช่วง · ตรวจ name/url ของไฟล์ · กันกดส่งซ้ำ (`p_client_key` 10 นาที) ·
**การรอ `j.uploading` ที่ `src/45-view-ot-form.js:245` คงไว้ครบ** ·
รายการงาน OT อย่างน้อย 1 รายการ · ประเภทงาน

**ไม่แตะ** Workflow · ผู้อนุมัติ · สถานะคำขอ · สิทธิ์ผู้ใช้ · การคำนวณวันลาและ OT

**ผลทดสอบ (Browser Harness · เส้นทางจริง)**

| กรณี | ผล |
|------|-----|
| ลาป่วยไม่มีไฟล์ | **ส่งสำเร็จ** · `p_files = []` · error = null |
| ลากิจไม่มีไฟล์ | **ส่งสำเร็จ** · `p_files = []` · error = null |
| ข้อความ "ไฟล์แนบไม่บังคับ" | แสดงทั้งลาป่วยและลากิจ |

**ยังไม่ได้ทดสอบ** (ต้องใช้ Supabase Storage จริงและการอนุมัติจริง Harness จำลองไม่ได้)

ลางานมีไฟล์ · OT 1 JOB / หลาย JOB / ผสมแนบ-ไม่แนบ · ขณะกำลังอัปโหลด · Workflow อนุมัติเดิม

---


## Build `c3526d77` — แถวยาวเฉพาะ Desktop: ลางาน · OT · อนุมัติคำขอลา

**ไฟล์ที่เปลี่ยน**

`src/34-view-requests-leave.js` (`leaveCard`) · `src/35-view-ot.js` (`viewOT`) ·
`src/11-view-approvals-payroll.js` (`leaveApprovalCard`) · `src/css/styles.css`

**Desktop breakpoint ที่ใช้จริง: `@media (min-width: 1024px)`**
CSS ใหม่ทั้งหมดอยู่ในบล็อกนี้เท่านั้น ไม่มี Global CSS ใหม่

**วิธีที่ใช้ — แยก View ไม่แตะของเดิม**

ทั้ง 3 หน้าคืน Markup 2 ก้อน:
`.lv-row` / `.ap-row` ที่มี `.only-desktop` (แถวยาวใหม่) และ
`.req-card` / `.ap-card` ที่มี `.only-mobile` (การ์ดเดิมทุกบรรทัด ไม่ถูกแตะ)
มือถือจึงเหมือน Source เดิมทุกพิกเซล

**1. หน้าลางานของฉัน (Desktop) — 5 คอลัมน์**

`ประเภท/เลขที่ · วันที่ + เต็มวัน/จำนวนวัน · ไฟล์แนบ · สถานะ · จัดการ`
สูง 90px · ไม่มี Avatar/ชื่อซ้ำ · ไม่แสดงชื่อไฟล์ยาว · มีไฟล์แสดงจำนวน ไม่มีแสดง "ไม่มีไฟล์แนบ"
ปุ่ม `รายละเอียด / Timeline` เปลี่ยนเป็นปุ่มรูปตา `ดูรายละเอียด`
การ์ดสิทธิ์ลาป่วย/ลากิจ/พักร้อนด้านบนคงเดิม
**ไม่มีคอลัมน์ "สิทธิคงเหลือ" ต่อแถว** ตามที่ผู้ใช้ยืนยัน เพราะ `njhr_leave_list`
ไม่คืนสิทธิ์ ณ เวลาที่ยื่นแต่ละใบ การนำยอดรวมปัจจุบันมาแสดงซ้ำจะทำให้คำขอย้อนหลังคลาดเคลื่อน

**2. หน้า OT ของฉัน (Desktop) — 5 คอลัมน์**

`วันที่/เลขที่ · เวลา + จำนวนชั่วโมง / จำนวนงาน · ไฟล์แนบ · สถานะ · จัดการ`
ลบ Avatar `–` และ chip จุดหน้า "1 รายการงาน" เฉพาะ Desktop View
รูปแบบแถว สี ระยะห่าง ตรงกับหน้าลางาน

**3. หน้าอนุมัติ → แท็บคำขอลา (Desktop) — 6 คอลัมน์**

`พนักงาน (Avatar + ชื่อ + รหัส + แผนก) · รายละเอียดการลา · จำนวน · ไฟล์แนบ · สถานะ · จัดการ`
จำนวนแสดงเฉพาะจำนวนที่ขอ เช่น `ลา 1 วัน` ไม่มีสิทธิคงเหลือต่อแถว
ปุ่มเรียง `[รูปตา] [ขอข้อมูลเพิ่ม] [ไม่อนุมัติ] [อนุมัติ]`
แท็บคำขอ OT และลงชื่อย้อนหลังไม่ถูกแตะ

**Logic ที่ยืนยันว่าไม่เปลี่ยน**

ปุ่มทุกตัวใช้ `data-lvdetail` · `data-lvcancel` · `data-detail` · `data-cancel` ·
`data-approve` · `data-reject` · `data-moreinfo` ตัวเดิม
Handler เดิมจับจาก `data-*` จึงเป็น Logic เดิมทั้งหมด
ไม่แตะ RPC · Database · RLS · Workflow · Role · สถานะ · ตัวกรอง · Badge บน Tabs

**Blocker ที่แก้ระหว่างทาง**

`build.js` ปฏิเสธ: `chunk ot อ้าง dRow ซึ่งอยู่ใน chunk shared-hr-meta`
ตัวแปรชื่อชนกับ chunk อื่น เปลี่ยนเป็น `otDRow`

**ปัญหาที่พบและแก้**

หน้าอนุมัติที่ 1024px (SUPER_ADMIN) ล้นจอ `1103/1024` เพราะปุ่ม 4 ตัวกว้างเกิน
เพิ่ม `@media (min-width:1024px) and (max-width:1279px)` ย่อ padding/font/ไอคอน
แก้แล้วเหลือ `1024/1024`

**ผลทดสอบ Desktop (4 ความกว้าง × 3 หน้า × 2 Role = 24 ชุด)**

| หน้า | 1024 | 1366 | 1440 | 1920 |
|------|------|------|------|------|
| ลางาน | ไม่ล้น | ไม่ล้น | ไม่ล้น | ไม่ล้น |
| OT | ไม่ล้น | ไม่ล้น | ไม่ล้น | ไม่ล้น |
| อนุมัติ | ไม่ล้น | ไม่ล้น | ไม่ล้น | ไม่ล้น |

Console / Page Error = 0 ทุกชุด

**Regression มือถือ (เทียบ Build `94def1b3`)**

| หน้า | 390 USER | 390 SA | 430 USER | 430 SA |
|------|---------|--------|----------|--------|
| ลางาน | 0 px | 0 px | 0 px | 0 px |
| OT | 0 px | 0 px | 0 px | 0 px |
| อนุมัติ | 0 px | 0 px | ดูหมายเหตุ | 0 px |

หมายเหตุ: `#/approvals` จำกัด `roles: ['SUPER_ADMIN','ADMIN']` บัญชี USER ถูก Router
เด้งไป `#/dashboard` ภาพที่จับได้จึงเป็นหน้าหลัก เป็นความต่างจากจังหวะ redirect
ของ harness ไม่ใช่การเปลี่ยน UI — ยืนยันจาก 390 USER ที่ได้ 0 px ด้วยเงื่อนไขเดียวกัน

**ยังไม่ได้ทำในรอบนี้**

| รายการ | สถานะ |
|--------|-------|
| Modal รายละเอียดเฉพาะ Desktop (720–820px) | ยังใช้ Modal เดิมของระบบ (`showTimeline` / `lvShowTimeline`) |
| Toolbar แถวเดียว + จำนวนทั้งหมด | ยังเป็นของเดิม |
| ทดสอบ Action จริง (ยกเลิก · ขอข้อมูลเพิ่ม · อนุมัติ/ไม่อนุมัติ) | ยังไม่ได้ทดสอบ |

---


## Build `94def1b3` — UI มือถือหน้า "ตั้งค่าการอนุมัติ" (ส่วน C)

**ไฟล์ที่เปลี่ยน** `src/css/styles.css` เท่านั้น

**C.1 ชื่อชุด Workflow ยาว**

`.wf-set-head` บนมือถือเปลี่ยนเป็น Grid `minmax(0, 1fr) auto`
ชื่ออยู่คอลัมน์ 1 · badge สถานะอยู่คอลัมน์ 2 (`justify-self: end`)
แยกพื้นที่กันคนละคอลัมน์ badge จึงไม่ตกผิดรูปและไม่ทับชื่อ
ชื่อแสดงสูงสุด 2 บรรทัดด้วย `-webkit-line-clamp: 2`

**C.2 `as-warn-chips`**

ต้นเหตุ: กฎเดิมอยู่ใน `@media (min-width: 1024px)` เท่านั้น (`mobile.css:597`)
มือถือจึงไม่มี `gap` เลย ทำให้ "MANAGER" กับ "MANAGING DIRECTOR" ติดกัน
เพิ่มกฎฐานสำหรับทุกความกว้าง — `display: flex` · `flex-wrap: wrap` · `gap: 6px`
และ `.as-wchip` ได้ `max-width: 100%` + `overflow-wrap: anywhere`

**ผลตรวจ**

| หัวข้อ | Desktop | มือถือ |
|--------|---------|--------|
| ความสูงการ์ดในแถวเดียวกัน | `[148,148]` `[174,174]` `[148,148]` | เท่ากันทุกแถว |
| Horizontal Overflow | ไม่มี | ไม่มี |
| Console / Page Error | 0 | 0 |

**ไม่แตะ** Role · สิทธิ์ · ลำดับ Workflow · Logic การอนุมัติ · RPC · ฐานข้อมูล
Fixture อยู่ใน `harness/` เท่านั้น ไม่เข้า Deploy Build

**ส่วน A และ B ยังไม่ได้ทำ**

| ส่วน | สาเหตุ |
|------|--------|
| A ระบบแจ้งเตือน + Dedupe | ยังขาดโครงสร้างตาราง `njhr_doc*` จาก Production จึงยังไม่รู้ว่าเอกสาร HR แจ้งเตือนผู้ใด |
| B ตำแหน่ง/แผนกหายหลังรีเฟรช | พบต้นเหตุแล้ว แต่ยังไม่ได้เลือกแนวทางแก้ (B1 แก้ SQL / B2 แก้หน้าเว็บ) |

---


## Build `aee4353b` — REPORT ALL 37 คอลัมน์ + จำนวนครั้งสแกน + ผู้อนุมัติ OT

**ไฟล์ที่เปลี่ยน** `src/11-view-approvals-payroll.js` · `supabase-new/O2_report_all_ot.sql` (ใหม่)

**บั๊กเดิมที่พบและแก้: ข้อมูลเหลื่อมคอลัมน์**

อาร์เรย์ `cells` มีเพียง 28 ค่าทั้งที่ชีตมี 35 คอลัมน์ และไม่มีค่าของ
"รายละเอียดลงเวลา" ทำให้ข้อมูลตั้งแต่คอลัมน์ X เลื่อนขึ้น 1 ช่อง
(X แสดง "รวมวันลา" · Y แสดง "ลากิจ" …) และคอลัมน์ AC–AI ว่างเป็น `-` ทั้งหมด

เขียนใหม่ให้มี **37 ค่าเรียงตรงกับ `RP1_HEAD` ทุกตำแหน่ง** และเติม 5 คอลัมน์
ที่ไม่เคยมีข้อมูล: `รายละเอียดลงเวลา` · `รายละเอียดลา` · `รายละเอียด OT` ·
`OT 1.5/วันหยุด 1/OT 3` · `ผู้อนุมัติ OT`
เปลี่ยนลูปทั้ง 4 จุดให้อ้าง `RP1_N` แทนเลข 35 ที่ hardcode ไว้

**คอลัมน์ใหม่ 2 ช่อง**

`R จำนวนครั้งสแกนเข้า` · `S จำนวนครั้งสแกนออก` วางก่อน `ขาดสแกนเข้า`

```js
if (a.in  && !t.scanInD[a.date])  { t.scanInD[a.date]  = 1; t.scanIn++;  }
if (a.out && !t.scanOutD[a.date]) { t.scanOutD[a.date] = 1; t.scanOut++; }
```

นับจาก `check_in` / `check_out` จริงของ `njhr_att_report` (โซนเวลา Asia/Bangkok) ·
1 พนักงาน 1 วัน = สูงสุด 1 ครั้ง · นับก่อนตัดวันหยุด · ไม่มีข้อมูล = 0 ·
คำขอลงชื่อย้อนหลังอยู่ในตัวแปร `corrs` คนละลูป **จึงไม่ถูกนับเป็นการสแกนจริง**
และยังคงอยู่ในคอลัมน์ `Y ลงชื่อย้อนหลัง` เหมือนเดิม

**โครงสร้างสุดท้าย 37 คอลัมน์ A:AK**

| กลุ่ม | ช่วง | จำนวน |
|-------|------|-------|
| ข้อมูลพนักงาน | A:C | 3 |
| รายได้ | D:K | 8 |
| รายการหัก / เงินสุทธิ | L:Q | 6 |
| การลงเวลา | R:Z | 9 |
| การลา | AA:AF | 6 |
| OT | AG:AK | 5 |

`RP1_WRAP` → Z · AF · AG · `dimension`/`autoFilter` → AK ·
Conditional Formatting ขาดสแกน `T:U` · สาย `W` · รวมวันลา `AA`
สี · ฟอนต์ · เส้นขอบ · ความกว้าง · Freeze pane · สูตร `=SUM(D:J)` `=SUM(L:O)` `=K-P` คงเดิม

**SQL ใหม่ `njhr_report_all_ot` — คอลัมน์ผู้อนุมัติ OT**

ตรวจ Production ก่อนเขียน: `njhr_ot_list` คืน 20 คอลัมน์ **ไม่มีผู้อนุมัติเลย** ·
`ot_requests` **ไม่มีคอลัมน์ `timeline`** โค้ดเดิมที่อ่าน `o.timeline` จึงเป็นโค้ดตาย
`njhr_ot_decide` เขียนผู้อนุมัติลง `ot_requests.approvals` (jsonb)
`{at, by, role, action, note}` ต่อท้ายทุกครั้งที่ตัดสิน

RPC ใหม่ดึงเฉพาะ element ที่ `action = 'APPROVE'` เรียงตาม `with ordinality`
(= ลำดับขั้นจริง) รวมชื่อไม่ซ้ำด้วย `, ` · แปลง username → ชื่อจริงผ่าน
`njhr_user_display()` (`app_users.full_name` → `employees` → username) ·
เฉพาะ `status = 'APPROVED'` · ไม่มีผู้อนุมัติจริง = `'—'`

ใช้ `njhr_ot_guard(p_token)` ตัวเดียวกับ `njhr_ot_list` สิทธิ์จึงเท่าเดิม ·
`SECURITY DEFINER` + `set search_path = public` + `revoke from public` +
`grant to anon, authenticated`
**ไม่แตะ `njhr_ot_list` และ `njhr_ot_decide`** หน้าคำขอ/หน้าอนุมัติ/หน้า OT ไม่กระทบ
`rpCollect()` เรียก RPC ใหม่แทน `njhr_ot_list` เฉพาะ REPORT ALL
**จำนวน RPC ของหน้านี้ยังเป็น 5 ตัวเท่าเดิม**

**ผลทดสอบ (Harness · Fixture 5 RPC · 4 กรณี · JSZip 3.10.1 จาก node_modules ไม่ใช้ CDN)**

ทดสอบผ่านเส้นทางเดียวกับผู้ใช้จริง: เปิด `#/reportall` → เลือกวันที่ → กด EXPORT → ดักไฟล์จริง

| # | เช็ก | ผล |
|---|------|-----|
| 1 | 37 คอลัมน์ A:AK | ผ่าน |
| 2 | การลงเวลา R:Z (`merge R1:Z1`) | ผ่าน |
| 3 | การลา AA:AF | ผ่าน |
| 4 | OT AG:AK | ผ่าน |
| 5 | จำนวนครั้งสแกนถูกทั้ง 4 กรณี | ผ่าน |
| 6 | ลา · รายละเอียด OT · ชั่วโมง OT ใต้หัวข้อถูก | ผ่าน |
| 7 | AK ผู้อนุมัติจริง | ผ่าน |
| 8 | แถวไม่มีข้อมูล = 0 / — | ผ่าน |
| 9 | รายได้/หัก/สุทธิไม่เปลี่ยน | ผ่าน |
| 10 | ไม่เหลื่อมแม้แต่ 1 คอลัมน์ | ผ่าน |

กรณีทดสอบ: มีสแกนครบ (มี 2 แถวในวันเดียว → นับ 3 ไม่ใช่ 4) · มีลา · มี OT · ไม่มีข้อมูลเลย

**ยังไม่ได้ทดสอบกับข้อมูลจริง** — `ot_requests` บน Production มี 0 แถว

**ลำดับ Deploy:** ต้องรัน `O2_report_all_ot.sql` **ก่อน** อัปไฟล์เว็บ
ไม่งั้น REPORT ALL จะ error เพราะเรียก RPC ที่ยังไม่มีในฐานข้อมูล

---


## Build `86114ac6` — การ์ด "ตั้งค่าการอนุมัติ" 3 ส่วน + Modal รายละเอียด

**ไฟล์ที่เปลี่ยน** `src/12-view-reports-settings.js` · `src/css/styles.css` · `src/css/mobile.css`

**โครงสร้างการ์ดใหม่ (`asRenderWfList()`)**

| ส่วน | Class | เนื้อหา |
|------|-------|---------|
| บน | `.wf-set-head` | ชื่อชุดซ้าย (ตัดที่ 2 บรรทัดด้วย `-webkit-line-clamp`) · badge สถานะมุมขวา |
| กลาง | `.wf-set-info` | Chip ประเภทคำขอ · จำนวนขั้น · จำนวนผู้อนุมัติ (`flex-wrap: wrap`) |
| ล่าง | `.wf-set-acts` | `margin-top: auto` + เส้นคั่นบาง · ปุ่ม รูปตา/แก้ไข/ลบ ชิดขวา `flex-wrap: nowrap` |

`nowrap` ที่แถวปุ่มทำให้ไม่มีปุ่มตกไปคนละแถว · `margin-top: auto` ดันแถวปุ่มลงล่างสุด
ปุ่มทุกการ์ดจึงอยู่ระดับเดียวกัน

**รายละเอียดผังอนุมัติย้ายไป Modal**

- ลบบล็อก `.wf-set-depts` และ `.wf-set-tl` ออกจากการ์ดทั้งหมด การ์ดไม่ขยายตามเนื้อหาอีก
- ปุ่มรูปตา (`data-as-wfview`, `icon('eye')`) เปิด `asWfDetail()` — Modal อ่านอย่างเดียว
  แสดงชื่อชุด · ประเภทคำขอ · สถานะ · จำนวนขั้น · ผู้อนุมัติทั้งหมด · ขอบเขตแผนก ·
  แผนกที่ใช้ชุดนี้ · ลำดับการอนุมัติ (ผู้ยื่น → ขั้นที่ 1…N → สำเร็จ)
  แต่ละขั้นมีชื่อขั้น เงื่อนไข **ALL/ANY** และรายชื่อผู้อนุมัติพร้อมตำแหน่ง
- ใช้ `njhr_wf_steps` ตัวเดิม พารามิเตอร์เดิม **ไม่เพิ่ม RPC ใหม่**
- ปิดได้ 4 ทาง: ปุ่ม X · ปุ่ม "ปิด" · คลิกพื้นหลัง · **Escape** (ผูก/ถอด listener
  เฉพาะตอน Modal นี้เปิด ไม่แตะ `openModal()` ที่ Modal อื่นใช้ร่วม)
  คืนตำแหน่ง scroll เดิมทุกเส้นทางการปิด
- `box.onclick` จับเฉพาะ `[data-as-wfview]` `[data-as-wfedit]` `[data-as-wfdel]`
  **กดพื้นที่ว่างของการ์ดไม่เกิดอะไรขึ้น**

**ดีไซน์**

กรอบเทาอ่อน `#E4E9F2` 1px + เส้นซ้าย 3px (เขียว `#16A34A` เปิดใช้งาน · เทาปิดใช้งาน
พร้อมพื้น `#F8FAFC`) — เลิกใช้กรอบเขียวเข้มล้อมทั้งใบ
Padding 16px · Radius 12px · Gap 12px · เงา `0 1px 2px rgba(16,24,40,.04)`
Desktop 2 การ์ดต่อแถวทุกความกว้าง (จอ ≥1600px ปรับจาก 3 คอลัมน์เหลือ 2)

**ปุ่มจัดการ**

| ปุ่ม | Desktop | มือถือ | สี |
|------|---------|--------|-----|
| รูปตา `.wf-act-view` | 40×40 | 44×44 | น้ำเงิน `#1D4ED8` |
| แก้ไข `.wf-act-edit` | 40×40 | 44×44 | กรมท่า `#0B1F46` |
| ลบ `.wf-act-del` | 40×40 | 44×44 | เทา → แดง `#DC2626` เมื่อ hover |

`aria-label` และ `title` ครบทั้ง 3 ปุ่ม

**ผลวัดจริง (Harness)**

| หัวข้อ | Desktop | มือถือ |
|--------|---------|--------|
| ความสูงการ์ดในแถวเดียวกัน | `[148,148]` · `[174,174]` · `[148,148]` เท่ากันทุกแถว | คอลัมน์เดียว |
| ชื่อยาว 40 ตัวอักษร | สูงเท่าการ์ดชื่อสั้นในแถวเดียวกัน | ไม่ล้น |
| กดพื้นที่ว่างการ์ดเปิด Modal | false | false |
| รายละเอียดค้างในการ์ด | false | false |
| Modal ปิด 4 ทาง + คืน scroll | ผ่านทั้งหมด | ผ่านทั้งหมด |
| Modal พอดีจอ / เลื่อนเนื้อในได้ | 660×810 · true | 390×713 · true |
| Console / Page Error | 0 | 0 |

**ไม่แตะ** RPC · ฐานข้อมูล · Role · สิทธิ์ · Logic การอนุมัติ ·
`asOpenWf()` และ `asWfDelete()` คงเดิมทุกบรรทัด

**ค้างไว้ (นอกขอบเขต ยังไม่แก้)**

- มือถือ: badge สถานะตกบรรทัดใหม่เมื่อชื่อชุดยาว (ยังอ่านได้ ไม่ทับกัน)
- แถบเตือน `as-warn-chips` บนมือถือ ชื่อแผนกติดกันไม่มีระยะห่าง

---


## Build `7c889306` — ระบบแจ้งเตือน (Frontend) + Modal จัดการวันหยุด

**ไฟล์ที่เปลี่ยน**

`src/06-core-shared-boot.js` · `src/06-auth-supabase.js` · `src/04-router-guards.js` ·
`src/18-view-notifications.js` · `src/17-view-calendar.js` · `src/css/styles.css` ·
`harness/ui_shot.js` · `harness/mh_fixtures.js`

**ผลตรวจ Production ก่อนแก้ (ไม่เดา)**

| หัวข้อ | ผลจริง |
|--------|--------|
| `pg_publication_tables` ของ `supabase_realtime` | **ไม่มี `public.notifications`** → ใช้ Polling ตาม fallback ข้อ 3 |
| Index บน `notifications` | มีแค่ `notifications_pkey(id)` และ `njhr_notif_user_idx(user_id,is_read,created_at)` — **ไม่มี dedupe key** |
| คอลัมน์ `notifications` | 11 ตัว: `id` `user_id` `title` `body` `icon` `is_read` `created_at` `link` `kind` `module` `reference_id` |
| RPC ที่มี `insert into notifications` | 8 ตัว — `njhr_leave_submit/decide` · `njhr_ot_submit/decide` · `njhr_att_correction_submit/approve/reject` · `njhr_announcement_save` |
| ทดสอบด้วยข้อมูลจริง | ยื่นใบลา 1 ใบ → เกิด 2 แถวถึงผู้อนุมัติ 2 คน → ป้ายแดงขึ้นถูกต้อง |

**สิ่งที่แก้ (Frontend ล้วน ไม่แตะ SQL / RPC / ฐานข้อมูล)**

- ป้ายแดงทุกกระดิ่งอ่านจาก `_ntUnread` ตัวเดียว (`njhr_notify_unread`) จึงไม่มีทางนับซ้ำ
  ครอบ `#btn-bell` · `.att-mb-bell` · `.req-mb-bell` · เกิน 99 แสดง `99+`
- `NJHR.notify.paint()` ถูกเรียกหลัง `NJHR.views.render()` ทุกจุดรวมเส้นทาง lazy
  แก้อาการกระดิ่งมือถือไม่มีป้ายแดงเพราะ view เพิ่ง mount ทีหลัง
- Polling 45 วินาที + ตรวจทันทีเมื่อ `visibilitychange` / `focus` / `online`
  หยุดเมื่อหน้าอยู่เบื้องหลังหรือออกจากระบบ · `_ntBusy` กัน RPC ซ้อนกัน
- เสียงติ๊งสร้างจาก WebAudio ในเครื่อง **ไม่มีไฟล์เสียง ไม่มี CDN**
  ปลดล็อกหลัง Login และหลังผู้ใช้แตะหน้าจอครั้งแรก (ข้อจำกัด Autoplay)
  ตั้งค่าเปิด/ปิดที่ `NJHR.notify.setSound()` เก็บใน localStorage
  ทุกจุดครอบ `try/catch` เบราว์เซอร์ไม่อนุญาตเสียงก็ไม่พัง
- ดังครั้งเดียวต่อรอบแม้มีหลายรายการ · `_ntPrimed` กันดังตอน boot ·
  `_ntSeen` จำ id ที่เด้งแล้ว จึงไม่ดังซ้ำตอน render หรือเปลี่ยนหน้า
- Toast `.toast-nt` มีหัวข้อ · เนื้อหา · เวลา · กดแล้วเรียก `njhr_notify_read`
  **ก่อน** เปิดหน้าปลายทาง (`link` จาก `njhr_notify_link`)
- "อ่านทั้งหมดแล้ว" อัปเดตทุกป้ายแดงทันทีผ่าน `NJHR.notify.paint()`
  เปิดแอปหรือเปิดหน้าแจ้งเตือน **ไม่** ทำเครื่องหมายว่าอ่าน
- `navigator.setAppBadge` / `clearAppBadge` พร้อม fallback ปลอดภัย

**Modal "จัดการวันหยุดบริษัท" (#/calendar)**

- แถบเครื่องมือแถวเดียว `.ch-tools` — ปี · โหลดวันหยุดราชการ · วางรายการวันหยุด ·
  เพิ่มวันหยุด · Export Excel ปุ่มสูงเท่ากัน ไม่ตกบรรทัด
  Desktop ขยาย Modal เป็น 880px (รูปแบบเดียวกับ `.modal:has(#ot-f)` ที่มีอยู่แล้ว)
  มือถือลดขนาดก่อน ไม่พอจึงเลื่อนแนวนอน ไม่ให้ปุ่มซ้อนกัน
- คอลัมน์ "จัดการ" ไอคอนแก้ไข/ลบเรียงแนวนอน กึ่งกลาง gap 10px (มือถือ 8px)
  พื้นที่กด 40×40 · `data-ch-edit` / `data-ch-del` และ Handler เดิมไม่เปลี่ยน

**ผลทดสอบ (unread = 120)**

| หน้า | กระดิ่งที่มองเห็น | ป้าย |
|------|-------------------|------|
| หน้าหลัก มือถือ/Desktop | `#btn-bell` | `99+` |
| ลงเวลา มือถือ | `.att-mb-bell` | `99+` |
| คำขอ มือถือ | `.req-mb-bell` | `99+` |

ตรงกันทั้ง USER และ SUPER_ADMIN · `pageerror` 0 · `check-all-js.js` PASSED ·
`calendar_test.js` PASSED

**ยังไม่ได้ทำ (ต้องแก้ SQL — แยกรอบ)**

| ข้อ | สิ่งที่ขาด |
|-----|-----------|
| 4 | เอกสาร HR (`njhr_doc_issue` · `njhr_doc_ack` · `njhr_doc_respond`) ไม่มีการแจ้งเตือน |
| 4 | ยกเลิกคำขอ (`njhr_leave_cancel` · `njhr_att_correction_cancel` · `njhr_doc_cancel`) ไม่มี |
| 4 | สมาชิกใหม่รออนุมัติ → SUPER_ADMIN ไม่มี RPC ใดรับผิดชอบ |
| 5 | dedupe key — ยังไม่มี unique index กดปุ่มซ้ำจะได้แถวซ้ำ |

---


## Build `78756a07` — Touch Target ≥ 44×44 บนมือถือ โดยไม่ขยับ Layout

**ไฟล์ที่เปลี่ยน** `src/css/mobile.css` · `src/07-view-dashboard.js` (ห่อข้อความ 1 บรรทัด)

**ปัญหาที่วัดได้ก่อนแก้**

ปุ่มบนมือถือ 5 จุดเล็กกว่า 44×44 px
`#drawer-close` 38×38 · `#btn-bell` 38×38 · `#pfm-close` 38×38 ·
`.att-mb-more` 34×34 · `.mh-t .mh-more` 49×20
และเมนูในลิ้นชักของ ADMIN/SUPER_ADMIN สูง 38–42 px (`.user-shell` ตั้ง 48 px
ไว้ให้ USER อยู่แล้ว แต่ไม่ครอบ Role ผู้ดูแล)

**การแก้ — ขยายพื้นที่กดออกนอก Layout**

ขยายกล่องปุ่มเป็น 44×44 แล้วชดเชยด้วย Negative Margin เท่ากับส่วนที่โต
พื้นที่กดจึงโตออกนอก Layout โดยตำแหน่งไอคอน ข้อความ และความสูงการ์ดไม่ขยับ

| ปุ่ม | เดิม | ชดเชย |
|------|------|--------|
| `.side-close` · `#btn-bell` · `.pfm-x` | 38×38 | `margin: -3px` |
| `.att-mb-more` | 34×34 | `margin: -5px -5px -5px auto` |
| `.mh-t .mh-more` | 49×20 | `margin-top/-bottom: -12px` + `padding-left: 12px` |
| `.side-menu .menu-item` · `.menu-cat-btn` | 38–42 | `min-height: 44px` (ลิ้นชักเป็นชั้นลอย ไม่ดัน Layout) |

**กรณี `.mh-more` — ซ้อน `.mh-pd` 1.2 px**

หลังขยายเป็น 44 px ขอบล่างของพื้นที่กดอยู่ที่ 411.7 px ซึ่งล้ำแถวรายการ
รออนุมัติแถวแรกที่เริ่มต้น 410.5 px เป็นระยะ 1.2 px
`margin` แนวตั้งขยับไม่ได้เพราะตำแหน่งถูกกำหนดโดย `align-items` ของ flex container

แก้โดยแยกข้อความออกเป็น `.mh-more-label` แล้ว
`transform: translateY(-2px)` ที่ `.mh-more` (ยกพื้นที่กด) และ
`transform: translateY(2px)` ที่ `.mh-more-label` (เลื่อนข้อความกลับ)
พร้อม `pointer-events: none` ให้ Handler อยู่ที่ `.mh-more` ตัวเดิม
ขอบล่างใหม่ = 409.7 px ไม่ชน `.mh-pd` แม้แต่เศษพิกเซล

ไม่ใช้ `top` / `margin` / `padding` เพิ่มที่ container · ไม่แตะ `z-index` ·
ไม่ลดพื้นที่กดต่ำกว่า 44 px · ไม่แตะ `.ic` ขนาดไอคอนที่มองเห็นคงเดิม

**Desktop ไม่ได้รับผลกระทบ** — กฎทั้งหมดอยู่ใน `@media (max-width: 900px)`

**ผลตรวจ**

| หัวข้อ | ผล |
|--------|-----|
| Touch Target < 44×44 บนมือถือ | **0 จุด** ทุกหน้า ทุก Role |
| `overlapsExcludingDrawerStack` | **0** |
| `.mh-more` ซ้อน `.mh-pd` | **0 px** (409.7 vs 410.5) |
| Pixel Diff มือถือ 4 หน้า × 2 Role | **0 px ทั้ง 8 ภาพ** |
| Pixel Diff Desktop × 2 Role | **0 px ทั้ง 2 ภาพ** |
| Console / Page Error | **0** |
| Horizontal Overflow | **0** |
| ปุ่มไร้ Handler | **0** |
| ปุ่มไอคอนล้วนที่ขาด `aria-label` | **0** |

**ไม่แตะ** ฟอนต์น้ำหนัก 500 (ใช้จริง 24 จุด) · `index.html` (ไม่ได้เพิ่ม `media` attribute) ·
SQL / RPC / Workflow / Role / Permission · Desktop

---


## Build `828b7e95` — ตัด RPC ที่เสียเปล่าออกจากหน้าหลักมือถือ

**ไฟล์ที่เปลี่ยน** `src/07-view-dashboard.js` (แก้ 1 เงื่อนไข)

**คอขวดที่วัดได้ก่อนแก้**

หน้าหลักมือถือยิง RPC **14 ตัว** ต่อการเปิด 1 ครั้ง · FCP 648 ms
เทียบกับหน้าอื่นที่ยิง 5–9 ตัว · FCP 228–260 ms

`njhr_empfile_list` ถูกยิงทุกครั้งแม้ `photo_url` จะว่าง เพราะเงื่อนไขเดิมเป็น
`if (dashHomePhoto(...)) ... else dashHomePhotoSigned(...)`
ซึ่ง `else` ครอบทั้งกรณี "เป็น path ใน Storage" และกรณี "ไม่มีค่าเลย"
บน Production ที่ `employees.photo_url` ว่างทั้ง 108 คน จึงเสีย 1 Round-trip
ฟรีให้ผู้ใช้ทุกคนทุกครั้งที่เปิดหน้าหลัก โดยไม่มีทางได้รูปกลับมา

**การแก้**

เพิ่มเงื่อนไข `else if (pv)` — เรียก `dashHomePhotoSigned()` เฉพาะเมื่อ
`photo_url` มีค่าจริงแต่ไม่ใช่ URL เต็มเท่านั้น

**ผลที่วัดได้หลังแก้**

| หัวข้อ | ก่อน | หลัง |
|--------|------|------|
| RPC หน้าหลัก (มือถือ) | 14 | **13** |
| RPC หน้าหลัก (Desktop) | 14 | **13** |

**เส้นทางรูปพนักงานยังครบทั้ง 3 แบบ**

| `photo_url` | ผลลัพธ์ | `njhr_empfile_list` |
|-------------|---------|---------------------|
| URL เต็ม | รูปแสดง (`data-uri 132x132`) | 0 ครั้ง |
| path ใน Storage | รูปแสดงผ่าน Signed URL | 1 ครั้ง |
| ว่าง | Avatar ตัวอักษร | **0 ครั้ง** |

**Pixel Diff — ทุกหน้า `0 px / 0.0000%`**

Desktop · หน้าหลักมือถือ · หน้าลงเวลา · หน้าคำขอ · หน้าโปรไฟล์ ทั้ง USER และ SUPER_ADMIN

**ปุ่มที่กดไม่ได้**

สแกน `button` / `a[href]` / `[role=button]` ที่มองเห็นได้ ทุก Route × 2 ขนาดจอ
หา element ที่ไม่มี handler ทั้ง inline และ delegated → **พบ 0 ปุ่ม**
`ออกงาน` ที่ `disabled` เป็นพฤติกรรมถูกต้อง (ยังไม่ได้เข้างาน)

**ยังไม่แก้ (รออนุมัติ — จะทำให้ Pixel Diff เปลี่ยน)**

Touch Target < 44px จำนวน 5 จุด: `#drawer-close` 38×38 · `#btn-bell` 38×38 ·
`.mh-more` 49×20 · `.att-mb-more` 34×34 · `#pfm-close` 38×38

---


## Build `e5e38134` — หน้าคำขอมือถือตามภาพ PNG แบบผสม (#/requests)

รวมงานหน้าลงเวลามือถือ (ถอดการ์ดพนักงาน + ปุ่มลงเวลา 2 คอลัมน์) ไว้ด้วย

**ไฟล์ที่เปลี่ยน**

`src/34-view-requests-leave.js` · `src/33-view-attendance.js` · `src/css/mobile.css` ·
`harness/ui_shot.js` · `harness/mh_fixtures.js`

**หน้าคำขอ (#/requests) — มือถือเท่านั้น**

- Desktop เดิมห่อ `.only-desktop` ครบทุกบรรทัด · มือถือใช้ Layout ใหม่ `.req-mb`
- หัวแถบกรมท่าไล่เฉด + โลโก้ NJL แดง + `NJL HR` + `ระบบบริหารทรัพยากรบุคคล` + กระดิ่ง + ชื่อหน้า `คำขอ`
- การ์ดขาว `สรุปสิทธิ์การลา` 3 ช่อง (ลาป่วยเขียว · ลากิจส้ม · พักร้อนน้ำเงิน)
  ค่ามาจาก `njhr_leave_balances.remaining` จริง · กำกับหัวข้อว่า **คงเหลือ**
  ไม่มีข้อมูล = แสดง `—` (ไม่เดาเป็นศูนย์) · ระหว่างโหลดใช้ Skeleton
- ปุ่มแนวนอน 3 รายการ สูง 78px — `ยื่นใบลา` → `nav('#/leave')` ·
  `ขอ OT` → `nav('#/ot')` · `ลงชื่อย้อนหลัง` → `lvOpenAction('attendance-correction')`
  → `NJHR.features.attendanceCorrection.open()` (Flow เดิมที่ยิง `njhr_att_correction_submit`)
- แท็บ `ล่าสุด` / `รออนุมัติ` / `เสร็จแล้ว` — Active แดง + เส้นแดงใต้
  เปลี่ยนแท็บใช้ข้อมูลที่โหลดแล้ว **ไม่ยิง RPC ซ้ำ**
- รายการรวม 3 ประเภทจาก `njhr_leave_list` · `njhr_ot_list` (p_mine=true) ·
  `njhr_att_correction_list` โหลดแบบ settle ต่อ Promise — ประเภทหนึ่งล้ม อีกประเภทยังแสดงได้
- Status Mapping ใช้ `rhStatus()` เดิม ไม่สร้างสถานะใหม่ · REJECTED แสดงในแท็บเสร็จแล้ว
- ไม่มี Employee Mapping = ปิดการสร้างคำขอและแจ้ง Error ไม่แตะปุ่มอื่น

**หน้าลงเวลา (#/attendance) — มือถือเท่านั้น**

- ถอดการ์ดพนักงานออกทั้ง Markup (`att-mb-emp`) และ CSS ไม่ได้ซ่อนด้วย `visibility`
- ปุ่ม `เข้างาน` / `ออกงาน` เป็น 2 คอลัมน์กว้างเท่ากันด้วย `minmax(0, 1fr)`
- `attMe()` และตรรกะเปิด-ปิดปุ่มคงเดิมทุกบรรทัด

**ไม่แตะ**

SQL · RPC · RLS · Workflow · Edge Function · ฐานข้อมูล · Role/Permission ·
Desktop · หน้าหลักมือถือ · หน้าโปรไฟล์ · Bottom Navigation และ Header ของ Route อื่น

**Pixel Diff — ทุกหน้าที่ไม่อยู่ใน Scope**

| หน้า | Baseline | USER | SUPER_ADMIN |
|------|----------|------|-------------|
| Desktop 1440×900 | `f5b5aa0e` | 0 px / 0.0000% | 0 px / 0.0000% |
| หน้าหลักมือถือ | `e86ff36b` | 0 px / 0.0000% | 0 px / 0.0000% |
| หน้าลงเวลามือถือ | `1464e9af` | 0 px / 0.0000% | 0 px / 0.0000% |
| หน้าโปรไฟล์มือถือ | `f5b5aa0e` | 0 px / 0.0000% | 0 px / 0.0000% |

**หมายเหตุ Build ID** — `build.js` คำนวณ Build ID จาก hash ของไฟล์ผลลัพธ์
ค่าจึงเป็น `e5e38134` ตามเนื้อไฟล์จริง ไม่สามารถกำหนดเองได้โดยไม่แก้เนื้อโค้ด

---


## Build `e86ff36b` — หน้าหลักมือถือตามภาพ PNG ล่าสุด (#/dashboard)

รวมงานปฏิทินองค์กรของ build `fdf80871` ไว้ครบ (build นั้นไม่ได้ปล่อยแยก)

**ไฟล์ที่เปลี่ยน**

`src/07-view-dashboard.js` (เฉพาะ `dashMobileHome()` + helper ใหม่ 4 ตัว) ·
`src/css/mobile.css` (บล็อก `.mh`) ·
`harness/ui_shot.js` (ใหม่) · `harness/mh_shot.js` · `harness/mh_fixtures.js` ·
`harness/fonts/` (ใหม่ · @fontsource/prompt 5.3.0 · OFL-1.1)

**รายการแก้ไข**

- พื้นหลังหน้าหลักเป็น Gradient กรมท่า `#0B1F46 → #12305F → #0B1F46` + radial 2 ชั้น
  เต็มความกว้างจอโดยหัก padding ของ `.main-view` (`margin: -14px -16px -96px`)
  ใช้เทคนิคเดียวกับ `.pfm` ที่มีอยู่แล้ว
- **ตัด Emoji ออกทั้งหมด** เปลี่ยนเป็น `icon()` ชุด SVG ของระบบ
  (`calendar` · `clock` · `calendarOff` · `timer` · `history`)
- การ์ดพนักงาน Gradient ฟ้าอ่อน→ขาว · ลิงก์ไป `#/profile` · มีลูกศรขวา
  และแถบสถานะลงเวลาพื้นส้มในการ์ด (ป้อนจาก `njhr_att_today` ตัวเดิม ไม่เพิ่ม RPC)
- **แก้ `แผนก: —`** — `dashHomeDept()` ไล่หาจากแหล่งจริง 4 ชั้น
  `dept(deptId)` → `e.deptName` → `u.sb.emp_department` → `u.department`
  ไม่มีค่าจริงเลย = ซ่อนบรรทัดแผนกทิ้ง ไม่แสดง `—`
  ต้นเหตุ: `njhr_session_check` (`31_secure_session.sql:80`) ไม่คืน `emp_department`
  ต่างจาก `njhr_login` ค่าจึงหายทุกครั้งที่ตรวจ session ซ้ำ
- **รูปพนักงาน** — เพิ่ม `njhr_me_get` (อ่านอย่างเดียว ทุก Role เรียกได้) เติมเฉพาะ
  รูป · แผนก · รหัสพนักงาน บนการ์ด รองรับ 3 เส้นทาง
  1) `photo_url` เป็น `https://` หรือ `data:image/` → ใช้ตรง
  2) เป็น path ใน Storage → `njhr_empfile_list` หา `PERSONAL/PHOTO` แล้วขอ Signed URL
     ผ่าน Edge Function `njhr-emp-file` ด้วย `file_id`
  3) ไม่มี / ขอไม่สำเร็จ / รูปเสีย → Avatar ตัวอักษร (วางไว้ข้างหลังเสมอ หน้าไม่พัง)
  ไม่มีการเขียน `photo_url` หรือ Signed URL ลง Console หรือ DOM attribute ใด
  **สภาพ Production วันนี้: `employees.photo_url` ว่างทั้ง 108 คน และ
  `njhr_emp_files` หมวด `PERSONAL/PHOTO` มี 0 แฟ้ม → ทุกคนได้ Avatar ตัวอักษร**
- การ์ดสถิติ 2×2 เขียว/ฟ้า/ส้ม/ม่วง · สถานะวันนี้ส้มอ่อน (นาฬิกาลดจาก 34px เหลือ 13px)
  · Chip รออนุมัติเหลือง · ไอคอนรายการ เขียว/ม่วง/ส้ม · ประกาศเป็นการ์ด Gradient น้ำเงิน
- `padding-bottom: calc(100px + env(safe-area-inset-bottom))` กันประกาศถูก Bottom Nav บัง
- หัวแถบ `.tb-mb` ลด padding บน-ล่างเหลือ 6px · โลโก้ 44×32
- แก้บั๊กเดิม: `.mh { display:flex }` เคยถูก `.only-mobile{display:block!important}` ทับ

**Regression ที่จับได้ระหว่างทดสอบ และแก้แล้ว**

`.mh { display: flex !important }` เขียนไว้นอก media query จึงไปทับ
`.only-mobile { display: none }` ของ Desktop ทำให้หน้าหลักมือถือโผล่บนจอ Desktop
(`onlyMobileVisible` = 1 เทียบกับ Baseline = 0)
แก้โดยย้ายเฉพาะ `display` เข้า `@media (max-width: 900px)`

**ไม่แตะ**

Desktop · SQL / RPC / Workflow · Role / Permission · Bottom Navigation · Route ·
Header กรมท่าทุก Role · หน้าลงเวลา / คำขอ / โปรไฟล์ ·
การโหลด Google Fonts ของ Production (`index.html:10` คงเดิมทุกตัวอักษร)

**ผลทดสอบ (harness/ui_shot.js)**

เงื่อนไขเดียวกันทุกภาพ: Fixture ชุดเดียว · `TZ=Asia/Bangkok` · เวลาตรึง 10 ส.ค. 2569 09:41 ·
`animation`/`transition` = `none !important` · ฟอนต์ Prompt จากไฟล์ในเครื่อง

| หัวข้อ | ผล |
|--------|-----|
| Pixel Diff Desktop 1440×900 USER | 0 px จาก 1,296,000 = 0.0000% |
| Pixel Diff Desktop 1440×900 SUPER_ADMIN | 0 px จาก 1,296,000 = 0.0000% |
| Desktop `.only-mobile` ที่มองเห็น | 0 / 3 ทั้ง 2 Role (เท่ากับ Baseline) |
| จอล้นแนวนอน | ไม่มี — มือถือ 390/390 · Desktop 1440/1440 |
| Console Error / `pageerror` | 0 ทุกภาพ |
| `document.fonts.check()` มือถือ | 400 · 500 · 600 · 700 = `true` ครบ |
| `document.fonts.check()` Desktop | 400 · 600 · 700 = `true` · **500 = `false`** |
| `getComputedStyle(body).fontFamily` | `Prompt, "Segoe UI", Tahoma, sans-serif` |

หมายเหตุน้ำหนัก 500 บน Desktop: หน้า Desktop ไม่ได้เรียกใช้ `font-weight: 500`
เบราว์เซอร์จึงไม่ activate face ตัวนั้น `document.fonts.check()` คืน `false`
เป็นสถานะ `unloaded` ตามปกติของ CSS Font Loading API **ไม่ใช่ฟอนต์โหลดไม่สำเร็จ**
และเป็นค่าเดียวกันทั้ง Baseline และ Build ใหม่

**MD5 ของไฟล์ Deploy ที่เปลี่ยน (เทียบ `f5b5aa0e`)**

`asset-manifest.js` · `config.js` · `index.html` · `sw.js` ·
`mobile.css` · `views/dashboard.js` · `views/calendar/main.js`
ไฟล์ Deploy อีก 31 ไฟล์ MD5 เท่าเดิมทุกค่า

**ยังไม่ผ่าน / ยังไม่ได้ทำ**

| หัวข้อ | สถานะ |
|--------|-------|
| รัน `N1_calendar_rpc.sql` บน Production | ยังไม่ได้รัน |
| Login จริง 3 Role บน Production | NOT TESTED |
| `pg_get_functiondef` ของ RPC จริงบน Production | ยังไม่ได้รับ |
| Google Fonts CDN โหลดสำเร็จบน Production | ยังไม่มีหลักฐาน — Harness ใช้ไฟล์ในเครื่อง |

---


## Build `fdf80871` — ปฏิทินองค์กรเปิดให้ทุก Role ดูได้ (#/calendar)

**อาการ**

ทุก Role กดเมนู "ปฏิทินองค์กร" แล้วได้ `เชื่อมต่อฐานข้อมูลไม่สำเร็จ / คุณไม่มีสิทธิ์ดูข้อมูลพนักงาน`
ทั้งที่อินเทอร์เน็ตปกติ

**ต้นเหตุ (ยืนยันจาก Source · ไม่ใช่การเดา)**

หน้าเดิมเรียก 4 RPC พร้อมกันใน `Promise.all()` ตัวใดตัวหนึ่งถูกปฏิเสธสิทธิ์ → ทั้งหน้าล้ม

| RPC | Guard | ผลกับ Role `USER` |
|---|---|---|
| `njhr_dept_list` (`55_departments.sql:66`) | `njhr_emp_guard(p_token,false)` | ถูกปฏิเสธ — ข้อความ `คุณไม่มีสิทธิ์ดูข้อมูลพนักงาน` |
| `njhr_leave_report` (`45_leave_reports.sql:107`) | `njhr_rpt_guard` | ถูกปฏิเสธ |
| `njhr_ot_list` (`65_ot.sql:195`) | `njhr_ot_guard` | จำกัดเฉพาะของตนเอง |
| `njhr_holiday_list` (`58_holidays.sql:57`) | `njhr_ctx` | ผ่าน |

`njhr_ctx()` แปลง role ผ่าน `njhr_norm_role()` ซึ่ง map `USER` → `EMPLOYEE` (`41_leave_rpc.sql:86`)
แต่ `njhr_emp_guard` อนุญาตเฉพาะ `SUPER_ADMIN / ADMIN / HR / MANAGER / ACCOUNT`
`EMPLOYEE` จึงไม่อยู่ในรายการ → USER ทุกคนเปิดปฏิทินไม่ได้

**ไฟล์ที่เปลี่ยน**

`src/17-view-calendar.js` (แก้ 4 จุด) · `supabase-new/N1_calendar_rpc.sql` (ใหม่) ·
`harness/calendar_test.js` (ใหม่) · `package.json` (เพิ่ม script `test:calendar`)

**รายการแก้ไข**

- **SQL ใหม่ `njhr_calendar_month(p_token, p_from, p_to, p_dept uuid)` → `jsonb`**
  ตรวจ Session เองจาก `njhr_sessions` + `app_users` บังคับ `app_code='salary'` และ `is_active`
  **ไม่เรียก** `njhr_emp_guard` และ **ไม่เรียก** `njhr_rpt_guard`
  `SECURITY DEFINER` · `set search_path = public` · `revoke from public` + `grant to anon, authenticated`
  จำกัดช่วงวันที่ไม่เกิน 62 วัน · กรองแผนกด้วย `employees.department_id` (UUID)
  คืนเฉพาะ `departments(id/code/name)` · `holidays(date/name)` ·
  `leaves(start/end/display_name/department)` · `ot(date/display_name/department)`
  ไม่มีเหตุผลลา · รายละเอียดงาน OT · เอกสารแนบ · ชั่วโมง/ยอดเงิน OT · เลขบัตรประชาชน · เบอร์โทร · เงินเดือน
- `calLoad()` เรียก RPC ตัวเดียวแทน `Promise.all()` 4 ตัว — `seq` guard เดิมคงไว้
- `eventsOf()` อ่านวันหยุดจากผลลัพธ์ RPC (`calState.holSet` / `holLabel`) แทน `holHas()/holName()`
  จึงตัด fallback `db.holidays` ที่เคยดึงข้อมูลค้างในเครื่องออก
- Error State แสดงเฉพาะ `ไม่สามารถโหลดปฏิทินองค์กรได้ กรุณาลองใหม่` ไม่หลุดข้อความ SQL/สิทธิ์
- Session หมดอายุ → `doLogout(true)` ตาม Flow เดิม ไม่แสดงข้อมูลค้าง

**ไม่แตะ**

`njhr_emp_guard` · `njhr_rpt_guard` · `njhr_ctx` · `njhr_norm_role` · `njhr_dept_list` ·
`njhr_leave_report` · `njhr_ot_list` · `njhr_holiday_list` · `njhr_holiday_save/delete/impact` ·
สิทธิ์หน้ารายงาน · สิทธิ์ทะเบียนพนักงาน · เมนูปฏิทินของ USER · Schema · ข้อมูล · RLS ·
หน้าหลัก / ลงเวลา / คำขอ / โปรไฟล์

**MD5 ของไฟล์ Deploy ที่เปลี่ยน**

| ไฟล์ | MD5 |
|------|-----|
| `views/calendar/main.js` | `f5448f346e8038895a1151a8b9988cf9` |
| `asset-manifest.js` | `98f72e131078a968a73c499ebebe4baa` |
| `sw.js` | `f763009549645b4d18799843badecbb9` |
| `config.js` | `117ee8affeab0117c096c16f21b77927` |
| `index.html` | `0ae970803c1140f67ab55aaa971b73d8` |

ไฟล์ Deploy อีก 33 ไฟล์ MD5 เท่าเดิมทุกค่า (`styles.css` `f004525e…` · `mobile.css` `cf4f6d61…` ·
`runtime/core.js` `11b6e189…` · `compat/app-legacy.js` `60cb63ce…`)

**สถานะ**

| หัวข้อ | ผล |
|--------|-----|
| `node build.js --check` | ตรงกัน — build `fdf80871` |
| `node harness/check-all-js.js` | CHECK PASSED |
| `node harness/calendar_test.js` | PASSED — 65 ข้อ |
| SUPER_ADMIN / ADMIN / USER เปิดปฏิทินได้ | ผ่าน (Harness) |
| 3 Role เห็นวันหยุด/ลา/OT ชุดเดียวกัน | ผ่าน (Harness) |
| USER ไม่มีปุ่มเพิ่ม/แก้ไข/ลบวันหยุด | ผ่าน (Harness) |
| ADMIN/SUPER_ADMIN ยังจัดการวันหยุดได้ | ผ่าน (Harness) |
| กรองแผนกส่ง Department UUID | ผ่าน (Harness) |
| เปลี่ยนเดือนเร็ว ๆ ข้อมูลเก่าไม่ทับ | ผ่าน (Harness) |
| Error State / Session หมดอายุ | ผ่าน (Harness) |
| **รัน `N1_calendar_rpc.sql` บน Production** | **ยังไม่ได้รัน** |
| **Login จริง 3 Role บน Production** | **NOT TESTED** |
| **Playwright Regression (`test:p3`)** | **รันไม่ได้ — ไม่มี Chromium ในสภาพแวดล้อม Build** |

---


## Build `64e9dacd` — รอบที่ 2 (Error Handling ในกล่องยืนยัน)

**ไฟล์ที่เปลี่ยน**

`src/12-view-reports-settings.js` · `src/13-view-admin-users.js`

**รายการแก้ไข**

- ถอด `.catch` ที่แสดงข้อความอย่างเดียวออกจาก callback ของ `confirmDialog` **14 จุด**
  Error จึงถูกส่งกลับให้ `confirmDialog` จัดการ — Modal ค้างไว้ · แสดงข้อความใน `#cf-err` ·
  ปุ่มยืนยันกลับมากดใหม่ได้ · ปุ่มยกเลิกใช้ได้
- ข้อความผิดพลาดเดิมคงไว้ทั้งหมด (มาจาก `e.message` แหล่งเดียวกัน)
- คงไว้ 1 จุดโดยเจตนา — ปิดใช้งานกะที่ยังมีพนักงานใช้อยู่ (`12-view-reports-settings.js:649`)
  `.catch` ตัวนี้ไม่ได้แสดงข้อความอย่างเดียว แต่เปิดกล่องยืนยันซ้ำเพื่อ **บังคับปิด** (`p_force = true`)
  ถ้าถอดออกจะเสียเส้นทางบังคับปิดกะทั้งหมด

**MD5 ของไฟล์ Deploy**

| ไฟล์ | MD5 |
|------|-----|
| `app.js` | `95c8b81c856dfcba58276ceec1c1aeb1` |
| `styles.css` | `b00c290bc01396fd6edb1c70e5a6aa91` |
| `mobile.css` | `319b5a7affb218b933f76d1b7e449d91` |
| `index.html` | `bcb937ffb715f59919b4217bcd31f81f` |
| `sw.js` | `e524b4f6c96a3278f6a8abdfd0135ca4` |
| `config.js` | `5c517c0de521c0862d56bbd3d9f97eac` |
| `face.js` | `aaa22b51db0a01e822fbb75b323b6aaf` |
| `face.css` | `972e97c4839966ea70a7d8e2579288fa` |

**สถานะ**

| หัวข้อ | ผล |
|--------|-----|
| Regression 162 จุด | ต่าง 5 จุด — ความต่างโดยเจตนาที่อนุมัติแล้ว |
| Error → Modal ค้าง + แสดงข้อความ | ผ่าน |
| กดยืนยันใหม่หลัง Error | ผ่าน — ข้อความถูกล้าง ทำงานต่อได้ สำเร็จแล้ว Modal ปิด |
| กดยืนยันรัว 4 ครั้ง | RPC ยิง 1 ครั้ง |
| Console Error | ไม่มี |
| **gzip / Brotli** | **ยังไม่สามารถยืนยันจาก Production Response Header ได้** |
| Production Real Data | NOT TESTED |

---


## Build `f837637a` — รอบที่ 2 (แก้ 4 จุดที่ยังไม่ผ่าน)

**ไฟล์ที่เปลี่ยน**

`face.js` · `src/01-core-icons-utils.js` · `src/09-view-attendance.js` ·
`src/11-view-approvals-payroll.js` · `src/12-view-reports-settings.js` ·
`src/14-view-profile-hrdocs.js`

**รายการแก้ไข**

- callback ของ `confirmDialog` อีก 4 จุดคืน Promise แล้ว — ปิดใช้งานรายการเงินเดือน · ลบรายการเงินเดือน ·
  อนุมัติคำขอลา · ดำเนินการเอกสาร HR · ย้ายข้อมูลลงเวลา
  (`piBulkRun` · `send` · `fire` เพิ่ม `return` ให้คืน Promise · `run` คืนอยู่แล้ว)
- `face.js` ใช้ `loadStyleOnce` ตัวเดียวกับ `app.js` ผ่าน `window.NJHR_loadStyleOnce`
  ไม่มี `createElement('link')` เหลือใน `face.js` แล้ว
- เปิด `window.NJHR_loadStyleOnce` · `window.NJHR_loadScriptOnce` · `window.NJHR_asset`
  ให้โมดูลนอก IIFE ใช้ตัวโหลดชุดเดียวกัน
- ไฟล์ในโปรเจกต์ทุกตัวมี `?v=BUILD` ครบ — `face.js` · `face.css` · `master-salary.js` · `report-template.js`

**MD5 ของไฟล์ Deploy**

| ไฟล์ | MD5 |
|------|-----|
| `app.js` | `3c548251688f8f8828fd636c09c9e6b3` |
| `styles.css` | `b00c290bc01396fd6edb1c70e5a6aa91` |
| `mobile.css` | `319b5a7affb218b933f76d1b7e449d91` |
| `index.html` | `93dcca1fd0d9236592b56064037a43a0` |
| `sw.js` | `e572985cc450ec4ab82aaf8647dde2b1` |
| `config.js` | `b051f3886f08fba55dc92dcbb8053929` |
| `face.js` | `aaa22b51db0a01e822fbb75b323b6aaf` |
| `face.css` | `972e97c4839966ea70a7d8e2579288fa` |
| `master-salary.js` | `f64184805450a817bf70653a293f184f` |
| `report-template.js` | `a4067da78b7d4ad779d9c1259bccb03b` |

**สถานะ**

| หัวข้อ | ผล |
|--------|-----|
| Regression 162 จุด | ต่าง 5 จุด — ความต่างโดยเจตนาที่อนุมัติแล้ว |
| Screenshot | ไม่ต่างจากรอบก่อน |
| `app.js` โหลด | 1 ครั้ง |
| Console Error | ไม่มี |
| กดยืนยันรัว 4 ครั้ง | RPC ยิง 1 ครั้ง |
| Horizontal overflow | ไม่มี |
| **gzip / Brotli** | **ยังไม่สามารถยืนยันจาก Production Response Header ได้** |
| Production Real Data | NOT TESTED |

---


## Build `a56344e3` — รอบที่ 2 (แก้ 5 จุดที่ยังไม่ผ่าน)

**ไฟล์ที่เปลี่ยน**

`sw.js` · `face.js` · `src/01-core-icons-utils.js` · `src/03-ui-toast-modal.js` ·
`src/08-view-employees.js` · `src/09-view-attendance.js` · `src/10-view-requests-leave-ot.js` ·
`src/11-view-approvals-payroll.js` · `src/12-view-reports-settings.js` · `src/13-view-admin-users.js`

**รายการแก้ไข**

- `confirmDialog` รองรับ `onOk` ที่คืน Promise — แสดง Loading ที่ปุ่มยืนยัน ไม่ปิด Modal จนกว่าจะสำเร็จ
  ปิดปุ่มยกเลิกระหว่างทำงาน · เพิ่มช่อง `#cf-err` แสดงข้อความผิดพลาด · งาน synchronous ทำงานเหมือนเดิม
- callback ของ `confirmDialog` **22 จุด** คืน Promise แล้ว
- Service Worker เลิกใช้ `ignoreSearch: true` — เทียบ URL ตรงตัวรวม `?v=`
  และค้นเฉพาะ cache ของ build ปัจจุบันด้วย `caches.open(V).then(c => c.match(...))`
- `face.css` ใช้ Build Version เดียวกับ `face.js` จาก `window.NJHR_BUILD_VERSION`
  โหลดไม่สำเร็จจะลบ `<link>` และรีเซ็ต `S.cssAdded` ให้ลองใหม่ได้
- `loadStyleOnce()` เลิกกลืน Error — `onerror` reject จริง · timeout 20 วินาที · ลบ link ที่เสีย · ลองใหม่ได้

**MD5 ของไฟล์ Deploy**

| ไฟล์ | MD5 |
|------|-----|
| `app.js` | `59bc799cddccde96cdb52ba8787ab5d1` |
| `styles.css` | `b00c290bc01396fd6edb1c70e5a6aa91` |
| `mobile.css` | `319b5a7affb218b933f76d1b7e449d91` |
| `index.html` | `291a1b193b0702b6762cab3290af7f74` |
| `sw.js` | `1dbf7f3801b8994461f1d01e0035b503` |
| `config.js` | `65b2fd064d8c856ce7696e4f99d8958e` |
| `face.js` | `4273ab1b22ef9a05c43a851a43c9cd56` |
| `face.css` | `972e97c4839966ea70a7d8e2579288fa` |

**สถานะ**

| หัวข้อ | ผล |
|--------|-----|
| Regression 162 จุด | ต่าง 5 จุด — ความต่างโดยเจตนาที่อนุมัติแล้ว |
| `app.js` โหลด | 1 ครั้ง |
| Console Error | ไม่มี |
| กดยืนยันรัว 4 ครั้ง | RPC ยิง 1 ครั้ง |
| **gzip / Brotli** | **ยังไม่สามารถยืนยันจาก Production Response Header ได้** |
| Production Real Data | NOT TESTED |

---


## Build `8c90a997` — รอบที่ 2 (ปรับประสิทธิภาพความเสี่ยงต่ำ)

**ไฟล์ที่เปลี่ยน**

`index.html` · `sw.js` · `build.js` · `config.js` (build เขียนให้) ·
`src/01-core-icons-utils.js` · `src/03-ui-toast-modal.js` · `src/08-view-employees.js` ·
`src/09-view-attendance.js` · `src/11-view-approvals-payroll.js` ·
`src/12-view-reports-settings.js` · `src/14-view-profile-hrdocs.js` ·
`src/15-view-salary-merge-boot.js` · `src/css/styles.css`

**รายการแก้ไข**

- เลิกล็อกปุ่มทั้งหน้า — เหลือเฉพาะ `cursor: progress` · `SB_INFLIGHT` ยังกัน RPC ซ้ำ
- เพิ่ม `withButtonLoading()` ล็อกเฉพาะปุ่มที่กด คืนสถานะเสมอ
- เลิกใช้ `document.write` — เปลี่ยนเป็น `NJHR_loadBootScript()` (`script.async = false`)
- แก้ bootstrap ให้ตรวจ `document.readyState` กันระบบไม่เริ่มเมื่อ `DOMContentLoaded` ยิงไปก่อน
- เพิ่ม `loadScriptOnce()` / `loadStyleOnce()` — Promise cache · timeout 20 วินาที · ลองใหม่ได้
- Loader ทั้ง 8 จุดใช้ Helper กลางแล้ว ลบ Loader เดิมออกหมด
- เพิ่ม `njAsset()` ใส่ `?v=BUILD` ให้ไฟล์ในโปรเจกต์
- `build.js` เขียน Build Version ลง `sw.js` · `config.js` · `index.html` จากแหล่งเดียว
- Service Worker แบ่ง Core / Lazy / Network-only · เลิกกลืน Install Error · เพิ่ม `mobile.css` ที่ขาด

**MD5 ของไฟล์ Deploy**

| ไฟล์ | MD5 |
|------|-----|
| `app.js` | `4ebae007c0e49e9f871ee7a3c7933962` |
| `styles.css` | `b00c290bc01396fd6edb1c70e5a6aa91` |
| `mobile.css` | `319b5a7affb218b933f76d1b7e449d91` |
| `index.html` | `eafa913c373a85f77b04478af2a919f2` |
| `sw.js` | `5f0195ece1925537d7f47f5f225d2feb` |
| `config.js` | `632af6f1c3ebcf6ba07d0f3db63e12fb` |

**สถานะ**

| หัวข้อ | ผล |
|--------|-----|
| Regression 162 จุด | ต่าง 5 จุด — ความต่างโดยเจตนาที่อนุมัติแล้วทั้งหมด |
| `app.js` โหลด | 1 ครั้ง |
| Console Error | ไม่มี |
| Library ตอน Login | ไม่โหลดเลย |
| Cache | Core/Lazy แยกกลุ่ม · Asset ใช้ Build เดียวกัน |
| **gzip / Brotli** | **ยังไม่สามารถยืนยันจาก Production Response Header ได้** |
| Production Real Data | NOT TESTED |

---


## v2.2.0 — Build `29108eaf` (รอบสุดท้าย)

### เพิ่ม — กรอบการ์ด Workflow ตามสถานะ

หน้า `#/approval-settings` · การ์ดชุด Workflow (`.wf-set`)

| สถานะ | กรอบ | พื้นหลัง |
|-------|------|----------|
| มีขั้นอนุมัติและมีผู้อนุมัติครบแล้ว | 2px `#16A34A` เขียว | เดิม |
| 0 ขั้น **หรือ** ผู้อนุมัติ 0 คน | 2px `#FCA5A5` แดงอ่อน | `#FEF6F6` แดงอ่อนมาก |
| ปิดใช้งาน | 2px `#CBD5E1` เทา | เดิม |

มุมโค้งเดิม (Desktop 14px · Mobile 12px) · ขนาดการ์ดไม่เปลี่ยน · ลำดับการ์ดไม่เปลี่ยน

**ไฟล์ที่แก้ 3 ไฟล์**

| ไฟล์ | เปลี่ยน |
|------|---------|
| `src/12-view-reports-settings.js` | +3 บรรทัด — คำนวณ `wfStat` แล้วเติมเป็น class |
| `src/css/styles.css` | +4 บรรทัด (1091–1094) |
| `src/css/mobile.css` | +4 บรรทัด (619–622) |

---

## v2.1.0 — Build `c659103d`

- Build system: terser + clean-css (`mangle:false` · `compress:false` · CSS `level 2:false`)
- ย้ายต้นฉบับ CSS ไป `src/css/` · ไฟล์ที่รากเป็นผลลัพธ์ build
- Cache Version ใน `sw.js` ผูกกับ hash ของ build อัตโนมัติ
- `build.js` portable — `require('terser')` / `require('clean-css')` + `package.json` + `package-lock.json`
- Initial Payload 1,234,527 → 870,247 B (−29.5%) · Initial load 330 → 210 ms

## v2.0.x — Clone Baseline และหมวด D

| เวอร์ชัน | เปลี่ยน |
|----------|---------|
| v2.0.0 | Clone Baseline จาก NJ-HR-V10 (102 ไฟล์) |
| v2.0.1 | แยก Environment เป็น `config.js` |
| v2.0.2 | Environment Safety Gate + รหัส CFG-001…007 |
| v2.0.3 | รองรับ `file://` (ตัด query string ออกจาก config loader) |
| v2.0.4 | unregister Service Worker เฉพาะ scope ของ V2 |
| v2.0.5 | **แก้บั๊ก** `dRow is not defined` — หน้าโปรไฟล์พังทั้งหน้าใน V1 |
| v2.1.0-a | แยก `app.js` เป็น 15 Source Modules + `build.js` |
| v2.1.0-b | **แก้บั๊ก** `docContractProbationTemplate` ประกาศซ้ำ (36 บรรทัด dead code) |
| v2.1.0-c | **แก้บั๊ก** `njhr_att_report` ยิงซ้ำที่ `#/reports` (in-flight dedup) |
| v2.1.0-d | ลบ CSS declaration ที่ซ้ำ 4 จุด |
| v2.1.0-e | ลบ dead code 10 function + 4 ตัวแปร (−101 บรรทัด) |

## สิ่งที่ไม่เคยเปลี่ยนเลยตลอดทุกเวอร์ชัน

UI · DOM · Class · ID · Route ทั้ง 28 · Menu 5 หมวด · Role และ Permission · Workflow · สูตรคำนวณ · RPC Contract · Data Contract · Import / Export / Print · Database Schema · SQL · Storage Bucket

**V1 ไม่ถูกแก้และไม่ถูกกระทบ** — hash รวมทรี V1 `04fc2c8054257be3e3a3d3d1a6212b4c` เท่าเดิมตลอด
