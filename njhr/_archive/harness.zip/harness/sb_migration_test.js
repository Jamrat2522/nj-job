/* sb_migration_test.js — ตรวจการย้าย Data Source จาก Local → Supabase รอบนี้
     1. OT   — รายการ · ยื่น · ยกเลิก · อนุมัติ/ไม่อนุมัติ · รายละเอียด
     2. Dashboard Desktop — KPI · กราฟ · ประกาศ
     3. Announcement — list · detail · create · edit · ปิดใช้งาน
     4. Profile — โหลด/บันทึกข้อมูลติดต่อ
     5. Settings — โหลด/บันทึกตั้งค่าทั่วไป
   เงื่อนไขร่วมทุกชุด: db.* ว่างเปล่าเหมือน Production จริง
   ถ้าจุดใดยังอ่าน localStorage จะตกทดสอบทันที
   ใช้: node harness/sb_migration_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(62) + (d || '')); }
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
  .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const tick = ms => new Promise(r => setTimeout(r, ms || 50));
const fmtDMY = v => {
  const p = String(v == null ? '' : v).slice(0, 10).split('-');
  if (p.length !== 3) return '—';
  const z = n => (n < 10 ? '0' + n : '' + n);
  return z(+p[2]) + '/' + z(+p[1]) + '/' + (+p[0]);
};

/* ================= ข้อมูลฝั่งเซิร์ฟเวอร์จำลอง ================= */
const OT_LIST = [
  { id: '11111111-1111-1111-1111-111111111111', request_no: '260811-0001',
    employee_id: 'e1', emp_code: 'NJ001', prefix: 'นาย', emp_name: 'สมชาย ใจดี', nickname: 'ชาย',
    department: 'ขนส่ง', position_name: 'พนักงานขับรถ',
    ot_date: '2026-08-11', start_time: '18:00:00', end_time: '21:00:00', spans_next_day: false,
    ot_hours: 3, reason: 'ปิดงบ', status: 'PENDING', created_at: '2026-08-11T03:00:00Z',
    jobs_count: 2, files_count: 1, is_holiday: false }
];
const OT_GET = {
  request: { id: OT_LIST[0].id, ot_date: '2026-08-11', start_time: '18:00:00', end_time: '21:00:00',
    spans_next_day: false, ot_hours: 3, reason: 'ปิดงบ', status: 'PENDING',
    approvals: [{ at: '2026-08-11T03:00:00Z', by: 'user1', action: 'SUBMIT' }] },
  employee: { id: 'e1', emp_code: 'NJ001', name: 'นายสมชาย ใจดี', department: 'ขนส่ง', position: 'พนักงานขับรถ' },
  jobs: [
    { no: 1, job_code: 'JB-1', detail: 'ตรวจสินค้า', job_type: 'ตรวจปล่อย', job_date: '2026-08-11',
      start_time: '18:00:00', end_time: '21:00:00', spans_next_day: false, end_date: '2026-08-11', ot_hours: 1.5 },
    { no: 2, job_code: 'JB-2', detail: 'คีย์ใบขน', job_type: 'คีย์ใบขน', job_date: '2026-08-11',
      start_time: '18:00:00', end_time: '21:00:00', spans_next_day: false, end_date: '2026-08-11', ot_hours: 1.5 }
  ]
};
const OT_FILES = [{ job_no: 1, job_code: 'JB-1', file_name: 'doc.pdf', file_url: 'https://x/doc.pdf',
  file_path: 'p/doc.pdf', file_size: 10, content_type: 'application/pdf', created_at: '2026-08-11T03:00:00Z' }];

const DASH = {
  as_of: '2026-08-11T10:00:00', today: '2026-08-11', role: 'SUPER_ADMIN', is_manager: true,
  can_see_payroll: true, employee_id: 'e1',
  company: { employees_active: 111, employees_probation: 2, checked_in_today: 80, late_today: 5,
    on_leave_today: 6, ot_today: 3, pending_leave: 4, pending_ot: 2, pending_correction: 1,
    pending_document: 0, pending_total: 7 },
  me: {}, announcements: [
    { id: 'a1', title: 'ประกาศหยุดยาว', content: 'x', priority: 'HIGH', publish_at: '2026-08-10T00:00:00Z' },
    { id: 'a2', title: 'อบรมความปลอดภัย', content: 'y', priority: 'NORMAL', publish_at: '2026-08-09T00:00:00Z' }
  ],
  recent_leaves: [], recent_ots: [],
  payroll: { period_month: 7, period_year: 2026, status: 'CONFIRMED' }
};

/* แถวจาก njhr_ot_report (1 แถว = 1 JOB) สำหรับทดสอบ Payroll
   เซิร์ฟเวอร์กรอง p_status/p_from/p_to ให้แล้ว — ชุดนี้จำลองการกรองฝั่ง RPC จริง */
const OT_REPORT_ALL = [
  /* Case 1 · e1 คำขอเดียว 3 ชม. แยก 2 JOB (1.5 + 1.5) → รวมต้องได้ 3 ไม่ใช่ 6 */
  { ot_id: 'r1', job_no: 1, job_code: 'A', job_date: '2026-08-11', job_hours: 1.5,
    request_hours: 3, employee_id: 'e1', emp_code: 'NJ001', status: 'APPROVED', total_count: 5 },
  { ot_id: 'r1', job_no: 2, job_code: 'B', job_date: '2026-08-11', job_hours: 1.5,
    request_hours: 3, employee_id: 'e1', emp_code: 'NJ001', status: 'APPROVED', total_count: 5 },
  /* Case 5 · คนละพนักงาน ต้องไม่ปนกัน */
  { ot_id: 'r2', job_no: 1, job_code: 'C', job_date: '2026-08-12', job_hours: 2,
    request_hours: 2, employee_id: 'e2', emp_code: 'NJ002', status: 'APPROVED', total_count: 5 },
  /* Case 2/3 · Pending และ Rejected — RPC จะไม่ส่งมาเมื่อ p_status='APPROVED' */
  { ot_id: 'r3', job_no: 1, job_code: 'D', job_date: '2026-08-13', job_hours: 9,
    request_hours: 9, employee_id: 'e1', emp_code: 'NJ001', status: 'PENDING', total_count: 5 },
  { ot_id: 'r4', job_no: 1, job_code: 'E', job_date: '2026-08-14', job_hours: 7,
    request_hours: 7, employee_id: 'e1', emp_code: 'NJ001', status: 'REJECTED', total_count: 5 },
  /* Case 6 · คนเดิมแต่คนละงวด (กรกฎาคม) ต้องไม่ถูกนับในงวดสิงหาคม */
  { ot_id: 'r5', job_no: 1, job_code: 'F', job_date: '2026-07-20', job_hours: 5,
    request_hours: 5, employee_id: 'e1', emp_code: 'NJ001', status: 'APPROVED', total_count: 5 }
];

const ATT_TODAY = { work_date: '2026-08-11', check_in: '2026-08-11T01:30:00Z',
  check_out: null, status: 'PRESENT', work_hours: 0, late_min: 0,
  shift_name: 'กะปกติ', shift_start: '08:30:00', shift_end: '17:30:00', late_allow_minutes: 15 };
const LEAVE_BAL = [
  { leave_type: 'SICK', quota: 30, used: 2, pending: 0, remaining: 28 },
  { leave_type: 'VACATION', quota: 6, used: 1, pending: 0, remaining: 5 },
  { leave_type: 'OTHER', quota: null, used: 0, pending: 0, remaining: null }
];
const LEAVE_MINE = [
  { id: 'lv-1', request_no: '260810-0007', leave_type: 'SICK', start_date: '2026-08-10',
    end_date: '2026-08-12', total_days: 3, hours: 0, status: 'PENDING', ui_status: 'PENDING',
    created_at: '2026-08-09T03:00:00Z', total_count: 1 }
];
const ANN_FEED = [
  { id: 'f1', title: 'ประกาศถึงพนักงาน', content: 'x', priority: 'HIGH', is_important: true,
    require_ack: false, publish_at: '2026-08-10T00:00:00Z', is_read: false, acked: false,
    unread_count: 1, total_count: 1 }
];

const ANN_LIST = [
  { id: 'a1', title: 'ประกาศหยุดยาว', content: 'เนื้อหาประกาศ', priority: 'HIGH',
    publish_at: '2026-08-10T00:00:00Z', expire_at: null, is_active: true, is_live: true,
    created_by: 'admin', created_at: '2026-08-10T00:00:00Z', updated_by: 'admin',
    updated_at: '2026-08-10T00:00:00Z', total_count: 2 },
  { id: 'a2', title: 'ประกาศเก่า', content: 'เก่า', priority: 'NORMAL',
    publish_at: '2026-07-01T00:00:00Z', expire_at: null, is_active: false, is_live: false,
    created_by: 'admin', created_at: '2026-07-01T00:00:00Z', updated_by: 'admin',
    updated_at: '2026-07-01T00:00:00Z', total_count: 2 }
];

const ME = { employee: { id: 'e1', emp_code: 'NJ001', first_name: 'สมชาย', last_name: 'ใจดี',
  nickname: 'ชาย', birth_date: '1990-05-01', national_id: '1234567890123',
  phone: '0812345678', email: 'somchai@njl.test', address: '99 หมู่ 1', emergency_phone: '0899999999' },
  perm: {}, personal: {}, documents: {} };

const SETTINGS = [
  { key: 'company_name', value: 'N.J. LOGISTICS & FRUITS CO., LTD.', category: 'company', is_public: true },
  { key: 'work_start_time', value: '08:00', category: 'attendance', is_public: true },
  { key: 'late_grace_minutes', value: 15, category: 'attendance', is_public: true }
];

/* ================= สภาพแวดล้อม ================= */
function env(opt) {
  opt = opt || {};
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div><div id="modal-root"></div></body></html>');
  const win = dom.window;
  const calls = [];
  const toasts = [];
  /* db.* ว่างทั้งหมด — Production จริงเป็นแบบนี้ */
  const db = { employees: [], attendance: [], leaves: [], ots: [], corrections: [], payroll: [],
    announcements: [], holidays: [], notifications: [], leaveTypes: [], departments: [],
    users: [], balances: [], shifts: [], audit: [],
    settings: { companyName: 'เดิมในเครื่อง', workStart: '07:00', lateGrace: 99 } };
  let savedDb = 0;
  const NJHR = {
    state: { currentRoute: opt.route || '#/ot', docPending: 0, lvPending: 0 },
    router: { navId: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    features: { requestDetail: { open: (k, id) => { calls.push({ fn: '__detail', body: { k, id } }); } } },
    views: { register: () => {} }, compat: { scope: {} }
  };
  function rpcRouter(fn, body) {
    calls.push({ fn, body });
    if (opt.fail && opt.fail.indexOf(fn) >= 0) return Promise.reject(new Error('permission denied for ' + fn));
    switch (fn) {
      case 'njhr_ot_list': return Promise.resolve(OT_LIST);
      case 'njhr_ot_report': {
        /* จำลองการกรองของ RPC จริง: p_status + ช่วง p_from/p_to */
        const st = String(body.p_status || '').toUpperCase();
        const rows = OT_REPORT_ALL.filter(r =>
          (st === '' || st === 'ALL' || r.status === st) &&
          (!body.p_from || r.job_date >= body.p_from) &&
          (!body.p_to || r.job_date <= body.p_to));
        return Promise.resolve(rows.map(r => Object.assign({}, r, { total_count: rows.length })));
      }
      case 'njhr_pay_entry_totals': return Promise.resolve([]);
      case 'njhr_att_today': return Promise.resolve(ATT_TODAY);
      case 'njhr_leave_balances': return Promise.resolve(LEAVE_BAL);
      case 'njhr_leave_list': return Promise.resolve(LEAVE_MINE);
      case 'njhr_ann_feed': return Promise.resolve(ANN_FEED);
      case 'njhr_att_correction_list': return Promise.resolve([]);
      case 'njhr_ot_get': return Promise.resolve({ data: OT_GET });
      case 'njhr_ot_attach_list': return Promise.resolve(OT_FILES);
      case 'njhr_ot_submit': return Promise.resolve({ id: 'new-ot-uuid', ot_date: '2026-08-12', ot_hours: 3, jobs_count: 1, status: 'PENDING' });
      case 'njhr_ot_decide': return Promise.resolve({ id: body.p_id, status: body.p_action === 'APPROVE' ? 'APPROVED' : body.p_action === 'REJECT' ? 'REJECTED' : 'CANCELLED' });
      case 'njhr_ot_attach_add': return Promise.resolve({});
      case 'njhr_dashboard_summary': return Promise.resolve({ data: DASH });
      case 'njhr_announcement_list': return Promise.resolve(ANN_LIST);
      case 'njhr_announcement_get': return Promise.resolve({ data: ANN_LIST[0] });
      case 'njhr_announcement_save': return Promise.resolve({ id: body.p_id || 'new-ann', title: body.p_title, is_active: true });
      case 'njhr_announcement_set_active': return Promise.resolve({ id: body.p_id, is_active: body.p_active });
      case 'njhr_me_get': return Promise.resolve({ data: ME });
      case 'njhr_me_save': return Promise.resolve({ data: ME });
      case 'njhr_setting_list': return Promise.resolve(SETTINGS);
      case 'njhr_setting_save': return Promise.resolve({ key: body.p_key, value: body.p_value });
      case 'njhr_leave_types': return Promise.resolve([]);
      case 'njhr_rpt_leave_list': return Promise.resolve([]);
      case 'njhr_notify_list': return Promise.resolve([]);
      default: return Promise.resolve([]);
    }
  }
  Object.assign(NJHR.compat.scope, {
    icon: (n, cls) => '<span class="ic ' + (cls || '') + '" data-i="' + (n || '') + '"></span>', esc, debounce: f => f,
    avatarHTML: n => '<span class="avatar" data-n="' + esc(n) + '"></span>',
    emptyState: m => '<div class="empty"><p>' + m + '</p></div>',
    fmtDate: d => String(d || ''), fmtDateDMY: fmtDMY, todayISO: () => '2026-08-11',
    statusBadge: s => '<span class="badge">' + s + '</span>',
    currentUser: () => ({ id: 'u1', username: 'admin', role: 'SUPER_ADMIN', empId: 'e1' }),
    currentEmp: () => ({ id: 'e1', code: 'NJ001', title: 'นาย', firstName: 'สมชาย', lastName: 'ใจดี',
      position: 'พนักงานขับรถ', deptId: 'd1', phone: '', email: '', shift: '08:30-17:30' }),
    emp: () => null, empName: () => 'สมชาย ใจดี', dept: () => 'ขนส่ง',
    db: db, saveDB: () => { savedDb++; }, saveDbGuard: () => true,
    audit: (a) => { calls.push({ fn: '__audit', body: a }); },
    notify: () => { calls.push({ fn: '__notify' }); },
    notifyApprovers: () => { calls.push({ fn: '__notifyApprovers' }); },
    toast: (m, t) => { toasts.push({ m, t }); },
    nowStamp: () => '2026-08-11 10:00', uid: p => p + '-x', money: String, pad: n => (n < 10 ? '0' + n : '' + n),
    fmtMonthYear: (m, y) => m + '/' + y, round2: v => Math.round((Number(v) || 0) * 100) / 100,
    maskAcc: String, userOfEmp: () => null, balance: () => ({ used: 0 }),
    otJobsOf: o => (o.jobs || []), otJobHours: () => 0, otReqHours: () => 0, otFileCount: () => 0,
    TH_MONTHS: ['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'],
    TH_DAYS: ['อา','จ','อ','พ','พฤ','ศ','ส'], isHoliday: () => false, holName: () => '',
    startLiveClock: () => {}, pendingCount: () => 0, remainDays: () => 0,
    sbReady: () => true, sbToken: () => 'tok',
    sbRpc: (fn, body) => rpcRouter(fn, body).then(r => (Array.isArray(r) ? r[0] : r)),
    sbRpcList: (fn, body) => rpcRouter(fn, body).then(r => (Array.isArray(r) ? r : (r ? [r] : []))),
    openModal: (t, b, f) => {
      win.document.getElementById('modal-root').innerHTML =
        '<div class="modal-head"><h3>' + t + '</h3></div><div class="modal-body">' + b +
        '</div><div class="modal-foot">' + (f || '') + '</div>';
    },
    closeModal: () => { win.document.getElementById('modal-root').innerHTML = ''; },
    confirmDialog: (t, m, ok, fn) => { calls.push({ fn: '__confirm' }); return fn(); },
    withButtonLoading: (b, t, f) => f(),
    lvType: c => ({ name: c }), lvNum: v => Number(v) || 0, lvCode: x => String(x && x.id || x),
    lvModeTxt: m => m, lvMode: () => 'FULL', LEAVE_TYPES: [],
    rhStatus: () => ({ k: 'PENDING', c: 'badge-warn', t: 'รออนุมัติ' }),
    showTimeline: () => { calls.push({ fn: '__showTimeline' }); },
    bindReqCardActions: () => {}, refreshMenuBadge: () => {}, refreshLeavePending: () => {},
    /* ตัวนับ Badge จาก State กลาง (core) — chunk อื่นเรียกเพื่อไม่ต้องยิง RPC ซ้ำ */
    setOtPending: n => { calls.push({ fn: '__setOtPending', body: n }); },
    setFxPending: n => { calls.push({ fn: '__setFxPending', body: n }); },
    refreshOtPending: () => { calls.push({ fn: '__refreshOtPending' }); },
    refreshFixPending: () => { calls.push({ fn: '__refreshFixPending' }); },
    refreshPendingAll: () => {}, hydrateSettings: () => {},
    otJobsHTML: it => '<div class="otj-view" data-jobs="' + ((it.jobs || []).length) + '">' +
      (it.jobs || []).map(j => '<div class="otj-vrow">JOB ' + esc(j.job) + ' ' + esc(j.jobType) +
        ' ' + ((j.files || []).length) + ' ไฟล์</div>').join('') + '</div>',
    otBindJobFiles: () => {}, otJobEndDate: j => j.endDate || j.date,
    otSpan: () => null, otJobsOf: o => (o.jobs || []),
    ROLE_TH: { SUPER_ADMIN: 'ผู้ดูแลระบบสูงสุด', ADMIN: 'ผู้ดูแล', USER: 'พนักงาน' },
    dRow: (k, v) => '<div><small>' + k + '</small><b>' + esc(v) + '</b></div>',
    doLogout: () => {}, pfMobileHtml: () => '<div class="pfm"></div>',
    canAccess: () => true, gfGet: () => ({ mode: 'PROTOTYPE', radius: 200 }),
    ltLoad: () => {}, loadScriptOnce: () => Promise.resolve(),
    njAsset: a => a, rptSafeName: String, rptDateBE: String,
    rptLoadZip: () => Promise.resolve(), rptBuildXlsx: () => Promise.resolve({})
  });
  win.NJHR = NJHR;
  win.URL.createObjectURL = () => 'blob:x';
  win.URL.revokeObjectURL = () => {};
  const ctx = vm.createContext(win);
  return { win, NJHR, calls, toasts, db, savedDb: () => savedDb,
    run: rel => vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), ctx, { filename: rel }),
    host: () => win.document.getElementById('app'),
    doc: () => win.document,
    called: fn => calls.filter(c => c.fn === fn),
    body: fn => (calls.filter(c => c.fn === fn).slice(-1)[0] || {}).body };
}
function grab(E, name) { let f = null; E.NJHR.views.register = (n, x) => { if (n === name) f = x; }; return () => f; }

async function run() {
  /* ================= 1. OT — รายการ / ยกเลิก / รายละเอียด ================= */
  console.log('\n== OT: หน้าคำขอ OT ของฉัน (#/ot) ==');
  const E1 = env({ route: '#/ot' });
  const g1 = grab(E1, 'viewOT');
  E1.run('runtime/shared/requests.js');
  E1.run('views/ot/main.js');
  g1()(E1.host());
  await tick(60);
  chk('เรียก njhr_ot_list ด้วย p_mine=true', E1.body('njhr_ot_list') && E1.body('njhr_ot_list').p_mine === true,
    JSON.stringify(E1.body('njhr_ot_list') && E1.body('njhr_ot_list').p_mine));
  chk('db.ots ว่าง แต่ยังแสดงรายการได้',
    E1.db.ots.length === 0 && E1.doc().querySelectorAll('.lvt-ot tbody tr').length === 1, '');
  const row = Array.from(E1.doc().querySelectorAll('.lvt-ot tbody td')).map(x => x.textContent.trim());
  chk('เลขคำขอมาจาก request_no', row[0] === '260811-0001', row[0]);
  chk('ชั่วโมงมาจาก ot_hours', row[3].indexOf('3 ชั่วโมง') > 0, row[3]);
  chk('จำนวนไฟล์มาจาก files_count', row[4] === '1 ไฟล์', row[4]);
  chk('การ์ดมือถือยังอยู่', E1.doc().querySelectorAll('.req-card.only-mobile').length === 1, '');

  // ยกเลิก → njhr_ot_decide (CANCEL) และไม่แตะ Local
  const cbtn = E1.doc().querySelector('[data-cancel]');
  cbtn.click();
  await tick(60);
  const dec = E1.body('njhr_ot_decide');
  chk('ยกเลิกเรียก njhr_ot_decide action=CANCEL', dec && dec.p_action === 'CANCEL', JSON.stringify(dec && dec.p_action));
  chk('ยกเลิกไม่เขียน Audit ซ้ำที่ Frontend', E1.called('__audit').length === 0, '');
  chk('ยกเลิกไม่แตะ db.ots', E1.db.ots.length === 0, '');

  // รายละเอียด → Module ที่อ่าน njhr_ot_get (ไม่ใช้ showTimeline ที่อ่าน db.ots)
  const E1b = env({ route: '#/ot' });
  const g1b = grab(E1b, 'viewOT');
  E1b.run('runtime/shared/requests.js');
  E1b.run('views/ot/main.js');
  g1b()(E1b.host());
  await tick(60);
  E1b.doc().querySelector('[data-detail]').click();
  await tick(40);
  chk('ดูรายละเอียดเปิด requestDetail (njhr_ot_get) ไม่ใช้ showTimeline',
    E1b.called('__detail').length === 1 && E1b.called('__showTimeline').length === 0, '');

  // การ์ดข้อมูล OT เดิมในเครื่อง — ต้องไม่ลบ db.ots
  const E1c = env({ route: '#/ot' });
  E1c.db.ots.push({ id: 'OLD1', empId: 'e1', date: '2026-06-01', start: '18:00', end: '20:00',
    hours: 2, status: 'APPROVED', jobs: [], reason: 'เก่า' });
  const g1c = grab(E1c, 'viewOT');
  E1c.run('runtime/shared/requests.js');
  E1c.run('views/ot/main.js');
  g1c()(E1c.host());
  await tick(60);
  chk('มีการ์ดเตือนข้อมูล OT เดิมในเครื่อง',
    E1c.doc().getElementById('otmig-export') !== null, '');
  chk('ไม่ลบ db.ots เดิม', E1c.db.ots.length === 1, E1c.db.ots.length + ' รายการ');

  /* ================= 2. OT — ยื่นคำขอ ================= */
  console.log('\n== OT: ยื่นคำขอ ==');
  const src45 = fs.readFileSync(path.join(ROOT, 'views/ot/form.js'), 'utf8');
  chk('ฟอร์มไม่ push ลง db.ots แล้ว', src45.indexOf('db.ots.push') < 0, '');
  chk('ฟอร์มเรียก njhr_ot_submit', src45.indexOf('njhr_ot_submit') >= 0, '');
  chk('ฟอร์มไม่เรียก notifyApprovers ซ้ำ', src45.indexOf('notifyApprovers') < 0, '');
  chk('ฟอร์มยังลงทะเบียนไฟล์แนบด้วย njhr_ot_attach_add', src45.indexOf('njhr_ot_attach_add') >= 0, '');

  /* ================= 3. OT — คิวอนุมัติ ================= */
  console.log('\n== OT: แท็บคำขอ OT ในหน้าอนุมัติ ==');
  const E3 = env({ route: '#/approvals' });
  let vAppr = null;
  E3.NJHR.views.register = (n, f) => { if (n === 'viewApprovals') vAppr = f; };
  E3.run('runtime/shared/requests.js');
  E3.run('compat/app-legacy.js');
  chk('chunk ลงทะเบียน viewApprovals', typeof vAppr === 'function', '');
  if (typeof vAppr === 'function') {
    vAppr(E3.host());
    await tick(60);
    // สลับไปแท็บ OT
    const otTab = Array.from(E3.doc().querySelectorAll('.tab')).find(t => t.dataset.tab === 'ot');
    chk('มีแท็บ "คำขอ OT"', !!otTab, '');
    if (otTab) {
      otTab.click();
      await tick(120);
      chk('คิว OT เรียก njhr_ot_list (p_mine=false)',
        E3.calls.some(c => c.fn === 'njhr_ot_list' && c.body.p_mine === false && c.body.p_status === 'PENDING'), '');
      chk('ดึงรายการงานด้วย njhr_ot_get', E3.called('njhr_ot_get').length === 1, '');
      chk('ดึงไฟล์แนบด้วย njhr_ot_attach_list', E3.called('njhr_ot_attach_list').length === 1, '');
      const card = E3.doc().querySelector('.ap-card');
      chk('มีการ์ดอนุมัติ OT', !!card, '');
      if (card) {
        chk('ชื่อพนักงานมาจาก RPC ไม่ใช่ db.employees',
          card.querySelector('.ap-name').textContent.trim() === 'นายสมชาย ใจดี',
          card.querySelector('.ap-name').textContent.trim());
        chk('คงคลาสการ์ดเดิม (.card .req-card .ap-card)',
          card.className.indexOf('card') === 0 && card.className.indexOf('req-card') > 0, card.className);
        chk('ปุ่มเดิมครบ 4 ปุ่ม (อนุมัติ/ไม่อนุมัติ/ขอข้อมูลเพิ่ม/Timeline)',
          !!card.querySelector('[data-approve]') && !!card.querySelector('[data-reject]') &&
          !!card.querySelector('[data-moreinfo]') && !!card.querySelector('[data-detail]'), '');
        const jv = card.querySelector('.otj-view');
        chk('แสดงรายการงานครบ 2 รายการ (otJobsHTML ตัวเดิม)',
          !!jv && jv.querySelectorAll('.otj-vrow').length === 2,
          jv ? jv.querySelectorAll('.otj-vrow').length + ' แถว' : 'ไม่มี');
        chk('รายการงานมาจาก njhr_ot_get (JOB + ประเภทงาน)',
          !!jv && jv.textContent.indexOf('JB-1') >= 0 && jv.textContent.indexOf('ตรวจปล่อย') >= 0, '');
        chk('ไฟล์แนบจาก njhr_ot_attach_list ผูกเข้ารายการงานที่ 1',
          !!jv && jv.textContent.indexOf('doc.pdf') >= 0, '');

        // อนุมัติ
        card.querySelector('[data-approve]').click();
        await tick(80);
        const d3 = E3.body('njhr_ot_decide');
        chk('อนุมัติเรียก njhr_ot_decide action=APPROVE', d3 && d3.p_action === 'APPROVE', JSON.stringify(d3 && d3.p_action));
        chk('อนุมัติไม่เขียน Audit/Notify ซ้ำ',
          E3.called('__audit').length === 0 && E3.called('__notify').length === 0, '');
        chk('อนุมัติไม่แตะ db.ots', E3.db.ots.length === 0, '');
      }
      // ขอข้อมูลเพิ่ม — ยังไม่รองรับฝั่ง SQL ต้องไม่ยิง RPC
      const E3b = env({ route: '#/approvals' });
      let vA2 = null;
      E3b.NJHR.views.register = (n, f) => { if (n === 'viewApprovals') vA2 = f; };
      E3b.run('runtime/shared/requests.js');
      E3b.run('compat/app-legacy.js');
      vA2(E3b.host());
      await tick(60);
      Array.from(E3b.doc().querySelectorAll('.tab')).find(t => t.dataset.tab === 'ot').click();
      await tick(120);
      const mi = E3b.doc().querySelector('[data-moreinfo]');
      if (mi) {
        mi.click();
        await tick(40);
        chk('"ขอข้อมูลเพิ่ม" ไม่ยิง njhr_ot_decide (SQL ยังไม่รองรับ)',
          E3b.called('njhr_ot_decide').length === 0, '');
        chk('"ขอข้อมูลเพิ่ม" แจ้งผู้ใช้ตรง ๆ',
          E3b.toasts.some(t => /ยังไม่รองรับ/.test(t.m)), (E3b.toasts.slice(-1)[0] || {}).m || '');
      }
    }
  }

  /* ================= 4. Dashboard Desktop ================= */
  console.log('\n== Dashboard Desktop ==');
  const E4 = env({ route: '#/dashboard' });
  const g4 = grab(E4, 'viewDashboard');
  E4.run('views/dashboard.js');
  g4()(E4.host());
  await tick(80);
  chk('เรียก njhr_dashboard_summary', E4.called('njhr_dashboard_summary').length === 1, '');
  const num = id => (E4.doc().getElementById(id) || {}).textContent;
  chk('พนักงานทั้งหมด มาจาก company.employees_active', num('dk-emp') === '111', num('dk-emp'));
  chk('เข้างานวันนี้ มาจาก checked_in_today', num('dk-in') === '80', num('dk-in'));
  chk('มาสายวันนี้ มาจาก late_today', num('dk-late') === '5', num('dk-late'));
  chk('ลางานวันนี้ มาจาก on_leave_today', num('dk-leave') === '6', num('dk-leave'));
  chk('ขาดงานวันนี้ = 111 − 80 − 6 (สูตรเดิม)', num('dk-abs') === '25', num('dk-abs'));
  chk('OT วันนี้ มาจาก ot_today', num('dk-ot') === '3', num('dk-ot'));
  chk('รายการรออนุมัติ มาจาก pending_total', num('dk-pend') === '7', num('dk-pend'));
  chk('งวดเงินเดือน มาจาก data.payroll', num('dk-pay') === 'ยืนยันแล้ว', num('dk-pay'));
  chk('ป้ายงวดเงินเดือนเป็นเดือนจาก RPC',
    (E4.doc().getElementById('dk-pay-label') || {}).textContent === 'เงินเดือน กรก.',
    (E4.doc().getElementById('dk-pay-label') || {}).textContent);
  const bars = Array.from(E4.doc().querySelectorAll('#dash-chart .bar-row b')).map(x => x.textContent);
  chk('กราฟใช้ตัวเลขชุดเดียวกับ KPI', JSON.stringify(bars) === JSON.stringify(['75', '5', '6', '25']), bars.join(' · '));
  const anns = E4.doc().querySelectorAll('#dash-ann-body .list-row');
  chk('ประกาศมาจาก data.announcements', anns.length === 2, anns.length + ' รายการ');
  chk('ประกาศ HIGH ใช้ไอคอนปักหมุด',
    E4.doc().querySelector('#dash-ann-body .ann-ic.pin') !== null, '');
  chk('ไม่อ่าน db.employees/attendance/announcements',
    E4.db.employees.length === 0 && E4.db.announcements.length === 0, '');

  // Dashboard error → ห้ามแสดง 0
  const E4b = env({ route: '#/dashboard', fail: ['njhr_dashboard_summary'] });
  const g4b = grab(E4b, 'viewDashboard');
  E4b.run('views/dashboard.js');
  g4b()(E4b.host());
  await tick(80);
  chk('RPC ล้ม → KPI แสดง — ไม่ใช่ 0',
    (E4b.doc().getElementById('dk-emp') || {}).textContent === '—',
    (E4b.doc().getElementById('dk-emp') || {}).textContent);
  chk('RPC ล้ม → กราฟแสดงข้อความผิดพลาด',
    E4b.doc().querySelector('#dash-chart .form-error') !== null, '');

  /* ================= 5. Announcement ================= */
  console.log('\n== Announcement ==');
  const E5 = env({ route: '#/announcements' });
  let vAnn = null;
  E5.NJHR.views.register = (n, f) => { if (n === 'viewAnnouncements') vAnn = f; };
  E5.run('compat/app-legacy.js');
  chk('chunk ลงทะเบียน viewAnnouncements', typeof vAnn === 'function', '');
  if (typeof vAnn === 'function') {
    vAnn(E5.host());
    await tick(60);
    chk('เรียก njhr_announcement_list', E5.called('njhr_announcement_list').length === 1, '');
    chk('db.announcements ว่าง แต่แสดง 2 ประกาศ',
      E5.db.announcements.length === 0 && E5.doc().querySelectorAll('.req-card').length === 2, '');
    chk('ประกาศ HIGH แสดงหมุด', E5.host().innerHTML.indexOf('data-i="pin"') >= 0, '');
    chk('ประกาศที่ปิดใช้งานได้คลาส inactive-card',
      E5.doc().querySelectorAll('.inactive-card').length === 1, '');
    // อ่านประกาศ
    E5.doc().querySelector('[data-an-view]').click();
    await tick(50);
    chk('อ่านประกาศเรียก njhr_announcement_get', E5.called('njhr_announcement_get').length === 1, '');
    E5.NJHR.compat.scope.closeModal();
    // ปิดใช้งาน
    E5.doc().querySelector('[data-an-off]').click();
    await tick(60);
    const sa = E5.body('njhr_announcement_set_active');
    chk('ปิดใช้งานเรียก njhr_announcement_set_active(p_active=false)', sa && sa.p_active === false, JSON.stringify(sa));
    chk('ไม่เขียน Audit ซ้ำที่ Frontend', E5.called('__audit').length === 0, '');
    // เพิ่มประกาศใหม่
    const E5b = env({ route: '#/announcements' });
    let vA5 = null;
    E5b.NJHR.views.register = (n, f) => { if (n === 'viewAnnouncements') vA5 = f; };
    E5b.run('compat/app-legacy.js');
    vA5(E5b.host());
    await tick(60);
    E5b.doc().getElementById('an-add').click();
    await tick(30);
    const fm = E5b.doc().getElementById('an-f');
    fm.elements.title.value = 'ประกาศใหม่';
    fm.elements.body.value = 'เนื้อหา';
    fm.elements.pinned.checked = true;
    E5b.doc().getElementById('anf-save').click();
    await tick(60);
    const sv = E5b.body('njhr_announcement_save');
    chk('สร้างประกาศเรียก njhr_announcement_save (p_id=null)', sv && sv.p_id === null, JSON.stringify(sv && sv.p_id));
    chk('ปักหมุด → p_priority=HIGH', sv && sv.p_priority === 'HIGH', sv && sv.p_priority);
    chk('สร้างใหม่ส่ง p_notify=true (RPC เป็นผู้แจ้งเตือน)', sv && sv.p_notify === true, String(sv && sv.p_notify));
    chk('ไม่สร้าง notify() ซ้ำที่ Frontend', E5b.called('__notify').length === 0, '');
    chk('ไม่เขียนลง db.announcements', E5b.db.announcements.length === 0, '');
  }

  /* ================= 6. Profile ================= */
  console.log('\n== Profile: ข้อมูลติดต่อ ==');
  const E6 = env({ route: '#/profile' });
  let vPf = null;
  E6.NJHR.views.register = (n, f) => { if (n === 'viewProfile') vPf = f; };
  E6.run('views/profile/main.js');
  chk('chunk ลงทะเบียน viewProfile', typeof vPf === 'function', '');
  if (typeof vPf === 'function') {
    vPf(E6.host());
    await tick(60);
    chk('โหลดค่าเดิมด้วย njhr_me_get', E6.called('njhr_me_get').length === 1, '');
    const pf = E6.doc().getElementById('pf-f');
    chk('เติมเบอร์โทรจาก RPC ไม่ใช่ db.employees',
      pf.elements.phone.value === '0812345678', pf.elements.phone.value);
    pf.elements.phone.value = '0899999999';
    E6.doc().getElementById('pf-save').click();
    await tick(60);
    const ms = E6.body('njhr_me_save');
    chk('บันทึกเรียก njhr_me_save', !!ms, '');
    chk('ส่งครบทั้ง 7 field (ไม่ทำข้อมูลอื่นหาย)',
      ms && Object.keys(ms.p_data).length === 7 && ms.p_data.nickname === 'ชาย' &&
      ms.p_data.national_id === '1234567890123' && ms.p_data.address === '99 หมู่ 1' &&
      ms.p_data.emergency_phone === '0899999999',
      ms ? Object.keys(ms.p_data).join(',') : '');
    chk('ส่งเบอร์ใหม่ที่ผู้ใช้กรอก', ms && ms.p_data.phone === '0899999999', ms && ms.p_data.phone);
    chk('ไม่เขียน Audit ซ้ำที่ Frontend', E6.called('__audit').length === 0, '');
  }

  /* ================= 7. Settings ================= */
  console.log('\n== Settings: ตั้งค่าทั่วไป ==');
  const E7 = env({ route: '#/settings' });
  let vSt = null;
  E7.NJHR.views.register = (n, f) => { if (n === 'viewSettings') vSt = f; };
  E7.run('compat/app-legacy.js');
  chk('chunk ลงทะเบียน viewSettings', typeof vSt === 'function', '');
  if (typeof vSt === 'function') {
    vSt(E7.host());
    await tick(60);
    chk('โหลดด้วย njhr_setting_list', E7.called('njhr_setting_list').length === 1, '');
    const sf = E7.doc().getElementById('st-f');
    chk('ชื่อบริษัทมาจาก system_settings ไม่ใช่ db.settings',
      sf.elements.companyName.value === 'N.J. LOGISTICS & FRUITS CO., LTD.', sf.elements.companyName.value);
    chk('เวลาเริ่มงานมาจาก work_start_time', sf.elements.workStart.value === '08:00', sf.elements.workStart.value);
    chk('อนุโลมสายมาจาก late_grace_minutes', String(sf.elements.lateGrace.value) === '15', sf.elements.lateGrace.value);
    sf.elements.lateGrace.value = '20';
    E7.doc().getElementById('st-save').click();
    await tick(80);
    const saves = E7.called('njhr_setting_save');
    chk('บันทึกยิง njhr_setting_save ครบ 3 คีย์', saves.length === 3, saves.length + ' ครั้ง');
    const keys = saves.map(x => x.body.p_key).sort();
    chk('คีย์ตรงกับ system_settings จริง',
      JSON.stringify(keys) === JSON.stringify(['company_name', 'late_grace_minutes', 'work_start_time']),
      keys.join(', '));
    const lg = saves.find(x => x.body.p_key === 'late_grace_minutes');
    chk('ส่งค่าที่ผู้ใช้แก้', lg && lg.body.p_value === 20, String(lg && lg.body.p_value));
    chk('ไม่เขียน Audit ซ้ำที่ Frontend (RPC เขียนเอง)',
      E7.called('__audit').length === 0, E7.called('__audit').length + ' ครั้ง');
  }

  /* ================= 8. ตรวจ Source ว่าไม่เหลือ Local เป็นแหล่งหลัก ================= */
  console.log('\n== ตรวจ Source ==');
  const otSrc = fs.readFileSync(path.join(ROOT, 'views/ot/main.js'), 'utf8');
  chk('views/ot/main.js ไม่ filter db.ots เป็นรายการหลัก', otSrc.indexOf('db.ots.filter') < 0, '');
  const compat = fs.readFileSync(path.join(ROOT, 'compat/app-legacy.js'), 'utf8');
  chk('compat ไม่อ่าน db.announcements ใน CRUD ประกาศ',
    compat.indexOf('db.announcements.find') < 0 && compat.indexOf('db.announcements.unshift') < 0, '');
  const auth = fs.readFileSync(path.join(ROOT, 'runtime/core.js'), 'utf8');
  ['njhr_me_save', 'njhr_user_delete', 'njhr_activation_reject', 'njhr_activation_submit',
   'njhr_activation_link', 'njhr_att_correction_submit', 'njhr_gov_holiday_apply', 'njhr_gov_holiday_set']
    .forEach(function (r) {
      /* Terser ตัดเครื่องหมายคำพูดของ key ที่เป็น identifier ได้ จึงยอมรับทั้งสองรูปแบบ */
      chk('SB_WRITE_RPC มี ' + r,
        new RegExp('["\']?' + r + '["\']?:1').test(auth.replace(/\s/g, '')), '');
    });
  chk('SB_WRITE_RPC ไม่มี njhr_doc_confirm_text',
    !/["']?njhr_doc_confirm_text["']?:1/.test(auth.replace(/\s/g, '')), '');

  /* ================= 9. Dashboard USER (Desktop) ================= */
  console.log('\n== Dashboard USER (Desktop) ==');
  const E9 = env({ route: '#/dashboard' });
  E9.NJHR.compat.scope.currentUser = () => ({ id: 'u2', username: 'user1', role: 'USER', empId: 'e1' });
  const g9 = grab(E9, 'viewDashboard');
  E9.run('views/dashboard.js');
  g9()(E9.host());
  await tick(90);
  chk('USER ไม่เรียก njhr_dashboard_summary (ของผู้ดูแล)',
    E9.called('njhr_dashboard_summary').length === 0, '');
  /* หน้าหลักมือถือ (dashMobileHome) เรียก RPC ชุดเดียวกันด้วย จึงนับได้มากกว่า 1 */
  chk('ลงเวลาวันนี้เรียก njhr_att_today', E9.called('njhr_att_today').length >= 1,
    E9.called('njhr_att_today').length + ' ครั้ง');
  const stTxt = (E9.doc().getElementById('de-status') || {}).textContent || '';
  chk('สถานะลงเวลามาจาก RPC (เข้างาน 08:30)', stTxt.indexOf('เข้างาน') >= 0, stTxt.trim());
  chk('ชื่อกะมาจาก njhr_att_today',
    (E9.doc().getElementById('de-shift') || {}).textContent.indexOf('กะปกติ') === 0,
    (E9.doc().getElementById('de-shift') || {}).textContent);
  chk('ปุ่มออกงานเปิดใช้ได้เมื่อเข้างานแล้ว',
    E9.doc().getElementById('dash-out').disabled === false, '');
  chk('วันลาคงเหลือเรียก njhr_leave_balances', E9.called('njhr_leave_balances').length === 1, '');
  const bal = E9.doc().querySelectorAll('#de-bal .bal-item');
  chk('แสดงเฉพาะประเภทที่มีโควตา (2 จาก 3)', bal.length === 2, bal.length + ' ใบ');
  chk('ค่าคงเหลือมาจาก RPC', bal.length > 0 && bal[0].textContent.indexOf('28 วัน') > 0,
    bal.length ? bal[0].textContent.trim() : '');
  const lvBody = E9.body('njhr_leave_list');
  chk('คำขอลาเรียก njhr_leave_list (ของตนเอง)', !!lvBody, '');
  chk('OT ล่าสุดเรียก njhr_ot_list ด้วย p_mine=true',
    E9.calls.some(c => c.fn === 'njhr_ot_list' && c.body.p_mine === true), '');
  chk('OT ล่าสุดแสดงจาก RPC',
    (E9.doc().getElementById('de-ot') || {}).textContent.indexOf('11/08/2026') >= 0,
    (E9.doc().getElementById('de-ot') || {}).textContent.trim().slice(0, 30));
  chk('ประกาศใช้ njhr_ann_feed (ไม่ใช้ list ของผู้ดูแล)',
    E9.called('njhr_ann_feed').length >= 1 && E9.called('njhr_announcement_list').length === 0,
    E9.called('njhr_ann_feed').length + ' ครั้ง · list ' + E9.called('njhr_announcement_list').length + ' ครั้ง');
  chk('ประกาศสำคัญใช้ is_important จาก Feed',
    (E9.doc().getElementById('de-ann') || {}).innerHTML.indexOf('data-i="pin"') >= 0, '');
  chk('ไม่อ่าน db.leaves/db.ots/db.leaveTypes/db.announcements',
    E9.db.leaves.length === 0 && E9.db.ots.length === 0 &&
    E9.db.leaveTypes.length === 0 && E9.db.announcements.length === 0, '');
  chk('สลิปเงินเดือนยังใช้ db.payroll ตามเดิม (INTENTIONAL LOCAL)',
    (E9.doc().querySelector('.slip-mini') === null), 'db.payroll ว่าง → แสดง empty state เดิม');

  // USER dashboard เมื่อ RPC ล้ม → ต้องไม่แสดงว่าไม่มีข้อมูล
  const E9b = env({ route: '#/dashboard', fail: ['njhr_ot_list', 'njhr_ann_feed'] });
  E9b.NJHR.compat.scope.currentUser = () => ({ id: 'u2', username: 'user1', role: 'USER', empId: 'e1' });
  const g9b = grab(E9b, 'viewDashboard');
  E9b.run('views/dashboard.js');
  g9b()(E9b.host());
  await tick(90);
  chk('RPC ล้ม → OT แสดงข้อความผิดพลาด ไม่ใช่ "ยังไม่มีคำขอ OT"',
    E9b.doc().querySelector('#de-ot .form-error') !== null, '');
  chk('RPC ล้ม → ประกาศแสดงข้อความผิดพลาด',
    E9b.doc().querySelector('#de-ann .form-error') !== null, '');

  /* ================= 10. Badge รออนุมัติ ================= */
  console.log('\n== Badge รออนุมัติ ==');
  const core = fs.readFileSync(path.join(ROOT, 'runtime/core.js'), 'utf8');
  chk('pendingCount ไม่นับจาก db.ots/db.corrections แล้ว',
    !/db\.ots\.filter\(function\(o\)\{return o\.status==="PENDING"/.test(core.replace(/\s/g, '')), '');
  chk('มีตัวนับ OT จาก njhr_ot_list', core.indexOf('refreshOtPending') >= 0, '');
  chk('มีตัวนับลงชื่อย้อนหลังจาก njhr_att_correction_list', core.indexOf('refreshFixPending') >= 0, '');
  chk('นับด้วย p_limit=1 + total_count (ไม่ดึงทั้งคิวมานับ)',
    /p_limit:1[,}]/.test(core.replace(/\s/g, '')), '');
  chk('ไม่ยิง RPC ตอน render Sidebar (refreshMenuBadge ไม่เรียก RPC)',
    core.indexOf('function refreshMenuBadge') < 0 ||
    core.slice(core.indexOf('function refreshMenuBadge'),
               core.indexOf('function refreshMenuBadge') + 400).indexOf('sbRpc') < 0, '');

  /* ================= 11. Settings hydrate หลัง Login ================= */
  console.log('\n== Settings hydrate หลัง Login ==');
  chk('มี hydrateSettings ใน core', core.indexOf('hydrateSettings') >= 0, '');
  chk('hydrate ใช้ njhr_setting_list',
    /hydrateSettings[\s\S]{0,400}njhr_setting_list/.test(core), '');
  chk('Mapping ใช้ Key จริงทั้ง 3 ตัว',
    core.indexOf('company_name') >= 0 && core.indexOf('work_start_time') >= 0 &&
    core.indexOf('late_grace_minutes') >= 0, '');
  chk('ไม่ส่งคีย์ geofence ผ่าน njhr_setting_save',
    !/njhr_setting_save[\s\S]{0,200}geofence/.test(core), '');

  /* ================= 12. Legacy OT Export ================= */
  console.log('\n== Legacy OT Export ==');
  const E12 = env({ route: '#/ot' });
  E12.db.ots.push({ id: 'OT-mso123', no: 'OT-mso123', empId: 'e1', empCodeSnap: 'NJ001',
    deptSnap: 'ขนส่ง', positionSnap: 'พนักงานขับรถ', date: '2026-06-01',
    start: '18:00', end: '20:00', hours: 2, spansNextDay: false, status: 'APPROVED',
    reason: 'งานเก่า', note: 'หมายเหตุรวม', createdAt: '2026-06-01 10:00',
    approver: 'หัวหน้า A', approvedAt: '2026-06-02 09:00',
    timeline: [{ at: '2026-06-01 10:00', by: 'สมชาย', action: 'ส่งคำขอ', note: '' },
               { at: '2026-06-02 09:00', by: 'หัวหน้า A', action: 'อนุมัติ', note: 'ok' }],
    jobs: [{ no: 1, job: 'JB-9', detail: 'งาน', jobType: 'ตรวจปล่อย', date: '2026-06-01',
             start: '18:00', end: '20:00', nextDay: false, endDate: '2026-06-01', hours: 2,
             files: [{ name: 'old.pdf', size: 100, type: 'application/pdf',
                       url: 'https://x/old.pdf', path: 'ot/old.pdf' }] }] });
  const g12 = grab(E12, 'viewOT');
  E12.run('runtime/shared/requests.js');
  E12.run('views/ot/main.js');
  g12()(E12.host());
  await tick(60);
  let exported = null;
  E12.win.Blob = function (parts) { exported = String(parts[0]); this.parts = parts; };
  E12.doc().getElementById('otmig-export').click();
  await tick(40);
  chk('Export สร้างไฟล์ JSON ได้', !!exported, exported ? exported.length + ' ตัวอักษร' : 'ไม่มี');
  if (exported) {
    const doc12 = JSON.parse(exported);
    const L = doc12.rows[0].legacy, M = doc12.rows[0].migrate;
    chk('เก็บ legacy_request_no เดิม (OT-mso...)', L.legacy_request_no === 'OT-mso123', L.legacy_request_no);
    chk('เก็บ Timeline ครบ 2 ขั้น', (L.timeline || []).length === 2, (L.timeline || []).length + ' ขั้น');
    chk('เก็บผู้อนุมัติและเวลาอนุมัติ',
      L.approver === 'หัวหน้า A' && L.approved_at === '2026-06-02 09:00', L.approver);
    chk('เก็บ created_at เดิม', L.created_at === '2026-06-01 10:00', L.created_at);
    chk('เก็บหมายเหตุรวม', L.note === 'หมายเหตุรวม', L.note);
    chk('เก็บ Snapshot แผนก/ตำแหน่ง',
      L.dept_snapshot === 'ขนส่ง' && L.position_snapshot === 'พนักงานขับรถ', '');
    chk('เก็บไฟล์แนบ (ชื่อ + path)',
      L.jobs[0].files[0].name === 'old.pdf' && L.jobs[0].files[0].path === 'ot/old.pdf', '');
    chk('ชุด migrate ตรงรูปแบบ p_rows ของ njhr_ot_migrate',
      M.emp_code === 'NJ001' && M.date === '2026-06-01' && M.jobs[0].job_code === 'JB-9', '');
    chk('มีคำเตือน DO NOT IMPORT', /DO NOT IMPORT/.test(doc12.note), '');
  }
  chk('Export แล้วไม่ลบ db.ots', E12.db.ots.length === 1, E12.db.ots.length + ' รายการ');

  /* ================= 13. SB_WRITE_RPC ครบ ================= */
  console.log('\n== SB_WRITE_RPC เพิ่มเติมรอบนี้ ==');
  ['njhr_att_correction_approve', 'njhr_att_correction_reject', 'njhr_shift_assign_many',
   'njhr_shift_remove', 'njhr_shift_no_shift_set', 'njhr_wf_step_toggle',
   'njhr_wf_approver_add', 'njhr_wf_approver_remove',
   'njhr_ot_submit', 'njhr_ot_decide', 'njhr_announcement_save',
   'njhr_announcement_set_active', 'njhr_setting_save'].forEach(function (r) {
    chk('SB_WRITE_RPC มี ' + r,
      new RegExp('["\']?' + r + '["\']?:1').test(core.replace(/\s/g, '')), '');
  });

  /* ================= 14. Harness ไม่มี Absolute Path ================= */
  console.log('\n== Harness Portable ==');
  const hDir = path.join(ROOT, 'harness');
  if (fs.existsSync(hDir)) {
    /* ประกอบ pattern จากชิ้นส่วน เพื่อไม่ให้ไฟล์ทดสอบนี้ตรวจเจอตัวเอง */
    const ABS = new RegExp(['', 'home', 'claude', ''].join('\\/'));
    const bad = fs.readdirSync(hDir).filter(f => f.endsWith('.js'))
      .filter(f => ABS.test(fs.readFileSync(path.join(hDir, f), 'utf8')));
    chk('ไม่มีไฟล์ทดสอบใดอ้าง Absolute Path ของเครื่อง build', bad.length === 0, bad.slice(0, 3).join(', '));
    const NPMG = new RegExp(['npm', 'global'].join('-'));
    const pw = fs.readdirSync(hDir).filter(f => f.endsWith('.js'))
      .filter(f => NPMG.test(fs.readFileSync(path.join(hDir, f), 'utf8')));
    chk('ไม่มีไฟล์ใด require playwright จาก Global Path', pw.length === 0, pw.slice(0, 3).join(', '));
  }
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  chk('package.json ประกาศ playwright เป็น devDependency',
    !!(pkg.devDependencies && pkg.devDependencies.playwright), '');

  /* ================= 15. Payroll — OT จาก Supabase ================= */
  console.log('\n== Payroll: ชั่วโมง OT จาก Supabase ==');
  const E15 = env({ route: '#/payroll' });
  /* พนักงาน 2 คนจาก db.employees (ยังเป็นแหล่งเดิมของ Payroll — ไม่อยู่ในขอบเขตรอบนี้) */
  E15.db.employees.push(
    { id: 'e1', code: 'NJ001', firstName: 'สมชาย', lastName: 'ใจดี', status: 'ACTIVE',
      baseSalary: 24000, allowance: 0 },
    { id: 'e2', code: 'NJ002', firstName: 'สมหญิง', lastName: 'รักงาน', status: 'ACTIVE',
      baseSalary: 24000, allowance: 0 });
  E15.db.payroll.push({ month: 8, year: 2026, status: 'DRAFT', entries: [] });
  /* OT เดิมใน localStorage ที่ต้อง "ไม่ถูกนำมาคำนวณ" อีกแล้ว */
  E15.db.ots.push({ id: 'OLD-OT', empId: 'e1', status: 'APPROVED', date: '2026-08-11',
    start: '18:00', end: '23:00', hours: 5,
    jobs: [{ no: 1, job: 'LOCAL', jobType: 'x', date: '2026-08-11', hours: 5, files: [] }] });

  let vPay = null;
  E15.NJHR.views.register = (n, f) => { if (n === 'viewPayroll') vPay = f; };
  E15.run('runtime/shared/requests.js');
  E15.run('compat/app-legacy.js');
  chk('chunk ลงทะเบียน viewPayroll', typeof vPay === 'function', '');
  if (typeof vPay === 'function') {
    vPay(E15.host());
    await tick(60);
    const calc = E15.doc().getElementById('pr-calc');
    chk('มีปุ่มคำนวณเงินเดือน (งวด DRAFT)', !!calc, '');
    if (calc) {
      calc.click();
      await tick(150);
      const b15 = E15.body('njhr_ot_report');
      chk('Payroll เรียก njhr_ot_report', !!b15, '');
      chk('ขอเฉพาะ APPROVED จากเซิร์ฟเวอร์', b15 && b15.p_status === 'APPROVED', b15 && b15.p_status);
      chk('Case 6 · ช่วงวันที่ตรงงวดที่เลือก (ส.ค. 2026)',
        b15 && b15.p_from === '2026-08-01' && b15 && b15.p_to === '2026-08-31',
        b15 ? b15.p_from + ' → ' + b15.p_to : '');

      const ents = E15.db.payroll[0].entries;
      chk('คำนวณแล้วได้ครบ 2 คน', ents.length === 2, ents.length + ' คน');
      const e1 = ents.find(x => x.empId === 'e1');
      const e2 = ents.find(x => x.empId === 'e2');
      /* อัตรา OT เดิม = base/30/8*1.5 → 24000/30/8*1.5 = 150 บาท/ชม. */
      chk('Case 1+4 · e1 OT 2 JOB (1.5+1.5) รวม 3 ชม. ไม่บวกซ้ำเป็น 6',
        e1 && e1.ot === 450, e1 ? e1.ot + ' บาท (คาด 450 = 3 ชม. × 150)' : '');
      chk('Case 5 · e2 ได้ 2 ชม. ของตัวเอง ไม่ปนกับ e1',
        e2 && e2.ot === 300, e2 ? e2.ot + ' บาท (คาด 300 = 2 ชม. × 150)' : '');
      chk('Case 2 · OT PENDING 9 ชม. ไม่ถูกนำมาคำนวณ', e1 && e1.ot !== 450 + 1350, '');
      chk('Case 3 · OT REJECTED 7 ชม. ไม่ถูกนำมาคำนวณ', e1 && e1.ot < 1500, '');
      chk('Case 6 · OT งวด ก.ค. 5 ชม. ไม่ถูกนับในงวด ส.ค.', e1 && e1.ot === 450, '');
      chk('ไม่ใช้ db.ots (OT Local 5 ชม. ไม่เข้าสูตร)', e1 && e1.ot === 450, '');
      chk('db.ots เดิมยังอยู่ครบ ไม่ถูกลบ', E15.db.ots.length === 1, E15.db.ots.length + ' รายการ');
      chk('สถานะงวดเป็น CALCULATED ตามเดิม', E15.db.payroll[0].status === 'CALCULATED',
        E15.db.payroll[0].status);
    }
  }

  /* Payroll เมื่อ RPC ล้ม → ต้องไม่คำนวณ และไม่ fallback ไป Local */
  const E15b = env({ route: '#/payroll', fail: ['njhr_ot_report'] });
  E15b.db.employees.push({ id: 'e1', code: 'NJ001', firstName: 'สมชาย', lastName: 'ใจดี',
    status: 'ACTIVE', baseSalary: 24000, allowance: 0 });
  E15b.db.payroll.push({ month: 8, year: 2026, status: 'DRAFT', entries: [] });
  E15b.db.ots.push({ id: 'OLD-OT', empId: 'e1', status: 'APPROVED', date: '2026-08-11',
    start: '18:00', end: '23:00', hours: 5,
    jobs: [{ no: 1, job: 'LOCAL', jobType: 'x', date: '2026-08-11', hours: 5, files: [] }] });
  let vPay2 = null;
  E15b.NJHR.views.register = (n, f) => { if (n === 'viewPayroll') vPay2 = f; };
  E15b.run('runtime/shared/requests.js');
  E15b.run('compat/app-legacy.js');
  vPay2(E15b.host());
  await tick(60);
  const c2 = E15b.doc().getElementById('pr-calc');
  if (c2) {
    c2.click();
    await tick(150);
    chk('RPC ล้ม → ไม่คำนวณ (entries ยังว่าง)',
      E15b.db.payroll[0].entries.length === 0, E15b.db.payroll[0].entries.length + ' รายการ');
    chk('RPC ล้ม → สถานะยังเป็น DRAFT ไม่เปลี่ยน',
      E15b.db.payroll[0].status === 'DRAFT', E15b.db.payroll[0].status);
    chk('RPC ล้ม → แจ้งผู้ใช้ ไม่เงียบ',
      E15b.toasts.some(t => /ไม่สำเร็จ/.test(t.m)), (E15b.toasts.slice(-1)[0] || {}).m || '');
    chk('RPC ล้ม → ไม่ fallback ไป db.ots', E15b.db.ots.length === 1, '');
  }

  /* ================= 16. Static — Payroll ไม่อ่าน db.ots ================= */
  console.log('\n== Static: Payroll ไม่อ่าน Local OT ==');
  const paySrc = fs.readFileSync(path.join(ROOT, 'src/11-view-approvals-payroll.js'), 'utf8');
  const calcBlock = paySrc.slice(paySrc.indexOf('function prFetchOtHours'),
                                paySrc.indexOf("audit('PAYROLL_CONFIRM'"));
  chk('บล็อกคำนวณ Payroll ไม่มี db.ots', calcBlock.indexOf('db.ots.filter') < 0 &&
    calcBlock.indexOf('db.ots.reduce') < 0, '');
  chk('ใช้ job_hours ไม่ใช้ request_hours',
    calcBlock.indexOf('job_hours') >= 0 && !/\+\s*\(Number\(j\.request_hours\)/.test(calcBlock), '');
  chk('ไม่มี fallback แบบ sqlOT.length ? sqlOT : db.ots',
    !/\?\s*[A-Za-z_$][\w$]*\s*:\s*db\.ots/.test(paySrc), '');
  chk('ไม่สร้าง RPC ใหม่สำหรับ Payroll OT',
    paySrc.indexOf('njhr_payroll_ot') < 0 && paySrc.indexOf('njhr_pay_ot') < 0, '');

  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
}

run().catch(e => { console.error(e); process.exit(1); });
