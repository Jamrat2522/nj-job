/* ot_attach_recover_test.js — ข้อ 3: ไฟล์แนบล้มแล้วต้องกู้คืนได้ โดยไม่สร้างคำขอ OT ซ้ำ
     CASE A  ส่งคำขอล้ม            → ยังไม่มีคำขอ · ส่งใหม่ได้
     CASE B  ส่งสำเร็จ ไฟล์ครบ      → ปิดหน้าต่าง · แจ้งสำเร็จ
     CASE C  ส่งสำเร็จ ไฟล์ล้มบางตัว → ห้ามส่งคำขอซ้ำ · ปุ่มเปลี่ยนเป็น "แนบไฟล์ใหม่"
   ใช้: node harness/ot_attach_recover_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(56) + (d || '')); }
const tick = () => new Promise(r => setTimeout(r, 40));

const src = fs.readFileSync(path.join(ROOT, 'src/45-view-ot-form.js'), 'utf8');
const out = fs.readFileSync(path.join(ROOT, 'views/ot/form.js'), 'utf8');

/* ---------- จำลองการส่งคำขอ + แนบไฟล์ แล้วนับ RPC ---------- */
function sim(opt) {
  const calls = [];
  const failSet = new Set(opt.failFiles || []);
  const state = { closed: false, toast: null, errHtml: '', btn: { disabled: false, innerHTML: '', onclick: null } };

  /* ตัดเฉพาะฟังก์ชัน otAttachRecover ออกมาทดสอบตรง ๆ */
  const i = src.indexOf('  function otAttachRecover(');
  const j = src.indexOf('  /* Public Feature Contract ของ OT Form */');
  const code = src.slice(i, j);

  const ctx = {
    sbRpc(fn, body) {
      calls.push({ fn, body });
      if (fn === 'njhr_ot_attach_add' && failSet.has(body.p_file_name)) {
        return Promise.reject(new Error('Network error'));
      }
      return Promise.resolve({});
    },
    sbToken: () => 'tk',
    esc: s => String(s == null ? '' : s),
    closeModal() { state.closed = true; },
    toast(m) { state.toast = m; },
    refreshOtPending() {},
    viewOT() {},
    console: { error() {}, log() {} },
    Promise, String, Number, Object
  };
  const names = Object.keys(ctx);
  const api = new Function(...names, code + '\nreturn otAttachRecover;')(...names.map(k => ctx[k]));

  const err = {
    _h: '', set innerHTML(v) { this._h = v; state.errHtml = v; }, get innerHTML() { return this._h; },
    textContent: ''
  };
  return { api, calls, state, err, btn: state.btn };
}

(async function () {
  console.log('\n== CASE C · ไฟล์ล้มแล้วกู้คืน ==');

  /* ไฟล์ล้ม 2 ตัวจาก 3 */
  const failed = [
    { name: 'a.png', path: 'p/a.png', url: 'u/a', size: 10, type: 'image/png', job_no: 1, job_code: 'J1', msg: 'x' },
    { name: 'b.pdf', path: 'p/b.pdf', url: 'u/b', size: 20, type: 'application/pdf', job_no: 2, job_code: 'J2', msg: 'x' }
  ];
  const S = sim({});
  S.api('260813-0001', failed, 3, S.btn, S.err, {});

  chk('ไม่ปิดหน้าต่างทั้งที่ไฟล์ยังไม่ครบ', S.state.closed === false, '');
  chk('ไม่แจ้งสำเร็จ', S.state.toast === null, '');
  chk('แสดงเลขคำขอที่สร้างสำเร็จแล้ว', /260813-0001/.test(S.state.errHtml), '');
  chk('บอกจำนวนไฟล์ที่ล้ม', /2 จาก 3 ไฟล์/.test(S.state.errHtml), '');
  chk('ระบุชื่อไฟล์ที่ต้องแนบใหม่',
    /a\.png/.test(S.state.errHtml) && /b\.pdf/.test(S.state.errHtml), '');
  chk('ปุ่มเปลี่ยนเป็น "แนบไฟล์ใหม่" ไม่ใช่ "ส่งคำขอ"',
    /แนบไฟล์ใหม่ \(2\)/.test(S.btn.innerHTML) && !/ส่งคำขอ/.test(S.btn.innerHTML),
    S.btn.innerHTML);
  chk('ปุ่มกดได้', S.btn.disabled === false, '');

  /* กดแนบใหม่ — สำเร็จหมด */
  S.btn.onclick();
  await tick();
  const addCalls = S.calls.filter(c => c.fn === 'njhr_ot_attach_add');
  chk('แนบใหม่ยิงเฉพาะไฟล์ที่ล้ม 2 ไฟล์', addCalls.length === 2, addCalls.length + ' ครั้ง');
  chk('ใช้ ot_id เดิม ไม่สร้างคำขอใหม่',
    addCalls.every(c => c.body.p_ot_id === '260813-0001'), '');
  chk('ไม่เรียก njhr_ot_submit ซ้ำเลย',
    S.calls.filter(c => c.fn === 'njhr_ot_submit').length === 0, '');
  chk('ส่ง job_no / job_code เดิมของแต่ละไฟล์',
    addCalls.some(c => c.body.p_job_no === 1 && c.body.p_job_code === 'J1') &&
    addCalls.some(c => c.body.p_job_no === 2 && c.body.p_job_code === 'J2'), '');
  chk('ไม่อัปโหลดไฟล์ซ้ำ — ใช้ path เดิมที่อยู่บน Storage แล้ว',
    addCalls.every(c => /^p\//.test(c.body.p_file_path)), '');
  chk('ครบแล้วจึงปิดหน้าต่าง', S.state.closed === true, '');
  chk('ครบแล้วจึงแจ้งสำเร็จ', /แนบไฟล์ครบแล้ว/.test(S.state.toast || ''), S.state.toast);

  console.log('\n== CASE C2 · แนบใหม่แล้วยังล้มบางตัว ==');
  const S2 = sim({ failFiles: ['b.pdf'] });
  S2.api('260813-0002', failed, 3, S2.btn, S2.err, {});
  S2.btn.onclick();
  await tick();
  chk('ยังไม่ปิดหน้าต่าง', S2.state.closed === false, '');
  chk('ยังไม่แจ้งสำเร็จ', S2.state.toast === null, '');
  chk('เหลือเฉพาะไฟล์ที่ยังล้ม', /แนบไฟล์ใหม่ \(1\)/.test(S2.btn.innerHTML), S2.btn.innerHTML);
  chk('ไฟล์ที่สำเร็จแล้วไม่ถูกส่งซ้ำ', /b\.pdf/.test(S2.state.errHtml) &&
    !/a\.png/.test(S2.state.errHtml), '');

  /* กดอีกครั้ง คราวนี้สำเร็จ */
  const before = S2.calls.filter(c => c.fn === 'njhr_ot_attach_add').length;
  S2.calls.length = 0;
  const S3 = sim({});
  S3.api('260813-0002', [failed[1]], 3, S3.btn, S3.err, {});
  S3.btn.onclick();
  await tick();
  chk('ลองใหม่รอบสองยิงเฉพาะไฟล์เดียว',
    S3.calls.filter(c => c.fn === 'njhr_ot_attach_add').length === 1, '');
  chk('สำเร็จแล้วปิดหน้าต่าง', S3.state.closed === true, '');
  void before;

  console.log('\n== ตรวจ Source: ห้ามเปิดทางให้ส่งคำขอซ้ำ ==');
  chk('ยังใช้ Promise.all รอไฟล์ครบก่อน (ไม่รื้อของเดิม)',
    /Promise\.all\(attachJobs\.map/.test(src), '');
  chk('ไฟล์ล้ม → เรียก otAttachRecover ไม่คืนปุ่มส่งคำขอ',
    /if \(attachFail\.length\) \{[\s\S]{0,600}otAttachRecover\(otId/.test(src), '');
  chk('ไม่มีการตั้ง submitting = false ในเส้นทางไฟล์ล้ม',
    !/attachFail\.length[\s\S]{0,400}submitting = false/.test(src), '');
  chk('ไม่มีการคืนข้อความปุ่มเป็น "ส่งคำขอ" ในเส้นทางไฟล์ล้ม',
    !/attachFail\.length[\s\S]{0,400}innerHTML = 'ส่งคำขอ'/.test(src), '');
  /* ตัดคอมเมนต์ก่อน — ในฟังก์ชันมีคอมเมนต์ที่เขียนว่า "ไม่เรียก njhr_ot_submit อีกแล้ว" */
  const recBody = src.slice(src.indexOf('function otAttachRecover'),
    src.indexOf('Public Feature Contract'))
    .replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  chk('otAttachRecover ไม่เรียก njhr_ot_submit เลย',
    recBody.indexOf('njhr_ot_submit') < 0, '');
  chk('otAttachRecover เรียกเฉพาะ njhr_ot_attach_add',
    (recBody.match(/sbRpc\('([a-z_0-9]+)'/g) || [])
      .every(function (x) { return x.indexOf('njhr_ot_attach_add') >= 0; }), '');
  chk('เก็บ path/url/size ของไฟล์ไว้ใช้แนบใหม่',
    /attachFail\.push\(\{[\s\S]{0,240}path: t\.file\.path/.test(src), '');
  chk('CASE A · ส่งคำขอล้ม ยังคืนปุ่มให้ส่งใหม่ได้',
    /\['catch'\]\(function \(ex\) \{[\s\S]{0,200}submitting = false;[\s\S]{0,120}innerHTML = 'ส่งคำขอ'/.test(src), '');
  chk('ไฟล์ที่เว็บใช้จริงมี otAttachRecover', out.indexOf('otAttachRecover') >= 0, '');

  console.log('\n== ไม่มีไฟล์แนบเลย (ไม่กระทบเส้นทางปกติ) ==');
  chk('ไม่มีไฟล์ → ไม่เข้าเส้นทางกู้คืน',
    /if \(attachFail\.length\) \{/.test(src), '');
  chk('แจ้งสำเร็จพร้อมจำนวนไฟล์เมื่อครบ',
    /toast\('ส่งคำขอ OT แล้ว[\s\S]{0,200}แนบไฟล์ ' \+ attachJobs\.length/.test(src), '');

  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  console.log('NOT TESTED: การล้มจริงจาก Network บนเบราว์เซอร์ และการตรวจ DB ว่าไม่มีคำขอซ้ำ');
  process.exit(FAIL ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
