/* pf_mobile_test.js — หน้าโปรไฟล์บนมือถือ 2 เรื่อง
     1. กด "ข้อมูลส่วนตัว" แล้วต้องเปิดจริง (เดิมแพ้ .only-desktop ที่เป็น !important)
     2. เปลี่ยนรูปโปรไฟล์ได้ ผ่านระบบแฟ้มพนักงานเดิม ไม่สร้าง Storage ใหม่
   ใช้: node harness/pf_mobile_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(58) + (d || '')); }

const src = fs.readFileSync(path.join(ROOT, 'src/14-view-profile-hrdocs.js'), 'utf8');
const out = fs.readFileSync(path.join(ROOT, 'views/profile/main.js'), 'utf8');
const mob = fs.readFileSync(path.join(ROOT, 'mobile.css'), 'utf8');
const desk = fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8');
const min = mob.replace(/\s+/g, '');

/* ================= 1. ข้อมูลส่วนตัว ================= */
console.log('\n== กด "ข้อมูลส่วนตัว" แล้วต้องเปิดจริง ==');
chk('styles.css ยังมี .only-desktop { display:none !important } (ไม่ถอดออกจากระบบ)',
  desk.replace(/\s+/g, '').indexOf('.only-desktop{display:none!important}') >= 0, '');
chk('กฎเปิดการ์ดมี !important จึงชนะ .only-desktop ได้',
  min.indexOf('.pf-legacy.pf-show-mobile{display:block!important') >= 0, '');
chk('กฎอยู่ใน @media (max-width: 900px) เท่านั้น',
  min.indexOf('@media(max-width:900px){.pf-legacy{display:none}') >= 0, '');
chk('.pf-legacy ยังซ่อนตามปกติเมื่อไม่ได้กด',
  min.indexOf('.pf-legacy{display:none}') >= 0, '');

/* ตรวจการคำนวณ specificity/important จริง ๆ ด้วย jsdom */
const { JSDOM } = require('jsdom');
const dom = new JSDOM(
  '<!doctype html><html><head><style>' + desk + '</style><style>' + mob + '</style></head>' +
  '<body><div class="only-desktop pf-legacy" id="box">เนื้อหา</div></body></html>',
  { pretendToBeVisual: true });
const w = dom.window, box = w.document.getElementById('box');
/* jsdom ไม่จำลอง media query ตามความกว้างจริง จึงตรวจจากข้อความกฎแทน
   แต่ยืนยันได้ว่า element มีทั้งสองคลาสพร้อมกันจริง */
chk('กล่องมีทั้ง .only-desktop และ .pf-legacy พร้อมกัน (ต้นเหตุการชนกัน)',
  box.classList.contains('only-desktop') && box.classList.contains('pf-legacy'), '');

console.log('\n== ปุ่มและ Handler เดิม ==');
chk('ปุ่ม "ข้อมูลส่วนตัว" ยังใช้ Workflow เดิม (เติมคลาส ไม่เปลี่ยน Route)',
  /to === 'detail'[\s\S]{0,320}classList\.add\('pf-show-mobile'\)/.test(src), '');
chk('การ์ดพนักงานด้านบนเปิดได้ด้วย',
  /\.pfm-emp'\)[\s\S]{0,260}classList\.add\('pf-show-mobile'\)/.test(src), '');
chk('ไม่มีการ reload หน้า', src.indexOf('location.reload') < 0, '');
chk('ไม่สร้าง Route ใหม่', src.indexOf("'#/profile-detail'") < 0, '');
chk('เลื่อนไปที่การ์ดให้เห็นทันที', src.indexOf('scrollIntoView') >= 0, '');
chk('ไฟล์ที่เว็บใช้จริงมีคลาสนี้', out.indexOf('pf-show-mobile') >= 0, '');

/* ================= 2. รูปโปรไฟล์ ================= */
console.log('\n== รูปโปรไฟล์: UI ==');
chk('มีปุ่มกล้องบนรูป', src.indexOf('id="pfm-cam"') >= 0, '');
chk('มี input[type=file] ซ่อนไว้',
  /<input type="file" id="pfm-photo"[^>]*hidden/.test(src), '');
chk('รับเฉพาะรูปภาพ (accept)',
  /accept="image\/jpeg,image\/png,image\/webp"/.test(src), '');
chk('ปุ่มกล้องกันไม่ให้ลิงก์ทำงาน (อยู่ใน <a>)',
  /cam\.onclick[\s\S]{0,140}preventDefault\(\)[\s\S]{0,60}stopPropagation\(\)/.test(src), '');
chk('กดด้วยคีย์บอร์ดได้ (Enter / Space)', /cam\.onkeydown/.test(src), '');

console.log('\n== รูปโปรไฟล์: ตรวจไฟล์ก่อนอัปโหลด ==');
chk('จำกัดขนาด 10 MB เท่ากับระบบแฟ้มเดิม',
  /PF_PHOTO_MAX = 10 \* 1024 \* 1024/.test(src), '');
const empf = fs.readFileSync(path.join(ROOT, 'src/41-view-employees-documents.js'), 'utf8');
chk('ตรงกับ EMPF_MAX ของระบบเดิม',
  /EMPF_MAX = 10 \* 1024 \* 1024/.test(empf), '');
chk('รับเฉพาะ MIME รูปภาพ 3 ชนิด',
  /PF_PHOTO_MIME = \['image\/jpeg', 'image\/png', 'image\/webp'\]/.test(src), '');
chk('ไฟล์ผิดชนิด → แจ้ง Error ไม่อัปโหลด',
  /PF_PHOTO_MIME\.indexOf[\s\S]{0,200}return;/.test(src), '');
chk('ไฟล์ใหญ่เกิน → แจ้ง Error ไม่อัปโหลด',
  /file\.size > PF_PHOTO_MAX[\s\S]{0,140}return;/.test(src), '');
chk('กันกดซ้ำระหว่างอัปโหลด', /pfPhotoBusy/.test(src), '');

console.log('\n== รูปโปรไฟล์: ต่อระบบเดิม ไม่สร้างของใหม่ ==');
chk('ใช้ Edge Function njhr-emp-file ตัวเดิม',
  src.indexOf('/functions/v1/njhr-emp-file') >= 0, '');
chk('ขอสิทธิ์อัปโหลดด้วย action = upload-url',
  /action: 'upload-url'/.test(src), '');
chk('PUT ไฟล์ขึ้น Signed Upload URL', /fetch\(d\.upload_url, \{[\s\S]{0,80}method: 'PUT'/.test(src), '');
chk('บันทึกทะเบียนด้วย njhr_empfile_save', src.indexOf('njhr_empfile_save') >= 0, '');
chk('หมวด PERSONAL / ชนิด PHOTO',
  /p_category: 'PERSONAL', p_doc_kind: 'PHOTO'/.test(src), '');
chk('ขอลิงก์ดูรูปด้วย action = download-url', /action: 'download-url'/.test(src), '');
chk('ค้นรูปเดิมด้วย njhr_empfile_list', src.indexOf('njhr_empfile_list') >= 0, '');
chk('ไม่สร้าง Bucket ใหม่ / ไม่ทำ Public',
  src.indexOf('createBucket') < 0 && src.indexOf('public: true') < 0 &&
  src.indexOf('/storage/v1/object/public/') < 0, '');
chk('ไม่เก็บรูปเป็น Base64', src.indexOf('readAsDataURL') < 0 &&
  src.indexOf('toDataURL') < 0, '');
chk('ไม่เก็บ Signed URL ลง localStorage',
  !/localStorage[\s\S]{0,80}(url|URL)/.test(src.slice(src.indexOf('pfEmpFn'),
    src.indexOf('function pfMobileHtml'))), '');
chk('ไม่ใส่ Service Role Key ในหน้าเว็บ',
  src.indexOf('service_role') < 0 && src.indexOf('SERVICE_ROLE') < 0, '');

console.log('\n== รูปโปรไฟล์: ความถูกต้องของข้อมูล ==');
chk('employee id มาจาก njhr_me_get เท่านั้น',
  /pfPhotoInit\(el, pfMePromise\)/.test(src) &&
  /mePromise\.then\(function \(me\)[\s\S]{0,120}me\.id/.test(src), '');
chk('ไม่รับ employee id จาก URL',
  !/location\.(search|hash)[\s\S]{0,80}employee/.test(src), '');
chk('เรียก njhr_me_get ครั้งเดียวต่อการเปิดหน้า',
  (src.match(/sbRpc\('njhr_me_get'/g) || []).length === 1,
  (src.match(/sbRpc\('njhr_me_get'/g) || []).length + ' จุด');
chk('ฟอร์มข้อมูลติดต่อใช้ผลก้อนเดียวกัน',
  /pfMePromise\.then\(function \(me\)[\s\S]{0,200}elements\.phone\.value/.test(src), '');
chk('บันทึกยังใช้ njhr_me_save เดิม', src.indexOf('njhr_me_save') >= 0, '');

console.log('\n== รูปโปรไฟล์: ค้นหาและ Versioning ==');
/* ตัดคอมเมนต์ก่อน เพราะหัวข้ออธิบายว่า "ไม่ดูจาก photo_url" */
const srcCode = src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
chk('ค้น PHOTO เสมอ ไม่ดูจาก employees.photo_url',
  srcCode.indexOf('photo_url') < 0, '');
chk('กรองเฉพาะ PERSONAL + PHOTO ที่ยังไม่ถูกลบ',
  /category\) === 'PERSONAL' && String\(f\.doc_kind\) === 'PHOTO'[\s\S]{0,60}!f\.deleted_at/.test(src), '');
chk('เรียงเอาไฟล์ล่าสุด', /localeCompare/.test(src), '');
chk('มีรูปเดิม → ส่ง p_id เดิมเพื่อทำ Versioning',
  /p_id: \(pfPhotoCur && pfPhotoCur\.id\) \|\| null/.test(src), '');
chk('ไม่ลบไฟล์เก่าทิ้งเอง', src.indexOf('njhr_empfile_delete') < 0, '');

console.log('\n== รูปโปรไฟล์: ไม่ทำหน้าพัง ==');
chk('หารูปไม่เจอ → คืน null ใช้ avatarHTML เดิม',
  /njhr_empfile_list ล้มเหลว[\s\S]{0,80}return null/.test(src), '');
chk('ขอลิงก์ไม่สำเร็จ → ไม่พัง คงตัวอักษรย่อ',
  /ขอลิงก์รูปไม่สำเร็จ[\s\S]{0,80}return null/.test(src), '');
chk('รูปโหลดไม่ขึ้น → แจ้งแทนที่จะค้าง', /img\.onerror/.test(src), '');
chk('ล้มเหลวแล้วคืนปุ่มให้กดใหม่ได้',
  /pfPhotoBusy = false;[\s\S]{0,120}classList\.remove\('is-busy'\)/.test(src), '');
chk('ล้างค่า input เพื่อเลือกไฟล์เดิมซ้ำได้', /inp\.value = ''/.test(src), '');
chk('ไม่ขึ้นข้อความสำเร็จหลอก',
  /toast\('เปลี่ยนรูปโปรไฟล์เรียบร้อยแล้ว'\)/.test(src) &&
  /pfPhotoLoad\(empId\);[\s\S]{0,120}toast\('เปลี่ยนรูปโปรไฟล์/.test(src), '');

console.log('\n== ไม่กระทบ Desktop และส่วนอื่น ==');
chk('styles.css (Desktop) ไม่มีกฎรูปโปรไฟล์มือถือ',
  desk.indexOf('.pfm-cam') < 0 && desk.indexOf('.pfm-photo-img') < 0, '');
chk('กฎรูปทั้งหมดอยู่ใน mobile.css',
  mob.indexOf('.pfm-cam') >= 0 && mob.indexOf('.pfm-photo-img') >= 0, '');
chk('การ์ด Desktop (.profile-card) ไม่ถูกแตะ',
  src.indexOf('card profile-card') >= 0, '');
chk('ไม่แก้ระบบแฟ้มพนักงานเดิม',
  empf.indexOf('function empfUploadOne') >= 0 && empf.indexOf('EMPF_MAX') >= 0, '');
chk('ไฟล์ที่เว็บใช้จริงมีฟังก์ชันรูปโปรไฟล์',
  out.indexOf('pfPhotoInit') >= 0 && out.indexOf('pfPhotoUpload') >= 0, '');

console.log('\n== Edge Function ที่ต้องมีบน Production ==');
const efPath = path.join(ROOT, 'edge-functions/njhr-emp-file/index.ts');
chk('Source ของ Edge Function อยู่ใน Repository', fs.existsSync(efPath), '');
if (fs.existsSync(efPath)) {
  const ef = fs.readFileSync(efPath, 'utf8');
  chk('รองรับ action upload-url', ef.indexOf('upload-url') >= 0, '');
  chk('รองรับ action download-url', ef.indexOf('download-url') >= 0, '');
}

console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
console.log('BLOCKED: Production ไม่มี Edge Function njhr-emp-file — Upload จริงยังทดสอบไม่ได้');
process.exit(FAIL ? 1 : 0);
