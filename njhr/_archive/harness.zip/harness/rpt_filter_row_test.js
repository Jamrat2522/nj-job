/* rpt_filter_row_test.js — ตรวจแถบตัวกรองหน้า "รายงานการลงเวลา"
     · Desktop = แถวเดียว (flex-wrap: nowrap) ไม่มีอะไรตกบรรทัด
     · ลำดับ: ประเภทรายงาน · วันที่เริ่ม · ถึง · วันที่สิ้นสุด · แผนก · สถานะ · ค้นหา · ล้างตัวกรอง · Export
     · ช่องค้นหา flex-grow · ความสูงเท่ากัน · ไม่มี Horizontal Scroll
     · มือถือและ Logic เดิมต้องไม่ถูกแตะ
   ใช้: node harness/rpt_filter_row_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(60) + (d || '')); }

const css = fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8');
const cssMin = css.replace(/\s+/g, '');
const rptJs = fs.readFileSync(path.join(ROOT, 'views/attendance/report.js'), 'utf8');

/* ---- ตัดเฉพาะบล็อก @media min-width:901px ที่มีกฎ .rpt-filters ---- */
function deskBlock() {
  const key = '@mediascreenand(min-width:901px){';
  let i = -1;
  while ((i = cssMin.indexOf(key, i + 1)) >= 0) {
    let d = 1, j = i + key.length;
    for (; j < cssMin.length && d > 0; j++) {
      if (cssMin[j] === '{') d++;
      else if (cssMin[j] === '}') d--;
    }
    const body = cssMin.slice(i + key.length, j - 1);
    if (body.indexOf('.rpt-filters') >= 0) return body;
  }
  return '';
}
const DESK = deskBlock();

/* ================= 1. Desktop = แถวเดียว ================= */
console.log('\n== Desktop: แถวเดียว ==');
chk('มีบล็อก @media (min-width: 901px) สำหรับ .rpt-filters', DESK.length > 0, DESK.length + ' อักขระ');
chk('.rpt-filters ตั้ง flex-wrap: nowrap', DESK.indexOf('.rpt-filters{flex-wrap:nowrap') >= 0, '');
chk('ระยะห่างระหว่างช่อง 8–10px', /\.rpt-filters\{flex-wrap:nowrap;gap:(8|9|10)px/.test(DESK), '');
chk('ช่องค้นหา flex-grow กินพื้นที่ที่เหลือ',
  /\.rpt-filters\.rpt-emp-box\{flex:1 1 \d+px/.test(DESK) || DESK.indexOf('.rpt-filters.rpt-emp-box{flex:11') >= 0,
  '');
chk('select หดได้เมื่อพื้นที่แคบ (ไม่ตกบรรทัด)',
  /\.rpt-filters>select\{flex:0 1 auto|\.rpt-filters>select\{flex:01auto/.test(DESK), '');
chk('select ไม่ยืดเกินจำเป็น (max-width)', DESK.indexOf('max-width:200px') >= 0, '');
/* CSS ถูก minify แล้ว attribute selector ไม่มีเครื่องหมายคำพูด */
chk('ช่องวันที่กว้างคงที่ ไม่ยืด', DESK.indexOf('input[type=date]{flex:00auto;width:148px') >= 0, '');
chk('ปุ่มไม่ตัดคำ (white-space: nowrap)', DESK.indexOf('white-space:nowrap') >= 0, '');
chk('ซ่อนตัวคั่น .grow เพื่อไม่ให้ดันปุ่มตกบรรทัด',
  DESK.indexOf('.rpt-filters>.grow{display:none}') >= 0, '');
chk('กัน overflow ด้วย min-width: 0 บน select', DESK.indexOf('min-width:0') >= 0, '');

/* ================= 2. ความสูงเท่ากัน ================= */
console.log('\n== ความสูง ==');
chk('select / date / ช่องค้นหา สูง 42px เท่าปุ่ม', DESK.indexOf('min-height:42px') >= 0, '');
chk('ปุ่ม .btn สูง 42px ตามเดิม (ไม่แก้)', /\.btn\{[^}]*height:42px/.test(cssMin), '');
chk('.toolbar ยัง align-items: center (จัดกึ่งกลางแนวตั้ง)',
  /\.toolbar\{display:flex;align-items:center/.test(cssMin), '');

/* ================= 3. ลำดับใน DOM ================= */
console.log('\n== ลำดับตัวกรองใน DOM ==');
const bar = rptJs.slice(rptJs.indexOf('toolbar rpt-filters'), rptJs.indexOf('rpt-export') + 60);
const order = [
  ['ประเภทรายงาน', 'rpt-type'], ['วันที่เริ่ม', 'rpt-from'], ['คำว่า "ถึง"', 'ถึง'],
  ['วันที่สิ้นสุด', 'rpt-to'], ['แผนก', 'rpt-dept'], ['ค้นหา', 'rpt-q'],
  ['ล้างตัวกรอง', 'rpt-clear'], ['Export Excel', 'rpt-export']
];
let last = -1, seqOk = true, seen = [];
order.forEach(function (x) {
  const i = bar.indexOf(x[1]);
  seen.push(x[0] + (i < 0 ? '(ไม่พบ)' : ''));
  if (i < 0 || i < last) seqOk = false;
  if (i >= 0) last = i;
});
chk('ลำดับใน DOM ถูกต้องครบทุกช่อง', seqOk, seen.join(' → '));
chk('"ล้างตัวกรอง" อยู่ก่อน "Export Excel"',
  bar.indexOf('rpt-clear') < bar.indexOf('rpt-export') && bar.indexOf('rpt-clear') >= 0, '');
chk('มีช่องสถานะการลงเวลา (rpt-astatus)', rptJs.indexOf('rpt-astatus') >= 0, '');

/* ================= 4. ไม่แตะ Logic / DOM / มือถือ ================= */
console.log('\n== ไม่กระทบส่วนอื่น ==');
chk('ปุ่มล้างตัวกรองยังผูก Handler เดิม', rptJs.indexOf("getElementById('rpt-clear')") >= 0 ||
  rptJs.indexOf('getElementById("rpt-clear")') >= 0, '');
chk('ปุ่ม Export ยังผูก Handler เดิม', rptJs.indexOf("getElementById('rpt-export')") >= 0 ||
  rptJs.indexOf('getElementById("rpt-export")') >= 0, '');
['rpt-type', 'rpt-from', 'rpt-to', 'rpt-dept', 'rpt-q'].forEach(function (id) {
  chk('ตัวกรอง ' + id + ' ยังมี Handler', rptJs.indexOf(id) >= 0, '');
});
chk('ไม่มี class ใหม่ที่ไม่ได้ใช้ (.report-filter-bar)',
  css.indexOf('report-filter-bar') < 0 && rptJs.indexOf('report-filter-bar') < 0, '');

/* มือถือ: กฎเดิมต้องยังอยู่ครบ */
console.log('\n== มือถือไม่เปลี่ยน ==');
chk('กฎมือถือ .rpt-emp-box เต็มความกว้าง ยังอยู่',
  cssMin.indexOf('.rpt-emp-box{min-width:100%;flex:11100%}') >= 0, '');
/* ตัว minify อาจสลับลำดับ selector — ตรวจว่ากฎยังอยู่โดยไม่ผูกกับลำดับ */
chk('กฎมือถือ .rpt-filters 2 ช่องต่อแถว ยังอยู่',
  /\.rpt-filters>input\[type=date\],\.rpt-filters>select\{flex:1144%/.test(cssMin) ||
  /\.rpt-filters>select,\.rpt-filters>input\[type=date\]\{flex:1144%/.test(cssMin), '');
chk('กฎฐาน .rpt-filters ยังเป็น wrap (มือถือใช้ค่านี้)',
  cssMin.indexOf('.rpt-filters{flex-wrap:wrap;gap:8px}') >= 0, '');
const mcss = fs.readFileSync(path.join(ROOT, 'mobile.css'), 'utf8');
chk('mobile.css ไม่มีกฎ .rpt-filters เพิ่ม', mcss.indexOf('.rpt-filters') < 0, '');

console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
process.exit(FAIL ? 1 : 0);
