/* desk_table_mobile_diff.js — พิสูจน์ว่าการ์ดมือถือของลางาน/OT ไม่ถูกแตะ
   ยกเว้น "รูปแบบวันที่" ที่เปลี่ยนเป็น DD/MM/YYYY ตามที่สั่งไว้โดยเจตนา
   (เดิมชุดนี้พิสูจน์ว่า "หน้ามือถือคงเดิม 100%"
   รันหน้า #/ot และ #/leave ด้วย chunk เก่า (ก่อนแก้) และ chunk ใหม่ ใน jsdom เดียวกัน
   แล้วเทียบ HTML ของ .only-mobile ทุกใบแบบตัวต่อตัว
   ใช้: node harness/desk_table_mobile_diff.js <ทางโปรเจกต์ใหม่> <ทางโปรเจกต์เก่า> */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const NEW = path.resolve(process.argv[2]), OLD = path.resolve(process.argv[3]);

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(52) + (d || '')); }
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
  .replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const OTS = [
  { id: 'OT-AAA111', no: '260811-0001', empId: 'e1', date: '2026-08-11', start: '18:00', end: '21:00',
    hours: 3, reason: 'ปิดงบ', note: 'ด่วน', status: 'PENDING', createdAt: '2026-08-11T10:00:00Z',
    jobs: [{ no: 1, job: 'J1', detail: '', jobType: 'ตรวจปล่อย', files: [{ name: 'a.pdf' }] },
           { no: 2, job: 'J2', detail: '', jobType: 'คีย์ใบขน', files: [] }] },
  { id: 'OT-BBB222', empId: 'e1', date: '2026-08-09', start: '19:00', end: '22:00',
    hours: 3, reason: 'งานด่วน', status: 'APPROVED', createdAt: '2026-08-09T10:00:00Z',
    jobs: [], task: 'งานเก่า', file: 'old.pdf' }
];
/* แถวจาก njhr_ot_list สำหรับ build ใหม่ (build เก่าอ่าน db.ots จึงไม่ใช้ชุดนี้) */
const OT_RPC = [
  { id: 'OT-AAA111', request_no: '260811-0001', employee_id: 'e1', emp_name: 'สมชาย ใจดี',
    ot_date: '2026-08-11', start_time: '18:00:00', end_time: '21:00:00', spans_next_day: false,
    ot_hours: 3, reason: 'ปิดงบ', status: 'PENDING', created_at: '2026-08-11T10:00:00Z',
    jobs_count: 2, files_count: 1, is_holiday: false },
  { id: 'OT-BBB222', request_no: '260809-0004', employee_id: 'e1', emp_name: 'สมชาย ใจดี',
    ot_date: '2026-08-09', start_time: '19:00:00', end_time: '22:00:00', spans_next_day: false,
    ot_hours: 3, reason: 'งานด่วน', status: 'APPROVED', created_at: '2026-08-09T10:00:00Z',
    jobs_count: 0, files_count: 1, is_holiday: false }
];

const LEAVES = [
  { id: 'lv-1', request_no: '260810-0007', leave_type: 'SICK', status: 'PENDING', ui_status: 'PENDING',
    start_date: '2026-08-10', end_date: '2026-08-10', total_days: 1, hours: 0,
    leave_unit: 'day', reason: 'ไม่สบาย', file_name: 'med.pdf', emp_name: 'สมชาย ใจดี', department: 'ขนส่ง' },
  { id: 'lv-2', leave_type: 'BUSINESS', status: 'APPROVED', ui_status: 'APPROVED',
    start_date: '2026-08-03', end_date: '2026-08-04', total_days: 2, hours: 0,
    leave_unit: 'day', reason: 'ธุระ', file_name: null, emp_name: 'สมชาย ใจดี', department: 'ขนส่ง' }
];


/* แทนที่วันที่ทุกรูปแบบด้วย token เดียว เพื่อพิสูจน์ว่า "ส่วนที่ไม่ใช่วันที่" เหมือนเดิมทุกไบต์
     เก่า: 11 ส.ค. 2569   ใหม่: 11/08/2026 */
const TH_RE = /\d{1,2} (?:ม\.ค\.|ก\.พ\.|มี\.ค\.|เม\.ย\.|พ\.ค\.|มิ\.ย\.|ก\.ค\.|ส\.ค\.|ก\.ย\.|ต\.ค\.|พ\.ย\.|ธ\.ค\.) \d{4}/g;
const DMY_RE = /\d{2}\/\d{2}\/\d{4}/g;
/* ISO_RE รองรับผลของ stub fmtDate ใน harness (คืน '2026-08-10' ตรง ๆ)
   ซึ่งเป็นรูปแบบของ build เก่าในชุดทดสอบนี้ ไม่ใช่รูปแบบบนหน้าจอจริง */
const ISO_RE = /\d{4}-\d{2}-\d{2}/g;
function normDate(h) {
  return String(h).replace(TH_RE, '@DATE@').replace(DMY_RE, '@DATE@').replace(ISO_RE, '@DATE@');
}
function isDMY(h) { return !TH_RE.test(h); }

function env(root) {
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div></body></html>');
  const win = dom.window;
  const NJHR = {
    state: { currentRoute: '#/ot' }, router: { navId: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    features: {}, views: { register: () => {} }, compat: { scope: {} }
  };
  Object.assign(NJHR.compat.scope, {
    icon: () => '<span class="ic"></span>', esc, debounce: f => f,
    avatarHTML: () => '<span class="avatar"></span>',
    emptyState: m => '<div class="empty">' + m + '</div>',
    fmtDateDMY: v => { const p = String(v == null ? '' : v).slice(0, 10).split('-');
      if (p.length !== 3) return '—';
      const y = parseInt(p[0], 10), m = parseInt(p[1], 10), d = parseInt(p[2], 10);
      if (!isFinite(y) || !isFinite(m) || !isFinite(d)) return '—';
      const z = n => (n < 10 ? '0' + n : '' + n);
      return z(d) + '/' + z(m) + '/' + y; },
    fmtDate: d => String(d || ''), empName: () => 'สมชาย ใจดี',
    statusBadge: s => '<span class="badge">' + s + '</span>',
    currentUser: () => ({ id: 'u1', role: 'USER', empId: 'e1' }),
    currentEmp: () => ({ id: 'e1', firstName: 'สมชาย', lastName: 'ใจดี', deptId: 'd1' }),
    dept: () => 'ขนส่ง', toast: () => {}, db: { ots: OTS, leaves: [] },
    showTimeline: () => {}, bindReqCardActions: () => {},
    sbReady: () => true, sbToken: () => 'tok',
    sbRpc: () => Promise.resolve({}),
    sbRpcList: fn => {
      if (fn === 'njhr_leave_list') return Promise.resolve(LEAVES.map(r => Object.assign({ total_count: LEAVES.length }, r)));
      if (fn === 'njhr_ot_list') return Promise.resolve(OT_RPC);
      return Promise.resolve([]);
    },
    openModal: () => {}, closeModal: () => {}, confirmDialog: () => {}, nav: () => {},
    TH_MONTHS: ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'],
    lvType: c => ({ SICK: { code: 'SICK', name: 'ลาป่วย', color: '#16A34A' },
                    BUSINESS: { code: 'BUSINESS', name: 'ลากิจ', color: '#2563EB' } }[c] ||
                  { code: c, name: c, color: '#64748B' }),
    lvMode: r => (r && r.leave_unit === 'hour' ? 'HOURLY' : 'FULL'),
    lvModeTxt: m => ({ FULL: 'เต็มวัน', HOURLY: 'รายชั่วโมง' }[m] || m),
    lvNum: v => { const n = Number(v); return isFinite(n) ? Math.round(n * 100) / 100 : 0; },
    lvCode: x => (x && typeof x === 'object'
      ? (x.request_no || x.requestNo || ('LV-' + String(x.id || '').slice(0, 6).toUpperCase()))
      : 'LV-' + String(x || '').slice(0, 6).toUpperCase()),
    LEAVE_TYPES: [], refreshLeavePending: () => {}, RQ_CARDS: [], rqState: { seq: 0, bal: [], err: '' },
    rqRenderMenu: () => {}, rqRenderBal: () => {}, rqPick: () => null, rhStatus: () => ({ k: 'PENDING' }),
    audit: () => {}, saveDB: () => {}, nowStamp: () => '', render: () => {}, uid: () => 'x'
  });
  win.NJHR = NJHR;
  const ctx = vm.createContext(win);
  return { win, NJHR,
    run: rel => vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), ctx, { filename: rel }),
    host: () => win.document.getElementById('app') };
}

function mobileOf(root, chunk, viewName) {
  const E = env(root);
  let fn = null;
  E.NJHR.views.register = (n, f) => { if (n === viewName) fn = f; };
  E.run(chunk);
  if (!fn) return null;
  fn(E.host());
  return E;
}

function cards(E) {
  return Array.from(E.host().querySelectorAll('.only-mobile')).map(x => x.outerHTML);
}

/* ---------- OT ----------
   หน้า #/ot เปลี่ยนแหล่งข้อมูลจาก db.ots (localStorage) เป็น njhr_ot_list (Supabase) แล้ว
   การเทียบ HTML กับ build เก่าจึงไม่มีความหมายอีก (คนละแหล่ง คนละฟิลด์)
   เปลี่ยนเป็นตรวจว่าโครงการ์ดมือถือยังเป็นชุดคลาสเดิมและใช้ DD/MM/YYYY แทน */
const otNew = mobileOf(NEW, 'views/ot/main.js', 'viewOT');

/* ---------- LEAVE (รอ RPC) ---------- */
const lvNew = mobileOf(NEW, 'views/leave/main.js', 'viewLeave');
const lvOld = mobileOf(OLD, 'views/leave/main.js', 'viewLeave');
setTimeout(function () {
  /* ---- OT: ตรวจโครงการ์ดมือถือ ไม่เทียบไบต์กับ build เก่า ---- */
  const ot = cards(otNew);
  chk('OT · ยังมีการ์ดมือถือ (.only-mobile)', ot.length === 2, ot.length + ' ใบ');
  const otHtml = ot.join('');
  ['req-card', 'req-top', 'req-body', 'req-reason', 'req-actions', 'chip chip-info']
    .forEach(function (cls) {
      chk('OT · คงคลาสเดิม .' + cls.split(' ')[0], otHtml.indexOf(cls) >= 0, '');
    });
  chk('OT · ปุ่มเดิมครบ (รายละเอียด + ยกเลิก)',
    otHtml.indexOf('data-detail=') >= 0 && otHtml.indexOf('data-cancel=') >= 0, '');
  chk('OT · ใช้ DD/MM/YYYY ไม่เหลือ พ.ศ./เดือนไทย',
    isDMY(otHtml) && /\d{2}\/\d{2}\/\d{4}/.test(otHtml),
    (otHtml.match(DMY_RE) || []).slice(0, 2).join(' · '));

  const c = cards(lvNew), d = cards(lvOld);
  chk('ลางาน · จำนวนการ์ดมือถือเท่าเดิม', c.length === d.length, c.length + ' vs ' + d.length);
  chk('ลางาน · HTML การ์ดมือถือเหมือนเดิมทุกไบต์ (ยกเว้นรูปแบบวันที่)',
    JSON.stringify(c.map(normDate)) === JSON.stringify(d.map(normDate)),
    c.length ? 'ยาว ' + c.join('').length + ' อักขระ' : '');
  chk('ลางาน · การ์ดมือถือใช้ DD/MM/YYYY แล้ว ไม่เหลือ พ.ศ./เดือนไทย',
    isDMY(c.join('')) && /\d{2}\/\d{2}\/\d{4}/.test(c.join('')),
    (c.join('').match(DMY_RE) || []).slice(0, 2).join(' · '));
  if (JSON.stringify(c.map(normDate)) !== JSON.stringify(d.map(normDate))) {
    console.log('NEW:', c[0]); console.log('OLD:', d[0]);
  }
  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
}, 80);
