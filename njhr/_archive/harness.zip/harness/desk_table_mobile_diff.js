/* desk_table_mobile_diff.js — พิสูจน์ว่า "หน้ามือถือคงเดิม 100%"
   รันหน้า #/ot และ #/leave ด้วย chunk เก่า (ก่อนแก้) และ chunk ใหม่ ใน jsdom เดียวกัน
   แล้วเทียบ HTML ของ .only-mobile ทุกใบแบบตัวต่อตัว
   ใช้: node harness/desk_table_mobile_diff.js <ทางโปรเจกต์ใหม่> <ทางโปรเจกต์เก่า> */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const NEW = path.resolve(process.argv[2]), OLD = path.resolve(process.argv[3]);

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(52) + (d || '')); }
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
  .replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const OTS = [
  { id: 'OT-AAA111', no: '260811-0001', empId: 'e1', date: '2026-08-11', start: '18:00', end: '21:00',
    hours: 3, reason: 'ปิดงบ', note: 'ด่วน', status: 'PENDING', createdAt: '2026-08-11T10:00:00Z',
    jobs: [{ no: 1, job: 'J1', detail: '', jobType: 'ตรวจปล่อย', files: [{ name: 'a.pdf' }] },
           { no: 2, job: 'J2', detail: '', jobType: 'คีย์ใบขน', files: [] }] },
  { id: 'OT-BBB222', empId: 'e1', date: '2026-08-09', start: '19:00', end: '22:00',
    hours: 3, reason: 'งานด่วน', status: 'APPROVED', createdAt: '2026-08-09T10:00:00Z',
    jobs: [], task: 'งานเก่า', file: 'old.pdf' }
];
const LEAVES = [
  { id: 'lv-1', request_no: '260810-0007', leave_type: 'SICK', status: 'PENDING', ui_status: 'PENDING',
    start_date: '2026-08-10', end_date: '2026-08-10', total_days: 1, hours: 0,
    leave_unit: 'day', reason: 'ไม่สบาย', file_name: 'med.pdf', emp_name: 'สมชาย ใจดี', department: 'ขนส่ง' },
  { id: 'lv-2', leave_type: 'BUSINESS', status: 'APPROVED', ui_status: 'APPROVED',
    start_date: '2026-08-03', end_date: '2026-08-04', total_days: 2, hours: 0,
    leave_unit: 'day', reason: 'ธุระ', file_name: null, emp_name: 'สมชาย ใจดี', department: 'ขนส่ง' }
];

function env(root) {
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div></body></html>');
  const win = dom.window;
  const NJHR = {
    state: { currentRoute: '#/ot' }, router: { navId: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    features: {}, views: { register: () => {} }, compat: { scope: {} }
  };
  Object.assign(NJHR.compat.scope, {
    icon: () => '<span class="ic"></span>', esc, debounce: f => f,
    avatarHTML: () => '<span class="avatar"></span>',
    emptyState: m => '<div class="empty">' + m + '</div>',
    fmtDate: d => String(d || ''), empName: () => 'สมชาย ใจดี',
    statusBadge: s => '<span class="badge">' + s + '</span>',
    currentUser: () => ({ id: 'u1', role: 'USER', empId: 'e1' }),
    currentEmp: () => ({ id: 'e1', firstName: 'สมชาย', lastName: 'ใจดี', deptId: 'd1' }),
    dept: () => 'ขนส่ง', toast: () => {}, db: { ots: OTS, leaves: [] },
    showTimeline: () => {}, bindReqCardActions: () => {},
    sbReady: () => true, sbToken: () => 'tok',
    sbRpc: () => Promise.resolve({}),
    sbRpcList: fn => (fn === 'njhr_leave_list'
      ? Promise.resolve(LEAVES.map(r => Object.assign({ total_count: LEAVES.length }, r)))
      : Promise.resolve([])),
    openModal: () => {}, closeModal: () => {}, confirmDialog: () => {}, nav: () => {},
    TH_MONTHS: ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'],
    lvType: c => ({ SICK: { code: 'SICK', name: 'ลาป่วย', color: '#16A34A' },
                    BUSINESS: { code: 'BUSINESS', name: 'ลากิจ', color: '#2563EB' } }[c] ||
                  { code: c, name: c, color: '#64748B' }),
    lvMode: r => (r && r.leave_unit === 'hour' ? 'HOURLY' : 'FULL'),
    lvModeTxt: m => ({ FULL: 'เต็มวัน', HOURLY: 'รายชั่วโมง' }[m] || m),
    lvNum: v => { const n = Number(v); return isFinite(n) ? Math.round(n * 100) / 100 : 0; },
    lvCode: x => (x && typeof x === 'object'
      ? (x.request_no || x.requestNo || ('LV-' + String(x.id || '').slice(0, 6).toUpperCase()))
      : 'LV-' + String(x || '').slice(0, 6).toUpperCase()),
    LEAVE_TYPES: [], refreshLeavePending: () => {}, RQ_CARDS: [], rqState: { seq: 0, bal: [], err: '' },
    rqRenderMenu: () => {}, rqRenderBal: () => {}, rqPick: () => null, rhStatus: () => ({ k: 'PENDING' }),
    audit: () => {}, saveDB: () => {}, nowStamp: () => '', render: () => {}, uid: () => 'x'
  });
  win.NJHR = NJHR;
  const ctx = vm.createContext(win);
  return { win, NJHR,
    run: rel => vm.runInContext(fs.readFileSync(path.join(root, rel), 'utf8'), ctx, { filename: rel }),
    host: () => win.document.getElementById('app') };
}

function mobileOf(root, chunk, viewName) {
  const E = env(root);
  let fn = null;
  E.NJHR.views.register = (n, f) => { if (n === viewName) fn = f; };
  E.run(chunk);
  if (!fn) return null;
  fn(E.host());
  return E;
}

function cards(E) {
  return Array.from(E.host().querySelectorAll('.only-mobile')).map(x => x.outerHTML);
}

/* ---------- OT (เรนเดอร์ทันที ไม่รอ RPC) ---------- */
const otNew = mobileOf(NEW, 'views/ot/main.js', 'viewOT');
const otOld = mobileOf(OLD, 'views/ot/main.js', 'viewOT');
const a = cards(otNew), b = cards(otOld);
chk('OT · จำนวนการ์ดมือถือเท่าเดิม', a.length === b.length, a.length + ' vs ' + b.length);
chk('OT · HTML การ์ดมือถือเหมือนเดิมทุกไบต์', JSON.stringify(a) === JSON.stringify(b),
  a.length ? 'ยาว ' + a.join('').length + ' อักขระ' : '');

/* ---------- LEAVE (รอ RPC) ---------- */
const lvNew = mobileOf(NEW, 'views/leave/main.js', 'viewLeave');
const lvOld = mobileOf(OLD, 'views/leave/main.js', 'viewLeave');
setTimeout(function () {
  const c = cards(lvNew), d = cards(lvOld);
  chk('ลางาน · จำนวนการ์ดมือถือเท่าเดิม', c.length === d.length, c.length + ' vs ' + d.length);
  chk('ลางาน · HTML การ์ดมือถือเหมือนเดิมทุกไบต์', JSON.stringify(c) === JSON.stringify(d),
    c.length ? 'ยาว ' + c.join('').length + ' อักขระ' : '');
  if (JSON.stringify(c) !== JSON.stringify(d)) { console.log('NEW:', c[0]); console.log('OLD:', d[0]); }
  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
}, 80);
