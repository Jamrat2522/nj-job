/* dash_leave_xcheck.js — พิสูจน์ว่า "คำขอลาล่าสุด" บน Dashboard
   กับหน้า REPORT ลางาน (#/rpt-leave) อ่านจากแหล่งข้อมูลส่วนกลางเดียวกัน
   วิธี: ป้อนแถวชุดเดียวกันจาก RPC ตัวเดียวกันให้ทั้งสอง chunk แล้วเทียบ
         ชื่อผู้ลา · ประเภทการลา · วันที่ · สถานะ ของ 5 คำขอล่าสุด
   ใช้: node harness/dash_leave_xcheck.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(58) + (d || '')); }
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
  .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const tick = ms => new Promise(r => setTimeout(r, ms || 40));

const RPC_ROWS = [
  { req_id: 'l1', request_no: '260810-0007', emp_code: 'NJ001', prefix: 'นาย', full_name: 'สมชาย ใจดี',
    nickname: 'ชาย', department: 'ขนส่ง', leave_type: 'SICK', start_date: '2026-08-10',
    end_date: '2026-08-10', leave_unit: 'day', mode_txt: 'เต็มวัน', start_time: null, end_time: null,
    total_days: 1, hours: 0, status: 'PENDING', ui_status: 'PENDING', created_at: '2026-08-09T03:00:00Z' },
  { req_id: 'l2', request_no: '260803-0002', emp_code: 'NJ002', prefix: 'นางสาว', full_name: 'สมหญิง รักงาน',
    nickname: 'หญิง', department: 'บัญชี', leave_type: 'PERSONAL', start_date: '2026-08-03',
    end_date: '2026-08-04', leave_unit: 'day', mode_txt: 'หลายวัน', start_time: null, end_time: null,
    total_days: 2, hours: 0, status: 'APPROVED', ui_status: 'APPROVED', created_at: '2026-08-01T03:00:00Z' },
  { req_id: 'l3', request_no: '260701-0002', emp_code: 'NJ003', prefix: 'นาย', full_name: 'มานะ อดทน',
    nickname: 'นะ', department: 'ขนส่ง', leave_type: 'VACATION', start_date: '2026-07-01',
    end_date: '2026-07-05', leave_unit: 'day', mode_txt: 'หลายวัน', start_time: null, end_time: null,
    total_days: 5, hours: 0, status: 'CANCELLED', ui_status: 'CANCELLED', created_at: '2026-06-30T03:00:00Z' }
];

const LV = { SICK: 'ลาป่วย', PERSONAL: 'ลากิจ', VACATION: 'ลาพักร้อน', OTHER: 'ลาอื่น ๆ' };
const ST = { PENDING: 'รออนุมัติ', APPROVED: 'อนุมัติแล้ว', CANCELLED: 'ยกเลิกแล้ว' };

function env() {
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div></body></html>');
  const win = dom.window;
  const calls = [];
  const db = { employees: [], attendance: [], leaves: [], ots: [], corrections: [], payroll: [],
    announcements: [], holidays: [], notifications: [], leaveTypes: [], departments: [],
    users: [], balances: [], shifts: [], audit: [], settings: {} };
  const NJHR = {
    state: { currentRoute: '#/dashboard', docPending: 0 },
    router: { navId: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    features: {}, views: { register: () => {} }, compat: { scope: {} }
  };
  Object.assign(NJHR.compat.scope, {
    icon: () => '<span class="ic"></span>', esc, debounce: f => f,
    avatarHTML: () => '<span class="avatar"></span>',
    emptyState: m => '<div class="empty"><p>' + m + '</p></div>',
    fmtDateDMY: v => { const p = String(v == null ? '' : v).slice(0, 10).split('-');
      if (p.length !== 3) return '—';
      const y = parseInt(p[0], 10), m = parseInt(p[1], 10), d = parseInt(p[2], 10);
      if (!isFinite(y) || !isFinite(m) || !isFinite(d)) return '—';
      const z = n => (n < 10 ? '0' + n : '' + n);
      return z(d) + '/' + z(m) + '/' + y; },
    /* ตัวช่วยรอบเดือน 26–25 (สูตรเดียวกับ src/01-core-icons-utils.js) */
    cycleRange: ym => {
      const p = String(ym || '').split('-');
      const y = parseInt(p[0], 10), m = parseInt(p[1], 10);
      if (!isFinite(y) || !isFinite(m) || m < 1 || m > 12) return null;
      const z = n => (n < 10 ? '0' + n : '' + n);
      const py = m === 1 ? y - 1 : y, pm = m === 1 ? 12 : m - 1;
      return { ym: y + '-' + z(m), start: py + '-' + z(pm) + '-26',
               end: y + '-' + z(m) + '-25', endExclusive: y + '-' + z(m) + '-26' };
    },
    cycleCurrent: iso => {
      const t = String(iso || '2026-08-11').split('-');
      let y = +t[0], m = +t[1]; const d = +t[2];
      if (d >= 26) { if (m === 12) { y += 1; m = 1; } else { m += 1; } }
      const z = n => (n < 10 ? '0' + n : '' + n);
      const py = m === 1 ? y - 1 : y, pm = m === 1 ? 12 : m - 1;
      return { ym: y + '-' + z(m), start: py + '-' + z(pm) + '-26',
               end: y + '-' + z(m) + '-25', endExclusive: y + '-' + z(m) + '-26' };
    },
    cycleLabel: ym => String(ym || ''),
    cycleRangeText: ym => 'รอบข้อมูล ' + String(ym || ''),
    cycleOptions: (cur, back, fwd) => {
      const p = String(cur || '').split('-');
      const y = parseInt(p[0], 10), m = parseInt(p[1], 10);
      if (!isFinite(y) || !isFinite(m)) return [];
      const z = n => (n < 10 ? '0' + n : '' + n);
      const out = [];
      for (let i = -(back || 12); i <= (fwd || 0); i++) {
        let mm = m + i, yy = y;
        while (mm < 1) { mm += 12; yy -= 1; }
        while (mm > 12) { mm -= 12; yy += 1; }
        out.push(yy + '-' + z(mm));
      }
      return out.reverse();
    },
    fmtDate: d => String(d || ''), todayISO: () => '2026-08-11',
    statusBadge: s => '<span class="badge">' + (ST[s] || s) + '</span>',
    currentUser: () => ({ id: 'u1', username: 'admin', role: 'SUPER_ADMIN', empId: 'e1' }),
    currentEmp: () => ({ id: 'e1', firstName: 'จำรัส', lastName: 'ผาเทพ', shift: '08:30-17:30' }),
    emp: () => null, empName: () => '—', dept: () => '—', leaveType: () => ({ name: '' }),
    db: db, pendingCount: () => 0, remainDays: () => 0,
    money: String, maskAcc: String, fmtMonthYear: (m, y) => m + '/' + y,
    TH_MONTHS: ['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'],
    TH_DAYS: ['อา','จ','อ','พ','พฤ','ศ','ส'], pad: n => (n < 10 ? '0' + n : '' + n),
    isHoliday: () => false, holName: () => '', startLiveClock: () => {},
    nav: () => {}, toast: () => {}, audit: () => {},
    sbReady: () => true, sbToken: () => 'tok',
    sbRpcList: (fn, body) => {
      calls.push({ fn, body });
      if (fn === 'njhr_rpt_leave_list') return Promise.resolve(RPC_ROWS);
      if (fn === 'njhr_emp_departments') return Promise.resolve([{ name: 'ขนส่ง' }, { name: 'บัญชี' }]);
      return Promise.resolve([]);
    },
    sbRpc: () => Promise.resolve({}),
    rptSafeName: v => String(v), rptDateBE: v => String(v || ''),
    rptLoadZip: () => Promise.resolve(), rptBuildXlsx: () => Promise.resolve({}),
    lvType: c => ({ name: LV[c] || c })
  });
  win.NJHR = NJHR;
  win.URL.createObjectURL = () => 'blob:x';
  win.URL.revokeObjectURL = () => {};
  const ctx = vm.createContext(win);
  return { win, NJHR, calls,
    run: rel => vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), ctx, { filename: rel }),
    host: () => win.document.getElementById('app'),
    doc: () => win.document };
}

/* Dashboard (นอกขอบเขตงานเปลี่ยนรูปแบบวันที่) ยังใช้ fmtDate เดิม
   ส่วน REPORT ลางาน ใช้ fmtDateDMY (DD/MM/YYYY)
   จึงเทียบ "วันเดียวกัน" โดยแปลง DD/MM/YYYY กลับเป็น ISO ก่อน ไม่ใช่เทียบสตริงดิบ */
const dmyToIso = s => String(s).split(' – ')
  .map(x => { const p = x.trim().split('/'); return p.length === 3 ? p[2] + '-' + p[1] + '-' + p[0] : x.trim(); })
  .join(' – ');

async function run() {
  /* ---------- Dashboard ---------- */
  const A = env();
  let vDash = null;
  A.NJHR.views.register = (n, f) => { if (n === 'viewDashboard') vDash = f; };
  A.run('views/dashboard.js');
  vDash(A.host());
  await tick(60);
  const h = Array.from(A.doc().querySelectorAll('.card-head h3'))
    .find(x => x.textContent.trim() === 'คำขอลาล่าสุด');
  const dashRows = Array.from(h.closest('.card').querySelectorAll('.list .list-row')).map(r => ({
    who: r.querySelector('b').textContent.trim(),
    sub: r.querySelector('small').textContent.trim(),
    status: r.querySelector('.badge').textContent.trim()
  }));

  /* ---------- REPORT ลางาน ---------- */
  const B = env();
  let vRpt = null;
  B.NJHR.views.register = (n, f) => { if (n === 'viewRptLeave') vRpt = f; };
  B.run('views/reports/menu.js');
  vRpt(B.host());
  await tick(60);
  const rptRows = Array.from(B.doc().querySelectorAll('.rptm-table tbody tr')).map(tr => {
    const td = Array.from(tr.children).map(x => x.textContent.trim());
    return { no: td[1], type: td[2], date: td[3], who: td[6], status: td[7] };
  });

  chk('ทั้งสองหน้าเรียก RPC ตัวเดียวกัน',
    A.calls.some(c => c.fn === 'njhr_rpt_leave_list') &&
    B.calls.some(c => c.fn === 'njhr_rpt_leave_list'), 'njhr_rpt_leave_list');
  chk('Dashboard ได้ 3 รายการ · REPORT ได้ 3 รายการ',
    dashRows.length === 3 && rptRows.length === 3,
    dashRows.length + ' / ' + rptRows.length);

  /* เทียบทีละคำขอ — REPORT เรียงตาม start_date desc, Dashboard เรียงตาม created_at desc
     ข้อมูลชุดนี้ให้ลำดับเดียวกัน จึงเทียบตรงตำแหน่งได้ */
  let ok = true, detail = [];
  for (let i = 0; i < 3; i++) {
    const d = dashRows[i], r = rptRows[i];
    const sameWho = d.who === r.who;
    const sameType = d.sub.indexOf(r.type) === 0;
    const sameDate = d.sub.indexOf(dmyToIso(r.date)) > 0;
    const sameSt = d.status === r.status;
    if (!(sameWho && sameType && sameDate && sameSt)) { ok = false; }
    detail.push(d.who + '=' + r.who);
  }
  chk('ชื่อผู้ลาตรงกันทุกคำขอ', dashRows.every((d, i) => d.who === rptRows[i].who), detail.join(' · '));
  chk('ประเภทการลาตรงกันทุกคำขอ',
    dashRows.every((d, i) => d.sub.indexOf(rptRows[i].type) === 0),
    dashRows.map((d, i) => rptRows[i].type).join(' · '));
  chk('วันที่เป็นวันเดียวกันทุกคำขอ (REPORT แสดง DD/MM/YYYY)',
    dashRows.every((d, i) => d.sub.indexOf(dmyToIso(rptRows[i].date)) > 0),
    rptRows.map(r => r.date).join(' · '));
  chk('REPORT ลางาน แสดงวันที่เป็น DD/MM/YYYY ปี ค.ศ. ทุกแถว',
    rptRows.every(r => /^\d{2}\/\d{2}\/\d{4}( – \d{2}\/\d{2}\/\d{4})?$/.test(r.date)),
    rptRows.map(r => r.date).join(' · '));
  chk('สถานะตรงกันทุกคำขอ',
    dashRows.every((d, i) => d.status === rptRows[i].status),
    rptRows.map(r => r.status).join(' · '));
  chk('สรุป: ข้อมูลตรงกันทุกฟิลด์', ok, '');

  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
}

run().catch(e => { console.error(e); process.exit(1); });
