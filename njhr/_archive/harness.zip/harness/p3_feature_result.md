
## EMPLOYEES

| Test Case | ผล | หลักฐาน |
|---|---|---|
| EMP · Dashboard ไม่โหลด P3 Module | PASS | js=/config.js,/asset-manifest.js,/runtime/namespace.js,/runtime/core.js,/views/dashboard.js |
| EMP · เปิด Employees List | PASS | แถว=20 viewHost=59475B |
| EMP · โหลด views/employees/list.js | PASS | js=/runtime/shared/emp-meta.js,/runtime/shared/hr-meta.js,/views/employees/list.js |
| EMP · ไม่โหลด Import / Export / Form / Documents ตอนเปิดรายการ | PASS | moduleState={"dashboard":"loaded","employees":"loaded","shared-emp-meta":"loaded","shared-hr-meta":"loaded"} |
| EMP · ไม่โหลด Compatibility Bundle | PASS | compat=not_loaded |
| EMP · ไม่โหลด Leave / OT / Attendance | PASS | ไม่พบใน request |
| EMP · Search ทำงาน | PASS | แถวหลังค้นหา=1 |
| EMP · Filter สถานะทำงาน | PASS | แถว=20 |
| EMP · หัวตารางสำหรับ Sort ยังอยู่ | PASS | th[data-sort]=0 |
| EMP · กดเพิ่มพนักงาน จึงโหลด views/employees/form.js | PASS | moduleState.employees-form=loaded |
| EMP · กดเพิ่มพนักงาน เปิดฟอร์มได้ | PASS | modal="เพิ่มพนักงาน" |
| EMP · Validation Error แสดงและไม่ปิดฟอร์ม | PASS | ข้อความ="กรุณาระบุรหัสพนักงาน" |
| EMP · กดแก้ไขพนักงาน เปิดฟอร์มได้ | PASS | modal="แก้ไขข้อมูลพนักงาน" |
| EMP · กดเอกสารแนบ จึงโหลด views/employees/documents.js | PASS | moduleState.employees-documents=loaded |
| EMP · เปิดเอกสารแนบพนักงานได้ | PASS | modal="แฟ้มเอกสารพนักงาน" |
| EMP · กด Import จึงโหลด views/employees/import.js | PASS | moduleState.employees-import=loaded |
| EMP · กด Import เปิดฟอร์มนำเข้าได้ | PASS | modal="นำเข้าพนักงานจาก Excel" |
| EMP · Import ไม่ลาก Export ตามมา | PASS | export=not_loaded |
| EMP · Import ไฟล์ถูก / ไฟล์ผิด / บาง Field ผิด | NOT TESTED | ต้องอัปโหลดไฟล์ .xlsx จริงผ่าน File API — ยังไม่ได้ทำในรอบนี้ |
| EMP · Upload / Download / Delete เอกสารแนบ | NOT TESTED | ต้องใช้ Storage และ Signed URL จริง — ทดสอบด้วย fixture ไม่ครอบคลุม |
| EMP · Save Success / Save Error กับข้อมูลจริง | NOT TESTED | ห้ามเขียนข้อมูล Production — fixture ตอบ 200 เสมอ |
| EMP · กด Export จึงโหลด views/employees/export.js | PASS | moduleState.employees-export=loaded |
| EMP · Export ดึง shared/report-export.js มาด้วย | PASS | โหลดแล้ว |
| EMP · Back กลับหน้าพนักงาน | PASS | hash=#/employees |
| EMP · Forward | PASS | hash=#/dashboard |
| EMP · Deep Link + Refresh | PASS | แถว=20 |
| EMP · กดเมนูรัวแล้วลงหน้าถูกต้อง | PASS | viewHost=59514 |
| EMP · ไม่มี unhandled error ตลอดชุด Employees | PASS | ไม่มี |
| EMP · Logout ระหว่าง Module โหลด → ไม่ render | PASS | กลับหน้า Login |
| EMP · ไม่มี unhandled error | PASS | ไม่มี |
| EMP · USER ไม่มีสิทธิ์ → Access Denied เดิม | PASS | hash=#/dashboard |
| EMP · USER ไม่มีสิทธิ์ → ไม่โหลด Module | PASS | js ใหม่=ไม่มี |
| EMP · Module โหลดไม่สำเร็จ → Error State + ปุ่มลองใหม่ | PASS | state=failed |
| EMP · กดลองใหม่แล้วโหลดสำเร็จ | PASS | state=loaded แถว=20 |

## ATTENDANCE

| Test Case | ผล | หลักฐาน |
|---|---|---|
| ATT · เปิดหน้าลงเวลา | PASS | viewHost=3858B |
| ATT · โหลด views/attendance/main.js | PASS | js=/runtime/shared/report-export.js,/runtime/shared/requests.js,/views/attendance/main.js |
| ATT · ไม่โหลด Attendance Report | PASS | report=not_loaded |
| ATT · ไม่โหลด Compatibility / Employees / Leave / OT | PASS | moduleState=dashboard,attendance,shared-report,shared-requests |
| ATT · เปลี่ยนวันที่/เดือน | NOT TESTED | ไม่พบ #att-from บนหน้า (โครงสร้างจริงต่างจากที่ Prompt สมมติ) |
| ATT · เปลี่ยนแผนก | NOT TESTED | ไม่พบ #att-dept บนหน้า |
| ATT · Check-in / Check-out จริง | NOT TESTED | ห้ามสร้างเวลาจริง — ไม่มี Test Account บน Production |
| ATT · ไม่โหลด Correction ตอนเปิดหน้าลงเวลา | PASS | moduleState=not_loaded |
| ATT · กดแก้ไขเวลา จึงโหลด views/attendance/correction.js | PASS | moduleState.attendance-correction=loaded |
| ATT · เปิดฟอร์มแก้ไขเวลาได้ | PASS | modal="🕒 ลงชื่อย้อนหลัง" |
| ATT · เปิดรายงานลงเวลา (#/reports) | PASS | viewHost=2614B |
| ATT · โหลด views/attendance/report.js ตอนเปิดรายงานเท่านั้น | PASS | state=loaded |
| ATT · รายงานไม่ลาก Compatibility มาด้วย | PASS | compat=not_loaded |
| ATT · Back จากรายงาน | PASS | hash=#/attendance |
| ATT · Forward กลับรายงาน | PASS | hash=#/reports |
| ATT · Deep Link รายงาน | PASS | viewHost=2614 |
| ATT · ไม่มี unhandled error ตลอดชุด Attendance | PASS | ไม่มี |
| ATT · RPC ล้มเหลว → หน้าไม่พัง ไม่มีจอขาว | PASS | viewHost=3355 pageerror=0 |

## LEAVE

| Test Case | ผล | หลักฐาน |
|---|---|---|
| LEAVE · เปิดหน้าลางาน | PASS | viewHost=1923B |
| LEAVE · โหลด views/leave/main.js | PASS | js=/runtime/shared/requests.js,/runtime/shared/hr-meta.js,/runtime/shared/leave-meta.js,/views/leave/main.js |
| LEAVE · ไม่โหลด OT / Employees Import / Compatibility | PASS | moduleState=dashboard,requests-leave,shared-requests,shared-hr-meta,shared-leave-meta |
| LEAVE · แสดงสิทธิ์ลา | PASS | ข้อความ="ลาป่วย 0 วัน สิทธิ์ 30 วัน/ปี ลากิจ 0 วัน สิทธิ์ 6 วัน/ปี ลา" |
| LEAVE · ไม่โหลด Leave Form / Detail ตอนเปิดหน้า | PASS | moduleState={"dashboard":"loaded","requests-leave":"loaded","shared-requests":"loaded","shared-hr-meta":"loaded","shared-leave-meta":"loaded"} |
| LEAVE · กดขอลา จึงโหลด views/leave/form.js | PASS | moduleState.leave-form=loaded |
| LEAVE · เปิดฟอร์มขอลาได้ | PASS | modal="ขอลางาน" |
| LEAVE · ฟอร์มมีช่องประเภทลา/ช่วงวันที่/เต็มวัน-ครึ่งวัน/เหตุผล/ไฟล์แนบครบ | PASS | {"type":true,"start":true,"end":true,"mode":true,"note":true,"file":true,"send":true,"err":true} |
| LEAVE · Validation ทำงาน (กดส่งโดยไม่กรอกเหตุผล) | PASS | ข้อความ="กรุณาระบุเหตุผลการลา" |
| LEAVE · ตัวเลือกเต็มวัน/ครึ่งวัน/รายชั่วโมง คงเดิม | PASS | เต็มวัน ครึ่งวันเช้า ครึ่งวันบ่าย รายชั่วโมง |
| LEAVE · เปิดรายละเอียดคำขอ | NOT TESTED | ไม่พบแถวคำขอใน fixture (ประวัติว่าง) |
| LEAVE · ประวัติลาและ OT (#/req-history) เปิดได้ | PASS | viewHost=814 |
| LEAVE · #/req-history ใช้ chunk เดียวกัน ไม่โหลดเพิ่ม | PASS | ไม่มี compat |
| LEAVE · หน้ารวมคำขอ (#/requests) เปิดได้ | PASS | hash=#/requests |
| LEAVE · Submit Success / Submit Error กับข้อมูลจริง | NOT TESTED | ห้ามสร้างคำขอจริงบน Production |
| LEAVE · ไม่มี unhandled error ตลอดชุด Leave | PASS | ไม่มี |

## OT

| Test Case | ผล | หลักฐาน |
|---|---|---|
| OT · เปิดหน้า OT | PASS | viewHost=1003B |
| OT · โหลด views/ot/main.js | PASS | js=/runtime/shared/requests.js,/views/ot/main.js |
| OT · ไม่โหลด Employees Import / Attendance Report / Compatibility | PASS | moduleState=dashboard,ot,shared-requests |
| OT · ไม่โหลด OT Form ตอนเปิดหน้า | PASS | moduleState={"dashboard":"loaded","ot":"loaded","shared-requests":"loaded"} |
| OT · กดขอ OT จึงโหลด views/ot/form.js | PASS | moduleState.ot-form=loaded |
| OT · เปิดฟอร์มขอ OT ได้ | PASS | modal="ขอ OT" |
| OT · ฟอร์มมีวันที่/เวลาเริ่ม-สิ้นสุด/ชั่วโมง/ปุ่มเพิ่มรายการงานครบ | PASS | {"date":true,"start":true,"end":true,"hours":true,"addJob":true,"rows":true,"send":true,"err":true} |
| OT · เพิ่มรายการงานได้ | PASS | รายการ 0 -> 1 |
| OT · Validation เวลา/ข้อมูลไม่ครบทำงาน | PASS | ข้อความ="กรุณากรอก JOB · ประเภทงาน ให้ครบทุกรายการ" |
| OT · Submit Success / Submit Error กับข้อมูลจริง | NOT TESTED | ห้ามสร้างคำขอจริงบน Production |
| OT · กดเมนูรัวแล้วลงหน้าถูกต้อง | PASS | viewHost=1003 |
| OT · Deep Link + Refresh | PASS | viewHost=1003 |
| OT · ไม่มี unhandled error ตลอดชุด OT | PASS | ไม่มี |

## LISTENER + RESPONSIVE

| Test Case | ผล | หลักฐาน |
|---|---|---|
| P3 · Listener ไม่เพิ่มหลังวน 5 หน้า × 3 รอบ + Back/Forward + Logout/Login | PASS | {"window:load":1,"window:hashchange":1,"window:keydown":1,"window:resize":1} |
| P3 · Responsive 360x740 — 5 หน้าใหม่ไม่ล้นจอ | PASS | ทั้ง 5 หน้าไม่ล้น |
| P3 · Responsive 768x1024 — 5 หน้าใหม่ไม่ล้นจอ | PASS | ทั้ง 5 หน้าไม่ล้น |
| P3 · Responsive 1440x900 — 5 หน้าใหม่ไม่ล้นจอ | PASS | ทั้ง 5 หน้าไม่ล้น |
| P3 · iPhone Safari (WebKit จริง) | NOT TESTED | ยังไม่ได้ทดสอบบนอุปกรณ์ iPhone Safari จริง — สภาพแวดล้อมนี้มีเฉพาะ Chromium |

**PASS 76 · FAIL 0 · NOT TESTED 10**
