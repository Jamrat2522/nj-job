/* dash_leave_test.js — ตรวจการ์ด "คำขอลาล่าสุด" บน Dashboard ผู้ดูแล
   โหลด chunk ที่ build แล้วจริง (views/dashboard.js) ลง jsdom
   ตรวจ 5 ข้อตามที่กำหนด:
     1. แสดงคำขอลาล่าสุดจาก Supabase ได้
     2. ข้อมูลตรงกับที่ RPC ส่งมา (ชุดเดียวกับหน้ารายการลางาน)
     3. เรนเดอร์ใหม่ทุกครั้ง (รีเฟรช/เครื่องอื่น = ยิง RPC ใหม่ ไม่ใช้ localStorage)
     4. RPC Error → ห้ามขึ้น "ยังไม่มีคำขอลา"
     5. ปุ่ม "ดูทั้งหมด" ยังชี้ปลายทางเดิม
   ใช้: node harness/dash_leave_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(60) + (d || '')); }
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
  .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const tick = ms => new Promise(r => setTimeout(r, ms || 30));

/* แถวจาก njhr_rpt_leave_list — จงใจสลับลำดับ created_at เพื่อพิสูจน์การเรียงใหม่→เก่า */
const RPC_ROWS = [
  { req_id: 'l2', request_no: '260803-0002', prefix: 'นางสาว', full_name: 'สมหญิง รักงาน',
    department: 'บัญชี', leave_type: 'PERSONAL', start_date: '2026-08-03', end_date: '2026-08-04',
    mode_txt: 'หลายวัน', total_days: 2, status: 'APPROVED', ui_status: 'APPROVED',
    created_at: '2026-08-01T03:00:00Z' },
  { req_id: 'l1', request_no: '260810-0007', prefix: 'นาย', full_name: 'สมชาย ใจดี',
    department: 'ขนส่ง', leave_type: 'SICK', start_date: '2026-08-10', end_date: '2026-08-10',
    mode_txt: 'เต็มวัน', total_days: 1, status: 'PENDING', ui_status: 'PENDING',
    created_at: '2026-08-09T03:00:00Z' },
  { req_id: 'l3', request_no: '260701-0002', prefix: 'นาย', full_name: 'มานะ อดทน',
    department: 'ขนส่ง', leave_type: 'VACATION', start_date: '2026-07-01', end_date: '2026-07-05',
    mode_txt: 'หลายวัน', total_days: 5, status: 'CANCELLED', ui_status: 'CANCELLED',
    created_at: '2026-06-30T03:00:00Z' },
  { req_id: 'l4', request_no: '260620-0001', prefix: '', full_name: 'ปิติ ชอบงาน',
    department: 'คลัง', leave_type: 'OTHER', start_date: '2026-06-20', end_date: '2026-06-20',
    mode_txt: 'เต็มวัน', total_days: 1, status: 'REJECTED', ui_status: 'REJECTED',
    created_at: '2026-06-19T03:00:00Z' },
  { req_id: 'l5', request_no: '260610-0003', prefix: 'นาง', full_name: 'ศรี ขยัน',
    department: 'บัญชี', leave_type: 'SICK', start_date: '2026-06-10', end_date: '2026-06-10',
    mode_txt: 'เต็มวัน', total_days: 1, status: 'COMPLETED', ui_status: 'COMPLETED',
    created_at: '2026-06-09T03:00:00Z' },
  { req_id: 'l6', request_no: '260601-0001', prefix: 'นาย', full_name: 'เก่า สุด',
    department: 'คลัง', leave_type: 'PERSONAL', start_date: '2026-06-01', end_date: '2026-06-01',
    mode_txt: 'เต็มวัน', total_days: 1, status: 'APPROVED', ui_status: 'APPROVED',
    created_at: '2026-05-31T03:00:00Z' }
];

function env(opt) {
  opt = opt || {};
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div></body></html>');
  const win = dom.window;
  const calls = [];
  const errs = [];
  /* db.* ว่างเปล่าเหมือน Production จริง — ถ้าการ์ดยังอ่าน localStorage จะขึ้น "ยังไม่มีคำขอลา" */
  const db = { employees: [], attendance: [], leaves: [], ots: [], corrections: [], payroll: [],
    announcements: [], holidays: [], notifications: [], leaveTypes: [], departments: [],
    users: [], balances: [], shifts: [], audit: [], settings: {} };
  const NJHR = {
    state: { currentRoute: '#/dashboard', docPending: 0 },
    router: { navId: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    features: {}, views: { register: () => {} }, compat: { scope: {} }
  };
  Object.assign(NJHR.compat.scope, {
    icon: () => '<span class="ic"></span>', esc, debounce: f => f,
    avatarHTML: n => '<span class="avatar" data-n="' + esc(n) + '"></span>',
    emptyState: m => '<div class="empty"><p>' + m + '</p></div>',
    fmtDate: d => String(d || ''), todayISO: () => '2026-08-11',
    statusBadge: s => '<span class="badge">' + s + '</span>',
    currentUser: () => ({ id: 'u1', username: 'admin', role: 'SUPER_ADMIN', empId: 'e1' }),
    currentEmp: () => ({ id: 'e1', firstName: 'จำรัส', lastName: 'ผาเทพ', shift: '08:30-17:30' }),
    emp: () => null, empName: () => '—', dept: () => '—', leaveType: () => ({ name: '' }),
    db: db, pendingCount: () => 0, remainDays: () => 0,
    money: String, maskAcc: String, fmtMonthYear: (m, y) => m + '/' + y,
    TH_MONTHS: ['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'],
    TH_DAYS: ['อา','จ','อ','พ','พฤ','ศ','ส'], pad: n => (n < 10 ? '0' + n : '' + n),
    isHoliday: () => false, holName: () => '', startLiveClock: () => {},
    nav: () => {}, toast: () => {}, audit: () => {},
    sbReady: () => opt.sbReady !== false,
    sbToken: () => (opt.noToken ? '' : 'tok'),
    sbRpcList: (fn, body) => {
      calls.push({ fn, body });
      if (fn === 'njhr_rpt_leave_list') {
        if (opt.rpcFail) return Promise.reject(new Error('permission denied for function njhr_rpt_leave_list'));
        return Promise.resolve(opt.rows === undefined ? RPC_ROWS : opt.rows);
      }
      return Promise.resolve([]);
    },
    sbRpc: () => Promise.resolve({}),
    lvType: c => ({ SICK: { name: 'ลาป่วย' }, PERSONAL: { name: 'ลากิจ' },
      VACATION: { name: 'ลาพักร้อน' }, OTHER: { name: 'ลาอื่น ๆ' } }[c] || { name: c })
  });
  win.NJHR = NJHR;
  const origErr = win.console.error;
  win.console = Object.assign({}, win.console, { error: (...a) => { errs.push(a.join(' ')); } });
  const ctx = vm.createContext(win);
  return { win, NJHR, calls, errs, db,
    run: rel => vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), ctx, { filename: rel }),
    host: () => win.document.getElementById('app'),
    doc: () => win.document };
}

function grab(E) {
  let fn = null;
  E.NJHR.views.register = (n, f) => { if (n === 'viewDashboard') fn = f; };
  return () => fn;
}

function cardOf(doc) {
  // การ์ดที่มีหัวข้อ "คำขอลาล่าสุด"
  const heads = Array.from(doc.querySelectorAll('.card-head h3'));
  const h = heads.find(x => x.textContent.trim() === 'คำขอลาล่าสุด');
  return h ? h.closest('.card') : null;
}

async function run() {
  /* ================= 1–2. แสดงข้อมูลจริงจาก Supabase ================= */
  console.log('\n== ปกติ: RPC คืนข้อมูล 6 คำขอ ==');
  const E = env();
  const get = grab(E);
  E.run('views/dashboard.js');
  const view = get();
  chk('chunk ลงทะเบียน viewDashboard', typeof view === 'function', '');
  if (typeof view !== 'function') return finish();

  view(E.host());
  const doc = E.doc();
  const card = cardOf(doc);
  chk('มีการ์ด "คำขอลาล่าสุด"', !!card, '');
  chk('ก่อนข้อมูลกลับ ไม่ขึ้น "ยังไม่มีคำขอลา"',
    card && card.textContent.indexOf('ยังไม่มีคำขอลา') < 0,
    card ? card.querySelector('#dash-lv').textContent.trim() : '');

  await tick(40);
  const c2 = cardOf(doc);
  chk('เรียก RPC njhr_rpt_leave_list', E.calls.some(x => x.fn === 'njhr_rpt_leave_list'), '');
  const body = E.calls.find(x => x.fn === 'njhr_rpt_leave_list').body;
  chk('ส่งตัวกรองเป็น null ทั้งหมด (ไม่จำกัดช่วงวันที่/แผนก)',
    body.p_from === null && body.p_to === null && body.p_dept === null && body.p_q === null,
    JSON.stringify(body));
  chk('ส่ง token ของผู้ล็อกอิน (สิทธิ์ตรวจฝั่งเซิร์ฟเวอร์)', body.p_token === 'tok', '');

  const rows = Array.from(c2.querySelectorAll('.list .list-row'));
  chk('แสดง 5 รายการ (ตัดจาก 6)', rows.length === 5, rows.length + '/5');

  const names = rows.map(r => r.querySelector('b').textContent.trim());
  chk('เรียงใหม่→เก่าตาม created_at',
    JSON.stringify(names) === JSON.stringify(
      ['นายสมชาย ใจดี', 'นางสาวสมหญิง รักงาน', 'นายมานะ อดทน', 'ปิติ ชอบงาน', 'นางศรี ขยัน']),
    names.join(' | '));

  const s0 = rows[0].querySelector('small').textContent.trim();
  chk('บรรทัดรอง = ประเภทการลา + วันที่ (วันเดียว)', s0 === 'ลาป่วย · 2026-08-10', s0);
  const s1 = rows[1].querySelector('small').textContent.trim();
  chk('ช่วงหลายวันแสดงทั้งช่วง', s1 === 'ลากิจ · 2026-08-03 – 2026-08-04', s1);
  chk('สถานะมาจาก ui_status ของ RPC',
    rows[0].querySelector('.badge').textContent.trim() === 'PENDING',
    rows[0].querySelector('.badge').textContent.trim());
  chk('รูป/ตัวย่อใช้ชื่อจาก RPC',
    rows[0].querySelector('.avatar').getAttribute('data-n') === 'นายสมชาย ใจดี', '');
  chk('ไม่มีคำนำหน้าว่างแล้วเกิดช่องว่างนำหน้า',
    names[3] === 'ปิติ ชอบงาน', names[3]);

  /* ================= 5. ปุ่มดูทั้งหมด ================= */
  const link = c2.querySelector('.card-head a.link');
  chk('ปุ่ม "ดูทั้งหมด" ยังชี้ปลายทางเดิม #/approvals',
    link && link.getAttribute('href') === '#/approvals' && link.textContent.trim() === 'ดูทั้งหมด',
    link ? link.getAttribute('href') : 'ไม่พบ');

  /* ================= 3. ไม่พึ่ง localStorage ================= */
  chk('db.leaves ว่าง แต่ยังแสดงข้อมูลได้ (ไม่ใช้ localStorage)',
    E.db.leaves.length === 0 && rows.length === 5, 'db.leaves=' + E.db.leaves.length);
  const src = fs.readFileSync(path.join(ROOT, 'views/dashboard.js'), 'utf8');
  const seg = src.slice(src.indexOf('dash-lv') - 3000, src.indexOf('dash-lv') + 2000);
  chk('โค้ดการ์ดนี้ไม่อ้าง db.leaves', seg.indexOf('db.leaves') < 0, '');

  // เรนเดอร์ซ้ำ (เท่ากับรีเฟรช/เปิดอีกเครื่อง) → ต้องยิง RPC ใหม่ทุกครั้ง
  const before = E.calls.filter(x => x.fn === 'njhr_rpt_leave_list').length;
  view(E.host());
  await tick(40);
  const after = E.calls.filter(x => x.fn === 'njhr_rpt_leave_list').length;
  chk('เรนเดอร์ใหม่ = ยิง RPC ใหม่ (ไม่แคชค้าง)', after === before + 1, before + ' → ' + after);
  chk('เรนเดอร์ใหม่ยังแสดงครบ 5 รายการ',
    cardOf(E.doc()).querySelectorAll('.list .list-row').length === 5, '');

  /* ================= 4. RPC Error ================= */
  console.log('\n== RPC Error ==');
  const E2 = env({ rpcFail: true });
  const g2 = grab(E2);
  E2.run('views/dashboard.js');
  g2()(E2.host());
  await tick(40);
  const cErr = cardOf(E2.doc());
  const txt = cErr.querySelector('#dash-lv').textContent.trim();
  chk('Error · ไม่ขึ้น "ยังไม่มีคำขอลา"', txt.indexOf('ยังไม่มีคำขอลา') < 0, txt);
  chk('Error · แสดงข้อความผิดพลาดใน .form-error',
    !!cErr.querySelector('#dash-lv .form-error'), txt);
  chk('Error · ข้อความมีสาเหตุจริงจากเซิร์ฟเวอร์',
    txt.indexOf('njhr_rpt_leave_list') >= 0, txt);
  chk('Error · role="alert" เพื่อให้ผู้ใช้รับรู้',
    cErr.querySelector('#dash-lv .form-error').getAttribute('role') === 'alert', '');
  chk('Error · บันทึกสาเหตุลง console.error',
    E2.errs.some(x => x.indexOf('njhr_rpt_leave_list') >= 0), E2.errs[0] || 'ไม่มี log');

  /* ================= ไม่มี token / ยังไม่เชื่อม Supabase ================= */
  console.log('\n== ยังไม่เชื่อมต่อ Supabase ==');
  const E3 = env({ noToken: true });
  const g3 = grab(E3);
  E3.run('views/dashboard.js');
  g3()(E3.host());
  await tick(40);
  const t3 = cardOf(E3.doc()).querySelector('#dash-lv').textContent.trim();
  chk('ไม่มี token · ไม่ขึ้น "ยังไม่มีคำขอลา"', t3.indexOf('ยังไม่มีคำขอลา') < 0, t3);
  chk('ไม่มี token · ไม่ยิง RPC', !E3.calls.some(x => x.fn === 'njhr_rpt_leave_list'), '');

  /* ================= Empty State จริง ================= */
  console.log('\n== RPC คืนรายการว่างจริง ==');
  const E4 = env({ rows: [] });
  const g4 = grab(E4);
  E4.run('views/dashboard.js');
  g4()(E4.host());
  await tick(40);
  const t4 = cardOf(E4.doc()).querySelector('#dash-lv').textContent.trim();
  chk('รายการว่างจริง → แสดง "ยังไม่มีคำขอลา"', t4.indexOf('ยังไม่มีคำขอลา') >= 0, t4);
  chk('รายการว่างจริง → ไม่แสดง .form-error',
    !cardOf(E4.doc()).querySelector('#dash-lv .form-error'), '');

  finish();
}

function finish() {
  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
}

run().catch(e => { console.error(e); process.exit(1); });
