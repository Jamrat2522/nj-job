/* lv_bal_row_test.js — ตรวจการ์ดสรุปสิทธิ์ลางานบนหน้า "ลางาน"
     · Desktop = 7 ใบแถวเดียว เต็มความกว้าง
     · การ์ดกระชับ (min-height 90px · padding 14–16px)
     · ลำดับข้อความในการ์ด: ชื่อ → ตัวเลข+วัน → ลาแล้ว → คงเหลือ (เฉพาะพักร้อน)
     · จอแคบย่อ font/gap ก่อน แล้วค่อยเป็น 4+3 ไม่มี Horizontal Scroll
     · ไม่แตะ JS · ตาราง · Mobile
   ใช้: node harness/lv_bal_row_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(60) + (d || '')); }

const mcss = fs.readFileSync(path.join(ROOT, 'mobile.css'), 'utf8');
const scss = fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8');
const min = mcss.replace(/\s+/g, '');
const sMin = scss.replace(/\s+/g, '');
const lvJs = fs.readFileSync(path.join(ROOT, 'views/leave/main.js'), 'utf8');

function block(prefix) {
  let i = -1;
  while ((i = min.indexOf(prefix, i + 1)) >= 0) {
    let d = 1, j = i + prefix.length;
    for (; j < min.length && d > 0; j++) {
      if (min[j] === '{') d++;
      else if (min[j] === '}') d--;
    }
    const b = min.slice(i + prefix.length, j - 1);
    if (b.indexOf('#lv-bal') >= 0) return b;
  }
  return '';
}
const DESK = block('@media(min-width:1024px){');
const T1400 = block('@media(min-width:1281px)and(max-width:1400px){');
const T1280 = block('@media(min-width:1200px)and(max-width:1280px){');
const T1199 = block('@media(min-width:1024px)and(max-width:1199px){');

/* ================= 1. 7 ใบแถวเดียว ================= */
console.log('\n== Desktop: 7 ใบแถวเดียว ==');
chk('มีบล็อก Desktop ของ #lv-bal', DESK.length > 0, DESK.length + ' อักขระ');
chk('Grid 7 ช่องเท่ากัน',
  DESK.indexOf('grid-template-columns:repeat(7,minmax(0,1fr))') >= 0, '');
chk('ระยะห่าง 10px', /#lv-bal\.bal-cards\{[^}]*gap:10px/.test(DESK), '');
chk('การ์ดสูงเท่ากันทุกใบ (align-items: stretch)',
  /#lv-bal\.bal-cards\{[^}]*align-items:stretch/.test(DESK), '');
chk('ไม่เหลือ 3 คอลัมน์แบบเดิม',
  DESK.indexOf('grid-template-columns:repeat(3,1fr)') < 0, '');
chk('การ์ดไม่ล้นช่อง (min-width: 0)', /#lv-bal\.bal-card\{[^}]*min-width:0/.test(DESK), '');

/* ================= 2. ขนาดการ์ด ================= */
console.log('\n== ขนาดการ์ด ==');
const mh = /#lv-bal\.bal-card\{[^}]*min-height:(\d+)px/.exec(DESK);
chk('min-height อยู่ในช่วง 90–105px', !!mh && +mh[1] >= 90 && +mh[1] <= 105,
  mh ? mh[1] + 'px' : 'ไม่มี');
/* CSS ถูก minify แล้ว ช่องว่างระหว่างค่าหายไป */
const pd = /#lv-bal\.bal-card\{[^}]*padding:(\d+)px(\d+)px/.exec(DESK);
chk('padding แนวตั้ง 14–16px', !!pd && +pd[1] >= 14 && +pd[1] <= 16,
  pd ? pd[1] + 'px ' + pd[2] + 'px' : 'ไม่มี');
chk('ไม่ตั้งความสูงตายตัวจนสูงเกิน', !/#lv-bal\.bal-card\{[^}]*[^n-]height:1[3-5]\d px/.test(DESK), '');
chk('ระยะห่างก่อน "คำขอลาของฉัน" 20–24px',
  /#lv-bal\.bal-cards\{[^}]*margin-bottom:2[0-4]px/.test(DESK),
  (/#lv-bal\.bal-cards\{[^}]*margin-bottom:(\d+)px/.exec(DESK) || [])[1] + 'px');

/* ================= 3. ข้อความในการ์ด ================= */
console.log('\n== ข้อความในการ์ด ==');
chk('ชื่อประเภทลาอยู่บนสุด (small ตัวแรก)',
  DESK.indexOf('#lv-bal.bal-card>small:first-child{font-size:12') >= 0, '');
chk('ชื่อยาวไม่ล้นการ์ด', /small:first-child\{[^}]*overflow-wrap:anywhere/.test(DESK), '');
const bf = /#lv-bal\.bal-cardb\{font-size:(\d+)px/.exec(DESK);
chk('ตัวเลขเด่นที่สุดในการ์ด (19–22px)', !!bf && +bf[1] >= 19 && +bf[1] <= 22,
  bf ? bf[1] + 'px' : 'ไม่มี');
const bi = /#lv-bal\.bal-cardbi\{font-size:(\d+)px/.exec(DESK);
chk('คำว่า "วัน" เล็กกว่าตัวเลข', !!bi && !!bf && +bi[1] < +bf[1],
  bi ? bi[1] + 'px < ' + bf[1] + 'px' : '');
const sm = /#lv-bal\.bal-card>small\.muted\{font-size:([\d.]+)px/.exec(DESK);
chk('"ลาแล้ว" เล็กกว่าชื่อประเภท', !!sm && parseFloat(sm[1]) <= 12,
  sm ? sm[1] + 'px' : '');
chk('"คงเหลือ" มีขนาดกำหนดไว้', /\.bal-rem\{font-size:12px/.test(DESK), '');
chk('สีเขียวของ "คงเหลือ" ยังมาจาก styles.css เดิม (ไม่แก้สี)',
  sMin.indexOf('.bal-card.bal-rem{display:block') >= 0 &&
  sMin.indexOf('color:var(--green)') >= 0 &&
  DESK.indexOf('color:') < 0, '');
/* ลำดับใน DOM */
const paint = lvJs.slice(lvJs.indexOf('lvRenderBal'), lvJs.indexOf('lvRenderBal') + 900);
chk('ลำดับใน DOM: ชื่อ → ตัวเลข → ลาแล้ว → คงเหลือ',
  paint.indexOf('bal-card') < paint.indexOf('ลาแล้ว') &&
  paint.indexOf('ลาแล้ว') < paint.indexOf('bal-rem'), '');

/* ================= 4. ความกว้างพอจริงไหม ================= */
console.log('\n== งบความกว้าง ==');
function fit(w, cols, gap, padX, font) {
  const frame = w - 270 - 48;                       // Sidebar 270 · padding 48
  const card = (frame - gap * (cols - 1)) / cols;
  return { card: Math.floor(card), inner: Math.floor(card - padX * 2) };
}
/* ข้อความที่ยาวที่สุดในการ์ด = "คงเหลือ 6 วัน" (13 ตัว) */
const longest = 'คงเหลือ 6 วัน'.length;
const w12 = f => Math.ceil(longest * f * 0.62);
[[1920, 7, 10, 13, 12], [1440, 7, 10, 13, 12], [1366, 7, 10, 13, 12],
 [1280, 7, 7, 9, 11.5], [1199, 4, 8, 11, 12], [1024, 4, 8, 11, 12]].forEach(function (x) {
  const r = fit(x[0], x[1], x[2], x[3], x[4]);
  const need = w12(x[4]);
  console.log('        ' + (x[0] + 'px · ' + x[1] + ' ช่อง').padEnd(18) +
    'การ์ด ' + r.card + 'px · ที่ว่างข้อความ ' + r.inner + 'px · ต้องการ ' + need + 'px');
  chk('ที่ ' + x[0] + 'px · ' + x[1] + ' ช่อง ข้อความไม่ล้น', r.inner >= need,
    r.inner + ' ≥ ' + need);
});

/* ================= 5. ลำดับการย่อ ================= */
console.log('\n== ลำดับการย่อ ==');
chk('1281–1400px ย่อ gap และ padding ก่อน (ยัง 7 ใบ)',
  T1400.length > 0 && T1400.indexOf('repeat(4') < 0 && T1400.indexOf('gap:8px') >= 0, '');
chk('1200–1280px ย่ออีกขั้น (ยัง 7 ใบ)',
  T1280.length > 0 && T1280.indexOf('repeat(4') < 0, '');
chk('1024–1199px เปลี่ยนเป็น 4 + 3 (พื้นที่ไม่พอจริง)',
  T1199.indexOf('grid-template-columns:repeat(4,minmax(0,1fr))') >= 0, '');
chk('ทุกระดับไม่ซ่อนการ์ดใด',
  [T1400, T1280, T1199].every(function (b) { return b.indexOf('display:none') < 0; }), '');

/* ================= 6. ไม่แตะ JS / ตาราง / มือถือ ================= */
console.log('\n== ไม่กระทบส่วนอื่น ==');
chk('ไม่แก้ JS ของหน้าลางาน (ยังมี lvRenderBal เดิม)', lvJs.indexOf('lvRenderBal') >= 0, '');
chk('ยังอ่านค่าจาก lvBal เดิม', lvJs.indexOf('lvBal') >= 0, '');
chk('ยังใช้ lvUsedDays / lvRemainDays เดิม',
  lvJs.indexOf('lvUsedDays') >= 0 && lvJs.indexOf('lvRemainDays') >= 0, '');
chk('ไม่แตะตารางคำขอลา (.lvt-lv ยังอยู่)', lvJs.indexOf('lvt lvt-lv') >= 0, '');
chk('ปุ่มขอลางานยังอยู่', lvJs.indexOf('lv-new') >= 0, '');
chk('ตัวกรองสถานะยังอยู่', lvJs.indexOf('lv-filter') >= 0, '');
chk('การ์ดยังเป็น only-desktop (มือถือใช้ทางของตัวเอง)',
  lvJs.indexOf('bal-cards only-desktop') >= 0, '');
chk('กฎมือถือ .bal-cards 2 คอลัมน์ ยังอยู่ใน styles.css',
  sMin.indexOf('.bal-cards{grid-template-columns:repeat(2,1fr)}') >= 0, '');
chk('กฎฐาน .bal-cards 4 คอลัมน์ ยังอยู่ (ไม่แก้ของกลาง)',
  sMin.indexOf('.bal-cards{display:grid;grid-template-columns:repeat(4,1fr)') >= 0, '');
chk('กฎใหม่ทั้งหมด scope ใต้ #lv-bal',
  [DESK, T1400, T1280, T1199].every(function (b) {
    return b.split('}').filter(function (r) {
      const sel = r.split('{')[0];
      return sel.trim() && sel.indexOf('#lv-bal') < 0;
    }).length === 0;
  }), '');
chk('อยู่ใน @media min-width: 1024px เท่านั้น (มือถือไม่กระทบ)',
  min.indexOf('#lv-bal.bal-cards{display:grid;grid-template-columns:repeat(7') >
  min.indexOf('@media(min-width:1024px){'), '');

console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
process.exit(FAIL ? 1 : 0);
