/* leave_balance_test.js — ตรวจกติกาแสดงยอดวันลาในหน้า Leave
     · ทุกประเภทแสดง "ลาแล้ว X วัน" จาก used เท่านั้น (pending ไม่นับ)
     · มีเพียง "ลาพักร้อน" ที่แสดง "คงเหลือ X วัน" เพิ่มได้
     · ไม่แสดง quota / "สิทธิ์ X วัน/ปี" ที่ใดเลย
     · Dropdown ประเภทการลา = ชื่ออย่างเดียว ไม่มีตัวเลข
   ตรวจทั้ง Desktop (#/leave) และ Mobile (#/requests)
   ใช้: node harness/leave_balance_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(60) + (d || '')); }
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
  .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const tick = ms => new Promise(r => setTimeout(r, ms || 50));

/* ข้อมูลจาก njhr_leave_balances — ตั้งใจให้ used ≠ remaining และมี pending
   ลาป่วย: quota 30 · used 1 · pending 2 · remaining 27
     → ต้องแสดง "ลาแล้ว 1 วัน" ไม่ใช่ 3 (pending ไม่นับ) และห้ามโผล่ 30 หรือ 27 */
const BAL = [
  { leave_type: 'SICK', quota: 30, used: 1, pending: 2, remaining: 27 },
  { leave_type: 'PERSONAL', quota: 10, used: 2, pending: 0, remaining: 8 },
  { leave_type: 'VACATION', quota: 6, used: 2, pending: 0, remaining: 4 },
  { leave_type: 'MATERNITY', quota: null, used: 0, pending: 0, remaining: null },
  { leave_type: 'ORDINATION', quota: null, used: 5, pending: 0, remaining: null },
  { leave_type: 'OTHER', quota: null, used: 0, pending: 1, remaining: null }
];
const LT = [
  { code: 'SICK', name: 'ลาป่วย', color: '#DC2626', needDoc: false },
  { code: 'PERSONAL', name: 'ลากิจ', color: '#2563EB', needDoc: false },
  { code: 'VACATION', name: 'ลาพักร้อน', color: '#059669', needDoc: false },
  { code: 'MATERNITY', name: 'ลาคลอด', color: '#DB2777', needDoc: false },
  { code: 'ORDINATION', name: 'ลาบวช', color: '#D97706', needDoc: false },
  { code: 'OTHER', name: 'ลาอื่น ๆ', color: '#64748B', needDoc: false }
];
/* ตัวเลขที่ห้ามโผล่บนหน้าจอ = quota และ remaining ของประเภทที่ไม่ใช่พักร้อน */
const FORBIDDEN = [['30', 'quota ลาป่วย'], ['27', 'remaining ลาป่วย'],
                   ['10', 'quota ลากิจ'], ['8', 'remaining ลากิจ'], ['6', 'quota พักร้อน']];

function env(route) {
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div><div id="modal-root"></div>' +
    '<div id="toasts"></div></body></html>');
  const win = dom.window;
  const lvBal = {};
  const NJHR = {
    state: { currentRoute: route, lvPending: 0, docPending: 0 },
    router: { navId: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    features: {}, views: { register: () => {} }, compat: { scope: {} }
  };
  Object.assign(NJHR.compat.scope, {
    icon: (n, c) => '<span class="ic ' + (c || '') + '" data-i="' + (n || '') + '"></span>',
    esc, debounce: f => f, avatarHTML: () => '<span class="avatar"></span>',
    emptyState: m => '<div class="empty">' + m + '</div>',
    fmtDate: d => String(d || ''), fmtDateDMY: d => String(d || ''),
    todayISO: () => '2026-08-12', nowStamp: () => '2026-08-12 12:00',
    statusBadge: s => '<span class="badge">' + s + '</span>',
    currentUser: () => ({ id: 'u1', username: 'user1', role: 'USER', empId: 'e1' }),
    currentEmp: () => ({ id: 'e1', code: '0001', title: 'นาย', firstName: 'สมชาย',
      lastName: 'ใจดี', deptId: 'd1', position: '-' }),
    emp: () => null, empName: () => 'สมชาย ใจดี', dept: () => 'ขนส่ง',
    db: { leaves: [], ots: [], corrections: [] }, saveDB: () => {}, uid: p => p + '-x',
    audit: () => {}, toast: () => {}, nav: () => {}, refreshLeavePending: () => {},
    sbReady: () => true, sbToken: () => 'tok',
    sbRpc: () => Promise.resolve({}),
    sbRpcList: fn => {
      if (fn === 'njhr_leave_balances') return Promise.resolve(BAL);
      if (fn === 'njhr_leave_list') return Promise.resolve([]);
      if (fn === 'njhr_att_correction_list') return Promise.resolve([]);
      if (fn === 'njhr_ot_list') return Promise.resolve([]);
      return Promise.resolve([]);
    },
    openModal: (t, b, f) => {
      win.document.getElementById('modal-root').innerHTML =
        '<div class="modal-head"><h3>' + t + '</h3></div><div class="modal-body">' + b +
        '</div><div class="modal-foot">' + (f || '') + '</div>';
    },
    closeModal: () => { win.document.getElementById('modal-root').innerHTML = ''; },
    confirmDialog: (t, m, o, fn) => fn(), withButtonLoading: (b, t, f) => f(),
    LEAVE_TYPES: LT, lvBal: lvBal,
    lvType: c => (LT.find(x => x.code === c) || { name: c, color: '#64748B' }),
    lvNum: v => { const n = Number(v); return isFinite(n) ? Math.round(n * 100) / 100 : 0; },
    lvCode: x => String((x && x.request_no) || (x && x.id) || x || ''),
    lvMode: () => 'FULL', lvModeTxt: m => m,
    isWeekend: () => false, isHoliday: () => false, holName: () => '',
    businessDays: () => 1, hoursDiff: () => 3,
    sbUploadLeaveFile: () => Promise.resolve({}),
    rhStatus: () => ({ k: 'PENDING', c: 'badge-warn', t: 'รออนุมัติ' }),
    showTimeline: () => {}, bindReqCardActions: () => {}, bindFileButtons: () => {},
    filePreviewOpen: () => {}, fileDownload: () => {},
    reqInfoBar: () => '<div class="ot-req-info"></div>',
    startLiveClock: () => {}, canAccess: () => true, menuHref: () => '#',
    TH_MONTHS: ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'],
    pad: n => (n < 10 ? '0' + n : '' + n)
  });
  win.NJHR = NJHR;
  const ctx = vm.createContext(win);
  return { win, NJHR, lvBal,
    run: rel => vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), ctx, { filename: rel }),
    host: () => win.document.getElementById('app'),
    doc: () => win.document };
}

function noForbidden(label, text) {
  chk(label + ' · ไม่มีข้อความ "สิทธิ์"/"วัน/ปี"',
    text.indexOf('วัน/ปี') < 0 && text.indexOf('สิทธิ์ 3') < 0 && text.indexOf('สิทธิ์ 1') < 0, '');
  /* ตรวจตัวเลขต้องห้ามแบบคำเต็ม เพื่อไม่ให้ชนกับเลขอื่นในหน้า */
  FORBIDDEN.forEach(function (f) {
    const re = new RegExp('(^|[^0-9])' + f[0] + '\\s*วัน');
    chk(label + ' · ไม่โผล่ ' + f[1] + ' (' + f[0] + ' วัน)', !re.test(text), '');
  });
}

async function run() {
  /* ================= Desktop #/leave ================= */
  console.log('\n== Desktop · หน้าลางาน (#/leave) ==');
  const E = env('#/leave');
  let viewLeave = null;
  E.NJHR.views.register = (n, f) => { if (n === 'viewLeave') viewLeave = f; };
  E.run('runtime/shared/requests.js');
  E.run('views/leave/main.js');
  chk('chunk ลงทะเบียน viewLeave', typeof viewLeave === 'function', '');
  if (typeof viewLeave === 'function') {
    viewLeave(E.host());
    await tick(80);
    const cards = Array.from(E.doc().querySelectorAll('#lv-bal .bal-card'));
    chk('แสดงการ์ดครบทุกประเภท (6 ประเภท)', cards.length === 6, cards.length + '/6');
    const byName = {};
    cards.forEach(function (c) {
      const nm = (c.querySelector('small') || {}).textContent || '';
      byName[nm.trim()] = c;
    });
    [['ลาป่วย', '1'], ['ลากิจ', '2'], ['ลาพักร้อน', '2'],
     ['ลาคลอด', '0'], ['ลาบวช', '5'], ['ลาอื่น ๆ', '0']].forEach(function (x) {
      const c = byName[x[0]];
      chk('Desktop ' + x[0] + ' · ลาแล้ว ' + x[1] + ' วัน',
        !!c && (c.querySelector('b') || {}).textContent.trim().indexOf(x[1] + ' ') === 0,
        c ? (c.querySelector('b') || {}).textContent.trim() : 'ไม่พบการ์ด');
      if (c) {
        chk('Desktop ' + x[0] + ' · มีคำว่า "ลาแล้ว"', c.textContent.indexOf('ลาแล้ว') >= 0, '');
      }
    });
    /* คงเหลือ — พักร้อนเท่านั้น */
    chk('Desktop พักร้อน · แสดง "คงเหลือ 4 วัน"',
      !!byName['ลาพักร้อน'] && byName['ลาพักร้อน'].textContent.indexOf('คงเหลือ 4 วัน') >= 0,
      byName['ลาพักร้อน'] ? byName['ลาพักร้อน'].textContent.trim() : '');
    ['ลาป่วย', 'ลากิจ', 'ลาคลอด', 'ลาบวช', 'ลาอื่น ๆ'].forEach(function (n) {
      chk('Desktop ' + n + ' · ไม่แสดง "คงเหลือ"',
        !!byName[n] && byName[n].textContent.indexOf('คงเหลือ') < 0, '');
    });
    chk('Desktop · มีเพียงการ์ดเดียวที่แสดงคงเหลือ',
      E.doc().querySelectorAll('#lv-bal .bal-rem').length === 1,
      E.doc().querySelectorAll('#lv-bal .bal-rem').length + ' ใบ');
    chk('Desktop · ไม่มีแถบสัดส่วนสิทธิ์ (.bar-track) ในการ์ดยอดลา',
      E.doc().querySelectorAll('#lv-bal .bar-track').length === 0, '');
    chk('Desktop · pending 2 วันของลาป่วย ไม่ถูกนับเป็นลาแล้ว',
      !!byName['ลาป่วย'] && byName['ลาป่วย'].textContent.indexOf('3 ') < 0, '');
    noForbidden('Desktop', E.doc().getElementById('lv-bal').textContent);
  }

  /* ================= Dropdown ประเภทการลา ================= */
  console.log('\n== Dropdown ประเภทการลา ==');
  const E2 = env('#/leave');
  E2.run('runtime/shared/requests.js');
  E2.run('views/leave/main.js');
  E2.run('views/leave/form.js');
  chk('chunk เปิดใช้งาน leaveForm',
    !!(E2.NJHR.features.leaveForm && typeof E2.NJHR.features.leaveForm.open === 'function'), '');
  if (E2.NJHR.features.leaveForm) {
    /* ต้องมี lvBal ก่อนเปิดฟอร์ม — เรียก viewLeave หนึ่งครั้งให้โหลดสิทธิ์เข้ามา */
    let vL = null;
    E2.NJHR.views.register = (n, f) => { if (n === 'viewLeave') vL = f; };
    E2.run('views/leave/main.js');
    if (vL) { vL(E2.host()); await tick(80); }
    E2.NJHR.features.leaveForm.open(E2.host());
    await tick(80);
    const sel = E2.doc().getElementById('lvf-type');
    chk('มี Dropdown ประเภทการลา', !!sel, '');
    if (sel) {
      const opts = Array.from(sel.options).map(o => o.textContent.trim());
      chk('Dropdown มีครบ 6 ประเภท', opts.length === 6, opts.length + '/6');
      chk('Dropdown แสดงชื่ออย่างเดียว',
        JSON.stringify(opts) === JSON.stringify(
          ['ลาป่วย', 'ลากิจ', 'ลาพักร้อน', 'ลาคลอด', 'ลาบวช', 'ลาอื่น ๆ']),
        opts.join(' | '));
      chk('Dropdown ไม่มีคำว่า "คงเหลือ"', opts.every(o => o.indexOf('คงเหลือ') < 0), '');
      chk('Dropdown ไม่มีคำว่า "ไม่จำกัด"', opts.every(o => o.indexOf('ไม่จำกัด') < 0), '');
      chk('Dropdown ไม่มีตัวเลขใด ๆ', opts.every(o => !/[0-9]/.test(o)), '');
      chk('Dropdown พักร้อนก็ไม่มีตัวเลขเช่นกัน',
        opts[2] === 'ลาพักร้อน', opts[2]);
    }
  }

  /* ================= Mobile #/requests ================= */
  console.log('\n== Mobile · หน้าคำขอ (#/requests) ==');
  const E3 = env('#/requests');
  let viewRequests = null;
  E3.NJHR.views.register = (n, f) => { if (n === 'viewRequests') viewRequests = f; };
  E3.run('runtime/shared/requests.js');
  E3.run('views/leave/main.js');
  chk('chunk ลงทะเบียน viewRequests', typeof viewRequests === 'function', '');
  if (typeof viewRequests === 'function') {
    viewRequests(E3.host());
    await tick(100);
    const bal = E3.doc().getElementById('req-bal');
    chk('มีการ์ดสรุปยอดลาบนมือถือ', !!bal, '');
    if (bal) {
      chk('Mobile · หัวการ์ดใช้คำว่า "ลาแล้ว" ไม่ใช่ "คงเหลือ"',
        bal.textContent.indexOf('ลาแล้ว') >= 0, bal.querySelector('.req-mb-bal-h').textContent.trim());
      const items = Array.from(bal.querySelectorAll('.req-bi'));
      chk('Mobile · มี 3 การ์ด (ป่วย/กิจ/พักร้อน)', items.length === 3, items.length + '/3');
      const val = i => ((items[i].querySelector('.req-bi-v b') || {}).textContent || '').trim();
      chk('Mobile ลาป่วย · ลาแล้ว 1 วัน (ไม่ใช่ 3)', val(0) === '1', val(0));
      chk('Mobile ลากิจ · ลาแล้ว 2 วัน', val(1) === '2', val(1));
      chk('Mobile พักร้อน · ลาแล้ว 2 วัน', val(2) === '2', val(2));
      chk('Mobile พักร้อน · แสดง "คงเหลือ 4 วัน"',
        items[2].textContent.indexOf('คงเหลือ 4 วัน') >= 0, items[2].textContent.trim());
      chk('Mobile ลาป่วย · ไม่แสดงคงเหลือ', items[0].textContent.indexOf('คงเหลือ') < 0, '');
      chk('Mobile ลากิจ · ไม่แสดงคงเหลือ', items[1].textContent.indexOf('คงเหลือ') < 0, '');
      chk('Mobile · มีเพียงใบเดียวที่แสดงคงเหลือ',
        bal.querySelectorAll('.req-bi-rem').length === 1,
        bal.querySelectorAll('.req-bi-rem').length + ' ใบ');
      noForbidden('Mobile', bal.textContent);
    }
  }

  /* ================= ตรวจ Source ================= */
  console.log('\n== Source ==');
  const lvSrc = fs.readFileSync(path.join(ROOT, 'views/leave/main.js'), 'utf8');
  const fmSrc = fs.readFileSync(path.join(ROOT, 'views/leave/form.js'), 'utf8');
  chk('หน้าลางานไม่แสดงข้อความ "สิทธิ์ ... วัน/ปี" แล้ว', lvSrc.indexOf('วัน/ปี') < 0, '');
  chk('Dropdown ไม่มีข้อความ "(คงเหลือ" แล้ว', fmSrc.indexOf('(คงเหลือ ') < 0 ||
    fmSrc.indexOf('วันลาคงเหลือไม่เพียงพอ') >= 0, '');
  chk('มีตัวช่วยกลาง lvUsedDays / lvRemainDays / lvIsVacation',
    ['lvUsedDays', 'lvRemainDays', 'lvIsVacation'].every(function (f) {
      return fs.readFileSync(path.join(ROOT, 'runtime/shared/requests.js'), 'utf8').indexOf(f) >= 0;
    }), '');
  /* Backend ต้องไม่ถูกแตะ */
  const sql = fs.readFileSync(path.join(ROOT, 'supabase-new/41_leave_rpc.sql'), 'utf8');
  chk('SQL njhr_leave_balances ยังคืน used/pending/remaining/quota ครบ',
    /returns table \(leave_type text, quota numeric, used numeric, pending numeric, remaining numeric\)/.test(sql), '');
  chk('SQL ยังนับ used จาก APPROVED เท่านั้น',
    sql.indexOf("when r.status='APPROVED'") >= 0, '');

  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
}

run().catch(e => { console.error(e); process.exit(1); });
