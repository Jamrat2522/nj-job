# DEPT_DROPDOWN_TEST — ผลทดสอบ Dropdown แผนกในฟอร์มพนักงาน

รัน: `node harness/dept_dropdown_test.js .`  ·  โหลด chunk ที่ build แล้วจริง (`views/employees/list.js` + `views/employees/form.js`) ลง jsdom
stub เฉพาะ `NJHR.compat.scope` ตามสัญญาเดิม · fixture แผนก 10 รายการ · **ไม่แตะข้อมูล Production**

| # | เคส | ก่อนแก้ `2d8a207c` | หลังแก้ `e6a0d165` | หลักฐาน (หลังแก้) |
|---|---|---|---|---|
| 1 | T1 · กดเพิ่มพนักงานทันทีก่อน List โหลดแผนกเสร็จ → Dropdown ครบ | FAIL | **PASS** | option=11 (— ไม่ระบุ — + 10 แผนก) |
| 2 | T1 · ตัวเลือกแรกคือ — ไม่ระบุ — | PASS | **PASS** | — ไม่ระบุ — |
| 3 | T1 · ชื่อแผนกตรงกับ SQL ทั้ง 10 รายการ | FAIL | **PASS** | ปฏิบัติการ,บัญชี,ทรัพยากรบุคคล,ขนส่ง,คลังสินค้า,จัดซื้อ,ไอที,การตลาด,ธุรการ,ความปลอดภัย |
| 4 | T2 · รอ List เสร็จแล้วกดเพิ่มพนักงาน → Dropdown ครบ | FAIL | **PASS** | option=11 |
| 5 | T2 · ใช้ cache เดิม ไม่ยิง njhr_emp_departments ซ้ำ | PASS | **PASS** | ก่อนเปิดฟอร์ม=1 หลังเปิดฟอร์ม=1 |
| 6 | T3 · กดแก้ไขโดยไม่ผ่านหน้ารายชื่อ → Dropdown ครบ | FAIL | **PASS** | option=11 |
| 7 | T4 · เลือกแผนกเดิมอัตโนมัติด้วย department_id | FAIL | **PASS** | ขนส่ง |
| 8 | T4 · โหลดพร้อมกัน njhr_emp_get + njhr_emp_departments | FAIL | **PASS** | calls=njhr_emp_get,njhr_emp_departments |
| 9 | T5 · ไม่มี department_id → fallback เทียบ department_name | FAIL | **PASS** | ไอที |
| 10 | T6 · พนักงานไม่มีแผนก → ไม่มีแผนกใดถูกเลือก (เหลือ — ไม่ระบุ —) | FAIL | **PASS** | option=11 selected=0 |
| 11 | T7 · แผนกเดิมไม่มีในระบบแล้ว → ยังเตือนเหมือนเดิม | PASS | **PASS** | มีข้อความเตือน |
| 12 | T8 · โหลดแผนกไม่สำเร็จ → ไม่เปิดฟอร์มว่าง | FAIL | **PASS** | ไม่เปิดฟอร์ม |
| 13 | T8 · แจ้งข้อความชัดเจน + เป็น error | FAIL | **PASS** | โหลดรายชื่อแผนกไม่สำเร็จ กรุณาลองใหม่ |
| 14 | T9 · แก้ไข + โหลดแผนกไม่สำเร็จ → ไม่เปิดฟอร์ม | FAIL | **PASS** | โหลดรายชื่อแผนกไม่สำเร็จ กรุณาลองใหม่ |
| 15 | T10 · เปิดฟอร์ม 3 ครั้ง → ยิง njhr_emp_departments แค่ครั้งเดียว | FAIL | **PASS** | เรียก 1 ครั้ง |
| 16 | T10 · ครั้งที่ 3 ยังได้ Dropdown ครบ | FAIL | **PASS** | option=11 |
| 17 | T11 · ตัวกรองแผนกหน้ารายชื่อยังครบเหมือนเดิม | PASS | **PASS** | option=11 (ทุกแผนก + 10) |
| 18 | T11 · ยอดรวมในวงเล็บยังคำนวณเหมือนเดิม | PASS | **PASS** | ทุกแผนก (145) |
| 19 | T12 · NJHR.compat.scope.empDepts สะท้อนข้อมูลหลังโหลดเสร็จ | FAIL | **PASS** | length=10 |

**ก่อนแก้: PASS 5 · FAIL 14**

**หลังแก้: PASS 19 · FAIL 0**
