/* cycle_range_test.js — ตรวจสูตรรอบเดือน 26–25 และการใช้งานในทั้ง 3 รายงาน
     รอบของเดือน M = 26 ของเดือน M-1 → 25 ของเดือน M
   ตรวจ: ข้ามปี · เดือนสั้น/ยาว · ปีอธิกสุรทิน · ไม่มีวันเลื่อนจาก Timezone
          ทั้ง 3 รายงานใช้สูตรกลางตัวเดียวกัน · ส่งช่วงวันที่ไปกรองที่ RPC
   ใช้: node harness/cycle_range_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(58) + (d || '')); }

/* ดึงฟังก์ชันจริงจาก src มารัน — ไม่เขียนสูตรซ้ำในเทส */
const coreSrc = fs.readFileSync(path.join(ROOT, 'src/01-core-icons-utils.js'), 'utf8');
function grab(name) {
  const i = coreSrc.indexOf('function ' + name + '(');
  if (i < 0) return null;
  let d = 0, j = coreSrc.indexOf('{', i);
  for (let k = j; k < coreSrc.length; k++) {
    if (coreSrc[k] === '{') d++;
    else if (coreSrc[k] === '}') { d--; if (d === 0) return coreSrc.slice(i, k + 1); }
  }
  return null;
}
const pad = n => (n < 10 ? '0' + n : '' + n);
const TH_MONTHS = ['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน',
  'กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
const fmtDateDMY = v => {
  const p = String(v || '').slice(0, 10).split('-');
  return p.length === 3 ? pad(+p[2]) + '/' + pad(+p[1]) + '/' + (+p[0]) : '—';
};
const todayISO = () => '2026-08-12';
const src = ['cycleRange', 'cycleCurrent', 'cycleLabel', 'cycleRangeText', 'cycleOptions']
  .map(grab).join('\n');
const F = new Function('pad', 'TH_MONTHS', 'fmtDateDMY', 'todayISO',
  src + '\nreturn { cycleRange, cycleCurrent, cycleLabel, cycleRangeText, cycleOptions };')
  (pad, TH_MONTHS, fmtDateDMY, todayISO);

/* ================= 1. สูตรรอบเดือน ================= */
console.log('\n== สูตรรอบ 26–25 ==');
[
  ['2026-08', '2026-07-26', '2026-08-25', 'เดือนปกติ'],
  ['2026-01', '2025-12-26', '2026-01-25', 'ข้ามปี (ม.ค. → ธ.ค. ปีก่อน)'],
  ['2026-12', '2026-11-26', '2026-12-25', 'ธันวาคม'],
  ['2026-03', '2026-02-26', '2026-03-25', 'ต่อจากกุมภาพันธ์ 28 วัน'],
  ['2024-03', '2024-02-26', '2024-03-25', 'ปีอธิกสุรทิน (ก.พ. 29 วัน)'],
  ['2026-05', '2026-04-26', '2026-05-25', 'ต่อจากเมษายน 30 วัน'],
  ['2026-07', '2026-06-26', '2026-07-25', 'ต่อจากมิถุนายน 30 วัน']
].forEach(function (c) {
  const r = F.cycleRange(c[0]);
  chk('รอบ ' + c[0] + ' · ' + c[3],
    !!r && r.start === c[1] && r.end === c[2],
    r ? r.start + ' → ' + r.end : 'null');
});
chk('endExclusive = วันถัดจากวันสิ้นรอบ (26 เดือนถัดไป)',
  F.cycleRange('2026-08').endExclusive === '2026-08-26',
  F.cycleRange('2026-08').endExclusive);
chk('endExclusive ของรอบ ธ.ค. = 26/12 ปีเดียวกัน (รอบจบ 25/12)',
  F.cycleRange('2026-12').endExclusive === '2026-12-26',
  F.cycleRange('2026-12').endExclusive);
chk('endExclusive = end + 1 วันเสมอทุกรอบ',
  ['2026-01', '2026-02', '2026-08', '2026-12', '2024-03'].every(function (y) {
    const r = F.cycleRange(y);
    return r.endExclusive === r.end.slice(0, 8) + '26' && r.end.slice(-2) === '25';
  }), '');
chk('ทุกรอบเริ่มวันที่ 26 เสมอ',
  ['2026-01', '2026-02', '2026-06', '2026-12'].every(function (y) {
    return F.cycleRange(y).start.slice(-2) === '26';
  }), '');
chk('ทุกรอบสิ้นสุดวันที่ 25 เสมอ',
  ['2026-01', '2026-02', '2026-06', '2026-12'].every(function (y) {
    return F.cycleRange(y).end.slice(-2) === '25';
  }), '');
[['', 'ค่าว่าง'], [null, 'null'], ['2026-13', 'เดือนเกิน 12'], ['2026-00', 'เดือน 0'], ['abc', 'ไม่ใช่วันที่']]
  .forEach(function (x) {
    chk('ค่าไม่ถูกต้อง (' + x[1] + ') คืน null', F.cycleRange(x[0]) === null, String(F.cycleRange(x[0])));
  });

/* ================= 2. ไม่มีวันเลื่อนจาก Timezone ================= */
console.log('\n== Timezone ==');
chk('cycleRange ไม่ใช้ new Date() (ตัดปัญหาวันเลื่อน)',
  grab('cycleRange').indexOf('new Date') < 0, '');
chk('cycleCurrent ไม่ใช้ new Date()',
  grab('cycleCurrent').indexOf('new Date') < 0, '');
/* คำนวณซ้ำใน Timezone ต่างกันต้องได้ผลเดิม */
const before = JSON.stringify(F.cycleRange('2026-01'));
process.env.TZ = 'UTC';
const after = JSON.stringify(F.cycleRange('2026-01'));
chk('เปลี่ยน TZ แล้วผลเหมือนเดิม', before === after, after);

/* ================= 3. รอบของ "วันนี้" ================= */
console.log('\n== รอบของวันนี้ ==');
[
  ['2026-08-01', '2026-08', 'วันที่ 1 → รอบเดือนนี้'],
  ['2026-08-25', '2026-08', 'วันที่ 25 → ยังรอบเดือนนี้ (วันสุดท้าย)'],
  ['2026-08-26', '2026-09', 'วันที่ 26 → ขึ้นรอบเดือนถัดไป'],
  ['2026-08-31', '2026-09', 'สิ้นเดือน → รอบเดือนถัดไป'],
  ['2026-12-26', '2027-01', 'วันที่ 26 ธ.ค. → รอบ ม.ค. ปีถัดไป'],
  ['2026-12-25', '2026-12', 'วันที่ 25 ธ.ค. → ยังรอบ ธ.ค.']
].forEach(function (c) {
  const r = F.cycleCurrent(c[0]);
  chk('วันนี้ ' + c[0] + ' · ' + c[2], !!r && r.ym === c[1], r ? r.ym : 'null');
});

/* ================= 4. Label และตัวเลือกเดือน ================= */
console.log('\n== Label / ตัวเลือก ==');
chk('cycleLabel เป็นชื่อเดือนไทย + ปี ค.ศ.',
  F.cycleLabel('2026-08') === 'สิงหาคม 2026', F.cycleLabel('2026-08'));
chk('cycleLabel ไม่ใช้ปี พ.ศ.', F.cycleLabel('2026-01').indexOf('2569') < 0, F.cycleLabel('2026-01'));
chk('cycleRangeText แสดงช่วงแบบ DD/MM/YYYY',
  F.cycleRangeText('2026-08') === 'รอบข้อมูล 26/07/2026 – 25/08/2026',
  F.cycleRangeText('2026-08'));
const opts = F.cycleOptions('2026-08', 24, 1);
chk('cycleOptions คืน 26 เดือน (ย้อน 24 + ปัจจุบัน + ล่วงหน้า 1)', opts.length === 26, opts.length + '');
chk('cycleOptions เรียงล่าสุดอยู่บนสุด', opts[0] === '2026-09', opts[0]);
chk('cycleOptions มีรอบปัจจุบันอยู่ในรายการ', opts.indexOf('2026-08') >= 0, '');
chk('cycleOptions ข้ามปีย้อนหลังถูกต้อง', opts[opts.length - 1] === '2024-08', opts[opts.length - 1]);
chk('cycleOptions ไม่มีเดือนซ้ำ', new Set(opts).size === opts.length, '');

/* ================= 5. ทั้ง 3 รายงานใช้สูตรกลางตัวเดียว ================= */
console.log('\n== การใช้งานในรายงาน ==');
const rptSrc = fs.readFileSync(path.join(ROOT, 'src/37-view-report-menu.js'), 'utf8');
const allSrc = fs.readFileSync(path.join(ROOT, 'src/12-view-reports-settings.js'), 'utf8');
const payScr = fs.readFileSync(path.join(ROOT, 'src/11-view-approvals-payroll.js'), 'utf8');
[['รายงานการลา + รายงานโอที', rptSrc], ['รายงานทั้งหมด (UI)', allSrc], ['รายงานทั้งหมด (state)', payScr]]
  .forEach(function (x) {
    chk(x[0] + ' · เรียก cycleRange/cycleCurrent จาก core',
      /cycleRange\(|cycleCurrent\(/.test(x[1]), '');
    chk(x[0] + ' · ไม่เขียนสูตร 26–25 ซ้ำเอง',
      x[1].indexOf("'-26'") < 0 && x[1].indexOf('"-26"') < 0, '');
  });
/* ตอนนี้มีช่องวันที่ "จาก–ถึง" เพิ่มเข้ามาแล้ว แต่เป็นตัวกรองภายในรอบเดือน
   ไม่ใช่ตัวกรองหลักแทนรอบเดือน — ตรวจว่ารอบเดือนยังเป็นฐานเสมอ */
chk('รายงานการลา/โอที · มีช่องวันที่ จาก–ถึง',
  rptSrc.indexOf('rptm-from') >= 0 && rptSrc.indexOf('rptm-to') >= 0, '');
chk('รายงานการลา/โอที · ช่วงวันที่ถูกตัดด้วยรอบเดือนเสมอ (ไม่หลุดรอบ)',
  /s\.from > c\.start\) \? s\.from : c\.start/.test(rptSrc) &&
  /s\.to < c\.end\) \? s\.to : c\.end/.test(rptSrc), '');
chk('รายงานการลา/โอที · รอบเดือนยังเป็นฐานของช่วงวันที่',
  /function rptmRange\(s\)[\s\S]{0,120}rptmCycle\(s\)/.test(rptSrc), '');
chk('รายงานทั้งหมด · ไม่มีช่องวันที่เริ่ม-สิ้นสุดแล้ว',
  allSrc.indexOf("'rp-from'") < 0 && allSrc.indexOf("'rp-to'") < 0, '');
chk('รายงานการลา/โอที · มีช่องรอบเดือน', rptSrc.indexOf('rptm-ym') >= 0, '');
chk('รายงานทั้งหมด · มีช่องรอบเดือน', allSrc.indexOf('rp-ym') >= 0, '');

/* ================= 6. กรองที่ฐานข้อมูล ไม่กรองในหน้าเว็บ ================= */
console.log('\n== กรองที่ RPC ==');
chk('รายงานการลา/โอที · ส่ง p_from/p_to จาก cycleRange ไป RPC',
  /p_from: cyc\.start, p_to: cyc\.end/.test(rptSrc), '');
chk('รายงานทั้งหมด · rpRangeOf() อ่านช่วงจาก rpCycle()',
  /function rpRangeOf\(\)[\s\S]{0,200}rpCycle\(\)/.test(payScr), '');
chk('ไม่มีการ filter รอบเดือนซ้ำในหน้าเว็บ (rows.filter ตามวันที่)',
  !/rows\.filter\([^)]*ot_date/.test(rptSrc) && !/rows\.filter\([^)]*start_date/.test(rptSrc), '');

/* ================= 7. ช่องรอบเดือนต้องไม่ว่างตอนเปิดหน้า ================= */
console.log('\n== ค่าเริ่มต้น ==');
chk('รายงานการลา/โอที · ตั้งรอบปัจจุบันก่อนสร้าง <select>',
  /function rptmRender[\s\S]{0,240}if \(!s\.ym\) s\.ym = cycleCurrent\(\)\.ym;/.test(rptSrc), '');
chk('รายงานทั้งหมด · ตั้งรอบปัจจุบันก่อนสร้าง <select>',
  /function viewReportAll[\s\S]{0,400}if \(!s\.ym\) s\.ym = cycleCurrent\(\)\.ym;/.test(allSrc), '');
chk('ล้างตัวกรองของรายงานการลา/โอที กลับรอบปัจจุบัน + ล้างวันที่',
  /s\.ym = cycleCurrent\(\)\.ym; s\.from = ''; s\.to = ''; s\.dept = ''/.test(rptSrc), '');
chk('ล้างตัวกรองของรายงานทั้งหมด กลับรอบปัจจุบัน',
  /ym: cycleCurrent\(\)\.ym/.test(allSrc), '');

console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
process.exit(FAIL ? 1 : 0);
