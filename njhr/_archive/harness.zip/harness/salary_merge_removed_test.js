/* salary_merge_removed_test.js — ตรวจว่า "รวมเงินเดือน" ถูกถอดออกจากระบบหมดแล้ว
   และเมนู/รายงาน/เงินเดือนส่วนอื่นยังอยู่ครบ ไม่มี Error
   ใช้: node harness/salary_merge_removed_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(62) + (d || '')); }

function read(rel) {
  const p = path.join(ROOT, rel);
  return fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : null;
}

/* ================= 1. ไฟล์ต้นทางถูกลบ ================= */
console.log('\n== ไฟล์ต้นทาง ==');
['src/15-view-salary-merge-boot.js', 'src/16-salary-merge-core.js'].forEach(function (f) {
  chk('ลบไฟล์ ' + f + ' แล้ว', !fs.existsSync(path.join(ROOT, f)), '');
});
const build = read('build.js');
chk('build.js ไม่อ้างไฟล์ที่ลบแล้ว',
  build.indexOf('salary-merge-core') < 0 && build.indexOf('salary-merge-boot') < 0, '');

/* ================= 2. Route และเมนูหายไป ================= */
console.log('\n== Route และเมนู ==');
const core = read('runtime/core.js');
chk('ไม่มี Route "#/salary-merge" ใน ROUTES', core.indexOf('#/salary-merge') < 0, '');
chk('ไม่มี view "viewSalaryMerge"', core.indexOf('viewSalaryMerge') < 0, '');
chk('เมนู Sidebar ไม่มี "รวมเงินเดือน"', core.indexOf('รวมเงินเดือน') < 0, '');

/* ================= 3. เมนูและหน้าอื่นยังอยู่ครบ ================= */
console.log('\n== เมนู/หน้าที่ต้องคงไว้ ==');
/* ชื่อเมนูรายงานถูกเปลี่ยนเป็นภาษาไทยแล้ว — Route ยังเป็นตัวเดิมทุกตัว */
[['รายงานการลงเวลา', '#/reports'], ['ประกันสังคม', '#/sso'], ['รายงานทั้งหมด', '#/reportall'],
 ['รายงานการลา', '#/rpt-leave'], ['รายงานโอที', '#/rpt-ot'],
 ['เงินเดือน', '#/payroll'], ['รายการเงินเดือน', '#/pay-items'],
 ['สลิปเงินเดือน', '#/epayslip']].forEach(function (x) {
  chk('ยังมีเมนู/Route ' + x[0] + ' (' + x[1] + ')',
    core.indexOf(x[1]) >= 0 && core.indexOf(x[0]) >= 0, '');
});
[['viewReports', 'รายงานการลงเวลา'], ['viewSSO', 'ประกันสังคม'], ['viewReportAll', 'รายงานทั้งหมด'],
 ['viewRptLeave', 'รายงานการลา'], ['viewRptOT', 'รายงานโอที'],
 ['viewPayroll', 'เงินเดือน'], ['viewPayItems', 'รายการเงินเดือน'],
 ['viewEPayslip', 'สลิปเงินเดือน']].forEach(function (x) {
  chk('ยังมี view ' + x[0] + ' (' + x[1] + ')', core.indexOf(x[0]) >= 0, '');
});

/* ================= 4. URL เดิมต้องไม่พัง ================= */
console.log('\n== เปิด URL เดิม #/salary-merge ==');
/* render() ของ core: ถ้า hash ไม่อยู่ใน ROUTES จะ fallback เป็น #/dashboard
   ตรวจว่าโค้ด fallback นี้ยังอยู่ จึงไม่เกิดหน้าขาวหรือ JS Error */
const flat = core.replace(/\s/g, '');
chk('มี fallback ไป #/dashboard เมื่อ Route ไม่รู้จัก',
  /if\(!ROUTES\[hash\]\)\{/.test(flat) && flat.indexOf('hash="#/dashboard"') >= 0, '');
chk('fallback ตั้ง location.hash ใหม่ (ไม่ค้างหน้าเปล่า)',
  /location\.hash!==hash\)\{location\.hash=hash;return\}/.test(flat), '');
chk('ไม่มีการอ้าง viewSalaryMerge ที่จะทำให้ Error', core.indexOf('SalaryMerge') < 0, '');

/* ================= 5. ไม่มีไฟล์อื่น Reference ของที่ลบ ================= */
console.log('\n== Reference ค้างในไฟล์ Deploy ==');
const deployJs = fs.readFileSync(path.join(ROOT, 'DEPLOY_MD5.txt'), 'utf8')
  .trim().split('\n').map(l => l.split('  ')[1].replace(/^\.\//, ''))
  .filter(f => f.endsWith('.js') && f !== 'master-salary.js');
const bad = deployJs.filter(function (f) {
  const t = read(f) || '';
  return t.indexOf('viewSalaryMerge') >= 0 || t.indexOf('#/salary-merge') >= 0 ||
         t.indexOf('SALARY_MASTER') >= 0;
});
chk('ไม่มีไฟล์ JS ใดอ้างของที่ลบแล้ว', bad.length === 0, bad.join(', '));
chk('ตรวจครบทุกไฟล์ JS ที่ Deploy', deployJs.length >= 30, deployJs.length + ' ไฟล์');

/* ================= 6. CSS เฉพาะหน้านี้ถูกลบ ================= */
console.log('\n== CSS ==');
const css = read('styles.css'), mcss = read('mobile.css');
chk('styles.css ไม่มี .sm-grid / .sm-box แล้ว',
  css.indexOf('.sm-grid') < 0 && css.indexOf('.sm-box') < 0, '');
chk('mobile.css ไม่มี .sm-grid / .sm-box', mcss.indexOf('.sm-grid') < 0 && mcss.indexOf('.sm-box') < 0, '');
/* คลาสของหน้าอื่นต้องไม่ถูกลบตาม */
['.rptm-table', '.lvt', '.otj-flist', '.kpi', '.fp-overlay'].forEach(function (c) {
  chk('CSS ยังมี ' + c + ' (หน้าอื่น)', css.indexOf(c) >= 0, '');
});

/* ================= 7. Backend ไม่ถูกแตะ ================= */
console.log('\n== Backend ==');
const sqlDir = path.join(ROOT, 'supabase-new');
if (fs.existsSync(sqlDir)) {
  const files = fs.readdirSync(sqlDir).filter(f => f.endsWith('.sql'));
  chk('ไฟล์ SQL ยังอยู่ครบ ไม่ได้ลบ', files.length > 100, files.length + ' ไฟล์');
  /* หน้า "รวมเงินเดือน" ไม่เคยเรียก RPC ใด — ทำงานฝั่ง Frontend ล้วน (อ่านไฟล์ Excel) */
  const anyDrop = files.some(function (f) {
    const t = fs.readFileSync(path.join(sqlDir, f), 'utf8');
    return /drop\s+(function|table|view)[\s\S]{0,80}salary_merge/i.test(t);
  });
  chk('ไม่มี SQL ที่ DROP ของ "รวมเงินเดือน"', !anyDrop, '');
}

console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
process.exit(FAIL ? 1 : 0);
