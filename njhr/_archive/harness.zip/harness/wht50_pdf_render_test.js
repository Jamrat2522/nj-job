/* wht50_pdf_render_test.js — สร้าง PDF 50 ทวิ จริงด้วยฟอนต์จริง แล้วตรวจไฟล์ที่ได้
     ใช้ pdf-lib + @pdf-lib/fontkit รุ่นเดียวกับที่ Edge Function ใช้
     และใช้ buildWht50Pdf() ตัวจริงจาก edge-functions/njhr-doc-pdf/wht50.ts

   สิ่งที่พิสูจน์ได้จากเทสนี้
     · ฟอนต์ไทยถูก Embed ลงไฟล์จริง (ตรวจจาก FontFile2 ในโครงสร้าง PDF)
     · ข้อความไทยอ่านกลับออกมาได้ครบ ไม่กลายเป็น □ หรือ ?
     · ไฟล์เป็น PDF จริง (%PDF header) ขนาด > 0 เปิดได้
     · Layout A4 · จำนวนหน้า 2 ฉบับ

   สิ่งที่เทสนี้ "ไม่" พิสูจน์
     · การ Deploy Edge Function บน Production
     · การ Upload ขึ้น Storage และ Signed URL
     · สถานะ READY ในฐานข้อมูลจริง

   ใช้: node harness/wht50_pdf_render_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(56) + (d || '')); }

const FONT_DIR = path.join(ROOT, 'edge-functions/njhr-doc-pdf/fonts');

/* ---------- โหลด buildWht50Pdf ตัวจริงจาก .ts ---------- */
function loadRenderer() {
  let tsc = null;
  try { tsc = require('typescript'); } catch (e) { return null; }
  const ts = fs.readFileSync(path.join(ROOT, 'edge-functions/njhr-doc-pdf/wht50.ts'), 'utf8');
  /* แทน import ของ Deno ด้วย require ของ Node — โค้ดส่วนที่เหลือไม่แตะ */
  const src = ts
    .replace(/import \{([^}]*)\} from "npm:pdf-lib@[^"]*";/,
      function (_m, names) { return 'const {' + names + '} = require("pdf-lib");'; })
    .replace(/import fontkit from "npm:@pdf-lib\/fontkit@[^"]*";/,
      'const fontkit = require("@pdf-lib/fontkit");');
  const js = tsc.transpileModule(src, {
    compilerOptions: { target: tsc.ScriptTarget.ES2019, module: tsc.ModuleKind.CommonJS }
  }).outputText;
  const mod = { exports: {} };
  new Function('module', 'exports', 'require', js)(mod, mod.exports, require);
  return mod.exports;
}

/* ---------- ข้อมูลทดสอบ — ไม่ใช่ข้อมูลจริงของพนักงาน ---------- */
const SNAP = {
  tax_year: 2026,
  doc_no: 'WHT-2569-0001',
  book_no: '1',
  seq_no: 1,
  form_type: 'PND1A',
  income_section: '40(1)',
  issue_date: '2027-02-10',
  payer_snapshot: {
    company_name: 'บริษัท เอ็น.เจ. โลจิสติกส์ แอนด์ ฟรุ๊ตส์ จำกัด',
    company_address: '99/9 หมู่ 5 ตำบลหนองปรือ อำเภอบางละมุง จังหวัดชลบุรี 20150',
    company_tax_id: '0205558000123'
  },
  payee_snapshot: {
    prefix: 'นาย', first_name: 'ทดสอบ', last_name: 'ระบบเอกสาร',
    national_id: '1234567890123',
    address: '12/3 ซอยทดสอบ ตำบลหนองปรือ อำเภอบางละมุง จังหวัดชลบุรี'
  },
  income_final: null,
  total_income: 480000, total_tax: 12500.5,
  total_sso: 9000, total_pvd: 14400,
  tax_payment_mode: 'WITHHOLD', tax_payment_mode_other: '',
  signer_name: 'ผู้จัดการฝ่ายบุคคล', signer_position: 'กรรมการผู้จัดการ',
  amend_seq: 0
};

(async function () {
  console.log('\n== ไฟล์ฟอนต์ในแพ็กเกจ ==');
  const files = fs.existsSync(FONT_DIR) ? fs.readdirSync(FONT_DIR) : [];
  const reg = path.join(FONT_DIR, 'Prompt-Regular.ttf');
  const bold = path.join(FONT_DIR, 'Prompt-Bold.ttf');
  chk('มี Prompt-Regular.ttf', fs.existsSync(reg),
    fs.existsSync(reg) ? fs.statSync(reg).size + ' ไบต์' : 'ไม่มี');
  chk('มี Prompt-Bold.ttf', fs.existsSync(bold),
    fs.existsSync(bold) ? fs.statSync(bold).size + ' ไบต์' : 'ไม่มี');
  chk('มีไฟล์ License (OFL.txt)', files.indexOf('OFL.txt') >= 0, '');
  if (!fs.existsSync(reg) || !fs.existsSync(bold)) {
    console.log('\nFONT MISSING — ข้ามการสร้าง PDF');
    console.log('รวม PASS ' + PASS + ' · FAIL ' + FAIL);
    process.exit(1);
  }
  const regBuf = fs.readFileSync(reg), boldBuf = fs.readFileSync(bold);
  chk('เป็นไฟล์ TrueType จริง (header 0x00010000 หรือ "true")',
    (regBuf.readUInt32BE(0) === 0x00010000 || regBuf.slice(0, 4).toString() === 'true') &&
    (boldBuf.readUInt32BE(0) === 0x00010000 || boldBuf.slice(0, 4).toString() === 'true'),
    '0x' + regBuf.readUInt32BE(0).toString(16));

  console.log('\n== โหลด Renderer ตัวจริง ==');
  const R = loadRenderer();
  if (!R) {
    console.log('SKIP  ไม่มี typescript — ติดตั้งด้วย npm i -D typescript');
    console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
    process.exit(FAIL ? 1 : 0);
  }
  chk('โหลด buildWht50Pdf ได้', typeof R.buildWht50Pdf === 'function', '');
  chk('โหลด assertThaiFontsReady ได้', typeof R.assertThaiFontsReady === 'function', '');

  console.log('\n== Font Preflight ==');
  let e1 = '';
  try { R.assertThaiFontsReady(null, boldBuf); } catch (e) { e1 = e.message; }
  chk('ไม่มี Regular → ล้มพร้อมชื่อไฟล์', /Prompt-Regular\.ttf/.test(e1), e1);
  let e2 = '';
  try { R.assertThaiFontsReady(regBuf, null); } catch (e) { e2 = e.message; }
  chk('ไม่มี Bold → ล้มพร้อมชื่อไฟล์', /Prompt-Bold\.ttf/.test(e2), e2);
  let e3 = 'ok';
  try { R.assertThaiFontsReady(regBuf, boldBuf); } catch (e) { e3 = e.message; }
  chk('มีครบ → ผ่าน', e3 === 'ok', e3);

  console.log('\n== สร้าง PDF จริง ==');
  let bytes = null, err = '';
  try {
    bytes = await R.buildWht50Pdf(SNAP, new Uint8Array(regBuf), new Uint8Array(boldBuf));
  } catch (e) { err = e.message; }
  chk('สร้างไฟล์สำเร็จ ไม่มี error', !!bytes && !err, err);
  if (!bytes) {
    console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
    process.exit(1);
  }

  const outDir = path.join(ROOT, 'harness', 'out');
  fs.mkdirSync(outDir, { recursive: true });
  const outFile = path.join(outDir, 'wht50-sample.pdf');
  fs.writeFileSync(outFile, Buffer.from(bytes));
  const buf = fs.readFileSync(outFile);

  chk('ไฟล์ขนาด > 0', buf.length > 0, buf.length + ' ไบต์');
  chk('ขึ้นต้นด้วย %PDF', buf.slice(0, 5).toString() === '%PDF-', buf.slice(0, 8).toString());
  chk('ไม่ใช่ HTML ที่ปลอมเป็น PDF',
    buf.slice(0, 200).toString().indexOf('<html') < 0 &&
    buf.slice(0, 200).toString().toLowerCase().indexOf('<!doctype') < 0, '');
  chk('ปิดท้ายด้วย %%EOF', buf.slice(-20).toString().indexOf('%%EOF') >= 0, '');

  console.log('\n== ฟอนต์ถูกฝังในไฟล์จริง ==');
  /* pdf-lib เก็บ Object ไว้ใน Object Stream ที่บีบอัดไว้ (useObjectStreams ค่าเริ่มต้น = true)
     สแกนไฟล์ดิบตรง ๆ จะไม่เจอ /FontFile2 หรือ /ToUnicode
     จึงโหลดกลับแล้วบันทึกใหม่แบบไม่ใช้ Object Stream เพื่อตรวจโครงสร้างข้างใน
     ไฟล์ที่ส่งจริงยังเป็นฉบับบีบอัดตามเดิม ไม่ได้เปลี่ยนอะไร */
  const { PDFDocument: PD2 } = require('pdf-lib');
  const flat = Buffer.from(
    await (await PD2.load(buf)).save({ useObjectStreams: false }));
  const raw = flat.toString('latin1');
  chk('มี FontFile2 (ฟอนต์ TrueType ฝังอยู่)', raw.indexOf('/FontFile2') >= 0, '');
  const nFontFile = (raw.match(/\/FontFile2/g) || []).length;
  chk('ฝังครบทั้ง Regular และ Bold', nFontFile >= 2, nFontFile + ' ชุด');
  chk('ชื่อฟอนต์ Prompt ปรากฏในไฟล์', /Prompt/.test(raw), '');
  chk('ไม่ได้ fallback ไป Helvetica',
    raw.indexOf('/BaseFont /Helvetica') < 0 && raw.indexOf('/BaseFont/Helvetica') < 0, '');
  chk('ใช้ Encoding แบบ Identity (รองรับ Unicode)',
    raw.indexOf('Identity-H') >= 0 || raw.indexOf('/Type0') >= 0, '');
  chk('มี ToUnicode CMap (ข้อความคัดลอกออกได้)', raw.indexOf('/ToUnicode') >= 0, '');

  console.log('\n== อ่านข้อความไทยกลับจาก PDF ==');
  /* อ่านผ่าน pdf-lib: ดึง ToUnicode ของแต่ละฟอนต์แล้วถอดกลับเป็นตัวอักษร
     ถ้าฟอนต์ฝังผิดหรือ subset ตัดอักษรไทยทิ้ง จะถอดกลับไม่ได้ */
  const doc = await PD2.load(buf);
  chk('เปิดไฟล์ด้วย pdf-lib ได้', !!doc, '');
  chk('มี 2 หน้า (ฉบับที่ 1 และ 2)', doc.getPageCount() === 2, doc.getPageCount() + ' หน้า');
  const p0 = doc.getPage(0);
  const sz = p0.getSize();
  chk('ขนาดหน้าเป็น A4 (595 × 842)',
    Math.abs(sz.width - 595.28) < 1 && Math.abs(sz.height - 841.89) < 1,
    Math.round(sz.width) + ' × ' + Math.round(sz.height));

  /* รวบรวมอักษรทั้งหมดที่ ToUnicode ประกาศไว้
     stream ของ CMap ถูกบีบด้วย FlateDecode จึงต้องคลายก่อนอ่าน */
  const zlib = require('zlib');
  let mapped = '';
  const streamRe = /stream\r?\n([\s\S]*?)\r?\nendstream/g;
  let sm;
  while ((sm = streamRe.exec(raw)) !== null) {
    let body = sm[1];
    let text = '';
    try { text = zlib.inflateSync(Buffer.from(body, 'latin1')).toString('latin1'); }
    catch (e) { text = body; }          // บาง stream ไม่ได้บีบ
    if (text.indexOf('beginbfchar') < 0 && text.indexOf('beginbfrange') < 0) continue;
    (text.match(/beginbfchar[\s\S]*?endbfchar/g) || []).forEach(function (blk) {
      const re = /<[0-9a-fA-F]{4}>\s*<([0-9a-fA-F]{4,})>/g;
      let m2;
      while ((m2 = re.exec(blk)) !== null) {
        const hex = m2[1];
        for (let i = 0; i < hex.length; i += 4) {
          mapped += String.fromCharCode(parseInt(hex.substr(i, 4), 16));
        }
      }
    });
    (text.match(/beginbfrange[\s\S]*?endbfrange/g) || []).forEach(function (blk) {
      const re = /<([0-9a-fA-F]{4})>\s*<([0-9a-fA-F]{4})>\s*<([0-9a-fA-F]{4,})>/g;
      let m2;
      while ((m2 = re.exec(blk)) !== null) {
        const lo = parseInt(m2[1], 16), hi = parseInt(m2[2], 16);
        const base = parseInt(m2[3].substr(0, 4), 16);
        for (let k = 0; k <= hi - lo; k++) mapped += String.fromCharCode(base + k);
      }
    });
  }
  chk('ถอดอักษรกลับจาก ToUnicode ได้', mapped.length > 0, mapped.length + ' อักขระ');

  const thaiChars = (mapped.match(/[\u0E00-\u0E7F]/g) || []);
  chk('มีอักษรไทยในไฟล์', thaiChars.length > 0, thaiChars.length + ' ตัว');

  /* ตรวจว่าอักษรที่จำเป็นต่อเอกสารอยู่ครบ */
  /* แยก 2 เรื่องออกจากกัน
     (ก) ฟอนต์ "รองรับ" อักขระไหนบ้าง — ตรวจจากตัวฟอนต์โดยตรง
     (ข) อักขระไหน "ถูกวาดลงเอกสารนี้จริง" — ตรวจจาก ToUnicode
     บางตัวเช่น ํ (นิคหิต) ฟอนต์รองรับแต่แบบ 50 ทวิ ไม่ได้ใช้ จึงไม่ควรถือว่าพลาด */
  const fkLib = require('@pdf-lib/fontkit');
  const fReg = fkLib.create(regBuf), fBold = fkLib.create(boldBuf);
  const support = {
    'พยัญชนะไทย': 'กขฃคฅฆงจฉชซฌญฎฏฐฑฒณดตถทธนบปผฝพฟภมยรฤลฦวศษสหฬอฮ',
    'สระ': 'ะัาำิีึืุูเแโใไๅ',
    'วรรณยุกต์': '่้๊๋',
    'เครื่องหมายไทย': '์ํฺฯๆ๎',
    'เลขไทย': '๐๑๒๓๔๕๖๗๘๙',
    'ตัวเลขอารบิก': '0123456789',
    'อังกฤษพิมพ์ใหญ่': 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    'อังกฤษพิมพ์เล็ก': 'abcdefghijklmnopqrstuvwxyz'
  };
  Object.keys(support).forEach(function (k) {
    const miss = support[k].split('').filter(function (c) {
      const a1 = fReg.glyphForCodePoint(c.codePointAt(0));
      const b1 = fBold.glyphForCodePoint(c.codePointAt(0));
      return !a1 || a1.id === 0 || !b1 || b1.id === 0;
    });
    chk('ฟอนต์รองรับ' + k + 'ครบ (ทั้ง Regular และ Bold)', miss.length === 0,
      miss.length ? 'ขาด: ' + miss.join('') : support[k].length + ' ตัว');
  });

  /* อักขระที่เอกสารนี้ใช้จริง ต้องถูกวาดลงไฟล์ครบ */
  const used = {
    'พยัญชนะที่ใช้ในเอกสาร': 'กงจดตทนบปผพภมยรลวสหอ',
    'สระที่ใช้': 'ะัาำิีืุูเแโไ',
    'วรรณยุกต์ที่ใช้': '่้',
    'ตัวเลข': '0123456789'
  };
  Object.keys(used).forEach(function (k) {
    const miss = used[k].split('').filter(function (c) { return mapped.indexOf(c) < 0; });
    chk('วาดลงเอกสารจริง: ' + k, miss.length === 0,
      miss.length ? 'ขาด: ' + miss.join('') : '');
  });

  console.log('\n== ข้อความตามแบบกรมสรรพากรอยู่ในไฟล์ ==');
  /* ตรวจจาก Model ว่าข้อความสำคัญถูกส่งเข้าไปวาดจริง
     (ตัวอักษรที่ประกอบข้อความเหล่านี้ต้องมีใน ToUnicode ครบทุกตัว) */
  const model = R.buildWht50Model(SNAP);
  const mustDraw = [
    ['ชื่อเอกสาร', model.title],
    ['อ้างมาตรา', model.subtitle],
    ['ฉบับที่ 1', model.copyLabels[0]],
    ['ฉบับที่ 2', model.copyLabels[1]],
    ['ชื่อบริษัท', model.payer.name],
    ['ที่อยู่บริษัท', model.payer.address],
    ['ชื่อผู้ถูกหักภาษี', model.payee.name],
    ['ที่อยู่ผู้ถูกหักภาษี', model.payee.address],
    ['คำรับรอง', model.certifyText],
    ['ภาษีเป็นตัวอักษร', model.taxWords],
    ['ผู้ลงนาม', model.signer.name],
    ['รายการเงินได้ 40(1)', model.incomeRows[0].label]
  ];
  mustDraw.forEach(function (x) {
    const miss = Array.from(new Set(x[1].replace(/\s/g, '').split('')))
      .filter(function (c) { return mapped.indexOf(c) < 0; });
    chk('วาดได้ครบทุกตัวอักษร: ' + x[0], miss.length === 0,
      miss.length ? 'ขาด: ' + miss.join('') : x[1].slice(0, 28));
  });

  console.log('\n== ตัวเลขและเลขประจำตัว ==');
  [['เลขประจำตัวผู้เสียภาษี', model.payer.taxid],
   ['เลขประจำตัวประชาชน', model.payee.taxid],
   ['เลขที่เอกสาร', model.docNo],
   ['วันที่ออก (พ.ศ.)', model.issueDate]].forEach(function (x) {
    const miss = Array.from(new Set(x[1].split('')))
      .filter(function (c) { return mapped.indexOf(c) < 0; });
    chk(x[0] + ' วาดได้ครบ', miss.length === 0, x[1]);
  });
  chk('ยอดเงินถูกต้องตามข้อมูลที่ป้อน',
    model.totalIncome === 480000 && model.totalTax === 12500.5, '');
  chk('ประกันสังคม / กองทุนสำรองฯ ถูกต้อง',
    model.totalSso === 9000 && model.totalPvd === 14400, '');

  console.log('\n== ⚠ ข้อบกพร่องที่ยังแก้ไม่ได้: ความกว้างวรรณยุกต์ ==');
  /* glyph ตัวแปรของวรรณยุกต์ที่เกิดจาก GSUB ไม่ถูกใส่ใน /W
     โปรแกรมอ่าน PDF จึงใช้ /DW = 1000 → เกิดช่องว่างหลังวรรณยุกต์
     เทสนี้จับปัญหาไว้ให้เห็นชัด ไม่ปล่อยผ่านเงียบ ๆ */
  /* แปลงตาราง /W ทั้งหมดเป็น map cid → width ตามสเปก PDF
     รูปแบบที่ใช้ได้มี 2 แบบ
       c [w1 w2 ...]   กำหนดทีละตัวเริ่มจาก c
       cFirst cLast w  กำหนดช่วงให้กว้างเท่ากันทั้งช่วง
     ต้องอ่านทั้งสองแบบ ไม่งั้นจะสรุปผิดว่า glyph หาย
     ทั้งที่จริงอยู่กลางช่วงที่ประกาศไว้แล้ว */
  function parseW(text) {
    const map = new Map();
    let idx = 0;
    while ((idx = text.indexOf('/W [', idx)) >= 0) {
      let depth = 0, end = idx + 3;
      for (; end < text.length; end++) {
        if (text[end] === '[') depth++;
        else if (text[end] === ']') { depth--; if (depth === 0) break; }
      }
      const body = text.slice(idx + 4, end);
      /* แยกเป็นโทเคน: ตัวเลข หรือ [ ... ] */
      const tok = body.match(/\[[^\]]*\]|-?\d+/g) || [];
      let k = 0;
      while (k < tok.length) {
        if (/^\[/.test(tok[k])) { k++; continue; }
        const first = parseInt(tok[k], 10);
        if (k + 1 < tok.length && /^\[/.test(tok[k + 1])) {
          const ws = (tok[k + 1].match(/-?\d+/g) || []).map(Number);
          ws.forEach(function (w, q) { map.set(first + q, w); });
          k += 2;
        } else if (k + 2 < tok.length && /^-?\d+$/.test(tok[k + 1]) &&
                   /^-?\d+$/.test(tok[k + 2])) {
          const last = parseInt(tok[k + 1], 10), w = parseInt(tok[k + 2], 10);
          for (let c = first; c <= last && c - first < 70000; c++) map.set(c, w);
          k += 3;
        } else k++;
      }
      idx = end;
    }
    return map;
  }
  const wMap = parseW(raw);
  const dwM = /\/DW\s+(-?\d+)/.exec(raw);
  const DW = dwM ? parseInt(dwM[1], 10) : 1000;   // ค่าปริยายตามสเปก PDF
  function effWidth(gid) { return wMap.has(gid) ? wMap.get(gid) : DW; }
  const wSeg = raw;
  const fkChk = require('@pdf-lib/fontkit').create(regBuf);
  const variantIds = [];
  ['ที่', 'ป้', 'ผู้', 'เบี้'].forEach(function (w) {
    fkChk.layout(w).glyphs.forEach(function (g) {
      if (g.advanceWidth === 0 && variantIds.indexOf(g.id) < 0) variantIds.push(g.id);
    });
  });
  const missing = variantIds.filter(function (gid) { return effWidth(gid) !== 0; });
  console.log('        glyph กว้าง 0 ที่ใช้จริง: ' + variantIds.join(', '));
  console.log('        /DW = ' + DW + ' · ตาราง /W ครอบคลุม ' + wMap.size + ' CID');
  console.log('        ที่ effective width ไม่เป็น 0: ' + (missing.join(', ') || 'ไม่มี'));
  chk('วรรณยุกต์ทุกตัวมี effective width = 0 ในไฟล์จริง', missing.length === 0,
    missing.length
      ? missing.map(function (g) { return g + '→' + effWidth(g); }).join(' · ')
      : variantIds.length + ' ตัว ทุกตัวกว้าง 0');
  /* เลือกเติม /W แบบระบุตัวแทนการตั้ง /DW 0 ทั้งฟอนต์
     เพราะ /DW 0 จะทำให้ glyph อื่นที่ตกหล่นกว้าง 0 ไปด้วยโดยไม่ตั้งใจ */
  chk('ไม่ได้ตั้ง /DW 0 ทั้งฟอนต์ (ใช้วิธีเติม /W แบบระบุ)',
    !/\/DW\s+0\b/.test(raw), /\/DW\s+(\d+)/.exec(raw) ? '/DW ' + RegExp.$1 : 'ไม่มี /DW');

  /* ตรวจอักษรไทยทุกตัวที่ระบบอาจเจอในข้อมูลจริง ไม่ใช่แค่ที่เอกสารนี้มี
     ชื่อคนและที่อยู่มีอักษรอะไรก็ได้ จึงต้องครอบคลุมทั้งชุด */
  const consAll = 'กขฃคฅฆงจฉชซฌญฎฏฐฑฒณดตถทธนบปผฝพฟภมยรฤลฦวศษสหฬอฮ';
  const marksAll = ['ิ', 'ี', 'ึ', 'ื', 'ั', '็', '์', '่', '้', '๊', '๋', 'ุ', 'ู'];
  const allVariants = new Set();
  consAll.split('').forEach(function (c) {
    marksAll.forEach(function (mk) {
      [c + mk, c + 'ี' + mk, c + 'ั' + mk].forEach(function (w) {
        fkChk.layout(w).glyphs.forEach(function (g) {
          if (g.advanceWidth === 0) allVariants.add(g.id);
        });
      });
    });
  });
  const missAll = Array.from(allVariants).filter(function (gid) { return effWidth(gid) !== 0; });
  console.log('        glyph กว้าง 0 ที่เป็นไปได้ทั้งหมด: ' + allVariants.size + ' ตัว');
  chk('รองรับอักษรไทยทุกตัวที่ข้อมูลจริงอาจมี (ไม่ใช่แค่เอกสารนี้)',
    missAll.length === 0,
    missAll.length
      ? missAll.slice(0, 8).map(function (g) { return g + '→' + effWidth(g); }).join(' · ')
      : allVariants.size + ' ตัว ทุกตัวกว้าง 0');

  console.log('\n        ไฟล์ตัวอย่าง: harness/out/wht50-sample.pdf (' + buf.length + ' ไบต์)');
  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  console.log('NOT TESTED: Deploy Edge Function · Upload Storage · Signed URL · READY ในฐานข้อมูลจริง');
  process.exit(FAIL ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
