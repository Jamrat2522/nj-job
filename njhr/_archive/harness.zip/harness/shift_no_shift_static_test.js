#!/usr/bin/env node
const fs = require('fs'), path = require('path');
const ROOT = process.argv[2] || path.join(__dirname, '..');
let P=0,F=0;
function chk(n,ok){ if(ok){P++;console.log('PASS  '+n)}else{F++;console.error('FAIL  '+n)} }
const sh=fs.readFileSync(path.join(ROOT,'src/12-view-reports-settings.js'),'utf8');
const att=fs.readFileSync(path.join(ROOT,'src/33-view-attendance.js'),'utf8');
const sql=fs.readFileSync(path.join(ROOT,'sql/102_shift_management.sql'),'utf8');
chk('Dropdown มีค่า NO_SHIFT/ไม่มีกะ', /SH_NO_SHIFT\s*=\s*'__NO_SHIFT__'/.test(sh) && />ไม่มีกะ<\/option>/.test(sh));
chk('เส้นทาง NO_SHIFT ใช้ njhr_shift_no_shift_set', /dest\s*===\s*SH_NO_SHIFT[\s\S]{0,120}shNoShiftSet/.test(sh));
chk('กะจริงใช้ njhr_shift_assign_many', /function shAssignMany[\s\S]{0,250}njhr_shift_assign_many/.test(sh));
chk('ลบ UI เก่านำเข้ากะ localStorage', !/shMigrateTool|id="sh-migrate"/.test(sh));
chk('ลบปุ่มแยกตั้ง/ยกเลิกไม่ใช้กะ', !/id="shu-ns"|id="shl-rm"|id="shl-ns"|id="shn-cancel"/.test(sh));
chk('NO_SHIFT กลับเข้ากะผ่าน shn-to/shn-move', /id="shn-to"/.test(sh) && /id="shn-move"/.test(sh));
chk('Attendance อ่าน njhr_shift_my_state', /njhr_shift_my_state/.test(att));
chk('NO_SHIFT ปิด requirement และไม่เปิด GPS/Face ก่อนรู้ state', /attendance_required\s*===\s*false/.test(att) && !/attRenderEmpCard\(\);\s*attCheckGps\(\)/.test(att));
chk('Trigger Default เฉพาะ AFTER INSERT', /AFTER INSERT ON public\.employees/.test(sql) && !/UPDATE\s+public\.employees/i.test(sql));
chk('Default resolve NJLOGISTIC 08:30-17:30 โดยไม่ hardcode UUID', /shift_name\)\)\s*=\s*'njlogistic'/.test(sql) && /time '08:30'/.test(sql) && /time '17:30'/.test(sql) && !/66f9aec2-8bc4-4fe1-83ce-d335f5a12e34/.test(sql));
chk('Migration ไม่มี DELETE employee_shifts/attendance', !/delete\s+from\s+public\.(employee_shifts|attendance)/i.test(sql));
console.log(`\nPASS ${P} · FAIL ${F}`); process.exit(F?1:0);
