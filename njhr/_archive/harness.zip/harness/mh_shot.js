#!/usr/bin/env node
/* mh_shot.js — ถ่ายภาพหน้าหลักมือถือจริงที่ 390×844 ทั้ง USER และ SUPER_ADMIN
   ใช้: node harness/mh_shot.js [port] [outDir]
   ต้องมี puppeteer-core + Chromium (ตั้งค่าพาธผ่าน NJHR_CHROME)

   ตอบทุก request ที่ยิงไป Supabase ด้วย harness/mh_fixtures.js
   ไม่แตะ Production · ไม่ต่อฐานข้อมูลจริง */
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const MF = require('./mh_fixtures.js');

const ROOT = path.join(__dirname, '..');
const PORT = Number(process.argv[2] || 8910);
const OUT = process.argv[3] || path.join(ROOT, 'harness', 'shots');
const TAG = process.env.NJHR_SHOT_TAG ? '_' + process.env.NJHR_SHOT_TAG : '';
const CHROME = process.env.NJHR_CHROME || require(require('path').join(__dirname, 'browser.js')).findBrowser() || '/tmp/chromium';

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.json': 'application/json' };

function serve(port) {
  return new Promise(r => {
    const s = http.createServer((rq, rs) => {
      let p = decodeURIComponent(rq.url.split('?')[0]);
      if (p === '/') p = '/index.html';
      const f = path.join(ROOT, p);
      if (!f.startsWith(ROOT) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) {
        rs.writeHead(404); return rs.end();
      }
      rs.writeHead(200, { 'Content-Type': TYPES[path.extname(f)] || 'application/octet-stream' });
      rs.end(fs.readFileSync(f));
    }).listen(port, () => r(s));
  });
}

(async () => {
  if (!fs.existsSync(CHROME)) {
    console.error('ไม่พบ Chromium ที่ ' + CHROME + ' — ตั้งค่า NJHR_CHROME ให้ชี้ไฟล์จริงก่อน');
    process.exit(1);
  }
  const puppeteer = require('puppeteer-core');
  fs.mkdirSync(OUT, { recursive: true });
  const srv = await serve(PORT);
  /* ห้ามใช้ --single-process: เปิด BrowserContext ที่สองแล้ว Chromium ตาย
     จึงเปิดเบราว์เซอร์ใหม่ต่อ 1 Role ไปเลย สะอาดและไม่มีสถานะข้ามกัน */
  const LAUNCH = {
    executablePath: CHROME, headless: true,
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu',
           '--font-render-hinting=none', '--hide-scrollbars']
  };

  const report = {};
  for (const role of ['USER', 'SUPER_ADMIN']) {
    const acc = MF.ACCOUNTS[role];
    const browser = await puppeteer.launch(LAUNCH);
    const page = await browser.newPage();
    const errors = [];
    const netFail = [];
    page.on('pageerror', e => errors.push(String(e.message)));
    /* ห้ามซ่อน Error — บันทึกทุก request ที่ล้มเหลวพร้อมสาเหตุ
       ปกปิดเฉพาะ URL ของรูป/Signed URL ตามข้อกำหนดความปลอดภัย */
    page.on('requestfailed', r => {
      const u = r.url();
      const safe = /^data:/.test(u) ? '(data URI ของรูปพนักงาน — ปกปิด)'
        : (u.indexOf('/storage/v1/object/sign') >= 0 || u.indexOf('/functions/v1/njhr-emp-file') >= 0)
          ? '(URL ของรูปพนักงาน — ปกปิด)' : u;
      netFail.push({ url: safe, reason: (r.failure() || {}).errorText || 'unknown',
                     type: r.resourceType() });
    });
    page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });

    await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2, isMobile: true,
                             hasTouch: true });
    await page.setRequestInterception(true);
    page.on('request', req => {
      const url = req.url();
      const CORS = {
        'access-control-allow-origin': '*',
        'access-control-allow-methods': 'POST, GET, OPTIONS',
        'access-control-allow-headers': 'authorization, apikey, content-type, x-client-info, prefer',
        'access-control-max-age': '600'
      };
      if (url.indexOf('/rest/v1/rpc/') >= 0 || url.indexOf('/functions/v1/') >= 0) {
        if (req.method() === 'OPTIONS') {
          return req.respond({ status: 204, headers: CORS, body: '' });
        }
        const fn = url.indexOf('/rpc/') >= 0
          ? url.split('/rpc/')[1].split('?')[0]
          : url.split('/functions/v1/')[1].split('?')[0];
        let body = {};
        try { body = JSON.parse(req.postData() || '{}'); } catch (e) { }
        return req.respond({ status: 200, contentType: 'application/json',
          headers: CORS, body: JSON.stringify(MF.respond(fn, body, acc)) });
      }
      if (url.indexOf('127.0.0.1') < 0 && url.indexOf('localhost') < 0) return req.abort();
      return req.continue();
    });

    /* ตั้ง session ก่อนสคริปต์ของหน้าทำงาน — ไม่พึ่งลำดับ set แล้ว reload */
    await page.evaluateOnNewDocument(a => {
      try {
        localStorage.setItem('njhr_token', a.session_token);
        localStorage.setItem('njhr_sb_user', JSON.stringify(a));
      } catch (e) { }
    }, acc);
    await page.goto('http://127.0.0.1:' + PORT + '/index.html#/dashboard', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 3000));

    const shot = path.join(OUT, 'mh_' + role + TAG + '_390x844.png');
    const buf = await page.screenshot({ path: shot });
    const full = path.join(OUT, 'mh_' + role + TAG + '_full.png');
    await page.screenshot({ path: full, fullPage: true });
    /* เลื่อนสุดหน้าแล้วถ่ายอีกใบ — ใช้ตรวจว่า Bottom Navigation บังการ์ดประกาศจริงหรือไม่ */
    await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));
    await new Promise(r => setTimeout(r, 400));
    await page.screenshot({ path: path.join(OUT, 'mh_' + role + TAG + '_bottom.png') });

    const info = await page.evaluate(() => {
      const q = s => document.querySelector(s);
      const txt = s => { const n = q(s); return n ? n.textContent.trim() : null; };
      const root = q('#mh-root');
      return {
        mounted: !!root,
        hDoc: document.documentElement.scrollWidth,
        wDoc: document.documentElement.clientWidth,
        overflowX: document.documentElement.scrollWidth > document.documentElement.clientWidth,
        bg: root ? getComputedStyle(root).backgroundImage.slice(0, 60) : null,
        name: txt('.mh-emp b'),
        code: txt('#mh-code'),
        dept: txt('#mh-dept'),
        deptRowHidden: q('.mh-dept') ? q('.mh-dept').hidden : null,
        deptDash: (document.body.innerText.indexOf('แผนก: —') >= 0),
        strip: txt('#mh-emp-st em'),
        stats: Array.prototype.map.call(document.querySelectorAll('.mh-st'),
          n => n.querySelector('small').textContent.trim() + '=' + n.querySelector('b').textContent.trim()),
        statSvg: document.querySelectorAll('.mh-st-ic svg').length,
        today: txt('#mh-st'),
        pend: Array.prototype.map.call(document.querySelectorAll('.mh-pd b'), n => n.textContent.trim()),
        pendIcons: Array.prototype.map.call(document.querySelectorAll('.mh-pd-ic'), n => n.className),
        ann: txt('.mh-ann small'),
        annBtn: !!q('.mh-ann-go'),
        bnav: Array.prototype.map.call(document.querySelectorAll('.bn-item'),
          n => n.textContent.trim() + (n.classList.contains('active') ? '*' : '')),
        bnavActiveColor: q('.bn-item.active') ? getComputedStyle(q('.bn-item.active')).color : null,
        emoji: /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/u.test(
          (q('#mh-root') || document.body).innerText),
        /* รูปพนักงานมาจากไหน — ไม่คืนค่า URL ออกมา คืนแค่ชนิดของแหล่ง */
        photoSource: (function () {
          const img = q('#mh-av img');
          if (!img) return q('#mh-av .avatar') ? 'letter-avatar' : 'none';
          if (!img.complete || img.naturalWidth === 0) return 'img-broken';
          const src = img.getAttribute('src') || '';
          return (src.slice(0, 5) === 'data:' ? 'data-uri' : 'http-url') +
                 ' ' + img.naturalWidth + 'x' + img.naturalHeight;
        })(),
        hash: location.hash,
        hasToken: !!localStorage.getItem('njhr_token'),
        onLogin: !!q('#login-form, .login-card, form#lgf') || /เข้าสู่ระบบ/.test((q('#app')||{}).innerText||''),
        /* วัดหลังเลื่อนสุดหน้าแล้วเท่านั้น จึงจะบอกได้ว่าถูก Bottom Navigation บังจริง */
        annBottom: (function () {
          window.scrollTo(0, document.documentElement.scrollHeight);
          const a = q('.mh-ann'), n = q('.bottom-nav');
          if (!a || !n) return null;
          return Math.round(n.getBoundingClientRect().top - a.getBoundingClientRect().bottom);
        })(),
        docH: document.documentElement.scrollHeight
      };
    });
    info.errors = errors;
    info.netFail = netFail;
    info.photoMode = MF.PHOTO_MODE;
    info.md5 = crypto.createHash('md5').update(buf).digest('hex');
    report[role] = info;
    await page.close();
    await browser.close();
  }

  srv.close();
  fs.writeFileSync(path.join(OUT, 'mh_report' + TAG + '.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify(report, null, 2));
})();
