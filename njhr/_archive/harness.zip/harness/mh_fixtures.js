/* mh_fixtures.js — ข้อมูลจำลองสำหรับถ่ายภาพหน้าหลักมือถือเท่านั้น
   ค่าคงที่ทั้งหมด ไม่มี random · ใช้กับ harness/mh_shot.js เท่านั้น
   ไม่มีโค้ดของแอปอ่านไฟล์นี้ และแอปไม่ได้ hardcode ค่าเหล่านี้ไว้ที่ใด */
const F = require('./fixtures.js');

const TODAY = '2026-08-10';
const MON_S = '2026-08-01', MON_E = '2026-08-31';

/* บัญชีทดสอบ 2 Role — ข้อมูลพนักงานชุดเดียวกันทั้งคู่ เพื่อเทียบหน้าตาให้ตรงกัน */
const NOEMP = {
  user_id: 'user-0099', username: 'orphan', role: 'USER',
  employee_id: null, emp_code: null, emp_name: 'บัญชีไม่ผูกพนักงาน',
  full_name: 'บัญชีไม่ผูกพนักงาน', department: '', emp_department: '',
  emp_position: '', emp_status: 'ACTIVE', session_token: 'MOCK-NOEMP'
};
const ACCOUNTS = {
  NOEMP: NOEMP,
  USER: {
    user_id: 'user-0004', username: 'jamlong', role: 'USER',
    employee_id: 'emp-0004', emp_code: '0004', emp_name: 'นายจำลอง ผาเทพ',
    full_name: 'นายจำลอง ผาเทพ', department: 'MANAGER', emp_department: 'MANAGER',
    emp_position: 'ผู้จัดการ', emp_status: 'ACTIVE', session_token: 'MOCK-USER'
  },
  SUPER_ADMIN: {
    user_id: 'user-0001', username: 'jamrat', role: 'SUPER_ADMIN',
    employee_id: 'emp-0004', emp_code: '0004', emp_name: 'นายจำลอง ผาเทพ',
    full_name: 'นายจำลอง ผาเทพ', department: 'MANAGER', emp_department: 'MANAGER',
    emp_position: 'ผู้จัดการ', emp_status: 'ACTIVE', session_token: 'MOCK-SUPER'
  }
};

/* njhr_att_report — 7 วันที่มี check_in (มาทำงาน 7) · ไม่มี late_min (มาสาย 0) */
const ATT = [];
for (let d = 3; d <= 9; d++) {
  ATT.push({
    employee_id: 'emp-0004', emp_code: '0004',
    work_date: '2026-08-' + String(d).padStart(2, '0'),
    check_in: '2026-08-' + String(d).padStart(2, '0') + 'T08:02:00+07:00',
    check_out: '2026-08-' + String(d).padStart(2, '0') + 'T17:30:00+07:00',
    late_min: 0
  });
}

/* njhr_leave_report — APPROVED 1 วัน + PENDING 1 ใบ (ขึ้นรายการรออนุมัติ) */
const LEAVE = [
  { req_id: 'lv-1', employee_id: 'emp-0004', emp_code: '0004', leave_type: 'ลากิจ',
    start_date: '2026-08-06', end_date: '2026-08-06', total_days: 1, status: 'APPROVED' },
  { req_id: 'lv-2', employee_id: 'emp-0004', emp_code: '0004', leave_type: 'ลาป่วย',
    start_date: '2026-08-14', end_date: '2026-08-14', total_days: 1, status: 'PENDING' }
];

/* njhr_ot_list — APPROVED 4 ชม. + PENDING 1 ใบ */
const OT = [
  { id: 'ot-1', employee_id: 'emp-0004', emp_code: '0004', ot_date: '2026-08-05',
    hours: 4, ot_hours: 4, status: 'APPROVED' },
  { id: 'ot-2', employee_id: 'emp-0004', emp_code: '0004', ot_date: '2026-08-12',
    hours: 3, ot_hours: 3, status: 'PENDING' }
];

/* njhr_att_correction_list — PENDING 1 ใบ */
const COR = [
  { id: 'cr-1', employee_id: 'emp-0004', work_date: '2026-08-04',
    new_check_in: '2026-08-04T08:00:00+07:00', status: 'PENDING' }
];

const ANN = [{
  id: 'ann-1', title: 'วันหยุดบริษัท 12 สิงหาคม 2569',
  content: 'เนื่องในวันแม่แห่งชาติ บริษัทขอแจ้งวันหยุดทำการในวันอังคารที่ 12 สิงหาคม 2569',
  publish_at: '2026-08-05T09:00:00+07:00', is_read: false, is_important: true,
  require_ack: false, acked: false, unread_count: 1
}];

/* โหมดรูปพนักงาน — ใช้พิสูจน์ทั้ง 2 เส้นทางของโค้ด โดยไม่ต้องมีรูปจริงและไม่ออกเน็ต
     none = ไม่มีรูป (ตรงกับสภาพ Production วันนี้: njhr_emp_files มี PERSONAL/PHOTO 0 แฟ้ม)
     url  = photo_url เป็น URL เต็ม  → โค้ดต้องใช้ตรง ๆ
     path = photo_url เป็น path ใน Storage → โค้ดต้องขอ Signed URL ผ่าน Edge Function */
const PHOTO_MODE = String(process.env.NJHR_PHOTO_MODE || 'none').toLowerCase();
/* รูปทดสอบเป็น data URI ในไฟล์นี้เอง — ไม่มี request ออกเน็ตแม้แต่ครั้งเดียว */
const TEST_IMG = 'data:image/svg+xml;utf8,' + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="132" height="132">' +
  '<rect width="132" height="132" fill="#1D4ED8"/>' +
  '<circle cx="66" cy="50" r="24" fill="#BFDBFE"/>' +
  '<ellipse cx="66" cy="118" rx="42" ry="34" fill="#BFDBFE"/></svg>');
const PHOTO_FILE_ID = '00000000-0000-4000-8000-000000000001';
function photoValue() {
  if (PHOTO_MODE === 'url') return TEST_IMG;
  if (PHOTO_MODE === 'path') return 'PERSONAL/PHOTO/emp-0004/photo.jpg';
  return '';
}


/* ---------- สถานการณ์หน้าลงเวลา (ทดสอบเท่านั้น ไม่ใช่ข้อมูล Production) ----------
   NJHR_ATT_CASE: none | in | done | outside | denied | noemp | noshift */
const ATT_CASE = String(process.env.NJHR_ATT_CASE || 'none').toLowerCase();
const SHIFT = { shift_name: 'กะเช้า', shift_start: '08:30:00', shift_end: '17:30:00' };
function attToday() {
  const base = ATT_CASE === 'noshift' ? {} : SHIFT;
  if (ATT_CASE === 'in') {
    return [Object.assign({}, base, { work_date: TODAY, status: 'NORMAL', late_min: 0,
      check_in: TODAY + 'T08:25:00+07:00', check_out: null, work_hours: null })];
  }
  if (ATT_CASE === 'done') {
    return [Object.assign({}, base, { work_date: TODAY, status: 'NORMAL', late_min: 0,
      check_in: TODAY + 'T08:25:00+07:00', check_out: TODAY + 'T17:34:00+07:00', work_hours: 9.1 })];
  }
  return [Object.assign({}, base, { work_date: TODAY, status: null, late_min: 0,
    check_in: null, check_out: null, work_hours: null })];
}
function gfCheck() {
  if (ATT_CASE === 'outside') return { pass: false, geofence_name: 'สำนักงานใหญ่' };
  return { pass: true, geofence_name: 'สำนักงานใหญ่' };
}


/* ---- ข้อมูลหน้าคำขอ (Harness เท่านั้น ไม่ใช่ข้อมูล Production) ---- */
const LEAVE_LIST = [
  { id: 'lv-1', leave_type: 'ลาป่วย', start_date: '2026-08-10', end_date: '2026-08-10',
    total_days: 1, hours: 0, status: 'PENDING', created_at: '2026-08-09T09:00:00Z' },
  { id: 'lv-2', leave_type: 'ลากิจ', start_date: '2026-08-06', end_date: '2026-08-06',
    total_days: 1, hours: 0, status: 'APPROVED', created_at: '2026-08-04T09:00:00Z' },
  { id: 'lv-3', leave_type: 'ลาพักร้อน', start_date: '2026-07-28', end_date: '2026-07-29',
    total_days: 2, hours: 0, status: 'REJECTED', created_at: '2026-07-25T09:00:00Z' }
];
const OT_MINE = [
  { id: 'ot-9', ot_date: '2026-08-08', ot_hours: 2, status: 'APPROVED',
    created_at: '2026-08-07T09:00:00Z' },
  { id: 'ot-8', ot_date: '2026-08-12', ot_hours: 3, status: 'PENDING',
    created_at: '2026-08-06T09:00:00Z' }
];
const COR_MINE = [
  { id: 'cr-3', work_date: '2026-08-04', new_check_in: '2026-08-04T08:00:00+07:00',
    new_check_out: '2026-08-04T17:30:00+07:00', status: 'CANCELLED',
    created_at: '2026-08-03T09:00:00Z' }
];
const BALANCES = [
  { leave_type: 'SICK', quota: 30, used: 0, pending: 0, remaining: 30 },
  { leave_type: 'PERSONAL', quota: 10, used: 0, pending: 0, remaining: 10 },
  { leave_type: 'VACATION', quota: 6, used: 0, pending: 0, remaining: 6 }
];
/* NJHR_REQ_MODE: full | empty | nobal | fail-leave | fail-ot | fail-fix */
const REQ_MODE = String(process.env.NJHR_REQ_MODE || 'full').toLowerCase();


/* ---- REPORT ALL fixture (Harness เท่านั้น · ไม่เข้า Production Build) ----
   4 กรณี: มีสแกน · มีลา · มี OT · ไม่มีข้อมูลเลย */
/* njhr_report_all_employees (L1) คืน full_name เป็น "ชื่อ นามสกุล" รวมกัน
   ตัวแปลงที่ src/11-view-approvals-payroll.js:1198 แยกที่ช่องว่างแรก
   Fixture จึงต้องใช้ full_name ไม่ใช่ first_name/last_name */
const RA_EMPS = [
  { id: 'e1', emp_code: 'A001', prefix: 'นาย', full_name: 'สแกน ครบวัน',
    department_name: 'IT', position_name: 'STAFF', base_salary: 30000, status: 'ACTIVE' },
  { id: 'e2', emp_code: 'A002', prefix: 'นาง', full_name: 'ลา ป่วยกิจ',
    department_name: 'IT', position_name: 'STAFF', base_salary: 24000, status: 'ACTIVE' },
  { id: 'e3', emp_code: 'A003', prefix: 'นาย', full_name: 'โอที ล่วงเวลา',
    department_name: 'OPS', position_name: 'STAFF', base_salary: 18000, status: 'ACTIVE' },
  { id: 'e4', emp_code: 'A004', prefix: 'นางสาว', full_name: 'ไม่มี ข้อมูล',
    department_name: 'OPS', position_name: 'STAFF', base_salary: 15000, status: 'ACTIVE' }
];
/* e1: 3 วัน เข้าครบ 3 ออกครบ 3 · วันที่ 3 มีสแกนเข้า 2 แถว (ต้องนับ 1)
   e2: 1 วัน เข้ามี ออกไม่มี  · e3: 1 วัน เข้าไม่มี ออกมี  · e4: ไม่มีแถวเลย */
const RA_ATT = [
  { employee_id: 'e1', emp_code: 'A001', work_date: '2026-08-03',
    check_in: '2026-08-03T08:00:00+07:00', check_out: '2026-08-03T17:00:00+07:00', late_min: 0 },
  { employee_id: 'e1', emp_code: 'A001', work_date: '2026-08-04',
    check_in: '2026-08-04T08:20:00+07:00', check_out: '2026-08-04T17:05:00+07:00', late_min: 20 },
  { employee_id: 'e1', emp_code: 'A001', work_date: '2026-08-05',
    check_in: '2026-08-05T07:55:00+07:00', check_out: '2026-08-05T17:02:00+07:00', late_min: 0 },
  { employee_id: 'e1', emp_code: 'A001', work_date: '2026-08-05',
    check_in: '2026-08-05T13:00:00+07:00', check_out: '2026-08-05T18:00:00+07:00', late_min: 0 },
  { employee_id: 'e2', emp_code: 'A002', work_date: '2026-08-03',
    check_in: '2026-08-03T08:10:00+07:00', check_out: null, late_min: 10 },
  { employee_id: 'e3', emp_code: 'A003', work_date: '2026-08-03',
    check_in: null, check_out: '2026-08-03T17:30:00+07:00', late_min: 0 }
];
const RA_LEAVE = [
  { id: 'l1', employee_id: 'e2', emp_code: 'A002', leave_type: 'ลาป่วย', type_name: 'ลาป่วย',
    start_date: '2026-08-06', end_date: '2026-08-07', total_days: 2, hours: 0,
    mode: 'DAILY', status: 'APPROVED' },
  { id: 'l2', employee_id: 'e2', emp_code: 'A002', leave_type: 'ลากิจ', type_name: 'ลากิจ',
    start_date: '2026-08-10', end_date: '2026-08-10', total_days: 1, hours: 0,
    mode: 'DAILY', status: 'APPROVED' }
];
/* njhr_report_all_ot (O2) คืน approver_name มาให้ตรง ๆ · '—' เมื่อไม่มีผู้อนุมัติจริง */
const RA_OT = [
  { id: 'o1', employee_id: 'e3', emp_code: 'A003', ot_date: '2026-08-04',
    start_time: '18:00', end_time: '21:00', spans_next_day: false, ot_hours: 3,
    status: 'APPROVED', prefix: 'นาย', emp_name: 'โอที ล่วงเวลา',
    department: 'OPS', position_name: 'STAFF',
    approver_name: 'นายจำรัส ผาเทพ, นางสาวปราณี ศรีทอง' }
];
const RA_COR = [
  { id: 'c1', employee_id: 'e1', emp_code: 'A001', work_date: '2026-08-04',
    new_check_in: '2026-08-04T08:00:00+07:00', status: 'APPROVED' }
];

function meGet(acc) {
  return {
    data: {
      perm: { role: acc.role, self_role: acc.role === 'USER' ? 'USER' : acc.role,
              username: acc.username, can_edit_personal: true, editable_fields: [] },
      employee: {
        id: acc.employee_id, emp_code: acc.emp_code, photo_url: photoValue(),
        prefix: 'นาย', first_name: 'จำลอง', last_name: 'ผาเทพ',
        full_name: acc.emp_name, department_name: acc.emp_department,
        position_name: acc.emp_position, level: '', start_date: '2020-03-02',
        emp_type: 'MONTHLY', status: 'ACTIVE', nickname: '', birth_date: null,
        national_id: '', phone: '', email: '', address: '', emergency_phone: ''
      },
      personal: { complete: true, filled: 7, total: 7, missing: [] },
      documents: { complete: true, filled: 3, total: 3, missing: [], items: [] },
      overall_complete: true
    }
  };
}

function respond(fn, body, acc) {
  switch (fn) {
    case 'njhr_healthcheck': return { ok: true, project_ready: true, version: 'mock' };
    case 'njhr_session_check': return acc;
    case 'njhr_login': return acc;
    case 'njhr_me_get': return meGet(acc);
    case 'njhr_att_today': return attToday();
    case 'njhr_gf_check': return gfCheck();
    case 'njhr_att_report': return (REQ_MODE === 'reportall') ? RA_ATT : ATT;
    case 'njhr_leave_report': return (REQ_MODE === 'reportall') ? RA_LEAVE : LEAVE;
    case 'njhr_ot_list':
      if (REQ_MODE === 'empty') return [];
      if (REQ_MODE === 'fail-ot') throw new Error('__RPC_FAIL__');
      return OT;                      // ชุดเดียวกับหน้าหลัก — Baseline หน้าอื่นจึงไม่เปลี่ยน
    case 'njhr_ann_feed': return ANN;
    case 'njhr_calendar_month': return {
      from: body && body.p_from, to: body && body.p_to,
      departments: [{ id: '11111111-1111-1111-1111-111111111111', code: 'IT', name: 'เทคโนโลยีสารสนเทศ' }],
      holidays: [{ holiday_date: '2026-08-12', name: 'วันแม่แห่งชาติ' }],
      leaves: [{ start_date: '2026-08-06', end_date: '2026-08-06', display_name: 'จำลอง', department: 'MANAGER' }],
      ot: [{ ot_date: '2026-08-05', display_name: 'จำลอง', department: 'MANAGER' }] };
    /* ---- Workflow (Harness เท่านั้น · ไม่เข้า Production Build) ---- */
    case 'njhr_report_all_employees': return RA_EMPS;
    case 'njhr_report_all_ot': return RA_OT;
    case 'njhr_pay_entry_totals': return [];
    case 'njhr_wf_list': return [
      { workflow_id: 'wf-1', wf_name: 'ชุดอนุมัติ · ACCOUNT', request_type: 'BOTH',
        active: true, scope: 'DEPT', anchor_dept: 'ACCOUNT', step_count: 1, approver_count: 2 },
      { workflow_id: 'wf-2', wf_name: 'ชุดอนุมัติ · CUSTOMER SERVICE EXPORT', request_type: 'BOTH',
        active: true, scope: 'DEPT', anchor_dept: 'CUSTOMER SERVICE EXPORT', step_count: 3, approver_count: 4 },
      { workflow_id: 'wf-3', wf_name: 'ชุดอนุมัติ · CUSTOMER SERVICE IMPORT AND LOGISTICS DEPARTMENT', request_type: 'LEAVE',
        active: true, scope: 'DEPT', anchor_dept: 'CUSTOMER SERVICE IMPORT', step_count: 3, approver_count: 3 },
      { workflow_id: 'wf-4', wf_name: 'ชุดอนุมัติ · SHIPPING AIRPORT', request_type: 'BOTH',
        active: true, scope: 'DEPT', anchor_dept: 'SHIPPING AIRPORT', step_count: 2, approver_count: 2 },
      { workflow_id: 'wf-5', wf_name: 'ชุดอนุมัติ · LCB', request_type: 'LEAVE',
        active: true, scope: 'DEPT', anchor_dept: 'SHIPPING LCB', step_count: 2, approver_count: 3 },
      { workflow_id: 'wf-6', wf_name: 'ชุดอนุมัติ · ทุกแผนก', request_type: 'OT',
        active: false, scope: 'ALL', anchor_dept: null, step_count: 0, approver_count: 0 }];
    case 'njhr_wf_steps': return [
      { step_no: 1, step_name: 'หัวหน้าแผนก', active: true, approve_mode: 'ANY',
        approvers: [{ name: 'นายสมชาย ใจดี', position: 'MANAGER' },
                    { name: 'นางสาวมาลี สุขใจ', position: 'ASSISTANT MANAGER' }] },
      { step_no: 2, step_name: 'ฝ่ายบุคคล', active: true, approve_mode: 'ALL',
        approvers: [{ name: 'นางสาวปราณี ศรีทอง', position: 'HR MANAGER' }] },
      { step_no: 3, step_name: 'กรรมการผู้จัดการ', active: true, approve_mode: 'ANY',
        approvers: [{ name: 'นายจำรัส ผาเทพ', position: 'MANAGING DIRECTOR' }] }];
    case 'njhr_wf_overview': return [
      { department: 'MANAGER', leave_steps: 0, ot_steps: 1 },
      { department: 'MANAGING DIRECTOR', leave_steps: 0, ot_steps: 1 }];
    case 'njhr_dept_list': return [
      { id: '11111111-1111-1111-1111-111111111111', code: 'IT', name: 'เทคโนโลยีสารสนเทศ' }];
    case 'njhr_holiday_list': return [
      { id: 'h1', holiday_date: '2026-03-03', dow_th: 'อังคาร', name: 'วันมาฆบูชา', is_weekend: false },
      { id: 'h2', holiday_date: '2026-04-13', dow_th: 'จันทร์', name: 'วันสงกรานต์', is_weekend: false },
      { id: 'h3', holiday_date: '2026-08-12', dow_th: 'พุธ', name: 'วันแม่แห่งชาติ', is_weekend: false }];
    case 'njhr_holiday_impact': return { leaves: 0, work_days: 244, holidays: 19 };
    /* ---- ทดสอบยื่นลางาน/OT (Harness เท่านั้น) ----
       บันทึก payload ที่หน้าเว็บส่งมา เพื่อยืนยันว่า p_files เป็น [] ได้ */
    case 'njhr_leave_submit':
      global.__lvSubmit = (global.__lvSubmit || []).concat([body]);
      return { id: '00000000-0000-4000-8000-00000000ab01', total_days: 1, hours: 0,
               duplicated: false, file_count: (body && body.p_files ? body.p_files.length : 0) };
    case 'njhr_ot_submit':
      global.__otSubmit = (global.__otSubmit || []).concat([body]);
      return [{ id: '00000000-0000-4000-8000-00000000cd01', ot_date: body && body.p_date,
                ot_hours: 3, jobs: 1, status: 'PENDING' }];
    case 'njhr_leave_types': return [
      { code: 'SICK', label_th: 'ลาป่วย', color: '#DC2626', active: true, need_doc: true,
        doc_after_days: 0, approval_mode: 'ANY', sort_order: 1, quota_field: 'leave_sick' },
      { code: 'PERSONAL', label_th: 'ลากิจ', color: '#2563EB', active: true, need_doc: false,
        doc_after_days: 0, approval_mode: 'ANY', sort_order: 2, quota_field: 'leave_personal' }];
    case 'njhr_leave_balances':
      return REQ_MODE === 'nobal' ? [] : BALANCES;
    case 'njhr_leave_list':
      if (REQ_MODE === 'empty') return [];
      if (REQ_MODE === 'fail-leave') throw new Error('__RPC_FAIL__');
      return LEAVE_LIST;
    case 'njhr_att_correction_list':
      if (REQ_MODE === 'reportall') return RA_COR;
      if (REQ_MODE === 'empty') return [];
      if (REQ_MODE === 'fail-fix') throw new Error('__RPC_FAIL__');
      return COR;                     // ชุดเดียวกับหน้าหลัก — Baseline หน้าอื่นจึงไม่เปลี่ยน
    case 'njhr_empfile_list': return { data: { files: PHOTO_MODE === 'path'
      ? [{ id: PHOTO_FILE_ID, category: 'PERSONAL', doc_kind: 'PHOTO',
           file_name: 'photo.jpg', mime_type: 'image/jpeg', file_size: 1024, version: 1 }]
      : [] } };
    /* Edge Function njhr-emp-file — ตอบ Signed URL จำลอง (เป็น data URI ไม่ออกเน็ต) */
    case 'njhr-emp-file':
      if (body && body.action === 'download-url' && body.file_id === PHOTO_FILE_ID) {
        return { url: TEST_IMG, file_name: 'photo.jpg', mime_type: 'image/jpeg', expires_in: 60 };
      }
      return { error: 'ไม่พบไฟล์' };
    case 'njhr_notify_unread': return Number(process.env.NJHR_UNREAD || 3);
    case 'njhr_notify_list': return [
      { id: 'nt-1', title: 'คำขอลาได้รับอนุมัติ', body: 'ลาป่วย 10 ส.ค. 2569 อนุมัติแล้ว',
        link: '#/leave', kind: 'leave', module: 'leave', reference_id: 'lv-1',
        is_read: false, created_at: '2026-08-10T02:41:00+00:00', unread_count: 3, total_count: 8 },
      { id: 'nt-2', title: 'มีคำขอ OT รออนุมัติ', body: 'จำลอง ผาเทพ ขอ OT 12 ส.ค. 2569 3 ชั่วโมง',
        link: '#/approvals', kind: 'ot', module: 'ot', reference_id: 'ot-8',
        is_read: false, created_at: '2026-08-09T09:00:00+00:00', unread_count: 3, total_count: 8 },
      { id: 'nt-3', title: 'ประกาศใหม่จากองค์กร', body: 'วันหยุดบริษัท 12 สิงหาคม 2569',
        link: '#/announcements', kind: 'ann', module: 'ann', reference_id: 'ann-1',
        is_read: false, created_at: '2026-08-05T02:00:00+00:00', unread_count: 3, total_count: 8 }];
    case 'njhr_notify_read': return true;
    case 'njhr_notify_read_all': return 3;
    /* njhr_leave_queue — โครงสร้างตรง RPC จริง 21 คอลัมน์ (41_leave_rpc.sql:213)
       Harness เท่านั้น ไม่เข้า Production Build */
    /* njhr_leave_detail — Timeline 3 ขั้นตามผังอนุมัติจริง (Harness เท่านั้น) */
    case 'njhr_leave_detail': return {
      id: body && body.p_leave_id, employee_id: 'e1', emp_name: 'สมชาย ใจดี',
      leave_type: 'SICK', status: 'PENDING', ui_status: 'PENDING',
      attachments: [],
      approvals: [
        { seq: 1, action: 'SUBMIT', action_th: 'ผู้ขอ', by_name: 'สมชาย ใจดี',
          at: '11 ส.ค. 2569 09:21', note: '' },
        { seq: 2, action: 'PENDING', action_th: 'หัวหน้างาน', by_name: 'รออนุมัติ',
          at: '', note: '' },
        { seq: 3, action: 'PENDING', action_th: 'ฝ่ายทรัพยากรบุคคล', by_name: 'รออนุมัติ',
          at: '', note: '' }] };
    case 'njhr_leave_queue': return [
      { id: 'aa000001-0000-4000-8000-000000000001', employee_id: 'e1', emp_code: 'A001',
        emp_name: 'สมชาย ใจดี', department: 'CUSTOMER SERVICE IMPORT', leave_type: 'SICK',
        start_date: '2026-08-12', end_date: '2026-08-12', leave_unit: 'day',
        start_time: null, end_time: null, hours: 0, is_halfday: false, total_days: 1,
        reason: 'มีอาการไม่สบาย เป็นไข้', status: 'PENDING', ui_status: 'PENDING',
        created_at: '2026-08-11T02:21:00Z', file_name: 'ใบรับรองแพทย์.pdf',
        remaining: 29, total_count: 2 },
      { id: 'aa000002-0000-4000-8000-000000000002', employee_id: 'e2', emp_code: 'A002',
        emp_name: 'กนกวรรณ มีสุข', department: 'ACCOUNT', leave_type: 'PERSONAL',
        start_date: '2026-08-06', end_date: '2026-08-07', leave_unit: 'day',
        start_time: null, end_time: null, hours: 0, is_halfday: false, total_days: 2,
        reason: 'ธุระส่วนตัว', status: 'APPROVED', ui_status: 'APPROVED',
        created_at: '2026-08-04T02:00:00Z', file_name: null,
        remaining: 8, total_count: 2 }];
    default: return F.respond(fn, body);
  }
}

module.exports = { ACCOUNTS, respond, TODAY, MON_S, MON_E, PHOTO_MODE, ATT_CASE };
