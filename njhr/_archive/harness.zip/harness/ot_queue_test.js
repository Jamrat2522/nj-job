/* ot_queue_test.js — ข้อ 2: คิวคำขอ OT ต้องไม่ยิง RPC ต่อรายการอีก
     ก่อนแก้:  njhr_ot_list 1 + (njhr_ot_get + njhr_ot_attach_list) x N  =  2N + 1
     หลังแก้:  njhr_ot_approval_queue 1 ครั้ง จบ

   ตรวจสองเส้นทาง
     1. Production รัน 91 แล้ว        → ต้องยิง 1 ครั้ง
     2. Production ยังไม่ได้รัน 91    → ต้องถอยไปเส้นทางเดิมได้ ไม่พัง

   ใช้: node harness/ot_queue_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(56) + (d || '')); }

const src = fs.readFileSync(path.join(ROOT, 'src/11-view-approvals-payroll.js'), 'utf8');
const sql = fs.readFileSync(path.join(ROOT, 'supabase-new/91_ot_approval_queue.sql'), 'utf8');
const sql65 = fs.readFileSync(path.join(ROOT, 'supabase-new/65_ot.sql'), 'utf8');
const sql47 = fs.readFileSync(path.join(ROOT, 'supabase-new/47_ot_attachments.sql'), 'utf8');
const out = fs.readFileSync(path.join(ROOT, 'compat/app-legacy.js'), 'utf8');

/* ---------- จำลองการโหลดคิว แล้วนับ RPC จริง ---------- */
function simulate(queueInstalled, n) {
  const calls = [];
  const rows = [];
  for (let i = 0; i < n; i++) {
    rows.push({
      id: 'ot-' + i, request_no: '26010' + i, employee_id: 'e' + i,
      emp_code: '00' + i, prefix: 'นาย', emp_name: 'ทดสอบ ' + i,
      ot_date: '2026-08-10', start_time: '18:00:00', end_time: '21:00:00',
      ot_hours: 3, status: 'PENDING', total_count: n,
      department: 'ขนส่ง', position_name: 'พนักงาน',
      jobs: [{ no: 1, job_code: 'J' + i, detail: 'งาน', job_type: 'LOAD',
               job_date: '2026-08-10', start_time: '18:00:00', end_time: '21:00:00',
               spans_next_day: false, end_date: null, ot_hours: 3, note: '' }],
      attachments: [{ job_no: 1, job_code: 'J' + i, file_name: 'a.png',
                      file_url: 'https://x/a.png', file_path: 'p/a.png',
                      file_size: 10, content_type: 'image/png', created_at: null }]
    });
  }

  /* ตัดเฉพาะส่วนคิว OT ออกมารัน — ไม่ต้องบูตทั้งระบบ */
  const start = src.indexOf('  var _otQueueRpcMissing = false;');
  const end = src.indexOf('  /* การ์ดคำขอ OT');
  const code = src.slice(start, end);

  const NJHR = { state: {} };
  const ctx = {
    NJHR,
    sbToken: () => 'tk',
    sbRpcList(fn) {
      calls.push(fn);
      if (fn === 'njhr_ot_approval_queue') {
        if (!queueInstalled) {
          const e = new Error('Could not find the function public.njhr_ot_approval_queue in the schema cache');
          e.code = 'PGRST202';
          return Promise.reject(e);
        }
        return Promise.resolve(rows);
      }
      if (fn === 'njhr_ot_list') {
        return Promise.resolve(rows.map(r => {
          const c = Object.assign({}, r); delete c.jobs; delete c.attachments; return c;
        }));
      }
      if (fn === 'njhr_ot_attach_list') return Promise.resolve(rows[0].attachments);
      return Promise.resolve([]);
    },
    sbRpc(fn) {
      calls.push(fn);
      if (fn === 'njhr_ot_get') return Promise.resolve({ data: { jobs: rows[0].jobs } });
      return Promise.resolve({});
    },
    setOtPending() {},
    apprRender() {},
    apOtShape(row, detail, files) {
      const jobs = ((detail && detail.jobs) || []).map(j => ({
        no: Number(j.no) || 0, job: j.job_code || '',
        files: (files || []).filter(f => Number(f.job_no) === Number(j.no))
          .map(f => ({ name: f.file_name, url: f.file_url }))
      }));
      return { id: row.id, jobs };
    },
    _otSeq: 0,
    console: { error() {}, warn() {}, log() {} },
    document: { getElementById: () => null },
    Promise, Number, String, Object
  };

  const names = Object.keys(ctx);
  const fn = new Function(...names,
    'var _otQueue = [], _otLoading = false;\n' + code +
    '\nreturn { load: apprLoadOt, getQueue: function () { return _otQueue; } };');
  const api = fn(...names.map(k => ctx[k]));
  api.load({});
  return { calls, api };
}

(async function () {
  const wait = () => new Promise(r => setTimeout(r, 80));

  console.log('\n== เมื่อ Production รัน 91 แล้ว ==');
  for (const n of [1, 10, 50]) {
    const s = simulate(true, n);
    await wait();
    const legacy = s.calls.filter(x => x === 'njhr_ot_get' || x === 'njhr_ot_attach_list').length;
    console.log('   ' + String(n).padStart(3) + ' รายการ  →  ' + s.calls.length +
      ' RPC  (' + Array.from(new Set(s.calls)).join(', ') + ')   เดิมต้องใช้ ' + (2 * n + 1));
    chk(n + ' รายการ ยิง RPC ครั้งเดียว', s.calls.length === 1, s.calls.length + ' ครั้ง');
    chk(n + ' รายการ ไม่ยิงต่อรายการอีก', legacy === 0, legacy + ' ครั้ง');
    const q = s.api.getQueue();
    chk(n + ' รายการ ได้ข้อมูลครบทุกแถว', q.length === n, q.length + '/' + n);
    chk(n + ' รายการ รายการงานและไฟล์แนบมาครบ',
      q.length > 0 && q[0].jobs.length === 1 && q[0].jobs[0].files.length === 1, '');
  }

  console.log('\n== เมื่อยังไม่ได้รัน 91 (ทางถอย) ==');
  const s2 = simulate(false, 10);
  await wait();
  const uniq = Array.from(new Set(s2.calls));
  console.log('   10 รายการ  →  ' + s2.calls.length + ' RPC  (' + uniq.join(', ') + ')');
  chk('ลอง RPC ใหม่ก่อน', s2.calls[0] === 'njhr_ot_approval_queue', s2.calls[0]);
  chk('ถอยไปใช้ njhr_ot_list เดิม', uniq.indexOf('njhr_ot_list') >= 0, '');
  chk('หน้ายังใช้งานได้ ได้ข้อมูลครบ', s2.api.getQueue().length === 10,
    s2.api.getQueue().length + '/10');

  console.log('\n== ตรรกะการถอย ==');
  chk('ถอยเฉพาะเมื่อ RPC ยังไม่ถูกติดตั้ง',
    /pgrst202/.test(src.toLowerCase()) &&
    src.indexOf('could not find the function') >= 0, '');
  chk('ข้อผิดพลาดอื่นไม่ถอย (ไม่กลบปัญหาจริง)',
    src.indexOf('function _otQueueNotInstalled') >= 0 &&
    /if \(_otQueueNotInstalled\(ex\)\)/.test(src), '');
  chk('จำไว้ไม่ลองซ้ำทุกครั้ง', src.indexOf('_otQueueRpcMissing = true') >= 0, '');
  chk('ยังเก็บเส้นทางเดิมไว้', src.indexOf('function apprLoadOtLegacy') >= 0, '');

  console.log('\n== SQL 91 ==');
  chk('ระบุชัดว่ายังไม่ได้รัน', sql.indexOf('ยังไม่ได้รัน') >= 0, '');
  chk('สร้าง njhr_ot_approval_queue',
    sql.indexOf('create or replace function public.njhr_ot_approval_queue') >= 0, '');
  chk('ไม่แก้ njhr_ot_list เดิม',
    sql.indexOf('function public.njhr_ot_list') < 0, '');
  chk('ไม่แก้ njhr_ot_get เดิม', sql.indexOf('function public.njhr_ot_get') < 0, '');
  chk('ไม่แก้ njhr_ot_attach_list เดิม',
    sql.indexOf('function public.njhr_ot_attach_list') < 0, '');
  chk('ใช้ guard ตัวเดียวกับ njhr_ot_list (สิทธิ์เท่าเดิม)',
    sql.indexOf('njhr_ot_guard(p_token)') >= 0 &&
    sql65.indexOf('njhr_ot_guard(p_token)') >= 0, '');
  chk('เงื่อนไขการมองเห็นคัดลอกจาก njhr_ot_list',
    sql.indexOf('or not c.is_manager') >= 0 &&
    sql.indexOf('then o.employee_id = c.employee_id else true end') >= 0, '');
  chk('ไฟล์แนบใช้เงื่อนไขสิทธิ์เดียวกับ njhr_ot_attach_list',
    sql.indexOf("c.role in ('SUPER_ADMIN','ADMIN','HR','MANAGER')") >= 0 &&
    sql47.indexOf("c.role in ('SUPER_ADMIN','ADMIN','HR','MANAGER')") >= 0, '');
  chk('กรองไฟล์ที่ถูกลบออก (deleted_at is null)',
    sql.indexOf('a.deleted_at is null') >= 0, '');
  chk('คีย์ของ jobs เหมือน njhr_ot_get',
    ['job_code', 'detail', 'job_type', 'job_date', 'spans_next_day', 'end_date', 'ot_hours']
      .every(k => sql.indexOf("'" + k + "'") >= 0), '');
  chk('คีย์ของ attachments เหมือน njhr_ot_attach_list',
    ['job_no', 'file_name', 'file_url', 'file_path', 'file_size', 'content_type']
      .every(k => sql.indexOf("'" + k + "'") >= 0), '');
  chk('คืนคอลัมน์เดิมของ njhr_ot_list ครบ',
    ['jobs_count', 'is_holiday', 'files_count', 'total_count', 'nickname', 'position_name']
      .every(k => sql.indexOf(k) >= 0), '');
  chk('มีดัชนีช่วย', sql.indexOf('njhr_ot_jobs_ot_id_job_no_idx') >= 0, '');
  chk('มี PREFLIGHT และ VERIFICATION',
    sql.indexOf('PREFLIGHT') >= 0 && sql.indexOf('VERIFICATION') >= 0, '');
  chk('begin/commit ครบคู่',
    (sql.match(/^begin;$/gm) || []).length === (sql.match(/^commit;$/gm) || []).length, '');

  console.log('\n== ไม่กระทบส่วนอื่น ==');
  chk('การ์ดและปุ่มอนุมัติเดิมไม่ถูกแตะ',
    src.indexOf('function otApprovalCard') >= 0 && src.indexOf('njhr_ot_decide') >= 0, '');
  chk('apOtShape เดิมยังใช้ตัวเดียวกัน',
    (src.match(/function apOtShape/g) || []).length === 1, '');
  chk('ไม่มีชื่อฟังก์ชันซ้ำในไฟล์',
    (function () {
      const seen = {}, dup = [];
      src.split('\n').forEach(l => {
        const m = /^ {2}function\s+([A-Za-z0-9_$]+)\s*\(/.exec(l);
        if (!m) return;
        if (seen[m[1]] && dup.indexOf(m[1]) < 0) dup.push(m[1]);
        seen[m[1]] = true;
      });
      return dup.length === 0;
    })(), '');
  chk('ไฟล์ที่เว็บใช้จริงมี RPC ใหม่', out.indexOf('njhr_ot_approval_queue') >= 0, '');

  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  console.log('NOT TESTED: ผลจริงจาก Production — ต้องรัน 91 แล้ววัดด้วย DevTools Network');
  process.exit(FAIL ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
