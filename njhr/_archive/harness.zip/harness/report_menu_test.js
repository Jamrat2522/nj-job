/* report_menu_test.js — ตรวจเมนู REPORT ลางาน (#/rpt-leave) และ REPORT OT (#/rpt-ot)
   โหลด chunk ที่ build แล้วจริง (views/reports/menu.js) ลง jsdom
   ตรวจ: ลำดับตัวกรอง · หัวคอลัมน์ · thead/tbody ตารางเดียว · ข้อมูลตรงแถว
          ตัวกรองใช้ร่วมกันได้ · ล้างตัวกรองคืนค่า+โหลดใหม่ · Export ใช้ทุกแถวหลังกรอง
          ไม่มี fallback ไป db.* / localStorage
   ใช้: node harness/report_menu_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(58) + (d || '')); }
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
  .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const tick = ms => new Promise(r => setTimeout(r, ms || 30));

/* ---------- ข้อมูลจำลอง "ฝั่งเซิร์ฟเวอร์" (แทน Postgres) ----------
   หน้าเว็บต้องอ่านจาก RPC เท่านั้น การกรองจึงทำที่ชั้นนี้ ไม่ใช่ในหน้าจอ */
const LEAVE_DB = [
  { req_id: 'l1', request_no: '260810-0007', emp_code: 'NJ001', prefix: 'นาย',
    full_name: 'สมชาย ใจดี', nickname: 'ชาย', department: 'ขนส่ง', leave_type: 'SICK',
    start_date: '2026-08-10', end_date: '2026-08-10', leave_unit: 'day', mode_txt: 'เต็มวัน',
    start_time: null, end_time: null, total_days: 1, hours: 0,
    status: 'PENDING', ui_status: 'PENDING', created_at: '2026-08-09T03:00:00Z' },
  { req_id: 'l2', request_no: null, emp_code: 'NJ002', prefix: 'นางสาว',
    full_name: 'สมหญิง รักงาน', nickname: 'หญิง', department: 'บัญชี', leave_type: 'BUSINESS',
    start_date: '2026-08-03', end_date: '2026-08-04', leave_unit: 'day', mode_txt: 'หลายวัน',
    start_time: null, end_time: null, total_days: 2, hours: 0,
    status: 'APPROVED', ui_status: 'APPROVED', created_at: '2026-08-01T03:00:00Z' },
  { req_id: 'l3', request_no: '260701-0002', emp_code: 'NJ003', prefix: 'นาย',
    full_name: 'มานะ อดทน', nickname: 'นะ', department: 'ขนส่ง', leave_type: 'SICK',
    start_date: '2026-07-01', end_date: '2026-07-01', leave_unit: 'hour', mode_txt: 'รายชั่วโมง',
    start_time: '09:00:00', end_time: '12:00:00', total_days: 0, hours: 3,
    status: 'CANCELLED', ui_status: 'CANCELLED', created_at: '2026-06-30T03:00:00Z' }
];
const OT_DB = [
  { req_id: 'o1', request_no: '260811-0001', emp_code: 'NJ001', prefix: 'นาย',
    full_name: 'สมชาย ใจดี', nickname: 'ชาย', department: 'ขนส่ง',
    ot_date: '2026-08-11', start_time: '18:00:00', end_time: '21:00:00', spans_next_day: false,
    ot_hours: 3, is_holiday: false, status: 'PENDING', created_at: '2026-08-11T03:00:00Z' },
  { req_id: 'o2', request_no: '260809-0004', emp_code: 'NJ002', prefix: 'นางสาว',
    full_name: 'สมหญิง รักงาน', nickname: 'หญิง', department: 'บัญชี',
    ot_date: '2026-08-09', start_time: '20:00:00', end_time: '02:00:00', spans_next_day: true,
    ot_hours: 6, is_holiday: true, status: 'APPROVED', created_at: '2026-08-09T03:00:00Z' },
  { req_id: 'o3', request_no: null, emp_code: 'NJ003', prefix: 'นาย',
    full_name: 'มานะ อดทน', nickname: 'นะ', department: 'ขนส่ง',
    ot_date: '2026-07-02', start_time: '18:30:00', end_time: '20:30:00', spans_next_day: false,
    ot_hours: 2, is_holiday: false, status: 'REJECTED', created_at: '2026-07-02T03:00:00Z' }
];

function serverFilter(rows, p, dateOf) {
  const q = String(p.p_q || '').trim().toLowerCase();
  return rows.filter(r => {
    const d = dateOf(r);
    if (p.p_from && d.end < p.p_from) return false;
    if (p.p_to && d.start > p.p_to) return false;
    if (p.p_dept && r.department !== p.p_dept) return false;
    if (q) {
      const hay = [r.emp_code, r.full_name, r.nickname, r.prefix + r.full_name].join(' ').toLowerCase();
      if (hay.indexOf(q) < 0) return false;
    }
    return true;
  });
}

function env() {
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div></body></html>');
  const win = dom.window;
  const calls = [];
  let lastToast = null, lastBlobName = null, lastXlsx = null;
  const NJHR = {
    state: { currentRoute: '#/rpt-leave' }, router: { navId: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    features: {}, views: { register: () => {} }, compat: { scope: {} }
  };
  Object.assign(NJHR.compat.scope, {
    icon: () => '<span class="ic"></span>', esc, debounce: f => f,
    fmtDateDMY: v => { const p = String(v == null ? '' : v).slice(0, 10).split('-');
      if (p.length !== 3) return '—';
      const y = parseInt(p[0], 10), m = parseInt(p[1], 10), d = parseInt(p[2], 10);
      if (!isFinite(y) || !isFinite(m) || !isFinite(d)) return '—';
      const z = n => (n < 10 ? '0' + n : '' + n);
      return z(d) + '/' + z(m) + '/' + y; },
    fmtDate: d => String(d || ''), emptyState: m => '<div class="empty">' + m + '</div>',
    emp: () => ({}), dept: () => '', audit: () => {},
    toast: m => { lastToast = m; },
    sbReady: () => true, sbToken: () => 'tok',
    sbRpcList: (fn, body) => {
      calls.push({ fn, body });
      if (fn === 'njhr_emp_departments') {
        return Promise.resolve([{ name: 'ขนส่ง' }, { name: 'บัญชี' }, { name: 'จัดซื้อ' }]);
      }
      if (fn === 'njhr_rpt_leave_list') {
        return Promise.resolve(serverFilter(LEAVE_DB, body,
          r => ({ start: r.start_date, end: r.end_date })));
      }
      if (fn === 'njhr_rpt_ot_list') {
        return Promise.resolve(serverFilter(OT_DB, body,
          r => ({ start: r.ot_date, end: r.ot_date })));
      }
      return Promise.reject(new Error('RPC ไม่รองรับใน harness: ' + fn));
    },
    rptSafeName: v => String(v).replace(/[\\/:*?"<>|]/g, '').replace(/\s+/g, '-').slice(0, 60),
    rptDateBE: iso => String(iso || ''),
    rptLoadZip: () => Promise.resolve(),
    rptBuildXlsx: (sheet, head, rows) => {
      lastXlsx = { sheet, head, rows };
      return Promise.resolve({ __blob: true });
    },
    lvType: c => ({ SICK: { code: 'SICK', name: 'ลาป่วย', color: '#16A34A' },
                    BUSINESS: { code: 'BUSINESS', name: 'ลากิจ', color: '#2563EB' } }[c] ||
                  { code: c, name: c, color: '#64748B' })
  });
  win.NJHR = NJHR;
  win.URL.createObjectURL = () => 'blob:x';
  win.URL.revokeObjectURL = () => {};
  const ctx = vm.createContext(win);
  return { win, NJHR, calls,
    run: rel => vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), ctx, { filename: rel }),
    host: () => win.document.getElementById('app'),
    doc: () => win.document,
    toast: () => lastToast,
    xlsx: () => lastXlsx };
}

function grab(E, names) {
  const out = {};
  E.NJHR.views.register = (n, f) => { if (names.indexOf(n) >= 0) out[n] = f; };
  return out;
}

function headOf(doc) {
  return Array.from(doc.querySelectorAll('.rptm-table thead th')).map(x => x.textContent.trim());
}
function bodyRows(doc) {
  return Array.from(doc.querySelectorAll('.rptm-table tbody tr'))
    .map(tr => Array.from(tr.children).map(td => td.textContent.trim()));
}

/* ---------- ตรวจโครงสร้างร่วม ---------- */
function auditPage(label, doc, heads) {
  const bar = doc.querySelector('.rptm-filters');
  chk(label + ' · มีแถบตัวกรอง', !!bar, '');
  if (bar) {
    const order = Array.from(bar.children).map(c => {
      const sp = c.querySelector ? c.querySelector('span') : null;
      if (c.tagName === 'LABEL') return sp ? sp.textContent.trim() : '';
      if (c.tagName === 'BUTTON') return c.textContent.trim();
      return '';
    }).filter(Boolean);
    chk(label + ' · ลำดับตัวกรองถูกต้อง',
      JSON.stringify(order) === JSON.stringify(
        ['วันที่เริ่มต้น', 'วันที่สิ้นสุด', 'แผนก', 'พนักงาน', 'ล้างตัวกรอง', 'EXPORT EXCEL']),
      order.join(' | '));
  }
  const tables = doc.querySelectorAll('.rptm-table');
  chk(label + ' · มีตารางเดียว', tables.length === 1, 'พบ ' + tables.length);
  const tbl = tables[0];
  if (tbl) {
    chk(label + ' · thead อยู่ในตารางเดียวกัน', tbl.querySelectorAll(':scope > thead').length === 1, '');
    chk(label + ' · tbody อยู่ในตารางเดียวกัน', tbl.querySelectorAll(':scope > tbody').length === 1, '');
  }
  const got = headOf(doc);
  chk(label + ' · ลำดับหัวคอลัมน์', JSON.stringify(got) === JSON.stringify(heads), got.join(' | '));
  const rows = bodyRows(doc);
  const bad = rows.filter(r => r.length !== heads.length);
  chk(label + ' · ทุกแถวมีช่องเท่าหัวคอลัมน์', bad.length === 0, 'ไม่ตรง ' + bad.length);
  return rows;
}

async function run() {
  /* ================= REPORT ลางาน ================= */
  console.log('\n== REPORT ลางาน (#/rpt-leave) ==');
  const E = env();
  const V = grab(E, ['viewRptLeave', 'viewRptOT']);
  E.run('views/reports/menu.js');
  chk('chunk ลงทะเบียน viewRptLeave', typeof V.viewRptLeave === 'function', '');
  chk('chunk ลงทะเบียน viewRptOT', typeof V.viewRptOT === 'function', '');
  if (!V.viewRptLeave || !V.viewRptOT) return finish();

  V.viewRptLeave(E.host());
  await tick(40);
  const doc = E.doc();

  const rows = auditPage('ลางาน', doc, RPTM_LEAVE_HEAD);
  chk('ลางาน · เรียก RPC njhr_rpt_leave_list',
    E.calls.some(c => c.fn === 'njhr_rpt_leave_list'), '');
  chk('ลางาน · ไม่เรียก RPC ของรายงานเดิม',
    !E.calls.some(c => c.fn === 'njhr_leave_report' || c.fn === 'njhr_leave_list'), '');
  chk('ลางาน · ไม่กรองวันที่โดยปริยาย (เห็นครบ 3 คำขอ)', rows.length === 3, rows.length + '/3');

  const r0 = rows[0] || [];
  chk('ลางาน · ลำดับเริ่มที่ 1', r0[0] === '1', r0[0]);
  chk('ลางาน · เลขคำขอจากฐานข้อมูล', r0[1] === '260810-0007', r0[1]);
  chk('ลางาน · ประเภทเป็นชื่อประเภทการลา', r0[2] === 'ลาป่วย', r0[2]);
  chk('ลางาน · วันที่เป็น DD/MM/YYYY ปี ค.ศ.', r0[3] === '10/08/2026', r0[3]);
  chk('ลางาน · รูปแบบการลาตรงข้อมูล', r0[4] === 'เต็มวัน', r0[4]);
  chk('ลางาน · จำนวนวันลาตรงข้อมูล', r0[5] === '1', r0[5]);
  chk('ลางาน · ชื่อคนลา = คำนำหน้า+ชื่อ', r0[6] === 'นายสมชาย ใจดี', r0[6]);
  chk('ลางาน · สถานะเป็นภาษาไทย', r0[7] === 'รออนุมัติ', r0[7]);

  const rNo = rows.find(r => r[1] === '—');
  chk('ลางาน · คำขอเก่าที่ไม่มีเลขแสดง —', !!rNo, rNo ? rNo[1] : 'ไม่พบ');
  const rHr = rows.find(r => r[4].indexOf('รายชั่วโมง') === 0);
  chk('ลางาน · ลารายชั่วโมงแสดงช่วงเวลา', !!rHr && rHr[4].indexOf('09:00–12:00') > 0,
    rHr ? rHr[4] : 'ไม่พบ');

  /* ---------- ตัวกรองใช้ร่วมกัน ---------- */
  const setVal = (id, v, ev) => {
    const el = doc.getElementById(id); el.value = v;
    (ev === 'input' ? el.oninput : el.onchange).call(el);
  };
  setVal('rptm-dept', 'ขนส่ง'); await tick(40);
  let f1 = bodyRows(doc);
  chk('ลางาน · กรองแผนกอย่างเดียว', f1.length === 2, f1.length + '/2');

  setVal('rptm-from', '2026-08-01'); await tick(40);
  setVal('rptm-to', '2026-08-31'); await tick(40);
  let f2 = bodyRows(doc);
  chk('ลางาน · แผนก + ช่วงวันที่ ใช้ร่วมกันได้', f2.length === 1 && f2[0][1] === '260810-0007',
    f2.length + ' แถว');

  setVal('rptm-q', 'ชาย', 'input'); await tick(60);
  let f3 = bodyRows(doc);
  chk('ลางาน · แผนก + วันที่ + ชื่อเล่น ใช้ร่วมกันได้', f3.length === 1, f3.length + '/1');
  const lastCall = E.calls.filter(c => c.fn === 'njhr_rpt_leave_list').slice(-1)[0];
  chk('ลางาน · ส่งตัวกรองครบทุกตัวไป RPC',
    lastCall.body.p_from === '2026-08-01' && lastCall.body.p_to === '2026-08-31' &&
    lastCall.body.p_dept === 'ขนส่ง' && lastCall.body.p_q === 'ชาย',
    JSON.stringify(lastCall.body));

  setVal('rptm-q', 'NJ003', 'input'); await tick(60);
  chk('ลางาน · ค้นด้วยรหัสพนักงานได้', bodyRows(doc).length === 0, 'นอกช่วงวันที่จึงเหลือ 0');

  /* ---------- ล้างตัวกรอง ---------- */
  doc.getElementById('rptm-clear').onclick.call(doc.getElementById('rptm-clear'));
  await tick(60);
  chk('ลางาน · ล้างตัวกรอง คืนค่าช่องทั้งหมด',
    doc.getElementById('rptm-from').value === '' && doc.getElementById('rptm-to').value === '' &&
    doc.getElementById('rptm-dept').value === '' && doc.getElementById('rptm-q').value === '', '');
  chk('ลางาน · ล้างตัวกรอง โหลดข้อมูลใหม่ครบ', bodyRows(doc).length === 3,
    bodyRows(doc).length + '/3');

  /* ---------- EXPORT ---------- */
  setVal('rptm-dept', 'ขนส่ง'); await tick(40);
  const btn = doc.getElementById('rptm-export');
  btn.onclick.call(btn);
  await tick(60);
  const x = E.xlsx();
  chk('ลางาน · Export ใช้หัวคอลัมน์ชุดเดียวกับตาราง',
    JSON.stringify(x.head) === JSON.stringify(RPTM_LEAVE_HEAD), x.head.join(' | '));
  chk('ลางาน · Export ได้ทุกแถวหลังกรอง (ไม่ใช่เฉพาะหน้าที่แสดง)',
    x.rows.length === 2, x.rows.length + '/2');
  chk('ลางาน · ลำดับข้อมูลใน Excel ตรงกับตาราง',
    JSON.stringify(x.rows[0]) === JSON.stringify(bodyRows(doc)[0]), x.rows[0].join(' | '));
  chk('ลางาน · แจ้งผลดาวน์โหลด', /REPORT ลางาน/.test(E.toast() || ''), E.toast() || '');

  /* ================= REPORT OT ================= */
  console.log('\n== REPORT OT (#/rpt-ot) ==');
  const E2 = env();
  const V2 = grab(E2, ['viewRptLeave', 'viewRptOT']);
  E2.run('views/reports/menu.js');
  E2.NJHR.state.currentRoute = '#/rpt-ot';
  V2.viewRptOT(E2.host());
  await tick(40);
  const doc2 = E2.doc();

  const orows = auditPage('OT', doc2, RPTM_OT_HEAD);
  chk('OT · เรียก RPC njhr_rpt_ot_list', E2.calls.some(c => c.fn === 'njhr_rpt_ot_list'), '');
  chk('OT · ไม่เรียก njhr_ot_list เดิม', !E2.calls.some(c => c.fn === 'njhr_ot_list'), '');
  chk('OT · 1 คำขอ = 1 แถว', orows.length === 3, orows.length + '/3');

  const o0 = orows[0] || [];
  chk('OT · ลำดับเริ่มที่ 1', o0[0] === '1', o0[0]);
  chk('OT · เลขคำขอจากฐานข้อมูล', o0[1] === '260811-0001', o0[1]);
  chk('OT · ประเภท = OT ปกติ', o0[2] === 'OT ปกติ', o0[2]);
  chk('OT · วันที่เป็น DD/MM/YYYY ปี ค.ศ.', o0[3] === '11/08/2026', o0[3]);
  chk('OT · ช่วงเวลาตรงข้อมูล', o0[4] === '18:00 – 21:00', o0[4]);
  chk('OT · จำนวนชั่วโมงตรงข้อมูล', o0[5] === '3', o0[5]);
  chk('OT · ชื่อคนขอ = คำนำหน้า+ชื่อ', o0[6] === 'นายสมชาย ใจดี', o0[6]);
  chk('OT · สถานะเป็นภาษาไทย', o0[7] === 'รออนุมัติ', o0[7]);

  const oHol = orows.find(r => r[2] === 'OT วันหยุด');
  chk('OT · วันหยุดแยกประเภทถูก', !!oHol && oHol[1] === '260809-0004', oHol ? oHol[1] : 'ไม่พบ');
  chk('OT · ข้ามวันแสดง (+1 วัน)', !!oHol && oHol[4].indexOf('(+1 วัน)') > 0, oHol ? oHol[4] : '');

  const setV2 = (id, v, ev) => {
    const el = doc2.getElementById(id); el.value = v;
    (ev === 'input' ? el.oninput : el.onchange).call(el);
  };
  setV2('rptm-from', '2026-08-01'); await tick(40);
  setV2('rptm-to', '2026-08-31'); await tick(40);
  chk('OT · กรองจากวันที่ทำ OT', bodyRows(doc2).length === 2, bodyRows(doc2).length + '/2');
  setV2('rptm-dept', 'บัญชี'); await tick(40);
  chk('OT · แผนก + วันที่ ใช้ร่วมกันได้', bodyRows(doc2).length === 1, bodyRows(doc2).length + '/1');

  const btn2 = doc2.getElementById('rptm-export');
  btn2.onclick.call(btn2);
  await tick(60);
  const x2 = E2.xlsx();
  chk('OT · Export ใช้หัวคอลัมน์ชุดเดียวกับตาราง',
    JSON.stringify(x2.head) === JSON.stringify(RPTM_OT_HEAD), x2.head.join(' | '));
  chk('OT · Export ตรงกับตัวกรองปัจจุบัน', x2.rows.length === 1, x2.rows.length + '/1');
  chk('OT · ลำดับข้อมูลใน Excel ตรงกับตาราง',
    JSON.stringify(x2.rows[0]) === JSON.stringify(bodyRows(doc2)[0]), x2.rows[0].join(' | '));

  /* ---------- ไม่มี fallback ไปข้อมูลอื่น ---------- */
  const src = fs.readFileSync(path.join(ROOT, 'views/reports/menu.js'), 'utf8');
  chk('ไม่อ้าง localStorage', src.indexOf('localStorage') < 0, '');
  chk('ไม่อ่าน db.leaves / db.ots', !/db\.(leaves|ots|employees)/.test(src), '');
  chk('ไม่อ้าง RPC เงินเดือน', !/njhr_pay|payroll|salary/i.test(src), '');

  finish();
}

const RPTM_LEAVE_HEAD = ['ลำดับ', 'เลขคำขอ', 'ประเภท', 'วันที่', 'รูปแบบการลา',
  'จำนวนวันลา', 'ชื่อคนลา', 'สถานะ'];
const RPTM_OT_HEAD = ['ลำดับ', 'เลขคำขอ', 'ประเภท', 'วันที่', 'ช่วงเวลา',
  'จำนวนชั่วโมง', 'ชื่อคนขอ', 'สถานะ'];

function finish() {
  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
}

run().catch(e => { console.error(e); process.exit(1); });
