/* report_menu_label_test.js — ตรวจการเปลี่ยนชื่อเมนูรายงานเป็นภาษาไทย
     รายงานทั้งหมด (#/reportall) · รายงานการลา (#/rpt-leave) · รายงานโอที (#/rpt-ot)
   ต้องเปลี่ยนเฉพาะ Label — Route · view · mod · roles · icon · EXPORT ต้องเหมือนเดิม
   ใช้: node harness/report_menu_label_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(62) + (d || '')); }

const core = fs.readFileSync(path.join(ROOT, 'runtime/core.js'), 'utf8');
const flat = core.replace(/\s/g, '');

/* ================= 1. Label ใหม่เป็นภาษาไทย ================= */
console.log('\n== ชื่อเมนูใหม่ ==');
const MENU = [
  ['รายงานทั้งหมด', '#/reportall', 'fileText', 'viewReportAll', 'compatibility'],
  ['รายงานการลา', '#/rpt-leave', 'calendarOff', 'viewRptLeave', 'report-menu'],
  ['รายงานโอที', '#/rpt-ot', 'timer', 'viewRptOT', 'report-menu']
];
MENU.forEach(function (m) {
  chk('มีชื่อเมนู "' + m[0] + '"', core.indexOf(m[0]) >= 0, '');
  chk('เมนู "' + m[0] + '" ผูกกับ Route เดิม ' + m[1],
    flat.indexOf('{r:"' + m[1] + '",t:"' + m[0] + '"') >= 0, '');
  chk('เมนู "' + m[0] + '" ใช้ Icon เดิม (' + m[2] + ')',
    flat.indexOf('{r:"' + m[1] + '",t:"' + m[0] + '",i:"' + m[2] + '"') >= 0, '');
});

/* ================= 2. ชื่อภาษาอังกฤษเดิมหายจากเมนู/หัวข้อหน้า ================= */
console.log('\n== ชื่อเดิมต้องไม่โผล่ในเมนูและหัวข้อหน้า ==');
[['REPORT ALL', '#/reportall'], ['REPORT ลางาน', '#/rpt-leave'], ['REPORT OT', '#/rpt-ot']]
  .forEach(function (x) {
    chk('ไม่มี t:"' + x[0] + '" ในเมนูแล้ว',
      flat.indexOf('t:"' + x[0] + '"') < 0, '');
    chk('ไม่มี title:"' + x[0] + '" ใน ROUTES แล้ว',
      flat.indexOf('title:"' + x[0] + '"') < 0, '');
  });

/* ================= 3. Route / view / mod / roles ไม่เปลี่ยน ================= */
console.log('\n== Route และภายในต้องเหมือนเดิม ==');
MENU.forEach(function (m) {
  chk('Route ' + m[1] + ' ยังอยู่', flat.indexOf('"' + m[1] + '":{') >= 0, '');
  chk('Route ' + m[1] + ' ยังใช้ view เดิม (' + m[3] + ')',
    new RegExp('"' + m[1].replace('/', '\\/') + '":\\{[^}]*view:"' + m[3] + '"').test(flat), '');
  chk('Route ' + m[1] + ' ยังใช้ mod เดิม (' + m[4] + ')',
    new RegExp('"' + m[1].replace('/', '\\/') + '":\\{[^}]*mod:"' + m[4] + '"').test(flat), '');
  chk('Route ' + m[1] + ' ยังจำกัดสิทธิ์ SUPER_ADMIN/ADMIN',
    new RegExp('"' + m[1].replace('/', '\\/') + '":\\{[^}]*roles:\\["SUPER_ADMIN","ADMIN"\\]').test(flat), '');
});
/* 3 รายการ: รายงานการลา · รายงานโอที · รายงาน 50 ทวิ */
chk('deskOnly ของรายงานเฉพาะจอคอมยังอยู่ (มือถือไม่แสดง)',
  (flat.match(/deskOnly:true/g) || []).length === 3,
  (flat.match(/deskOnly:true/g) || []).length + ' รายการ');
chk('ยังใช้ menuHref() ผูกลิงก์เหมือนเดิม (Active Menu ทำงานตามเดิม)',
  core.indexOf('menuHref') >= 0 && core.indexOf('menuMatch') >= 0, '');

/* ================= 4. เมนูอื่นในกลุ่มรายงานไม่ถูกแตะ ================= */
console.log('\n== เมนูอื่นในกลุ่มรายงาน ==');
[['รายงานการลงเวลา', '#/reports', 'chart'], ['ประกันสังคม', '#/sso', 'shield']]
  .forEach(function (x) {
    chk('เมนู "' + x[0] + '" ไม่เปลี่ยน',
      flat.indexOf('{r:"' + x[1] + '",t:"' + x[0] + '",i:"' + x[2] + '"') >= 0, '');
  });

/* ================= 5. EXPORT ไม่ถูกแตะ ================= */
console.log('\n== EXPORT ==');
const menuJs = fs.readFileSync(path.join(ROOT, 'views/reports/menu.js'), 'utf8');
chk('ชื่อ Sheet Excel ของรายงานการลา ยังเป็น "REPORT ลางาน"',
  menuJs.indexOf('sheet:"REPORT ลางาน"') >= 0 || menuJs.indexOf("sheet:'REPORT ลางาน'") >= 0, '');
chk('ชื่อ Sheet Excel ของรายงานโอที ยังเป็น "REPORT OT"',
  menuJs.indexOf('sheet:"REPORT OT"') >= 0 || menuJs.indexOf("sheet:'REPORT OT'") >= 0, '');
const compat = fs.readFileSync(path.join(ROOT, 'compat/app-legacy.js'), 'utf8');
chk('Sheet ของรายงานทั้งหมด ยังเป็น "REPORT ALL"', compat.indexOf('REPORT ALL') >= 0, '');
chk('rptBuildXlsx ยังถูกเรียกเหมือนเดิม', menuJs.indexOf('rptBuildXlsx') >= 0, '');

/* ================= 6. ต้นทางถูกแก้เฉพาะ 2 ไฟล์ ================= */
console.log('\n== ไฟล์ต้นทาง ==');
const shell = fs.readFileSync(path.join(ROOT, 'src/05-layout-shell.js'), 'utf8');
const router = fs.readFileSync(path.join(ROOT, 'src/04-router-guards.js'), 'utf8');
chk('05-layout-shell.js ใช้ชื่อไทยครบ 3 รายการ',
  MENU.every(function (m) { return shell.indexOf("t: '" + m[0] + "'") >= 0; }), '');
chk('04-router-guards.js ใช้ชื่อไทยครบ 3 รายการ',
  MENU.every(function (m) { return router.indexOf("title: '" + m[0] + "'") >= 0; }), '');
chk('04-router-guards.js ไม่แตะ view/mod/roles ของ 3 Route',
  MENU.every(function (m) {
    return router.indexOf("view: '" + m[3] + "'") >= 0 && router.indexOf("mod: '" + m[4] + "'") >= 0;
  }), '');
/* ไฟล์รายงานเองต้องไม่ถูกแตะ */
const rptSrc = fs.readFileSync(path.join(ROOT, 'src/37-view-report-menu.js'), 'utf8');
chk('src/37-view-report-menu.js ยังใช้ sheet เดิม (EXPORT ไม่เปลี่ยน)',
  rptSrc.indexOf("sheet: 'REPORT ลางาน'") >= 0 && rptSrc.indexOf("sheet: 'REPORT OT'") >= 0, '');

console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
process.exit(FAIL ? 1 : 0);
