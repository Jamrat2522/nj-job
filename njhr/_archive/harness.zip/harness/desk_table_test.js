/* desk_table_test.js — ตรวจตารางเดียวหน้าคอม (Desktop) ของ #/ot และ #/leave
   โหลด chunk ที่ build แล้วจริง (views/ot/main.js · views/leave/main.js) ลง jsdom
   ตรวจ: หัวคอลัมน์ · thead/tbody อยู่ในตารางเดียวกัน · จำนวนคอลัมน์ทุกแถวตรงหัว
          ไม่มีการ์ดฝั่ง Desktop · ไม่มีหัวข้อ "จัดการ" · ปุ่มเดิมอยู่ขวาสุด
          Mobile card เดิมยังอยู่ครบ (.only-mobile)
   ใช้: node harness/desk_table_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(58) + (d || '')); }
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
  .replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/* แถวจาก njhr_ot_list (Supabase) — หน้า #/ot ไม่อ่าน db.ots อีกแล้ว */
const OTS = [
  { id: 'OT-AAA111', request_no: '260811-0001', employee_id: 'e1', emp_name: 'สมชาย ใจดี',
    ot_date: '2026-08-11', start_time: '18:00:00', end_time: '21:00:00', spans_next_day: false,
    ot_hours: 3, reason: 'ปิดงบ', status: 'PENDING', created_at: '2026-08-11T10:00:00Z',
    jobs_count: 2, files_count: 1, is_holiday: false },
  { id: 'OT-BBB222', request_no: null, employee_id: 'e1', emp_name: 'สมชาย ใจดี',
    ot_date: '2026-08-09', start_time: '19:00:00', end_time: '22:00:00', spans_next_day: false,
    ot_hours: 3, reason: 'งานด่วน', status: 'APPROVED', created_at: '2026-08-09T10:00:00Z',
    jobs_count: 0, files_count: 1, is_holiday: true }
];

const LEAVES = [
  { id: 'lv-1', request_no: '260810-0007', leave_type: 'SICK', status: 'PENDING', ui_status: 'PENDING',
    start_date: '2026-08-10', end_date: '2026-08-10', total_days: 1, hours: 0,
    leave_unit: 'day', reason: 'ไม่สบาย', file_name: 'med.pdf', emp_name: 'สมชาย ใจดี' },
  { id: 'lv-2', leave_type: 'BUSINESS', status: 'APPROVED', ui_status: 'APPROVED',
    start_date: '2026-08-03', end_date: '2026-08-04', total_days: 2, hours: 0,
    leave_unit: 'day', reason: 'ธุระ', file_name: null, emp_name: 'สมชาย ใจดี' }
];

function makeEnv(scopeExtra) {
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div></body></html>');
  const win = dom.window;
  const NJHR = {
    state: { currentRoute: '#/ot' }, router: { navId: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    features: {}, views: { register: () => {} }, compat: { scope: {} }
  };
  Object.assign(NJHR.compat.scope, {
    icon: () => '<span class="ic"></span>', esc, debounce: f => f,
    avatarHTML: () => '<span class="avatar"></span>',
    emptyState: m => '<div class="empty">' + m + '</div>',
    fmtDateDMY: v => { const p = String(v == null ? '' : v).slice(0, 10).split('-');
      if (p.length !== 3) return '—';
      const y = parseInt(p[0], 10), m = parseInt(p[1], 10), d = parseInt(p[2], 10);
      if (!isFinite(y) || !isFinite(m) || !isFinite(d)) return '—';
      const z = n => (n < 10 ? '0' + n : '' + n);
      return z(d) + '/' + z(m) + '/' + y; },
    fmtDate: d => String(d || ''), empName: () => 'สมชาย ใจดี',
    statusBadge: s => '<span class="badge">' + s + '</span>',
    currentUser: () => ({ id: 'u1', role: 'USER', empId: 'e1' }),
    currentEmp: () => ({ id: 'e1', firstName: 'สมชาย', lastName: 'ใจดี', deptId: 'd1' }),
    dept: () => 'ขนส่ง', toast: () => {},
    /* db.ots ว่างเปล่าโดยเจตนา — ถ้าหน้า OT ยังอ่าน localStorage จะตกทดสอบทันที */
    db: { ots: [], leaves: [] },
    showTimeline: () => {}, bindReqCardActions: () => {},
    sbReady: () => true, sbToken: () => 'tok',
    sbRpc: () => Promise.resolve({}),
    sbRpcList: fn => (fn === 'njhr_ot_list' ? Promise.resolve(OTS) : Promise.resolve([])),
    confirmDialog: () => {}, closeModal: () => {},
    openModal: () => {}, closeModal: () => {}, confirmDialog: () => {},
    nav: () => {}, TH_MONTHS: ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'],
    lvType: c => ({ SICK: { code: 'SICK', name: 'ลาป่วย', color: '#16A34A' },
                    BUSINESS: { code: 'BUSINESS', name: 'ลากิจ', color: '#2563EB' } }[c] ||
                  { code: c, name: c, color: '#64748B' }),
    lvMode: r => (r && r.leave_unit === 'hour' ? 'HOURLY' : 'FULL'),
    lvModeTxt: m => ({ FULL: 'เต็มวัน', HOURLY: 'รายชั่วโมง' }[m] || m),
    lvNum: v => { const n = Number(v); return isFinite(n) ? Math.round(n * 100) / 100 : 0; },
    lvCode: x => (x && typeof x === 'object'
      ? (x.request_no || x.requestNo || ('LV-' + String(x.id || '').slice(0, 6).toUpperCase()))
      : 'LV-' + String(x || '').slice(0, 6).toUpperCase()),
    LEAVE_TYPES: [], refreshLeavePending: () => {}, RQ_CARDS: [], rqState: { seq: 0, bal: [], err: '' },
    rqRenderMenu: () => {}, rqRenderBal: () => {}, rqPick: () => null, rhStatus: () => ({ k: 'PENDING' }),
    audit: () => {}, saveDB: () => {}, nowStamp: () => '', render: () => {}, uid: () => 'x'
  });
  Object.assign(NJHR.compat.scope, scopeExtra || {});
  win.NJHR = NJHR;
  const ctx = vm.createContext(win);
  return { win, NJHR, ctx,
    run: rel => vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), ctx, { filename: rel }),
    host: () => win.document.getElementById('app') };
}

function grab(E, name) {
  let fn = null;
  E.NJHR.views.register = (n, f) => { if (n === name) fn = f; };
  return () => fn;
}

/* ---------- ตรวจร่วมของทั้งสองตาราง ---------- */
function auditTable(label, root, heads, rowCount) {
  const wraps = root.querySelectorAll('.lvt-wrap');
  chk(label + ' · มีตารางเดียว', wraps.length === 1, 'พบ ' + wraps.length + ' ตาราง');
  const wrap = wraps[0];
  if (!wrap) return;
  chk(label + ' · ตารางเป็น only-desktop', wrap.classList.contains('only-desktop'), wrap.className);
  const tbl = wrap.querySelector('table');
  chk(label + ' · thead อยู่ในตารางเดียวกัน', !!tbl && tbl.querySelectorAll(':scope > thead').length === 1, '');
  chk(label + ' · tbody อยู่ในตารางเดียวกัน', !!tbl && tbl.querySelectorAll(':scope > tbody').length === 1, '');

  const th = Array.from(tbl.querySelectorAll('thead th'));
  const got = th.map(x => x.textContent.trim());
  chk(label + ' · ลำดับหัวคอลัมน์', JSON.stringify(got.slice(0, heads.length)) === JSON.stringify(heads),
    got.join(' | '));
  chk(label + ' · คอลัมน์ปุ่มไม่มีชื่อหัว', th.length === heads.length + 1 && got[heads.length] === '',
    'คอลัมน์ทั้งหมด ' + th.length);
  chk(label + ' · ไม่มีหัวข้อ "จัดการ"', got.indexOf('จัดการ') < 0 && wrap.innerHTML.indexOf('จัดการ') < 0, '');

  const trs = Array.from(tbl.querySelectorAll('tbody tr'));
  chk(label + ' · จำนวนแถวตรงจำนวนข้อมูล', trs.length === rowCount, trs.length + '/' + rowCount);
  const bad = trs.filter(tr => tr.children.length !== th.length);
  chk(label + ' · ทุกแถวมีจำนวนช่องเท่าหัวคอลัมน์', bad.length === 0, 'แถวไม่ตรง ' + bad.length);

  const lastOk = trs.every(tr => {
    const last = tr.children[tr.children.length - 1];
    return last && last.querySelector('.lv-eye');
  });
  chk(label + ' · ปุ่มดูรายละเอียดอยู่ช่องขวาสุด', lastOk, '');
  chk(label + ' · ไม่มีการ์ดฝั่ง Desktop', wrap.querySelectorAll('.req-card, .lv-row').length === 0, '');
  return trs;
}

/* ================= OT ================= */
async function testOT() {
  console.log('\n== ตาราง OT (#/ot) ==');
  const E = makeEnv();
  const get = grab(E, 'viewOT');
  E.run('views/ot/main.js');
  const viewOT = get();
  chk('OT · chunk ลงทะเบียน viewOT', typeof viewOT === 'function', '');
  if (typeof viewOT !== 'function') return;
  viewOT(E.host());
  await tick(60);                    // viewOT โหลดจาก njhr_ot_list แบบ async
  const root = E.host();

  const trs = auditTable('OT', root,
    ['เลขคำขอ', 'ประเภท', 'วันที่', 'ช่วงเวลา', 'ไฟล์แนบ', 'สถานะ'], OTS.length);
  if (!trs) return;

  const r0 = Array.from(trs[0].children).map(td => td.textContent.trim());
  chk('OT · เลขคำขอตรงข้อมูล', r0[0] === '260811-0001', r0[0]);
  /* njhr_ot_list ไม่คืนประเภทงานรายรายการ (อยู่ที่ njhr_ot_jobs)
     คอลัมน์ "ประเภท" จึงใช้ is_holiday ชุดเดียวกับหน้า REPORT OT */
  chk('OT · ประเภท = OT ปกติ (is_holiday=false)', r0[1].indexOf('OT ปกติ') === 0, r0[1]);
  chk('OT · บรรทัดรองบอกจำนวนรายการงานจาก jobs_count', r0[1].indexOf('2 รายการงาน') > 0, r0[1]);
  chk('OT · วันที่เป็น DD/MM/YYYY ปี ค.ศ.', r0[2] === '11/08/2026', r0[2]);
  chk('OT · ช่วงเวลาตรงข้อมูล', r0[3].indexOf('18:00 – 21:00') === 0 && r0[3].indexOf('3 ชั่วโมง') > 0, r0[3]);
  chk('OT · ไฟล์แนบนับถูก', r0[4] === '1 ไฟล์', r0[4]);
  chk('OT · สถานะตรงข้อมูล', r0[5] === 'PENDING', r0[5]);
  chk('OT · PENDING มีปุ่มยกเลิก', !!trs[0].querySelector('[data-cancel="OT-AAA111"]'), '');
  chk('OT · APPROVED ไม่มีปุ่มยกเลิก', !trs[1].querySelector('[data-cancel]'), '');
  chk('OT · data-detail คงเดิม', !!trs[0].querySelector('[data-detail="OT-AAA111"]'), '');

  const r1 = Array.from(trs[1].children).map(td => td.textContent.trim());
  chk('OT · วันหยุดแยกประเภทถูก (is_holiday=true)', r1[1].indexOf('OT วันหยุด') === 0, r1[1]);
  chk('OT · คำขอเก่าที่ไม่มี request_no ถอยไปใช้ id', r1[0] === 'OT-BBB222', r1[0]);
  chk('OT · คำขอเก่านับไฟล์ระดับคำขอ', r1[4] === '1 ไฟล์', r1[4]);

  const mob = root.querySelectorAll('.req-card.only-mobile');
  chk('OT · การ์ดมือถือเดิมครบ', mob.length === OTS.length, mob.length + '/' + OTS.length);
}

/* ================= LEAVE ================= */
async function testLeave() {
  console.log('\n== ตารางลางาน (#/leave) ==');
  const E = makeEnv();
  E.NJHR.state.currentRoute = '#/leave';
  let viewLeave = null;
  E.NJHR.views.register = (n, f) => { if (n === 'viewLeave') viewLeave = f; };
  E.NJHR.compat.scope.sbRpcList = (fn) => {
    if (fn === 'njhr_leave_balances') return Promise.resolve([]);
    if (fn === 'njhr_leave_list') return Promise.resolve(LEAVES.map(r => Object.assign({ total_count: LEAVES.length }, r)));
    return Promise.resolve([]);
  };
  E.run('views/leave/main.js');
  chk('LEAVE · chunk ลงทะเบียน viewLeave', typeof viewLeave === 'function', '');
  if (typeof viewLeave !== 'function') return;
  viewLeave(E.host());

  setTimeout(function () {
    const root = E.host();
    const trs = auditTable('ลางาน', root,
      ['เลขคำขอ', 'ประเภท', 'วันที่', 'รูปแบบการลา', 'ไฟล์แนบ', 'สถานะ'], LEAVES.length);
    if (trs) {
      const r0 = Array.from(trs[0].children).map(td => td.textContent.trim());
      chk('ลางาน · เลขคำขอตรงข้อมูล', r0[0] === '260810-0007', r0[0]);
      chk('ลางาน · ประเภทเป็นชื่อประเภทการลา', r0[1] === 'ลาป่วย', r0[1]);
      chk('ลางาน · วันที่เป็น DD/MM/YYYY ปี ค.ศ.', r0[2] === '10/08/2026', r0[2]);
      chk('ลางาน · รูปแบบการลาตรงข้อมูล', r0[3].indexOf('เต็มวัน') === 0 && r0[3].indexOf('1 วัน') > 0, r0[3]);
      chk('ลางาน · ไฟล์แนบนับถูก', r0[4] === '1 ไฟล์', r0[4]);
      chk('ลางาน · สถานะตรงข้อมูล', r0[5] === 'PENDING', r0[5]);
      chk('ลางาน · PENDING มีปุ่มยกเลิก', !!trs[0].querySelector('[data-lvcancel="lv-1"]'), '');
      chk('ลางาน · APPROVED ไม่มีปุ่มยกเลิก', !trs[1].querySelector('[data-lvcancel]'), '');
      chk('ลางาน · data-lvdetail คงเดิม', !!trs[0].querySelector('[data-lvdetail="lv-1"]'), '');
      const r1 = Array.from(trs[1].children).map(td => td.textContent.trim());
      chk('ลางาน · ช่วงวันที่เป็น DD/MM/YYYY ทั้งคู่', r1[2] === '03/08/2026 – 04/08/2026', r1[2]);
      chk('ลางาน · ไม่มีไฟล์แนบแสดงข้อความเดิม', r1[4] === 'ไม่มีไฟล์แนบ', r1[4]);
      const mob = root.querySelectorAll('.req-card.only-mobile');
      chk('ลางาน · การ์ดมือถือเดิมครบ', mob.length === LEAVES.length, mob.length + '/' + LEAVES.length);
    }
    console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
    process.exit(FAIL ? 1 : 0);
  }, 60);
}

const tick = ms => new Promise(r => setTimeout(r, ms || 40));
(async function () { await testOT(); await testLeave(); })();
