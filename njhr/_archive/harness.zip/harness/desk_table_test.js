/* desk_table_test.js — ตรวจตารางเดียวหน้าคอม (Desktop) ของ #/ot และ #/leave
   โหลด chunk ที่ build แล้วจริง (views/ot/main.js · views/leave/main.js) ลง jsdom
   ตรวจ: หัวคอลัมน์ · thead/tbody อยู่ในตารางเดียวกัน · จำนวนคอลัมน์ทุกแถวตรงหัว
          ไม่มีการ์ดฝั่ง Desktop · ไม่มีหัวข้อ "จัดการ" · ปุ่มเดิมอยู่ขวาสุด
          Mobile card เดิมยังอยู่ครบ (.only-mobile)
   ใช้: node harness/desk_table_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(58) + (d || '')); }
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
  .replace(/>/g, '&gt;').replace(/"/g, '&quot;');

/* แถวจาก njhr_ot_list (Supabase) — หน้า #/ot ไม่อ่าน db.ots อีกแล้ว */
const OTS = [
  /* njhr_ot_list คืน prefix แยกจาก emp_name (65_ot.sql:187) — fixture จึงต้องแยกด้วย */
  { id: 'OT-AAA111', request_no: '260811-0001', employee_id: 'e1',
    prefix: 'นาย', emp_name: 'สมชาย ใจดี',
    ot_date: '2026-08-11', start_time: '18:00:00', end_time: '21:00:00', spans_next_day: false,
    ot_hours: 3, reason: 'ปิดงบ', status: 'PENDING', created_at: '2026-08-11T10:00:00Z',
    jobs_count: 2, files_count: 1, is_holiday: false },
  { id: 'OT-BBB222', request_no: null, employee_id: 'e1',
    prefix: 'นาย', emp_name: 'สมชาย ใจดี',
    ot_date: '2026-08-09', start_time: '19:00:00', end_time: '22:00:00', spans_next_day: false,
    ot_hours: 3, reason: 'งานด่วน', status: 'APPROVED', created_at: '2026-08-09T10:00:00Z',
    jobs_count: 0, files_count: 1, is_holiday: true }
];

const LEAVES = [
  { id: 'lv-1', request_no: '260810-0007', leave_type: 'SICK', status: 'PENDING', ui_status: 'PENDING',
    start_date: '2026-08-10', end_date: '2026-08-10', total_days: 1, hours: 0,
    leave_unit: 'day', reason: 'ไม่สบาย', file_name: 'med.pdf', emp_name: 'สมชาย ใจดี' },
  { id: 'lv-2', leave_type: 'BUSINESS', status: 'APPROVED', ui_status: 'APPROVED',
    start_date: '2026-08-03', end_date: '2026-08-04', total_days: 2, hours: 0,
    leave_unit: 'day', reason: 'ธุระ', file_name: null, emp_name: 'สมชาย ใจดี' }
];

/* ชุดข้อมูลเฉพาะสำหรับตรวจคอลัมน์ "จำนวนวัน" — ครึ่งวัน · รายชั่วโมง · ไม่มีข้อมูล */
const LEAVES_QTY = [
  { id: 'q1', request_no: '260812-0002', leave_type: 'BUSINESS', status: 'APPROVED',
    ui_status: 'APPROVED', start_date: '2026-08-12', end_date: '2026-08-12',
    total_days: 0.5, hours: 0, leave_unit: 'day', is_halfday: true,
    reason: 'ธุระครึ่งวัน', file_name: null, emp_name: 'สมชาย ใจดี' },
  { id: 'q2', request_no: '260813-0001', leave_type: 'SICK', status: 'PENDING',
    ui_status: 'PENDING', start_date: '2026-08-13', end_date: '2026-08-13',
    total_days: 0, hours: 2, leave_unit: 'hour',
    start_time: '09:00:00', end_time: '11:00:00',
    reason: 'พบแพทย์', file_name: null, emp_name: 'สมชาย ใจดี' },
  { id: 'q3', request_no: '260814-0001', leave_type: 'SICK', status: 'PENDING',
    ui_status: 'PENDING', start_date: '2026-08-14', end_date: '2026-08-14',
    total_days: null, hours: null, leave_unit: 'day',
    reason: 'ไม่มีข้อมูลจำนวนวัน', file_name: null, emp_name: 'สมชาย ใจดี' }
];

function makeEnv(scopeExtra) {
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div></body></html>');
  const win = dom.window;
  const NJHR = {
    state: { currentRoute: '#/ot' }, router: { navId: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    features: {}, views: { register: () => {} }, compat: { scope: {} }
  };
  Object.assign(NJHR.compat.scope, {
    icon: () => '<span class="ic"></span>', esc, debounce: f => f,
    avatarHTML: () => '<span class="avatar"></span>',
    emptyState: m => '<div class="empty">' + m + '</div>',
    fmtDateDMY: v => { const p = String(v == null ? '' : v).slice(0, 10).split('-');
      if (p.length !== 3) return '—';
      const y = parseInt(p[0], 10), m = parseInt(p[1], 10), d = parseInt(p[2], 10);
      if (!isFinite(y) || !isFinite(m) || !isFinite(d)) return '—';
      const z = n => (n < 10 ? '0' + n : '' + n);
      return z(d) + '/' + z(m) + '/' + y; },
    fmtDate: d => String(d || ''), empName: () => 'สมชาย ใจดี',
    statusBadge: s => '<span class="badge">' + s + '</span>',
    currentUser: () => ({ id: 'u1', role: 'USER', empId: 'e1' }),
    currentEmp: () => ({ id: 'e1', firstName: 'สมชาย', lastName: 'ใจดี', deptId: 'd1' }),
    dept: () => 'ขนส่ง', toast: () => {},
    /* db.ots ว่างเปล่าโดยเจตนา — ถ้าหน้า OT ยังอ่าน localStorage จะตกทดสอบทันที */
    db: { ots: [], leaves: [] },
    showTimeline: () => {}, bindReqCardActions: () => {},
    sbReady: () => true, sbToken: () => 'tok',
    sbRpcList: fn => (fn === 'njhr_ot_list' ? Promise.resolve(OTS) : Promise.resolve([])),
    /* jobs จงใจเรียงสลับ (no 2 มาก่อน no 1) เพื่อพิสูจน์ว่าเลือก "รายการที่ 1" จาก job_no จริง
       ไม่ใช่หยิบตัวแรกของ array */
    sbRpc: (fn, body) => {
      if (fn === 'njhr_ot_get') {
        return Promise.resolve({ data: { jobs: [
          { no: 2, job_code: 'JB-2', job_type: 'คีย์ใบขน' },
          { no: 1, job_code: 'ABC123', job_type: 'ตรวจปล่อย' }
        ] } });
      }
      return Promise.resolve({});
    },
    confirmDialog: () => {}, closeModal: () => {},
    openModal: () => {}, closeModal: () => {}, confirmDialog: () => {},
    nav: () => {}, TH_MONTHS: ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'],
    lvType: c => ({ SICK: { code: 'SICK', name: 'ลาป่วย', color: '#16A34A' },
                    BUSINESS: { code: 'BUSINESS', name: 'ลากิจ', color: '#2563EB' } }[c] ||
                  { code: c, name: c, color: '#64748B' }),
    lvMode: r => (r && r.leave_unit === 'hour' ? 'HOURLY' : 'FULL'),
    lvModeTxt: m => ({ FULL: 'เต็มวัน', HOURLY: 'รายชั่วโมง' }[m] || m),
    lvNum: v => { const n = Number(v); return isFinite(n) ? Math.round(n * 100) / 100 : 0; },
    lvCode: x => (x && typeof x === 'object'
      ? (x.request_no || x.requestNo || ('LV-' + String(x.id || '').slice(0, 6).toUpperCase()))
      : 'LV-' + String(x || '').slice(0, 6).toUpperCase()),
    LEAVE_TYPES: [], refreshLeavePending: () => {}, RQ_CARDS: [], rqState: { seq: 0, bal: [], err: '' },
    rqRenderMenu: () => {}, rqRenderBal: () => {}, rqPick: () => null, rhStatus: () => ({ k: 'PENDING' }),
    audit: () => {}, saveDB: () => {}, nowStamp: () => '', render: () => {}, uid: () => 'x'
  });
  Object.assign(NJHR.compat.scope, scopeExtra || {});
  win.NJHR = NJHR;
  const ctx = vm.createContext(win);
  return { win, NJHR, ctx,
    run: rel => vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), ctx, { filename: rel }),
    host: () => win.document.getElementById('app') };
}

function grab(E, name) {
  let fn = null;
  E.NJHR.views.register = (n, f) => { if (n === name) fn = f; };
  return () => fn;
}

/* ---------- ตรวจร่วมของทั้งสองตาราง ---------- */
function auditTable(label, root, heads, rowCount) {
  const wraps = root.querySelectorAll('.lvt-wrap');
  chk(label + ' · มีตารางเดียว', wraps.length === 1, 'พบ ' + wraps.length + ' ตาราง');
  const wrap = wraps[0];
  if (!wrap) return;
  chk(label + ' · ตารางเป็น only-desktop', wrap.classList.contains('only-desktop'), wrap.className);
  const tbl = wrap.querySelector('table');
  chk(label + ' · thead อยู่ในตารางเดียวกัน', !!tbl && tbl.querySelectorAll(':scope > thead').length === 1, '');
  chk(label + ' · tbody อยู่ในตารางเดียวกัน', !!tbl && tbl.querySelectorAll(':scope > tbody').length === 1, '');

  const th = Array.from(tbl.querySelectorAll('thead th'));
  const got = th.map(x => x.textContent.trim());
  chk(label + ' · ลำดับหัวคอลัมน์', JSON.stringify(got.slice(0, heads.length)) === JSON.stringify(heads),
    got.join(' | '));
  chk(label + ' · คอลัมน์ปุ่มไม่มีชื่อหัว', th.length === heads.length + 1 && got[heads.length] === '',
    'คอลัมน์ทั้งหมด ' + th.length);
  chk(label + ' · ไม่มีหัวข้อ "จัดการ"', got.indexOf('จัดการ') < 0 && wrap.innerHTML.indexOf('จัดการ') < 0, '');

  const trs = Array.from(tbl.querySelectorAll('tbody tr'));
  chk(label + ' · จำนวนแถวตรงจำนวนข้อมูล', trs.length === rowCount, trs.length + '/' + rowCount);
  const bad = trs.filter(tr => tr.children.length !== th.length);
  chk(label + ' · ทุกแถวมีจำนวนช่องเท่าหัวคอลัมน์', bad.length === 0, 'แถวไม่ตรง ' + bad.length);

  const lastOk = trs.every(tr => {
    const last = tr.children[tr.children.length - 1];
    return last && last.querySelector('.lv-eye');
  });
  chk(label + ' · ปุ่มดูรายละเอียดอยู่ช่องขวาสุด', lastOk, '');
  chk(label + ' · ไม่มีการ์ดฝั่ง Desktop', wrap.querySelectorAll('.req-card, .lv-row').length === 0, '');
  return trs;
}

/* ================= OT ================= */
async function testOT() {
  console.log('\n== ตาราง OT (#/ot) ==');
  const E = makeEnv();
  const get = grab(E, 'viewOT');
  E.run('views/ot/main.js');
  const viewOT = get();
  chk('OT · chunk ลงทะเบียน viewOT', typeof viewOT === 'function', '');
  if (typeof viewOT !== 'function') return;
  viewOT(E.host());
  await tick(60);                    // viewOT โหลดจาก njhr_ot_list แบบ async
  const root = E.host();

  const trs = auditTable('OT', root,
    ['เลขคำขอ', 'ชื่อพนักงาน', 'ประเภท', 'ประเภทงาน', 'วันที่', 'ช่วงเวลา',
     'จำนวนชั่วโมง', 'ไฟล์แนบ', 'สถานะ'],
    OTS.length);
  if (!trs) return;

  const r0 = Array.from(trs[0].children).map(td => td.textContent.trim());
  chk('OT · เลขคำขอตรงข้อมูล', r0[0] === '260811-0001', r0[0]);
  /* คอลัมน์ใหม่ — RPC ของ OT คืน prefix กับ emp_name แยกกัน ต้องประกอบเอง
     ต่างจากตารางลางานที่ emp_name รวมคำนำหน้ามาแล้ว */
  chk('OT · ชื่อพนักงาน = prefix + emp_name',
    r0[1] === 'นายสมชาย ใจดี', r0[1]);
  /* njhr_ot_list ไม่คืนประเภทงานรายรายการ (อยู่ที่ njhr_ot_jobs)
     คอลัมน์ "ประเภท" จึงใช้ is_holiday ชุดเดียวกับหน้า REPORT OT */
  chk('OT · ประเภทเป็นบรรทัดเดียว ไม่มีจำนวนรายการงาน', r0[2] === 'OT ปกติ', r0[2]);
  chk('OT · ประเภทงานมาจากรายการที่ 1', r0[3] === 'ตรวจปล่อย', r0[3]);
  chk('OT · วันที่เป็น DD/MM/YYYY ปี ค.ศ.', r0[4] === '11/08/2026', r0[4]);
  chk('OT · ช่วงเวลาแสดงเฉพาะเวลา ไม่มีชั่วโมงซ้ำ', r0[5] === '18:00 – 21:00', r0[5]);
  chk('OT · จำนวนชั่วโมงแยกคอลัมน์', r0[6] === '3 ชั่วโมง', r0[6]);
  chk('OT · ไฟล์แนบนับถูก', r0[7] === '1 ไฟล์', r0[7]);
  chk('OT · สถานะตรงข้อมูล', r0[8] === 'PENDING', r0[8]);
  chk('OT · PENDING มีปุ่มยกเลิก', !!trs[0].querySelector('[data-cancel="OT-AAA111"]'), '');
  chk('OT · APPROVED ไม่มีปุ่มยกเลิก', !trs[1].querySelector('[data-cancel]'), '');
  chk('OT · data-detail คงเดิม', !!trs[0].querySelector('[data-detail="OT-AAA111"]'), '');

  const r1 = Array.from(trs[1].children).map(td => td.textContent.trim());
  chk('OT · วันหยุดแยกประเภทถูก (is_holiday=true)', r1[2] === 'OT วันหยุด', r1[2]);
  chk('OT · คำขอเก่าที่ไม่มี request_no ถอยไปใช้ id', r1[0] === 'OT-BBB222', r1[0]);
  chk('OT · ไม่มีรายการงาน → ประเภทงานแสดง —', r1[3] === '—', r1[3]);
  chk('OT · คำขอเก่านับไฟล์ระดับคำขอ', r1[7] === '1 ไฟล์', r1[7]);
  chk('OT · มีคอลัมน์ .lvt-c-emp ทุกแถว',
    root.querySelectorAll('.lvt-ot tbody td.lvt-c-emp').length === OTS.length, '');
  chk('OT · ชื่อพนักงานอยู่ต่อจากเลขคำขอทันที',
    Array.from(trs[0].children)[1].classList.contains('lvt-c-emp'), '');
  chk('OT · ไม่มีชื่อพนักงาน → แสดง — ไม่ใช่ค่าว่างหรือ undefined',
    !/undefined|null/.test(r0[1] + r1[1]), r0[1] + ' · ' + r1[1]);

  const mob = root.querySelectorAll('.req-card.only-mobile');
  chk('OT · การ์ดมือถือเดิมครบ', mob.length === OTS.length, mob.length + '/' + OTS.length);
}

/* ================= LEAVE ================= */
async function testLeave() {
  console.log('\n== ตารางลางาน (#/leave) ==');
  const E = makeEnv();
  E.NJHR.state.currentRoute = '#/leave';
  let viewLeave = null;
  E.NJHR.views.register = (n, f) => { if (n === 'viewLeave') viewLeave = f; };
  E.NJHR.compat.scope.sbRpcList = (fn) => {
    if (fn === 'njhr_leave_balances') return Promise.resolve([]);
    if (fn === 'njhr_leave_list') return Promise.resolve(LEAVES.map(r => Object.assign({ total_count: LEAVES.length }, r)));
    return Promise.resolve([]);
  };
  E.run('views/leave/main.js');
  chk('LEAVE · chunk ลงทะเบียน viewLeave', typeof viewLeave === 'function', '');
  if (typeof viewLeave !== 'function') return;
  viewLeave(E.host());

  setTimeout(function () {
    const root = E.host();
    const trs = auditTable('ลางาน', root,
      ['เลขคำขอ', 'ชื่อพนักงาน', 'ประเภท', 'วันที่', 'รูปแบบการลา', 'จำนวนวัน',
       'ไฟล์แนบ', 'สถานะ'], LEAVES.length);
    if (trs) {
      const r0 = Array.from(trs[0].children).map(td => td.textContent.trim());
      chk('ลางาน · เลขคำขอตรงข้อมูล', r0[0] === '260810-0007', r0[0]);
      /* คอลัมน์ใหม่ — ชื่อมาจาก emp_name ที่ RPC ส่งมาอยู่แล้ว */
      chk('ลางาน · ชื่อพนักงานมาจาก emp_name จริง', r0[1] === LEAVES[0].emp_name, r0[1]);
      chk('ลางาน · ประเภทเป็นชื่อประเภทการลา', r0[2] === 'ลาป่วย', r0[2]);
      chk('ลางาน · วันที่เป็น DD/MM/YYYY ปี ค.ศ.', r0[3] === '10/08/2026', r0[3]);
      /* รูปแบบการลาเหลือบรรทัดเดียว จำนวนวันแยกไปคอลัมน์ใหม่ */
      chk('ลางาน · รูปแบบการลาเป็นบรรทัดเดียว ไม่มีจำนวนวันปน', r0[4] === 'เต็มวัน', r0[4]);
      chk('ลางาน · คอลัมน์จำนวนวันแสดงค่าจริง', r0[5] === '1 วัน', r0[5]);
      chk('ลางาน · ไฟล์แนบนับถูก', r0[6] === '1 ไฟล์', r0[6]);
      chk('ลางาน · สถานะตรงข้อมูล', r0[7] === 'PENDING', r0[7]);
      chk('ลางาน · PENDING มีปุ่มยกเลิก', !!trs[0].querySelector('[data-lvcancel="lv-1"]'), '');
      chk('ลางาน · APPROVED ไม่มีปุ่มยกเลิก', !trs[1].querySelector('[data-lvcancel]'), '');
      chk('ลางาน · data-lvdetail คงเดิม', !!trs[0].querySelector('[data-lvdetail="lv-1"]'), '');
      const r1 = Array.from(trs[1].children).map(td => td.textContent.trim());
      chk('ลางาน · ช่วงวันที่เป็น DD/MM/YYYY ทั้งคู่', r1[3] === '03/08/2026 – 04/08/2026', r1[3]);
      chk('ลางาน · คำขอหลายวันแสดงจำนวนวันถูก', r1[5] === '2 วัน', r1[5]);
      chk('ลางาน · ไม่มีไฟล์แนบแสดงข้อความเดิม', r1[6] === 'ไม่มีไฟล์แนบ', r1[6]);
      chk('ลางาน · ชื่อพนักงานแถวที่ 2 ตรงข้อมูล', r1[1] === LEAVES[1].emp_name, r1[1]);
      chk('ลางาน · มีคอลัมน์ .lvt-c-emp ทุกแถว',
        root.querySelectorAll('.lvt-lv tbody td.lvt-c-emp').length === LEAVES.length, '');
      chk('ลางาน · ชื่อพนักงานอยู่ต่อจากเลขคำขอทันที',
        Array.from(trs[0].children)[1].classList.contains('lvt-c-emp'), '');
      const mob = root.querySelectorAll('.req-card.only-mobile');
      chk('ลางาน · การ์ดมือถือเดิมครบ', mob.length === LEAVES.length, mob.length + '/' + LEAVES.length);
      /* คอลัมน์ "รูปแบบการลา" ต้องไม่มีบรรทัดที่สองและไม่มี <br> */
      const modeCells = Array.from(root.querySelectorAll('.lvt-lv tbody td.lvt-c-mode'));
      chk('ลางาน · รูปแบบการลาไม่มี <small> บรรทัดรอง',
        modeCells.every(td => td.querySelector('small') === null), '');
      chk('ลางาน · รูปแบบการลาไม่มี <br>',
        modeCells.every(td => td.querySelector('br') === null), '');
      chk('ลางาน · ไม่มีคำว่า "วัน" ซ้ำในคอลัมน์รูปแบบการลา',
        modeCells.every(td => !/\d/.test(td.textContent)),
        modeCells.map(td => td.textContent.trim()).join(' · '));
      chk('ลางาน · มีคอลัมน์ .lvt-c-qty ทุกแถว',
        root.querySelectorAll('.lvt-lv tbody td.lvt-c-qty').length === LEAVES.length, '');
    }
    testLeaveQty();
  }, 60);
}

const tick = ms => new Promise(r => setTimeout(r, ms || 40));

/* ================= จำนวนวัน: ครึ่งวัน · รายชั่วโมง · ไม่มีข้อมูล ================= */
async function testLeaveQty() {
  console.log('\n== ตารางลางาน · คอลัมน์จำนวนวัน ==');
  const E = makeEnv();
  E.NJHR.state.currentRoute = '#/leave';
  let viewLeave = null;
  E.NJHR.views.register = (n, f) => { if (n === 'viewLeave') viewLeave = f; };
  E.NJHR.compat.scope.lvMode = r => (r && r.leave_unit === 'hour' ? 'HOURLY'
    : (r && r.is_halfday ? 'HALF_AM' : 'FULL'));
  E.NJHR.compat.scope.lvModeTxt = m => ({ FULL: 'เต็มวัน', HALF_AM: 'ครึ่งวันเช้า',
    HALF_PM: 'ครึ่งวันบ่าย', HOURLY: 'รายชั่วโมง' }[m] || m);
  E.NJHR.compat.scope.sbRpcList = (fn) => {
    if (fn === 'njhr_leave_balances') return Promise.resolve([]);
    if (fn === 'njhr_leave_list') {
      return Promise.resolve(LEAVES_QTY.map(r => Object.assign({ total_count: LEAVES_QTY.length }, r)));
    }
    return Promise.resolve([]);
  };
  E.run('views/leave/main.js');
  viewLeave(E.host());
  await tick(80);

  const rows = Array.from(E.host().querySelectorAll('.lvt-lv tbody tr'))
    .map(tr => Array.from(tr.children).map(td => td.textContent.trim()));
  chk('จำนวนวัน · แสดงครบ 3 แถว', rows.length === 3, rows.length + '/3');
  if (rows.length === 3) {
    /* คอลัมน์เลื่อนไป 1 ช่องเพราะเพิ่ม "ชื่อพนักงาน" ต่อจากเลขคำขอ */
    chk('ครึ่งวัน · รูปแบบการลา = ครึ่งวันเช้า', rows[0][4] === 'ครึ่งวันเช้า', rows[0][4]);
    chk('ครึ่งวัน · จำนวนวัน = 0.5 วัน', rows[0][5] === '0.5 วัน', rows[0][5]);
    chk('รายชั่วโมง · รูปแบบการลา = รายชั่วโมง', rows[1][4] === 'รายชั่วโมง', rows[1][4]);
    chk('รายชั่วโมง · จำนวนวัน = 2 ชั่วโมง (ใช้ hours)', rows[1][5] === '2 ชั่วโมง', rows[1][5]);
    chk('ไม่มีข้อมูล · จำนวนวันแสดง — ไม่ใช่ undefined/null',
      rows[2][5] === '—', rows[2][5]);
    chk('ไม่มีข้อมูล · ไม่มีคำว่า undefined หรือ null บนหน้า',
      !/undefined|null|NaN/.test(E.host().textContent), '');
    /* ตารางลางานมี 9 ช่อง (ตาราง OT มี 10) */
    chk('ทุกแถวมีช่องครบ 9 ช่อง', rows.every(r => r.length === 9),
      rows.map(r => r.length).join(','));
    /* ไม่มี emp_name ในชุดนี้ → ต้องถอยไปชื่อผู้ใช้ปัจจุบัน ไม่ใช่ค่าว่างหรือ undefined */
    chk('ไม่มี emp_name · ช่องชื่อไม่ว่างและไม่ใช่ undefined',
      rows.every(r => r[1] && !/undefined|null/.test(r[1])),
      rows.map(r => r[1]).join(' · '));
  }
  leaveDeskCss();
  await testOtMultiJob();
}

/* ================= ขนาดตัวอักษร + ความกว้างคอลัมน์ (Desktop เท่านั้น) ================= */
function leaveDeskCss() {
  console.log('\n== ตารางลางาน · ขนาดตัวอักษรและคอลัมน์บนจอคอม ==');
  const fsSrc = require('fs'), pth = require('path');
  const css = fsSrc.readFileSync(pth.join(ROOT, 'styles.css'), 'utf8');
  const mob = fsSrc.readFileSync(pth.join(ROOT, 'mobile.css'), 'utf8');
  const min = css.replace(/\s+/g, '');

  /* ทุกกฎต้องอยู่ในบล็อกจอคอม */
  const i901 = min.indexOf('@media(min-width:901px)');
  const iLv = min.indexOf('.lvt-lvtheadth{font-size:');
  chk('กฎขนาดตัวอักษรอยู่ใน @media (min-width: 901px)', i901 >= 0 && iLv > i901, '');

  function num(re) { const m = re.exec(min); return m ? parseFloat(m[1]) : null; }
  const th = num(/\.lvt-lvtheadth\{font-size:([\d.]+)px/);
  const bd = num(/\.lvt-lvtbodytdb\{font-size:([\d.]+)px/);
  const sm = num(/\.lvt-lvtbodytdsmall\{font-size:([\d.]+)px/);
  const chip = num(/\.lvt-lvtbodytd\.chip\{font-size:([\d.]+)px/);

  chk('หัวตารางเล็กลงจาก 12.5px', th !== null && th < 12.5, th + 'px');
  chk('ข้อมูลในแถวเล็กลงจาก 15px', bd !== null && bd < 15, bd + 'px');
  chk('บรรทัดรองเล็กลงจาก 13px', sm !== null && sm < 13, sm + 'px');
  chk('Badge ประเภทลาเล็กลง', chip !== null && chip < 13, chip + 'px');

  /* ---------- ห้ามมีตัวหนาในตารางลางาน ----------
     <b> ได้ 700 จากค่าเริ่มต้นของเบราว์เซอร์ · หัวตาราง 600 · Badge Desktop 600
     ทั้งสามจุดต้องถูกเขียนทับ ไม่งั้นยังหนาอยู่ */
  const wTh = num(/\.lvt-lvtheadth\{[^}]*font-weight:(\d+)/);
  const wB = num(/\.lvt-lvtbodytdb\{[^}]*font-weight:(\d+)/);
  const wTd = num(/\.lvt-lvtbodytd\{[^}]*font-weight:(\d+)/);
  const wChip = num(/\.lvt-lvtbodytd\.chip\{[^}]*font-weight:(\d+)/);
  const wBadge = num(/\.lvt-lv\.lvt-c-st\.badge\{[^}]*font-weight:(\d+)/);
  const wBtn = num(/\.lvt-lv\.lvt-acts\.btn\{[^}]*font-weight:(\d+)/);
  chk('หัวตารางไม่หนา (≤ 500)', wTh !== null && wTh <= 500, wTh);
  chk('ข้อมูลในแถวไม่หนา (<b> ถูกเขียนทับเป็น 400)', wB === 400, wB);
  chk('ช่องตารางตั้งน้ำหนักปกติ', wTd !== null && wTd <= 500, wTd);
  chk('Badge ประเภทลาไม่หนา (≤ 500)', wChip !== null && wChip <= 500, wChip);
  chk('Badge สถานะไม่หนา (≤ 500) — เขียนทับกฎ Desktop เดิมที่เป็น 600',
    wBadge !== null && wBadge <= 500, wBadge);
  chk('ปุ่มยกเลิกคำขอไม่หนา (≤ 500)', wBtn !== null && wBtn <= 500, wBtn);
  chk('มีกฎกัน strong หนาหลุดเข้ามา',
    /\.lvt-lvtbodytdb,\.lvt-lvtbodytdstrong\{font-weight:400/.test(min), '');
  /* ต้องไม่มี 600/700/bold หลงเหลือในกฎของ .lvt-lv เลย */
  const lvRules = (min.match(/\.lvt-lv[^{]*\{[^}]*\}/g) || []);
  const heavy = lvRules.filter(r => /font-weight:(600|700|800|900|bold)/.test(r));
  chk('ไม่มี font-weight 600/700/bold ในกฎของ .lvt-lv เลย', heavy.length === 0,
    heavy.join(' | ').slice(0, 90));
  chk('ตรวจครบทุกกฎของ .lvt-lv', lvRules.length >= 10, lvRules.length + ' กฎ');
  /* ต้องไม่เล็กจนอ่านไม่ออก */
  chk('ยังอ่านง่าย ไม่ต่ำกว่า 11px', [th, bd, sm, chip].every(v => v !== null && v >= 11),
    [th, bd, sm, chip].join(' / '));

  /* ตาราง OT ต้องไม่ถูกแตะ */
  /* ตาราง OT มีชุดขนาดของตัวเองแล้ว (10 คอลัมน์) — ตรวจว่าย่อและบางลงจริง */
  const otTh = num(/\.lvt-ottheadth\{font-size:([\d.]+)px/);
  const otBd = num(/\.lvt-ottbodytdb\{font-size:([\d.]+)px/);
  chk('OT · หัวตารางเล็กลงจาก 12.5px', otTh !== null && otTh < 12.5, otTh + 'px');
  chk('OT · ข้อมูลในแถวเล็กลงจาก 15px', otBd !== null && otBd < 15, otBd + 'px');
  chk('OT · ตัวอักษรบางลง (font-weight 500)',
    /\.lvt-ottheadth\{[^}]*font-weight:500/.test(min) &&
    /\.lvt-ottbodytdb\{[^}]*font-weight:500/.test(min), '');
  chk('OT · ปุ่มจัดการเล็กและบางลง',
    /\.lvt-ot\.lvt-acts\.btn\{[^}]*font-weight:500/.test(min), '');
  chk('OT · ยังอ่านง่าย ไม่ต่ำกว่า 11px',
    [otTh, otBd].every(v => v !== null && v >= 11), otTh + ' / ' + otBd);
  chk('ค่ากลาง .lvt thead th ยังเป็น 12.5px', min.indexOf('.lvttheadth{text-align:left;font-weight:600;font-size:12.5px') >= 0, '');
  chk('ค่ากลาง .lvt tbody td b ยังเป็น 15px', min.indexOf('.lvttbodytdb{display:block;font-size:15px') >= 0, '');

  /* มือถือต้องไม่มีกฎใหม่เลย */
  chk('mobile.css ไม่มีกฎ .lvt-lv เพิ่ม', mob.indexOf('.lvt-lv') < 0, '');
  chk('ตารางยังเป็น .only-desktop',
    fsSrc.readFileSync(pth.join(ROOT, 'src/34-view-requests-leave.js'), 'utf8')
      .indexOf('card p0 only-desktop lvt-wrap') >= 0, '');

  /* ความกว้าง 9 คอลัมน์ต้องรวม 100% พอดี */
  const w = [];
  for (let n = 1; n <= 9; n++) {
    const sel = n === 1 ? '(?::first-child|:nth-child\\(1\\))' : ':nth-child\\(' + n + '\\)';
    const m = new RegExp('\\.lvt-lvtheadth' + sel + '\\{width:([\\d.]+)%').exec(min);
    if (m) w.push(parseFloat(m[1]));
  }
  console.log('        ความกว้าง: ' + w.join('% · ') + '%  รวม ' + w.reduce((a, b) => a + b, 0) + '%');
  chk('กำหนดความกว้างครบ 9 คอลัมน์', w.length === 9, w.length + '/9');
  chk('รวมได้ 100% พอดี', Math.abs(w.reduce((a, b) => a + b, 0) - 100) < 0.01, '');
  chk('คอลัมน์ชื่อพนักงานกว้างพอ (≥ 13%)', w[1] >= 13, w[1] + '%');


  /* ชื่อยาวต้องตัดด้วย ellipsis ไม่ดันคอลัมน์อื่น */
  chk('ชื่อพนักงานตัดด้วย ellipsis',
    /\.lvt-lvtbodytd\.lvt-c-empb\{overflow:hidden;text-overflow:ellipsis;white-space:nowrap/.test(min), '');

  /* ตรวจว่าข้อความยาวสุดยังพอในกรอบจริง */
  const FRAME = 1366 - 270 - 48;          // จอ 1366 · Sidebar 270 · padding 48
  const nameW = FRAME * (w[1] / 100) - 24; // ลบ padding ซ้ายขวา 12+12
  const need = Math.ceil('นายสมชาย ใจดี'.length * (bd || 13) * 0.62);
  console.log('        ที่ 1366px ช่องชื่อกว้าง ≈ ' + Math.floor(nameW) + 'px · ชื่อทั่วไปใช้ ≈ ' + need + 'px');
  chk('ชื่อพนักงานทั่วไปไม่ถูกตัดที่ 1366px', nameW >= need,
    Math.floor(nameW) + ' ≥ ' + need);

  /* ตาราง OT — 10 คอลัมน์ ต้องรวม 100% เช่นกัน */
  const wo = [];
  for (let n = 1; n <= 10; n++) {
    const sel = n === 1 ? '(?::first-child|:nth-child\\(1\\))' : ':nth-child\\(' + n + '\\)';
    const m = new RegExp('\\.lvt-ottheadth' + sel + '\\{width:([\\d.]+)%').exec(min);
    if (m) wo.push(parseFloat(m[1]));
  }
  console.log('        OT ความกว้าง: ' + wo.join('% · ') + '%  รวม ' + wo.reduce((a, b) => a + b, 0) + '%');
  chk('OT · กำหนดความกว้างครบ 10 คอลัมน์', wo.length === 10, wo.length + '/10');
  chk('OT · รวมได้ 100% พอดี', Math.abs(wo.reduce((a, b) => a + b, 0) - 100) < 0.01, '');
  chk('OT · ชื่อพนักงานตัดด้วย ellipsis',
    /\.lvt-ottbodytd\.lvt-c-empb\{overflow:hidden;text-overflow:ellipsis;white-space:nowrap/.test(min), '');
  const otNameW = FRAME * (wo[1] / 100) - 20;
  const otNeed = Math.ceil('นายสมชาย ใจดี'.length * (otBd || 12.5) * 0.62);
  console.log('        OT ที่ 1366px ช่องชื่อกว้าง ≈ ' + Math.floor(otNameW) + 'px · ต้องการ ≈ ' + otNeed + 'px');
  chk('OT · ชื่อพนักงานทั่วไปไม่ถูกตัดที่ 1366px', otNameW >= otNeed,
    Math.floor(otNameW) + ' ≥ ' + otNeed);
  chk('mobile.css ไม่มีกฎ .lvt-ot เพิ่ม', mob.indexOf('.lvt-ot') < 0, '');

}

/* ================= OT หลายรายการงาน: ต้องใช้ประเภทงานของรายการที่ 1 เท่านั้น ================= */
async function testOtMultiJob() {
  console.log('\n== ตาราง OT · คำขอหลายรายการงาน ==');
  const ROWS = [
    { id: 'M1', request_no: '260812-0001', employee_id: 'e1', emp_name: 'สมชาย ใจดี',
      ot_date: '2026-08-12', start_time: '17:30:00', end_time: '20:30:00', spans_next_day: false,
      ot_hours: 3, reason: 'งานด่วน', status: 'PENDING', created_at: '2026-08-12T10:00:00Z',
      jobs_count: 3, files_count: 0, is_holiday: true },
    { id: 'M2', request_no: '260812-0002', employee_id: 'e1', emp_name: 'สมชาย ใจดี',
      ot_date: '2026-08-12', start_time: '18:00:00', end_time: '19:00:00', spans_next_day: false,
      ot_hours: 1, reason: 'งานเดี่ยว', status: 'APPROVED', created_at: '2026-08-12T09:00:00Z',
      jobs_count: 1, files_count: 0, is_holiday: false },
    { id: 'M3', request_no: '260812-0003', employee_id: 'e1', emp_name: 'สมชาย ใจดี',
      ot_date: '2026-08-12', start_time: '20:00:00', end_time: '21:00:00', spans_next_day: false,
      ot_hours: null, reason: 'ไม่มีชั่วโมง', status: 'PENDING', created_at: '2026-08-12T08:00:00Z',
      jobs_count: 2, files_count: 0, is_holiday: false }
  ];
  /* M1 มี 3 รายการ ส่งกลับแบบสลับลำดับ — ต้องเลือก no:1 = "คีย์ใบขน"
     M3 รายการที่ 1 ไม่มี job_type — ต้องได้ — ไม่ใช่หยิบของรายการที่ 2 */
  const JOBS = {
    M1: [{ no: 3, job_type: 'คีย์ + ตรวจปล่อย' }, { no: 1, job_type: 'คีย์ใบขน' }, { no: 2, job_type: 'ตรวจปล่อย' }],
    M2: [{ no: 1, job_code: 'ABC123', job_type: 'ตรวจปล่อย' }],
    M3: [{ no: 2, job_type: 'ตรวจปล่อย' }, { no: 1, job_type: '' }]
  };
  const E = makeEnv();
  E.NJHR.state.currentRoute = '#/ot';
  const get = grab(E, 'viewOT');
  E.NJHR.compat.scope.sbRpcList = fn => (fn === 'njhr_ot_list' ? Promise.resolve(ROWS) : Promise.resolve([]));
  E.NJHR.compat.scope.sbRpc = (fn, body) => (fn === 'njhr_ot_get'
    ? Promise.resolve({ data: { jobs: JOBS[body.p_id] || [] } })
    : Promise.resolve({}));
  E.run('views/ot/main.js');
  get()(E.host());
  await tick(80);

  const rows = Array.from(E.host().querySelectorAll('.lvt-ot tbody tr'))
    .map(tr => Array.from(tr.children).map(td => td.textContent.trim()));
  chk('หลายรายการงาน · แสดงครบ 3 แถว', rows.length === 3, rows.length + '/3');
  if (rows.length === 3) {
    chk('3 รายการงาน · ประเภทงาน = คีย์ใบขน (รายการที่ 1)', rows[0][3] === 'คีย์ใบขน', rows[0][3]);
    chk('3 รายการงาน · ไม่รวมประเภทงานหลายรายการ',
      rows[0][2].indexOf('ตรวจปล่อย') < 0 && rows[0][2].indexOf(',') < 0, rows[0][2]);
    chk('3 รายการงาน · ประเภทยังเป็น OT วันหยุด บรรทัดเดียว', rows[0][2] === 'OT วันหยุด', rows[0][2]);
    chk('3 รายการงาน · ช่วงเวลา = 17:30 – 20:30', rows[0][5] === '17:30 – 20:30', rows[0][5]);
    chk('3 รายการงาน · จำนวนชั่วโมง = 3 ชั่วโมง', rows[0][6] === '3 ชั่วโมง', rows[0][6]);
    chk('1 รายการงาน · ประเภทงาน = ตรวจปล่อย', rows[1][3] === 'ตรวจปล่อย', rows[1][3]);
    chk('รายการที่ 1 ไม่มีประเภทงาน · แสดง — ไม่หยิบรายการที่ 2',
      rows[2][3] === '—', rows[2][3]);
    chk('ไม่มี ot_hours · แสดง — ไม่ใช่ 0 หรือ undefined', rows[2][6] === '—', rows[2][6]);
    chk('ทุกแถวมีช่องครบ 10 ช่อง', rows.every(r => r.length === 10), rows.map(r => r.length).join(','));
    chk('ไม่มีคำว่า "รายการงาน" ในตาราง Desktop แล้ว',
      E.host().querySelector('.lvt-ot').textContent.indexOf('รายการงาน') < 0, '');
    chk('ไม่มี undefined / null / NaN บนหน้า',
      !/undefined|null|NaN/.test(E.host().textContent), '');
  }
  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
}

(async function () { await testOT(); await testLeave(); })();
