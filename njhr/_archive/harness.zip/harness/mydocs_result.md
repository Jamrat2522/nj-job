# MYDOCS_TEST — ผลทดสอบ "เอกสารของฉัน" (PROMPT 2)

รัน: `node harness/mydocs_test.js .` · โหลด chunk ที่ build แล้วจริง (`runtime/core.js` + `compat/app-legacy.js`) ลง jsdom
stub เฉพาะ `NJHR.compat.scope` ตามสัญญาเดิม · **ไม่แตะ Supabase จริง ไม่เขียน Production**

| # | เคส | ผล | หลักฐาน |
|---|---|---|---|
| 1 | A1 · ไม่มีการเรียก Legacy RPC 6 ตัวใน Frontend ทั้งโปรเจกต์ | **PASS** | ตรวจ 6 ตัว ไม่พบเลย |
| 2 | A2 · เมนูมี userTitle "เอกสารของฉัน" และ myDocsBadge | **PASS** | พบทั้งคู่ใน core |
| 3 | A3 · Badge อ่านจาก NJHR.state.docPending (ไม่นับจาก array) | **PASS** | พบ accessor |
| 4 | A4 · refreshDocPending เรียก njhr_doc_my_pending | **PASS** | พบใน core |
| 5 | A5 · confirmation_text ดึงจาก njhr_doc_confirm_text | **PASS** | พบใน compat |
| 6 | A6 · ไม่ส่งข้อความยืนยันจาก client (DB เป็นผู้ snapshot) | **PASS** | ไม่มีพารามิเตอร์ข้อความยืนยันใน payload ใด ๆ |
| 7 | A7 · p_action ที่ใช้มีแค่ ACKNOWLEDGE / REJECT (ตามที่ backend รองรับ) | **PASS** | p_action=ACKNOWLEDGE,REJECT |
| 8 | A8 · ไม่เก็บรหัสผ่านลง localStorage / sessionStorage | **PASS** | ไม่พบการเก็บรหัสผ่าน |
| 9 | A9 · ล้างช่องรหัสผ่านหลังส่ง Request | **PASS** | พบการ clear |
| 10 | A10 · หลังตอบเอกสารสำเร็จ โหลดสถานะใหม่จาก Server | **PASS** | เรียก docRenderDetail + refreshDocPending |
| 11 | A11 · ไม่เก็บ ACK ลง localStorage | **PASS** | ไม่พบ |
| 12 | A12 · หน้าเอกสารของฉันไม่ส่ง p_employee จาก browser | **PASS** | ส่ง p_employee: null ให้ Server ผูกจาก token |
| 13 | B1 · USER ได้หน้า "เอกสารของฉัน" ไม่ใช่ศูนย์จัดการเอกสาร HR | **PASS** | หัวเรื่องถูกต้อง |
| 14 | B2 · ไม่มี Toolbar บริหาร (สร้างเอกสาร / Export / หัวเอกสาร / ตัวกรอง) | **PASS** | ซ่อนครบ |
| 15 | B3 · แยก 2 กลุ่ม รอดำเนินการ / ดำเนินการแล้ว | **PASS** | พบทั้ง 2 หัวข้อ |
| 16 | B4 · SENT/VIEWED อยู่กลุ่มรอดำเนินการ | **PASS** | พบ 000001 (รอลงนาม) + 000002 (รอรับทราบ) |
| 17 | B5 · SIGNED/ACKNOWLEDGED อยู่กลุ่มดำเนินการแล้ว (ไม่หายจากรายการ) | **PASS** | พบ 000003 + 000004 |
| 18 | B6 · ป้ายสถานะตาม requires_signature จริง | **PASS** | 4 ป้ายถูกต้อง |
| 19 | B7 · ไม่ส่ง p_employee จาก browser | **PASS** | p_employee = null |
| 20 | B8 · ไม่มีปุ่มรับทราบ/ลงนามบนหน้า List (ต้องเปิดเอกสารก่อน) | **PASS** | มีแค่ปุ่มเปิดเอกสาร |
| 21 | B9 · ปุ่มเปิดเอกสารมีครบทุกฉบับ | **PASS** | พบ 4 ปุ่ม |
| 22 | B10 · เรียก njhr_doc_my_pending เพื่ออัปเดต Badge | **PASS** | เรียกผ่าน NJHR.layout.refreshDocPending |
| 23 | B11 · ไม่เรียก Legacy RPC ใด ๆ | **PASS** | calls=njhr_doc_center_list |
| 24 | C · ADMIN ได้ศูนย์จัดการเอกสาร HR เดิม | **PASS** | หัวเรื่อง + สร้างเอกสาร + Export + ตาราง ครบ |
| 25 | C · SUPER_ADMIN ได้ศูนย์จัดการเอกสาร HR เดิม | **PASS** | หัวเรื่อง + สร้างเอกสาร + Export + ตาราง ครบ |
| 26 | D1 · โหลดไม่สำเร็จ → แสดง Error ไม่ค้างหน้าเปล่า | **PASS** | แสดงข้อความ |

**PASS 26 · FAIL 0**
