/* attach_preview_test.js — ตรวจปุ่ม 👁 (Preview) และ ⬇ (ดาวน์โหลด) ของไฟล์แนบ
   ใน Timeline / รายละเอียดคำขอลางาน และ OT
     · 👁 ต้องเปิด Preview ทับในหน้าเดิม ไม่เปิดแท็บใหม่ ไม่ reload
     · ปิด Preview แล้ว Timeline Modal เดิมต้องยังเปิดอยู่
     · ⬇ ต้องเริ่มดาวน์โหลดแล้วขึ้น Toast ที่กด × ปิดได้
     · ดาวน์โหลดล้มเหลว ต้องขึ้น Toast ผิดพลาด ไม่ใช่ข้อความสำเร็จ
   ใช้: node harness/attach_preview_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(60) + (d || '')); }
const tick = ms => new Promise(r => setTimeout(r, ms || 40));

const LEAVE_DETAIL = {
  leave_type: 'ลาป่วย', emp_name: 'สมชาย ใจดี', status: 'PENDING', ui_status: 'PENDING',
  reason: 'ไม่สบาย',
  attachments: [
    { name: 'ChatGPT Image 10 ส.ค. 2569 18_20_00.png', url: 'https://x/img.png' },
    { name: 'ใบรับรองแพทย์.pdf', url: 'https://x/doc.pdf' },
    { name: 'photo.JPG', url: 'https://x/p.JPG' },
    { name: 'ข้อมูล.xlsx', url: 'https://x/s.xlsx' }
  ],
  approvals: [{ seq: 1, action: 'SUBMIT', by_name: 'สมชาย', at: '2026-08-12 10:00' }]
};

/* โหลด runtime/core.js จริง เพื่อใช้ toastDismiss / filePreviewOpen / fileDownload ตัวจริง */
function env(opt) {
  opt = opt || {};
  const dom = new JSDOM(
    '<!doctype html><html><body><div id="app"></div><div id="modal-root"></div>' +
    '<div id="toasts"></div></body></html>');
  const win = dom.window;
  const opened = [];
  win.open = (...a) => { opened.push(a); return null; };          // ดักการเปิดแท็บใหม่
  let fetchMode = opt.fetchMode || 'ok';
  const clicks = [];
  win.URL.createObjectURL = () => 'blob:file';
  win.URL.revokeObjectURL = () => {};
  win.fetch = () => {
    if (fetchMode === 'reject') return Promise.reject(new Error('Network error'));
    if (fetchMode === 'http500') return Promise.resolve({ ok: false, status: 500 });
    return Promise.resolve({ ok: true, status: 200, blob: () => Promise.resolve({ size: 10 }) });
  };
  /* ดักการคลิก <a download> เพื่อยืนยันว่าเริ่มดาวน์โหลดจริงและไม่เปิดแท็บใหม่ */
  const origCreate = win.document.createElement.bind(win.document);
  win.document.createElement = function (tag) {
    const el = origCreate(tag);
    if (String(tag).toLowerCase() === 'a') {
      el.click = function () { clicks.push({ href: el.href, download: el.getAttribute('download'), target: el.getAttribute('target') }); };
    }
    return el;
  };
  const ctx = vm.createContext(win);
  return { win, ctx, opened, clicks,
    setFetch: m => { fetchMode = m; },
    run: rel => vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), ctx, { filename: rel }),
    doc: () => win.document,
    S: () => win.NJHR.compat.scope };
}

/* โหลด core.js จริง — ต้องมี NJHR namespace + asset manifest ก่อน
   core บูตเองตอนโหลด จึง stub ส่วนที่มันเรียกออกไปข้างนอกให้เงียบ */
function boot(E) {
  const w = E.win;
  w.NJHR_SUPABASE_URL = '';          // sbReady() = false → core ไม่ยิงเน็ต
  w.NJHR_SUPABASE_ANON_KEY = '';
  w.NJHR_BUILD_VERSION = 'test';
  w.NJHR_ASSETS = { buildId: 'test', runtime: {}, modules: {} };
  w.NJHR = {
    assets: w.NJHR_ASSETS, state: {}, router: { navId: () => 1, bump: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    views: { register: () => {}, has: () => false, render: () => {} },
    features: {}, compat: { scope: {} }, core: {}, auth: {}, ui: {}, layout: {}, notify: {}
  };
  try { E.run('runtime/core.js'); } catch (e) { console.error('boot core:', e.message); }
  return w.NJHR.compat && w.NJHR.compat.scope;
}

async function run() {
  /* ================= 1. ตัวช่วยใน core ================= */
  console.log('\n== core: filePreviewOpen · fileDownload · toastDismiss ==');
  const E = env();
  const S = boot(E);
  chk('core เปิดใช้งาน scope ได้', !!S, '');
  if (!S) return finish();
  chk('มี filePreviewOpen()', typeof S.filePreviewOpen === 'function', '');
  chk('มี fileDownload()', typeof S.fileDownload === 'function', '');
  /* toastDismiss เป็นฟังก์ชันภายใน core (ไม่ export) — ตรวจผ่าน fileDownload แทน */
  chk('core มี toastDismiss ในโค้ด',
    fs.readFileSync(path.join(ROOT, 'runtime/core.js'), 'utf8').indexOf('toastDismiss') >= 0, '');
  chk('toast() เดิมยังอยู่ ไม่ถูกแทนที่', typeof S.toast === 'function', '');

  /* ---- toast() เดิมต้องไม่เปลี่ยนพฤติกรรม (ไม่มีปุ่ม ×) ---- */
  S.toast('ข้อความเดิม');
  await tick(20);
  const old = E.doc().querySelectorAll('#toasts .toast');
  chk('toast() เดิมไม่มีปุ่ม × (หน้าอื่นไม่เปลี่ยนพฤติกรรม)',
    old.length === 1 && old[0].querySelector('.toast-x') === null, '');
  chk('toast() เดิมไม่มี class toast-dis', !old[0].classList.contains('toast-dis'), '');
  E.doc().getElementById('toasts').innerHTML = '';

  /* ================= 2. Preview แต่ละชนิดไฟล์ ================= */
  console.log('\n== Preview: ชนิดไฟล์ ==');
  const cases = [
    ['PNG', 'a.png', 'https://x/a.png', 'img'],
    ['JPG', 'b.JPG', 'https://x/b.JPG', 'img'],
    ['JPEG', 'c.jpeg', 'https://x/c.jpeg', 'img'],
    ['WEBP', 'd.webp', 'https://x/d.webp', 'img'],
    ['PDF', 'e.pdf', 'https://x/e.pdf', 'frame'],
    ['XLSX (ไม่รองรับ)', 'f.xlsx', 'https://x/f.xlsx', 'none'],
    ['ไม่มีนามสกุล', 'g', 'https://x/g', 'none']
  ];
  for (const [label, name, url, want] of cases) {
    S.filePreviewOpen(url, name);
    await tick(20);
    const doc = E.doc();
    const box = doc.querySelector('#file-preview-root .fp-box');
    chk('👁 ' + label + ' · เปิด Preview ในหน้าเดิม', !!box, '');
    if (box) {
      const kind = box.querySelector('.fp-img') ? 'img'
        : box.querySelector('.fp-frame') ? 'frame'
          : box.querySelector('.fp-none') ? 'none' : '?';
      chk('👁 ' + label + ' · แสดงแบบ ' + want, kind === want, kind);
      if (want === 'none') {
        chk('👁 ' + label + ' · ข้อความแจ้งให้ดาวน์โหลด',
          box.textContent.indexOf('ไม่รองรับการดูตัวอย่างไฟล์นี้ กรุณาดาวน์โหลดไฟล์') >= 0, '');
      }
      chk('👁 ' + label + ' · มีชื่อไฟล์ด้านบน',
        (box.querySelector('.fp-head h3') || {}).textContent === name, '');
      chk('👁 ' + label + ' · มีปุ่ม × และปุ่มปิด',
        !!doc.getElementById('fp-x') && !!doc.getElementById('fp-close'), '');
    }
    const cb = E.doc().getElementById('fp-close');
    if (cb) cb.click();
  }
  chk('👁 ทุกกรณี · ไม่เปิดแท็บใหม่เลย', E.opened.length === 0, E.opened.length + ' ครั้ง');
  chk('👁 ทุกกรณี · ไม่มี <a download> ถูกคลิก (ไม่ดาวน์โหลดอัตโนมัติ)',
    E.clicks.length === 0, E.clicks.length + ' ครั้ง');

  /* ================= 3. ปิด Preview แล้ว Timeline ยังอยู่ ================= */
  console.log('\n== Preview: ไม่ทำให้ Timeline ปิด ==');
  S.openModal('Timeline · ทดสอบ', '<div id="tl-marker">เนื้อหา Timeline</div>', '<button>ปิด</button>');
  await tick(20);
  chk('เปิด Timeline Modal ได้', !!E.doc().querySelector('#modal-root .modal-body'), '');
  S.filePreviewOpen('https://x/a.png', 'a.png');
  await tick(20);
  chk('เปิด Preview ทับได้ · Timeline ยังอยู่พร้อมกัน',
    !!E.doc().getElementById('file-preview-root') && !!E.doc().getElementById('tl-marker'), '');
  chk('Preview ใช้ container แยกจาก #modal-root',
    E.doc().querySelector('#modal-root #file-preview-root') === null, '');
  E.doc().getElementById('fp-close').click();
  await tick(20);
  chk('ปิด Preview · Preview หายไป', E.doc().getElementById('file-preview-root') === null, '');
  chk('ปิด Preview · Timeline Modal เดิมยังเปิดอยู่ตำแหน่งเดิม',
    !!E.doc().getElementById('tl-marker'), '');
  /* ปุ่ม × ของ Preview ก็ต้องไม่ปิด Timeline */
  S.filePreviewOpen('https://x/a.png', 'a.png');
  await tick(20);
  E.doc().getElementById('fp-x').click();
  await tick(20);
  chk('ปิดด้วยปุ่ม × · Timeline ยังเปิดอยู่',
    E.doc().getElementById('file-preview-root') === null && !!E.doc().getElementById('tl-marker'), '');
  S.closeModal();

  /* ================= 4. ดาวน์โหลดสำเร็จ ================= */
  console.log('\n== ดาวน์โหลด: สำเร็จ ==');
  E.doc().getElementById('toasts').innerHTML = '';
  E.clicks.length = 0;
  const FN = 'ChatGPT Image 10 ส.ค. 2569 18_20_00.png';
  S.fileDownload('https://x/img.png', FN);
  await tick(60);
  chk('⬇ เริ่มดาวน์โหลดจริง (คลิก <a download>)', E.clicks.length === 1, E.clicks.length + ' ครั้ง');
  if (E.clicks.length) {
    chk('⬇ ตั้งชื่อไฟล์ถูกต้อง', E.clicks[0].download === FN, E.clicks[0].download);
    chk('⬇ ไม่ตั้ง target=_blank', !E.clicks[0].target, String(E.clicks[0].target));
  }
  chk('⬇ ไม่เปิดแท็บใหม่', E.opened.length === 0, E.opened.length + ' ครั้ง');
  const t1 = E.doc().querySelector('#toasts .toast-dis');
  chk('⬇ ขึ้น Toast', !!t1, '');
  if (t1) {
    chk('⬇ Toast หัวข้อ "เริ่มดาวน์โหลดแล้ว"',
      (t1.querySelector('b') || {}).textContent === 'เริ่มดาวน์โหลดแล้ว',
      (t1.querySelector('b') || {}).textContent);
    chk('⬇ Toast แสดงชื่อไฟล์',
      (t1.querySelector('small') || {}).textContent === FN, (t1.querySelector('small') || {}).textContent);
    chk('⬇ Toast เป็นแบบสำเร็จ', t1.classList.contains('toast-success'), t1.className);
    chk('⬇ Toast มีปุ่ม ×', !!t1.querySelector('.toast-x'), '');
    /* กด × แล้วต้องปิดเฉพาะ Toast */
    S.openModal('Timeline · ทดสอบ', '<div id="tl2">x</div>', '');
    await tick(20);
    t1.querySelector('.toast-x').click();
    await tick(400);
    chk('⬇ กด × · Toast ปิด', E.doc().querySelector('#toasts .toast-dis') === null, '');
    chk('⬇ กด × · Timeline ยังเปิดอยู่ (ไม่ reload ไม่ปิดตาม)', !!E.doc().getElementById('tl2'), '');
    S.closeModal();
  }

  /* ================= 5. ดาวน์โหลดล้มเหลว ================= */
  console.log('\n== ดาวน์โหลด: ล้มเหลว ==');
  for (const [label, mode] of [['Network Error', 'reject'], ['HTTP 500 / Permission', 'http500']]) {
    E.doc().getElementById('toasts').innerHTML = '';
    E.clicks.length = 0;
    E.setFetch(mode);
    S.fileDownload('https://x/img.png', 'a.png');
    await tick(60);
    const te = E.doc().querySelector('#toasts .toast-dis');
    chk(label + ' · ขึ้น Toast ผิดพลาด',
      !!te && te.classList.contains('toast-error'), te ? te.className : 'ไม่มี toast');
    if (te) {
      chk(label + ' · หัวข้อ "ดาวน์โหลดไม่สำเร็จ"',
        (te.querySelector('b') || {}).textContent === 'ดาวน์โหลดไม่สำเร็จ',
        (te.querySelector('b') || {}).textContent);
      chk(label + ' · ข้อความ "กรุณาลองใหม่อีกครั้ง"',
        (te.querySelector('small') || {}).textContent === 'กรุณาลองใหม่อีกครั้ง', '');
      chk(label + ' · ไม่แสดงข้อความสำเร็จ',
        te.textContent.indexOf('เริ่มดาวน์โหลดแล้ว') < 0, '');
      chk(label + ' · มีปุ่ม × ปิดได้', !!te.querySelector('.toast-x'), '');
    }
  }
  E.setFetch('ok');
  E.doc().getElementById('toasts').innerHTML = '';
  S.fileDownload('', 'a.png');
  await tick(40);
  const t0 = E.doc().querySelector('#toasts .toast-dis');
  chk('ไม่มี URL · ขึ้น Toast ผิดพลาด ไม่ใช่สำเร็จ',
    !!t0 && t0.classList.contains('toast-error'), t0 ? t0.className : 'ไม่มี');

  /* ================= 6. ตรวจ Source ทุกจุดที่แสดงไฟล์แนบ ================= */
  console.log('\n== Source: ไม่มี target=_blank สำหรับไฟล์แนบแล้ว ==');
  [['runtime/shared/requests.js', 'Timeline ลางาน'],
   ['views/leave/detail.js', 'รายละเอียดคำขอ (ลางาน + OT)']].forEach(function (x) {
    const src = fs.readFileSync(path.join(ROOT, x[0]), 'utf8');
    chk(x[1] + ' · ไม่มี target="_blank"', src.indexOf('_blank') < 0, '');
    chk(x[1] + ' · ใช้ปุ่ม data-fp / data-fd', src.indexOf('data-fp') >= 0 && src.indexOf('data-fd') >= 0, '');
    chk(x[1] + ' · ผูก Event ด้วย bindFileButtons()', src.indexOf('bindFileButtons') >= 0, '');
  });
  const core = fs.readFileSync(path.join(ROOT, 'runtime/core.js'), 'utf8');
  chk('core · fileDownload ไม่เปิดแท็บใหม่ (ไม่มี window.open)',
    !/window\.open|target="_blank"/.test(core), '');
  const css = fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8').replace(/\s/g, '');
  chk('CSS · Preview z-index สูงกว่า Modal', css.indexOf('.fp-overlay{position:fixed;inset:0;z-index:1200') >= 0, '');
  chk('CSS · รูปใหญ่ใช้ object-fit:contain', css.indexOf('object-fit:contain') >= 0, '');
  chk('CSS · มีสไตล์ Toast ปิดได้', css.indexOf('.toast-dis') >= 0, '');

  finish();
}

function finish() {
  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
}

run().catch(e => { console.error(e); process.exit(1); });
