#!/usr/bin/env node
/* ui_shot.js — ถ่ายภาพ UI จริงพร้อมตรวจฟอนต์และเทียบ Pixel Diff
   ใช้: NJHR_CHROME=<path> node harness/ui_shot.js

   ตัวแปรสภาพแวดล้อม
     NJHR_CHROME     พาธ Chromium (บังคับ)
     NJHR_APP_ROOT   รากของแอปที่จะเสิร์ฟ (ค่าเริ่มต้น = โปรเจกต์นี้)
     NJHR_LABEL      ป้ายกำกับชุดภาพ เช่น c0742d77 / f5b5aa0e
     NJHR_PHOTO_MODE none | url | path  (ส่งต่อให้ mh_fixtures.js)
     NJHR_OUT        โฟลเดอร์ผลลัพธ์

   ฟอนต์: ใช้ไฟล์ .woff2 ใน harness/fonts เท่านั้น (@fontsource/prompt)
          ฉีดผ่าน @font-face ตอน runtime — ไม่แก้ index.html และไม่แก้ CSS ของแอป
          ไม่มี request ออกอินเทอร์เน็ตแม้แต่รายการเดียว

   เวลา: ตรึงไว้ที่ค่าคงที่ + ปิด animation/transition ทั้งหมด
         เพื่อให้ Pixel Diff เทียบได้จริง */
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const MF = require('./mh_fixtures.js');

const HARNESS = __dirname;
const PROJ = path.join(HARNESS, '..');
const APP_ROOT = process.env.NJHR_APP_ROOT || PROJ;
const LABEL = process.env.NJHR_LABEL || 'build';
const OUT = process.env.NJHR_OUT || path.join(HARNESS, 'shots');
const CHROME = process.env.NJHR_CHROME || require(require('path').join(__dirname, 'browser.js')).findBrowser() || '/tmp/chromium';
const FONT_DIR = path.join(HARNESS, 'fonts');
const PORT = Number(process.env.NJHR_PORT || 8930);
const ROUTE = process.env.NJHR_ROUTE || '#/dashboard';

/* เวลาที่ตรึง: 10 ส.ค. 2569 เวลา 09:41 น. (Asia/Bangkok) */
const FIXED_MS = Date.UTC(2026, 7, 10, 2, 41, 0);

const VIEWPORTS = {
  mobile360: { width: 360, height: 800, deviceScaleFactor: 2, isMobile: true, hasTouch: true },
  mobile430: { width: 430, height: 932, deviceScaleFactor: 2, isMobile: true, hasTouch: true },
  mobile: { width: 390, height: 844, deviceScaleFactor: 2, isMobile: true, hasTouch: true },
  desk1024: { width: 1024, height: 800, deviceScaleFactor: 1, isMobile: false, hasTouch: false },
  desk1366: { width: 1366, height: 850, deviceScaleFactor: 1, isMobile: false, hasTouch: false },
  desk2048: { width: 2048, height: 1100, deviceScaleFactor: 1, isMobile: false, hasTouch: false },
  desk1280: { width: 1280, height: 820, deviceScaleFactor: 1, isMobile: false, hasTouch: false },
  desk1920: { width: 1920, height: 1000, deviceScaleFactor: 1, isMobile: false, hasTouch: false },
  desktop: { width: 1440, height: 900, deviceScaleFactor: 1, isMobile: false, hasTouch: false }
};
const ROLES = (process.env.NJHR_ROLES || 'USER,SUPER_ADMIN').split(',').filter(Boolean);
const DENY_GEO = process.env.NJHR_GEO === 'deny';
const WEIGHTS = [400, 500, 600, 700];

const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.json': 'application/json',
  '.woff2': 'font/woff2' };

/* เสิร์ฟ 2 ราก: / = แอปที่จะทดสอบ · /__fonts/ = ไฟล์ฟอนต์ของ Harness */
function serve(port) {
  return new Promise((res, rej) => {
    const s = http.createServer((rq, rs) => {
      let p = decodeURIComponent(rq.url.split('?')[0]);
      let base = APP_ROOT;
      if (p.indexOf('/__fonts/') === 0) { base = FONT_DIR; p = p.slice('/__fonts'.length); }
      else if (p === '/__jszip.js') {
        base = path.join(PROJ, 'node_modules', 'jszip', 'dist'); p = '/jszip.min.js';
      }
      else if (p === '/') p = '/index.html';
      const f = path.join(base, p);
      if (!f.startsWith(base) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) {
        rs.writeHead(404); return rs.end();
      }
      rs.writeHead(200, { 'Content-Type': TYPES[path.extname(f)] || 'application/octet-stream',
                          'Cache-Control': 'no-store' });
      rs.end(fs.readFileSync(f));
    });
    s.on('error', rej);
    s.listen(port, () => res(s));
  });
}

/* @font-face ชี้ไฟล์ในเครื่องเท่านั้น — ชื่อ family ต้องเป็น "Prompt" ให้ตรงกับ CSS ของแอป */
function fontFaceCSS() {
  let css = '';
  ['latin', 'thai'].forEach(sub => WEIGHTS.forEach(w => {
    const file = 'prompt-' + sub + '-' + w + '-normal.woff2';
    if (!fs.existsSync(path.join(FONT_DIR, file))) {
      throw new Error('ไม่พบไฟล์ฟอนต์ harness/fonts/' + file + ' — หยุดตามข้อกำหนด ห้ามใช้ฟอนต์ทดแทน');
    }
    css += "@font-face{font-family:'Prompt';font-style:normal;font-weight:" + w +
           ";font-display:block;src:url('/__fonts/" + file + "') format('woff2');}\n";
  }));
  return css;
}

const FREEZE_CSS =
  '*,*::before,*::after{animation:none!important;transition:none!important;' +
  'animation-duration:0s!important;transition-duration:0s!important;' +
  'caret-color:transparent!important;scroll-behavior:auto!important}';

(async () => {
  if (!fs.existsSync(CHROME)) { console.error('ไม่พบ Chromium ที่ ' + CHROME); process.exit(1); }
  const FONTS = fontFaceCSS();               // ไม่มีไฟล์ = โยน error หยุดทันที
  const puppeteer = require('puppeteer-core');
  fs.mkdirSync(OUT, { recursive: true });
  const srv = await serve(PORT);
  const report = { label: LABEL, appRoot: APP_ROOT, photoMode: MF.PHOTO_MODE, runs: {} };

  const ONLY = (process.env.NJHR_MODES || '').split(',').filter(Boolean);
  for (const mode of Object.keys(VIEWPORTS)) {
    if (ONLY.length && ONLY.indexOf(mode) < 0) continue;
    for (const role of ROLES) {
      const acc = MF.ACCOUNTS[role];
      const browser = await puppeteer.launch({
        executablePath: CHROME, headless: true,
        env: Object.assign({}, process.env, { TZ: 'Asia/Bangkok' }),
        args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-gpu',
               '--font-render-hinting=none', '--hide-scrollbars',
               '--force-color-profile=srgb', '--disable-lcd-text']
      });
      const ORIGIN = 'http://127.0.0.1:' + PORT;
      if (!DENY_GEO) {
        try {
          await browser.defaultBrowserContext().overridePermissions(ORIGIN, ['geolocation']);
        } catch (e) { }
      }
      const page = await browser.newPage();
      /* พิกัดจำลองคงที่สำหรับการทดสอบ — ไม่ใช่พิกัดพนักงานจริง และไม่ถูกบันทึกลงรายงาน */
      if (!DENY_GEO) {
        try { await page.setGeolocation({ latitude: 13.7563, longitude: 100.5018, accuracy: 12 }); }
        catch (e) { }
      }
      const errors = [], netFail = [], rpcCount = {};
      page.on('pageerror', e => errors.push(String(e.message)));
      page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
      page.on('requestfailed', r => {
        const u = r.url();
        const safe = /^data:/.test(u) ? '(data URI ของรูปพนักงาน — ปกปิด)'
          : (u.indexOf('/storage/v1/object/sign') >= 0 || u.indexOf('/functions/v1/njhr-emp-file') >= 0)
            ? '(URL ของรูปพนักงาน — ปกปิด)' : u;
        netFail.push({ url: safe, reason: (r.failure() || {}).errorText || 'unknown', type: r.resourceType() });
      });

      await page.setViewport(VIEWPORTS[mode]);
      await page.emulateTimezone('Asia/Bangkok');

      /* ก่อนสคริปต์ของหน้าใด ๆ: session · ตรึงเวลา · ฉีดฟอนต์ · ปิด animation */
      await page.evaluateOnNewDocument((a, fixed, fonts, freeze, dash) => {
        try {
          localStorage.setItem('njhr_token', a.session_token);
          localStorage.setItem('njhr_sb_user', JSON.stringify(a));
          /* ป้อนข้อมูลผ่าน store เดิม (njhr_db_v3) ไม่ hardcode ใน UI */
          if (dash) localStorage.setItem('njhr_db_v3', dash);
        } catch (e) { }
        if (window.__denyGeo && navigator.geolocation) {
          navigator.geolocation.getCurrentPosition = function (ok, err) {
            if (err) err({ code: 1, message: 'User denied Geolocation' });
          };
        }
        const OrigDate = Date;
        function D() {
          if (arguments.length === 0) return new OrigDate(fixed);
          return new (Function.prototype.bind.apply(OrigDate,
            [null].concat(Array.prototype.slice.call(arguments))))();
        }
        D.prototype = OrigDate.prototype;
        D.now = function () { return fixed; };
        D.parse = OrigDate.parse; D.UTC = OrigDate.UTC;
        window.Date = D;
        const inject = () => {
          const s = document.createElement('style');
          s.id = '__harness_style';
          s.textContent = fonts + freeze;
          (document.head || document.documentElement).appendChild(s);
        };
        if (document.head) inject();
        else document.addEventListener('readystatechange', function once() {
          if (document.head) { document.removeEventListener('readystatechange', once); inject(); }
        });
      }, acc, FIXED_MS, FONTS, FREEZE_CSS, process.env.NJHR_DASH_DATA || null);
      if (DENY_GEO) await page.evaluateOnNewDocument(() => { window.__denyGeo = true; });

      await page.setRequestInterception(true);
      const rpcCalls = {};
      page.on('request', req => {
        const url = req.url();
        const CORS = { 'access-control-allow-origin': '*',
          'access-control-allow-methods': 'POST, GET, OPTIONS',
          'access-control-allow-headers': 'authorization, apikey, content-type, x-client-info, prefer',
          'access-control-max-age': '600' };
        if (url.indexOf('/rest/v1/rpc/') >= 0 || url.indexOf('/functions/v1/') >= 0) {
          if (req.method() === 'OPTIONS') return req.respond({ status: 204, headers: CORS, body: '' });
          const fn = url.indexOf('/rpc/') >= 0
            ? url.split('/rpc/')[1].split('?')[0] : url.split('/functions/v1/')[1].split('?')[0];
          rpcCount[fn] = (rpcCount[fn] || 0) + 1;
          if (fn === 'njhr_leave_submit') {
            try { page.evaluate(p2 => { window.__lastLeavePayload = p2; },
                  JSON.parse(req.postData() || '{}')); } catch (e) {}
          }
          let body = {};
          try { body = JSON.parse(req.postData() || '{}'); } catch (e) { }
          if (req.method() !== 'OPTIONS') rpcCalls[fn] = (rpcCalls[fn] || 0) + 1;
          let payload, code = 200;
          try { payload = MF.respond(fn, body, acc); }
          catch (e) {
            /* จำลอง RPC ล้มเหลวด้วยรูปแบบเดียวกับที่ PostgREST ตอบจริง (มี message) */
            code = 400;
            payload = { code: 'P0001', message: 'จำลอง RPC ล้มเหลว (Harness เท่านั้น)',
                        details: null, hint: null };
          }
          return req.respond({ status: code, contentType: 'application/json',
            headers: CORS, body: JSON.stringify(payload) });
        }
        if (url.indexOf('cdnjs.cloudflare.com') >= 0 && url.indexOf('jszip') >= 0) {
          /* JSZip เวอร์ชันเดียวกับ package.json (3.10.1) เสิร์ฟจาก node_modules ไม่ใช้ CDN */
          return req.respond({ status: 302,
            headers: { location: 'http://127.0.0.1:' + PORT + '/__jszip.js' }, body: '' });
        }
        if (url.indexOf('127.0.0.1') < 0 && url.indexOf('localhost') < 0) return req.abort();
        return req.continue();
      });

      await page.goto('http://127.0.0.1:' + PORT + '/index.html' + ROUTE, { waitUntil: 'load' });
      await page.evaluate(() => document.fonts.ready);
      await new Promise(r => setTimeout(r, 3000));
      await page.evaluate(() => document.fonts.ready);

      /* ทดสอบกดซ้ำ + Cleanup เมื่อเปลี่ยน Route (เฉพาะเมื่อสั่ง NJHR_ATT_CLICK=1) */
      let clickTest = null;
      if (process.env.NJHR_ATT_CLICK === '1' && mode === 'mobile') {
        const before = Object.assign({}, rpcCalls);
        await page.evaluate(() => {
          const b = document.getElementById('attmb-in');
          if (b) { b.click(); b.click(); b.click(); }
        });
        await new Promise(r => setTimeout(r, 1500));
        const after = Object.assign({}, rpcCalls);
        const busy = await page.evaluate(() => {
          const b = document.getElementById('attmb-in');
          return b ? { busy: b.getAttribute('data-busy') === '1', cls: b.className } : null;
        });
        await page.evaluate(() => { location.hash = '#/dashboard'; });
        await new Promise(r => setTimeout(r, 1500));
        const cleanup = await page.evaluate(() => ({
          attBlockGone: !document.getElementById('att-mb'),
          clockGone: !document.getElementById('attmb-time'),
          faceCardGone: !document.getElementById('attmb-face'),
          camGone: document.querySelectorAll('video').length === 0,
          route: location.hash
        }));
        clickTest = { rpcBefore: before, rpcAfter: after, buttonAfterClicks: busy, cleanup: cleanup };
      }

      /* ---- ทดสอบแท็บหน้าคำขอ: คลิกจริง ถ่ายจริง และนับ RPC ก่อน-หลัง ---- */
      let tabTest = null;
      if (process.env.NJHR_REQ_TABS === '1' && mode === 'mobile') {
        tabTest = [];
        const rpcBefore = JSON.stringify(rpcCalls);
        const TABS = ['all', 'pending', 'done'];
        for (const tb of TABS) {
          await page.evaluate(t => {
            const b = document.querySelector('.req-tab[data-tab="' + t + '"]');
            if (b) b.click();
          }, tb);
          await new Promise(r => setTimeout(r, 500));
          await page.screenshot({ path: path.join(OUT, LABEL + '_' + mode + '_' + role + '_tab-' + tb + '.png') });
          const info2 = await page.evaluate(() => {
            const on = document.querySelector('.req-tab.on');
            const rows = Array.prototype.map.call(document.querySelectorAll('.req-row'),
              n => (n.querySelector('.req-bd') || {}).textContent.trim());
            const root = document.getElementById('req-mb');
            return {
              active: on ? on.textContent.trim() : null,
              underline: on ? getComputedStyle(on, '::after').backgroundColor : null,
              count: rows.length, badges: rows,
              empty: !!document.querySelector('.req-empty'),
              overflow: root ? Array.prototype.some.call(root.querySelectorAll('b,small,.req-tab,.req-bd'),
                n => n.scrollWidth > n.clientWidth + 1) : null
            };
          });
          info2.tab = tb;
          tabTest.push(info2);
        }
        tabTest.rpcUnchanged = (JSON.stringify(rpcCalls) === rpcBefore);
        await page.evaluate(() => {
          const b = document.querySelector('.req-tab[data-tab="all"]');
          if (b) b.click();
        });
        await new Promise(r => setTimeout(r, 300));
      }

      /* เปิด Modal จัดการวันหยุดบริษัท แล้ววัดแถบเครื่องมือ/คอลัมน์จัดการ */
      let chTest = null;
      if (process.env.NJHR_OPEN_HOLIDAY === '1') {
        await page.evaluate(() => { const b = document.getElementById('cal-hol'); if (b) b.click(); });
        await new Promise(r => setTimeout(r, 1500));
        await page.screenshot({ path: path.join(OUT, LABEL + '_' + mode + '_' + role + '_holiday.png') });
        chTest = await page.evaluate(() => {
          const bar = document.querySelector('.ch-tools');
          if (!bar) return { opened: false };
          const kids = Array.prototype.filter.call(bar.children,
            n => n.offsetWidth > 0).map(n => ({
              tag: n.tagName.toLowerCase(), id: n.id || null,
              txt: (n.textContent || '').trim().slice(0, 22),
              top: Math.round(n.getBoundingClientRect().top),
              left: Math.round(n.getBoundingClientRect().left),
              w: Math.round(n.getBoundingClientRect().width),
              h: Math.round(n.getBoundingClientRect().height) }));
          const tops = kids.map(k => k.top + k.h);   /* เทียบขอบล่าง เพราะ align-items: flex-end */
          const acts = Array.prototype.map.call(document.querySelectorAll('.ch-act'), n => {
            const bs = Array.prototype.map.call(n.querySelectorAll('.btn-icon'), b2 => {
              const r = b2.getBoundingClientRect();
              return { label: b2.getAttribute('aria-label'), x: Math.round(r.left),
                       y: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height) };
            });
            return { sameRow: bs.length === 2 ? Math.abs(bs[0].y - bs[1].y) < 2 : null,
                     gap: bs.length === 2 ? Math.round(bs[1].x - (bs[0].x + bs[0].w)) : null,
                     buttons: bs };
          });
          const mw = document.querySelector('.modal, .modal-box, [class*=modal]');
          return { opened: true,
            barChildren: kids,
            allSameRow: tops.length ? (Math.max.apply(null, tops) - Math.min.apply(null, tops) < 2) : null,
            sameHeight: kids.filter(k => k.tag === 'button').every((k, i, a) => Math.abs(k.h - a[0].h) < 2),
            barScrollW: bar.scrollWidth, barClientW: bar.clientWidth,
            barScrolls: bar.scrollWidth > bar.clientWidth + 1,
            actionCells: acts.slice(0, 3),
            docOverflowX: document.documentElement.scrollWidth > document.documentElement.clientWidth };
        });
      }

      /* หน้าตั้งค่าการอนุมัติ: วัดความสูงการ์ด แล้วเปิด Modal ด้วยปุ่มรูปตา + ทดสอบการปิด 4 ทาง */
      let wfTest = null;
      if (process.env.NJHR_OPEN_WFVIEW === '1') {
        wfTest = await page.evaluate(() => {
          const cards = Array.prototype.map.call(document.querySelectorAll('.wf-set'), n => {
            const r = n.getBoundingClientRect();
            const b = n.querySelector('.wf-set-head > b');
            return { name: (b ? b.textContent : '').trim().slice(0, 40),
                     w: Math.round(r.width), h: Math.round(r.height), top: Math.round(r.top),
                     eye: !!n.querySelector('[data-as-wfview]'),
                     edit: !!n.querySelector('[data-as-wfedit]'),
                     del: !!n.querySelector('[data-as-wfdel]'),
                     details: !!(n.querySelector('.wf-set-depts') || n.querySelector('.wf-set-tl')) };
          });
          const rows = {};
          cards.forEach(c => { (rows[c.top] = rows[c.top] || []).push(c.h); });
          const rowEqual = Object.keys(rows).map(t => {
            const hs = rows[t]; return { top: +t, heights: hs,
              equal: Math.max.apply(null, hs) - Math.min.apply(null, hs) < 2 };
          });
          const btns = Array.prototype.map.call(
            document.querySelectorAll('.wf-set-acts .btn-icon'), n => {
              const r = n.getBoundingClientRect();
              return { label: n.getAttribute('aria-label'), w: Math.round(r.width), h: Math.round(r.height) };
            });
          return { cards, rowEqual, buttons: btns,
                   anyDetailsInCard: cards.some(c => c.details),
                   scrollY: Math.round(window.pageYOffset) };
        });
        /* กดพื้นที่ว่างของการ์ด — ต้องไม่เปิด Modal */
        await page.evaluate(() => {
          const c = document.querySelector('.wf-set');
          if (c) c.click();
        });
        await new Promise(r => setTimeout(r, 400));
        wfTest.modalOnCardClick = await page.evaluate(() => !!document.getElementById('wfd-flow'));
        /* เลื่อนหน้าลงก่อน แล้วกดรูปตา เพื่อทดสอบการคืนตำแหน่ง scroll */
        await page.evaluate(() => window.scrollTo(0, 240));
        await new Promise(r => setTimeout(r, 200));
        wfTest.scrollBefore = await page.evaluate(() => Math.round(window.pageYOffset));
        await page.evaluate(() => {
          const b = document.querySelector('[data-as-wfview]');
          if (b) b.click();
        });
        await new Promise(r => setTimeout(r, 1200));
        await page.screenshot({ path: path.join(OUT, LABEL + '_' + mode + '_' + role + '_wfmodal.png') });
        wfTest.modal = await page.evaluate(() => {
          const m = document.querySelector('.modal');
          if (!m) return { opened: false };
          const body = m.querySelector('.modal-body');
          const r = m.getBoundingClientRect();
          return { opened: true,
            title: (m.querySelector('.modal-head h3') || {}).textContent,
            hasX: !!document.getElementById('modal-x'),
            hasClose: !!document.getElementById('wfd-close'),
            steps: document.querySelectorAll('.wfd-step').length,
            modes: Array.prototype.map.call(document.querySelectorAll('.wfd-mode'), n => n.textContent.trim()),
            approvers: document.querySelectorAll('.wfd-appr .as-wchip').length,
            metaRows: document.querySelectorAll('.wfd-row').length,
            deptChips: document.querySelectorAll('.wfd-sec .as-wchip').length,
            w: Math.round(r.width), h: Math.round(r.height),
            fitsViewport: r.height <= window.innerHeight + 1,
            bodyScrolls: body ? body.scrollHeight > body.clientHeight : null };
        });
        /* ปิด 4 ทาง แล้วเช็คตำแหน่ง scroll ทุกครั้ง */
        const closeWays = [];
        const reopen = async () => {
          await page.evaluate(() => { const b = document.querySelector('[data-as-wfview]'); if (b) b.click(); });
          await new Promise(r => setTimeout(r, 800));
        };
        for (const way of ['x', 'closeBtn', 'backdrop', 'escape']) {
          if (!(await page.evaluate(() => !!document.getElementById('wfd-flow')))) await reopen();
          await page.evaluate(() => window.scrollTo(0, 240));
          if (way === 'x') await page.evaluate(() => {
            const n = document.getElementById('modal-x'); if (n) n.click();
          });
          else if (way === 'closeBtn') await page.evaluate(() => {
            const n = document.getElementById('wfd-close'); if (n) n.click();
          });
          else if (way === 'backdrop') await page.evaluate(() => {
            const o = document.getElementById('modal-overlay');
            if (o) o.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
          });
          else await page.keyboard.press('Escape');
          await new Promise(r => setTimeout(r, 500));
          closeWays.push({ way,
            closed: !(await page.evaluate(() => !!document.getElementById('wfd-flow'))),
            scrollY: await page.evaluate(() => Math.round(window.pageYOffset)) });
        }
        wfTest.closeWays = closeWays;
      }

      /* REPORT ALL: กด EXPORT จริง แล้วดักไฟล์ที่ระบบสร้างออกมาเป็น base64 */
      let raB64 = null;
      if (process.env.NJHR_REPORT_ALL === '1') {
        await page.evaluate(() => {
          window.__raBlob = null;
          const orig = URL.createObjectURL;
          URL.createObjectURL = function (b) { window.__raBlob = b; return orig.call(URL, b); };
          const a = HTMLAnchorElement.prototype.click;
          HTMLAnchorElement.prototype.click = function () { /* กันดาวน์โหลดจริง */ };
        });
        /* ต้องเลือกช่วงวันที่ก่อน ระบบจึงจะดึงข้อมูลและเปิดปุ่ม EXPORT */
        await page.evaluate(() => {
          const f = document.getElementById('rp-from'), t = document.getElementById('rp-to');
          if (f) { f.value = '2026-08-01'; f.onchange && f.onchange.call(f); }
        });
        await new Promise(r => setTimeout(r, 800));
        await page.evaluate(() => {
          const t = document.getElementById('rp-to');
          if (t) { t.value = '2026-08-31'; t.onchange && t.onchange.call(t); }
        });
        await new Promise(r => setTimeout(r, 4000));
        await page.evaluate(() => {
          const b = document.getElementById('rp-export');
          if (b) { b.disabled = false; b.click(); }
        });
        await new Promise(r => setTimeout(r, 8000));
        raB64 = await page.evaluate(() => new Promise(res => {
          if (!window.__raBlob) return res(null);
          const fr = new FileReader();
          fr.onload = () => res(String(fr.result).split(',')[1]);
          fr.onerror = () => res(null);
          fr.readAsDataURL(window.__raBlob);
        }));
        if (raB64) {
          fs.writeFileSync(path.join(OUT, LABEL + '_reportall.xlsx'), Buffer.from(raB64, 'base64'));
        }
        await page.screenshot({ path: path.join(OUT, LABEL + '_' + mode + '_' + role + '_reportall.png') });
      }

      /* ทดสอบยื่นลางาน: เลือกประเภท กรอกเหตุผล แล้วกดส่ง โดยไม่แนบไฟล์ */
      let lvTest = null;
      if (process.env.NJHR_LEAVE_SUBMIT) {
        const want = process.env.NJHR_LEAVE_SUBMIT;   // SICK | PERSONAL
        await page.evaluate(() => {
          const b = document.getElementById('lv-new') ||
                    document.querySelector('[id$="-new"], .btn-primary');
          if (b) b.click();
        });
        await new Promise(r => setTimeout(r, 2500));
        lvTest = await page.evaluate(t => {
          const f = document.getElementById('lv-f');
          if (!f) return { formOpen: false };
          const sel = f.querySelector('[name=typeId]');
          if (sel) {
            for (const o of sel.options) {
              if ((o.value || '').toUpperCase().indexOf(t) >= 0 ||
                  (o.textContent || '').indexOf(t === 'SICK' ? 'ป่วย' : 'กิจ') >= 0) {
                sel.value = o.value; break;
              }
            }
            if (sel.onchange) sel.onchange.call(sel);
          }
          const ta = f.querySelector('[name=reason]');
          if (ta) ta.value = 'ทดสอบยื่นคำขอโดยไม่แนบไฟล์';
          const hint = document.getElementById('lvf-doc-hint');
          return { formOpen: true, type: sel ? sel.value : null,
                   hintText: hint ? hint.textContent.trim() : null,
                   fileCount: document.querySelectorAll('#lvf-files .lvf-file').length };
        }, want);
        await new Promise(r => setTimeout(r, 400));
        await page.evaluate(() => {
          const b = document.getElementById('lvf-send') ||
                    document.querySelector('#lv-f ~ * .btn-primary, .modal-foot .btn-primary');
          if (b) b.click();
        });
        await new Promise(r => setTimeout(r, 2500));
        lvTest.err = await page.evaluate(() => {
          const e = document.getElementById('lvf-err');
          return e ? e.textContent.trim() : null;
        });
        lvTest.calls = rpcCalls['njhr_leave_submit'] || 0;
        lvTest.payload = await page.evaluate(() => window.__lastLeavePayload || null);
      }

      /* คลิก selector ใด ๆ แล้วถ่ายภาพ (ใช้เปิดหน้ารายละเอียด/อนุมัติ) */
      if (process.env.NJHR_CLICK_SEL) {
        await page.evaluate(sel => { const b = document.querySelector(sel); if (b) b.click(); },
          process.env.NJHR_CLICK_SEL);
        await new Promise(r => setTimeout(r, 2500));
        if (process.env.NJHR_CLICK_SEL2) {
          await page.evaluate(sel => { const b = document.querySelector(sel); if (b) b.click(); },
            process.env.NJHR_CLICK_SEL2);
          await new Promise(r => setTimeout(r, 2500));
        }
        await page.screenshot({ path: path.join(OUT, LABEL + '_' + mode + '_' + role + '_click.png') });
      }
      /* เปิดฟอร์มเต็มจอบนมือถือ แล้ววัดหัวแถบแดง + การ์ดพนักงาน + ปุ่มล่าง */
      let fmTest = null;
      if (process.env.NJHR_OPEN_FORM) {
        const bid = process.env.NJHR_OPEN_FORM;   // lv-new | ot-new
        await page.evaluate(id => { const b = document.getElementById(id); if (b) b.click(); }, bid);
        await new Promise(r => setTimeout(r, 2500));
        await page.screenshot({ path: path.join(OUT, LABEL + '_' + mode + '_' + role + '_form.png') });
        fmTest = await page.evaluate(() => {
          const ov = document.querySelector('.modal-overlay');
          if (!ov) return { open: false };
          const head = ov.querySelector('.modal-head');
          const emp = ov.querySelector('.fm-emp');
          const foot = ov.querySelector('.modal-foot');
          const cs = head ? getComputedStyle(head) : null;
          const r = ov.querySelector('.modal').getBoundingClientRect();
          return {
            open: true, full: ov.classList.contains('modal-full'),
            title: (head && head.querySelector('h3') || {}).textContent,
            headBg: cs ? cs.backgroundColor : null,
            backBtn: !!ov.querySelector('#modal-back'),
            empCard: !!emp,
            empName: emp ? (emp.querySelector('b') || {}).textContent : null,
            empSub: emp ? (emp.querySelector('small') || {}).textContent : null,
            footBtns: foot ? Array.prototype.map.call(foot.querySelectorAll('.btn'),
              b2 => b2.textContent.trim() + ':' + Math.round(b2.getBoundingClientRect().height)) : [],
            modalW: Math.round(r.width), modalH: Math.round(r.height),
            emoji: /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/u.test(ov.innerText),
            overflowX: document.documentElement.scrollWidth > document.documentElement.clientWidth
          };
        });
      }

      const key = mode + '_' + role;
      const file = path.join(OUT, LABEL + '_' + key + '.png');
      const buf = await page.screenshot({ path: file });
      /* มือถือ: ถ่ายส่วนล่างเพิ่ม เพื่อตรวจว่า Bottom Navigation ไม่บังการ์ดประกาศ */
      if (mode.indexOf('mobile') === 0) {
        await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight));
        await new Promise(r => setTimeout(r, 400));
        await page.screenshot({ path: path.join(OUT, LABEL + '_' + key + '_bottom.png') });
      }

      const info = await page.evaluate(w => {
        const q = s => document.querySelector(s);
        const txt = s => { const n = q(s); return n ? n.textContent.trim() : null; };
        /* วัดความกว้างข้อความจริงเทียบกับ fallback — ถ้าเท่ากันเป๊ะแปลว่ายังไม่ได้ใช้ Prompt */
        const measure = fam => {
          const c = document.createElement('canvas').getContext('2d');
          c.font = '600 32px ' + fam;
          return Math.round(c.measureText('ทดสอบฟอนต์ Prompt 123').width * 100) / 100;
        };
        const fontCheck = {};
        w.forEach(x => { fontCheck[x] = document.fonts.check(x + ' 16px Prompt'); });
        const loaded = [];
        document.fonts.forEach(f => { if (f.family === 'Prompt') loaded.push(f.weight + ':' + f.status); });
        const mobileNodes = Array.prototype.filter.call(
          document.querySelectorAll('.only-mobile'),
          n => getComputedStyle(n).display !== 'none');
        return {
          fontFamilyBody: getComputedStyle(document.body).fontFamily,
          fontFamilyH: q('h1,h2,h3') ? getComputedStyle(q('h1,h2,h3')).fontFamily : null,
          fontCheck: fontCheck,
          fontFaces: loaded.sort(),
          widthPrompt: measure("'Prompt'"),
          widthFallback: measure('Tahoma'),
          fontsStatus: document.fonts.status,
          mhMounted: !!q('#mh-root'),
          onlyMobileTotal: document.querySelectorAll('.only-mobile').length,
          onlyMobileVisible: mobileNodes.length,
          onlyDesktopVisible: Array.prototype.filter.call(
            document.querySelectorAll('.only-desktop'),
            n => getComputedStyle(n).display !== 'none').length,
          overflowX: document.documentElement.scrollWidth > document.documentElement.clientWidth,
          scrollW: document.documentElement.scrollWidth,
          clientW: document.documentElement.clientWidth,
          docH: document.documentElement.scrollHeight,
          name: txt('.mh-emp b') || txt('.dash-legacy h3'),
          dept: txt('#mh-dept'),
          deptDash: document.body.innerText.indexOf('แผนก: —') >= 0,
          photoSource: (function () {
            const img = q('#mh-av img');
            if (!img) return q('#mh-av .avatar') ? 'letter-avatar' : 'none';
            if (!img.complete || img.naturalWidth === 0) return 'img-broken';
            const src = img.getAttribute('src') || '';
            return (src.slice(0, 5) === 'data:' ? 'data-uri' : 'http-url') +
                   ' ' + img.naturalWidth + 'x' + img.naturalHeight;
          })(),
          clock: txt('#mh-clock'),
          apmProbe: (function () {
            const m = document.querySelector('.apm');
            if (!m) return null;
            const foot = document.querySelector('.modal-foot');
            return {
              title: (document.querySelector('.modal-head h3') || {}).textContent,
              empName: (m.querySelector('.fm-emp b') || {}).textContent,
              empSub: (m.querySelector('.fm-emp small') || {}).textContent,
              status: (m.querySelector('.apm-st') || {}).textContent,
              rows: Array.prototype.map.call(m.querySelectorAll('.apm-row'),
                r => (r.querySelector('span')||{}).textContent + '=' + (r.querySelector('b')||{}).textContent),
              tl: Array.prototype.map.call(m.querySelectorAll('.tl-item'),
                t => t.className.replace('tl-item ','') + ':' + (t.querySelector('b')||{}).textContent),
              buttons: foot ? Array.prototype.map.call(foot.querySelectorAll('.btn'),
                b => b.textContent.trim() + ':' + Math.round(b.getBoundingClientRect().height)) : [],
              overflow: Array.prototype.some.call(m.querySelectorAll('b,span'),
                n => n.scrollWidth > n.clientWidth + 1)
            };
          })(),
          widestEl: (function () {
            const w = document.documentElement.clientWidth; const out = [];
            document.querySelectorAll('body *').forEach(function (n) {
              const r = n.getBoundingClientRect();
              if (r.right > w + 0.5 || r.left < -0.5) {
                out.push({ tag: n.tagName.toLowerCase(), id: n.id || null,
                  cls: String(n.className || '').slice(0, 50),
                  txt: (n.textContent || '').trim().slice(0, 30),
                  parent: n.parentElement ? (n.parentElement.className || n.parentElement.tagName) : null,
                  card: (function(){var c=n.closest('.card');return c?(c.querySelector('h3')||{}).textContent:null;})(),
                  left: Math.round(r.left), right: Math.round(r.right) });
              }
            });
            return out.slice(0, 6);
          })(),
          kpiComputed: (function () {
            const k = document.querySelector('.dash-legacy .kpi');
            const r = document.querySelector('.dash-legacy');
            if (!k) return null;
            const cs = getComputedStyle(k), rc = k.getBoundingClientRect();
            const rs = r ? getComputedStyle(r) : null;
            const rr = r ? r.getBoundingClientRect() : null;
            const tb = document.querySelector('.topbar');
            return { display: cs.display, flexDirection: cs.flexDirection,
              textAlign: cs.textAlign, h: Math.round(rc.height), w: Math.round(rc.width),
              rootMaxWidth: rs ? rs.maxWidth : null, rootW: rr ? Math.round(rr.width) : null,
              rootMarginLeft: rs ? rs.marginLeft : null,
              topbarBg: tb ? getComputedStyle(tb).backgroundColor : null };
          })(),
          dashCards: (function () {
            const root = document.querySelector('.dash-legacy');
            if (!root) return null;
            const card = t => Array.prototype.find.call(root.querySelectorAll('.card'),
              c => (c.querySelector('h3') || {}).textContent === t);
            const rows = c => c ? Array.prototype.map.call(c.querySelectorAll('.list-row'), r => ({
              b: (r.querySelector('b') || {}).textContent.trim(),
              s: (r.querySelector('small') || {}).textContent.trim(),
              badge: (r.querySelector('.badge') || {}).textContent || null,
              href: r.getAttribute('href') || null,
              dot: !!r.querySelector('.nt-dot')
            })) : [];
            const lv = card('คำขอลาล่าสุด'), an = card('ประกาศบริษัทล่าสุด'), nt = card('การแจ้งเตือนล่าสุด');
            return {
              kpi: Array.prototype.map.call(root.querySelectorAll('.kpi'),
                k => ({ label: (k.querySelector('small')||{}).textContent, val: (k.querySelector('b')||{}).textContent,
                        href: k.getAttribute('href'), icon: !!k.querySelector('.kpi-ic svg') })),
              leave: rows(lv), ann: rows(an), notify: rows(nt),
              annPinned: an ? an.querySelectorAll('.ic-red').length : 0,
              chartRows: root.querySelectorAll('.bar-row').length,
              calDays: root.querySelectorAll('.mini-cal-grid > span').length,
              calToday: root.querySelectorAll('.mini-cal-grid .today').length,
              seeAll: Array.prototype.map.call(root.querySelectorAll('.card-head .link'), a2 => a2.getAttribute('href'))
            };
          })(),
          /* ระบบแจ้งเตือน */
          notifyProbe: (function () {
            var bells = Array.prototype.map.call(
              document.querySelectorAll('#btn-bell, .att-mb-bell, .req-mb-bell'),
              function (b) {
                var bd = b.querySelector('.bell-badge');
                var r = b.getBoundingClientRect();
                return { sel: b.id ? '#' + b.id : '.' + String(b.className).split(' ')[0],
                         badge: bd ? bd.textContent.trim() : null,
                         w: Math.round(r.width), h: Math.round(r.height) };
              });
            var api = window.NJHR && NJHR.notify;
            return {
              bells: bells,
              unreadState: (window.NJHR && NJHR.state) ? NJHR.state.ntUnread : null,
              apiPresent: !!api,
              apiKeys: api ? Object.keys(api).sort() : [],
              soundOn: api && api.soundOn ? api.soundOn() : null,
              badge99: api && api.badgeText ? [api.badgeText(5), api.badgeText(99), api.badgeText(100), api.badgeText(1000)] : null,
              setAppBadgeSupported: !!navigator.setAppBadge,
              toasts: document.querySelectorAll('.toast-nt').length
            };
          })(),
          /* รายงาน Touch Target ฉบับเต็ม: rect ทุกปุ่ม + ตรวจซ้อนทับ + ตรวจ handler */
          touchReport: (function () {
            const SEL = 'button,a[href],[role=button],input,select,textarea';
            const items = [];
            document.querySelectorAll(SEL).forEach(function (b) {
              const r = b.getBoundingClientRect();
              const cs = getComputedStyle(b);
              const visible = !(r.width === 0 || r.height === 0 ||
                                cs.display === 'none' || cs.visibility === 'hidden');
              let handler = null;
              if (b.onclick) handler = 'inline';
              else if (b.tagName === 'A' && b.getAttribute('href') &&
                       b.getAttribute('href') !== '#') handler = 'href';
              else if (Object.keys(b.dataset || {}).length) handler = 'data-attr';
              else {
                let p2 = b.parentElement, d2 = 0;
                while (p2 && d2 < 6) { if (p2.onclick) { handler = 'delegated'; break; } p2 = p2.parentElement; d2++; }
              }
              items.push({
                id: b.id || null, cls: String(b.className || '').slice(0, 48),
                tag: b.tagName.toLowerCase(),
                txt: (b.textContent || '').trim().slice(0, 24),
                ariaLabel: b.getAttribute('aria-label') || null,
                visible: visible, disabled: !!b.disabled,
                rect: { x: Math.round(r.left * 10) / 10, y: Math.round(r.top * 10) / 10,
                        w: Math.round(r.width * 10) / 10, h: Math.round(r.height * 10) / 10 },
                meets44: visible ? (r.width >= 44 && r.height >= 44) : null,
                handler: handler
              });
            });
            const vis = items.filter(function (i2) { return i2.visible; });
            const overlaps = [];
            for (let a = 0; a < vis.length; a++) {
              for (let b2 = a + 1; b2 < vis.length; b2++) {
                const A = vis[a].rect, B = vis[b2].rect;
                const ox = Math.min(A.x + A.w, B.x + B.w) - Math.max(A.x, B.x);
                const oy = Math.min(A.y + A.h, B.y + B.h) - Math.max(A.y, B.y);
                if (ox > 1 && oy > 1) {
                  /* ปุ่มที่ซ้อนเพราะเป็นลูกของอีกปุ่มไม่นับเป็นปัญหา */
                  const ea = document.querySelectorAll(SEL)[items.indexOf(vis[a])];
                  overlaps.push({ a: vis[a].id || vis[a].cls || vis[a].txt,
                                  b: vis[b2].id || vis[b2].cls || vis[b2].txt,
                                  overlapW: Math.round(ox * 10) / 10, overlapH: Math.round(oy * 10) / 10 });
                }
              }
            }
            return {
              total: items.length, visible: vis.length,
              under44: vis.filter(function (i2) { return !i2.meets44; }),
              noHandler: vis.filter(function (i2) { return !i2.handler && !i2.disabled; }),
              noAriaIconOnly: vis.filter(function (i2) { return !i2.txt && !i2.ariaLabel; }),
              overlaps: overlaps,
              items: items
            };
          })(),
          /* Touch Target: ทุก element ที่กดได้และมองเห็นได้ ต้อง ≥ 44×44 */
          touch: (function () {
            const bad = [];
            document.querySelectorAll('button,a[href],[role=button],input,select,textarea')
              .forEach(function (b) {
                const r = b.getBoundingClientRect();
                if (r.width === 0 || r.height === 0) return;
                const cs = getComputedStyle(b);
                if (cs.display === 'none' || cs.visibility === 'hidden') return;
                if (r.width < 44 || r.height < 44) {
                  bad.push({ id: b.id || null, cls: String(b.className || '').slice(0, 40),
                    txt: (b.textContent || '').trim().slice(0, 20),
                    w: Math.round(r.width * 10) / 10, h: Math.round(r.height * 10) / 10 });
                }
              });
            return bad;
          })(),
          /* ปุ่มที่ไม่มี handler เลย */
          deadButtons: (function () {
            const out = [];
            document.querySelectorAll('button,[role=button]').forEach(function (b) {
              const r = b.getBoundingClientRect();
              if (r.width === 0 || r.height === 0 || b.disabled) return;
              if (b.onclick) return;
              const ds = b.dataset || {};
              if (Object.keys(ds).length) return;
              let p2 = b.parentElement, d2 = 0;
              while (p2 && d2 < 6) { if (p2.onclick) return; p2 = p2.parentElement; d2++; }
              out.push({ id: b.id || null, txt: (b.textContent || '').trim().slice(0, 20) });
            });
            return out;
          })(),
          mobileCssApplied: (function () {
            const ls = Array.prototype.filter.call(document.styleSheets,
              s2 => s2.href && s2.href.indexOf('mobile.css') >= 0);
            if (!ls.length) return { linked: false };
            let rules = 0;
            try { rules = ls[0].cssRules.length; } catch (e) { rules = -1; }
            return { linked: true, disabled: ls[0].disabled, media: String(ls[0].media.mediaText || ''),
                     rules: rules };
          })(),
          fontW500: (function () {
            let n = 0;
            document.querySelectorAll('*').forEach(function (e2) {
              if (getComputedStyle(e2).fontWeight === '500') n++;
            });
            return n;
          })(),
          /* หน้าคำขอ */
          req: (function () {
            const root = q('#req-mb');
            if (!root) return null;
            const bal = Array.prototype.map.call(document.querySelectorAll('.req-bi'),
              n => (n.querySelector('.req-bi-l') || {}).textContent + '=' +
                   ((n.querySelector('.req-bi-v') || {}).textContent || '').trim());
            const rows = Array.prototype.map.call(document.querySelectorAll('.req-row'),
              n => (n.querySelector('b') || {}).textContent.trim() + ' [' +
                   (n.querySelector('.req-bd') || {}).textContent.trim() + ']');
            const acts = Array.prototype.map.call(document.querySelectorAll('.req-act'),
              n => (n.querySelector('b') || {}).textContent.trim() + ':' +
                   Math.round(n.getBoundingClientRect().height));
            const over = Array.prototype.some.call(root.querySelectorAll('b,small,.req-tab,.req-bd'),
              n => n.scrollWidth > n.clientWidth + 1);
            const bn = q('.bottom-nav'), last = root.querySelector('.req-row:last-of-type, .req-empty');
            return {
              tab: (q('.req-tab.on') || {}).textContent,
              tabs: Array.prototype.map.call(document.querySelectorAll('.req-tab'), n => n.textContent.trim()),
              balance: bal, rows: rows, rowCount: rows.length, acts: acts,
              emoji: /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/u.test(root.innerText),
              textOverflow: over,
              empty: !!q('.req-empty'), partErr: !!q('.req-part-err'), block: !!q('.req-mb-block'),
              navGap: (bn && last) ? Math.round(bn.getBoundingClientRect().top -
                                                last.getBoundingClientRect().bottom) : null
            };
          })(),
          /* ปุ่มลงเวลา: ต้องอยู่แถวเดียวกัน กว้างเท่ากัน และข้อความไม่ล้น */
          acts: (function () {
            const a = q('#attmb-in'), b = q('#attmb-out');
            if (!a || !b) return null;
            const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
            const ov = n => {
              const sp = n.querySelector('span');
              return sp ? (sp.scrollWidth > sp.clientWidth + 1) : false;
            };
            return {
              sameRow: Math.abs(ra.top - rb.top) < 2,
              inLeft: ra.left < rb.left,
              widthIn: Math.round(ra.width), widthOut: Math.round(rb.width),
              equalWidth: Math.abs(ra.width - rb.width) < 1.5,
              heightIn: Math.round(ra.height), heightOut: Math.round(rb.height),
              textOverflow: ov(a) || ov(b),
              disabledIn: a.disabled, disabledOut: b.disabled
            };
          })(),
          att: (function () {
            const r = q('#att-mb');
            if (!r) return null;
            const btn = id => { const n = q(id); return n ? { disabled: n.disabled, busy: n.getAttribute('data-busy') === '1' } : null; };
            return {
              mounted: true,
              title: txt('.att-mb-title'),
              brand: txt('.att-mb-bar b'), brandSub: txt('.att-mb-bar small'),
              time: txt('#attmb-time'), shift: txt('#attmb-shift'),
              empName: txt('#attmb-emp b'),
              empCode: (q('#attmb-emp small i') || {}).textContent || null,
              empDept: (function () { const n = document.querySelectorAll('#attmb-emp small i'); return n[1] ? n[1].textContent : null; })(),
              dash: r.innerText.indexOf('—') >= 0,
              gps: { title: txt('#attmb-gps b'), note: txt('#attmb-gps small'), cls: (q('#attmb-gps') || {}).className },
              face: { title: txt('#attmb-face b'), cls: (q('#attmb-face') || {}).className },
              btnIn: btn('#attmb-in'), btnOut: btn('#attmb-out'),
              hist: (q('#attmb-hist') || {}).innerText || null,
              err: txt('#attmb-err'),
              blocked: !!q('.att-mb-block'),
              analogHands: !!(q('#acl-h') && q('#acl-m')),
              emoji: /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/u.test(r.innerText),
              bnAtt: !!q('.bottom-nav.bn-att'),
              bnActive: (function () { const a = q('.bn-item.active'); return a ? a.textContent.trim() : null; })(),
              topbarHidden: (function () { const t2 = q('.topbar'); return !t2 || getComputedStyle(t2).display === 'none'; })()
            };
          })()
        };
      }, WEIGHTS);

      info.errors = errors; info.netFail = netFail; info.rpcCount = rpcCount;
      info.reqMode = process.env.NJHR_REQ_MODE || 'full'; info.rpcCalls = rpcCalls;
      if (chTest) info.holidayModal = chTest;
      if (fmTest) info.formMobile = fmTest;
      if (lvTest) info.leaveSubmit = lvTest;
      if (raB64 !== null) info.reportAllBytes = Buffer.from(raB64, 'base64').length;
      if (wfTest) info.approvalSettings = wfTest;
      if (tabTest) { info.tabTest = tabTest; info.tabRpcUnchanged = tabTest.rpcUnchanged; }
      info.route = ROUTE; info.attCase = MF.ATT_CASE; info.geo = DENY_GEO ? 'denied' : 'allowed';
      info.clickTest = clickTest;
      info.md5 = crypto.createHash('md5').update(buf).digest('hex');
      info.file = path.basename(file);
      info.route = ROUTE;
      report.runs[key] = info;

      await page.close(); await browser.close();
    }
  }
  srv.close();
  fs.writeFileSync(path.join(OUT, 'ui_report_' + LABEL + '.json'), JSON.stringify(report, null, 2));
  console.log('เสร็จ ' + LABEL + ' → ' + OUT);
})();
