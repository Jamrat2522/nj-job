/* date_format_test.js — ตรวจรูปแบบวันที่ DD/MM/YYYY (ปี ค.ศ.) ในขอบเขตที่กำหนด
     1. หน้าลางาน / คำขอลาของฉัน            (#/leave)
     2. หน้า OT / คำขอ OT ของฉัน             (#/ot)
     3. หน้ารายการ + รายละเอียดของลางาน      (#/requests · #/req-history · Modal)
     4. หน้ารายการ + รายละเอียดของ OT        (#/requests · #/req-history · Modal)
     5. REPORT ลางาน                          (#/rpt-leave · ตาราง + Excel)
     6. REPORT OT                             (#/rpt-ot · ตาราง + Excel)
   ตรวจทั้ง Desktop และ Mobile · ตรวจ Timezone ว่าไม่เลื่อนวัน
   ใช้: node harness/date_format_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(60) + (d || '')); }
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
  .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const tick = ms => new Promise(r => setTimeout(r, ms || 40));

/* รูปแบบที่ห้ามเหลืออยู่ในขอบเขต */
const TH_MONTH_RE = /(?:ม\.ค\.|ก\.พ\.|มี\.ค\.|เม\.ย\.|พ\.ค\.|มิ\.ย\.|ก\.ค\.|ส\.ค\.|ก\.ย\.|ต\.ค\.|พ\.ย\.|ธ\.ค\.)/;
const BE_YEAR_RE = /\b25\d{2}\b/;
const DMY_RE = /^\d{2}\/\d{2}\/\d{4}$/;
const DMY_ANY = /\d{2}\/\d{2}\/\d{4}/g;

function noLegacy(label, text) {
  chk(label + ' · ไม่เหลือชื่อเดือนไทย', !TH_MONTH_RE.test(text),
    (text.match(TH_MONTH_RE) || [''])[0]);
  chk(label + ' · ไม่เหลือปี พ.ศ.', !BE_YEAR_RE.test(text),
    (text.match(BE_YEAR_RE) || [''])[0]);
}

/* ---------- ตัวแปลงกลางฉบับจริง (คัดจาก src/01-core-icons-utils.js) ---------- */
function realFmtDateDMY(v) {
  const p = String(v == null ? '' : v).slice(0, 10).split('-');
  if (p.length !== 3) return '—';
  const y = parseInt(p[0], 10), m = parseInt(p[1], 10), d = parseInt(p[2], 10);
  if (!isFinite(y) || !isFinite(m) || !isFinite(d)) return '—';
  const z = n => (n < 10 ? '0' + n : '' + n);
  return z(d) + '/' + z(m) + '/' + y;
}

/* ================= 1) ตัวแปลงกลางในไฟล์จริง ================= */
function testFormatter() {
  console.log('\n== ตัวแปลงกลาง fmtDateDMY() ==');
  const src = fs.readFileSync(path.join(ROOT, 'src/01-core-icons-utils.js'), 'utf8');
  chk('ประกาศไว้ใน core ที่เดียว', (src.match(/function fmtDateDMY\s*\(/g) || []).length === 1, '');
  chk('ไม่ใช้ new Date() (กัน Timezone เลื่อนวัน)',
    src.slice(src.indexOf('function fmtDateDMY'), src.indexOf('function fmtDateDMY') + 600)
      .indexOf('new Date') < 0, '');

  const cases = [
    ['2026-08-11', '11/08/2026', 'วันที่ปกติ'],
    ['2026-08-01', '01/08/2026', 'วันมี 1 หลัก → เติม 0'],
    ['2026-01-05', '05/01/2026', 'เดือนมี 1 หลัก → เติม 0'],
    ['2026-12-31', '31/12/2026', 'สิ้นปี'],
    ['2026-01-01', '01/01/2026', 'ต้นปี'],
    ['2026-08-11T00:00:00Z', '11/08/2026', 'timestamp เที่ยงคืน UTC ต้องไม่ถอย 1 วัน'],
    ['2026-08-11T23:59:59+07:00', '11/08/2026', 'timestamp ปลายวัน +07 ต้องไม่บวก 1 วัน'],
    ['2026-08-11T17:00:00Z', '11/08/2026', 'timestamp 17:00Z (= 00:00 ไทยวันถัดไป) ต้องไม่เลื่อน'],
    ['', '—', 'ค่าว่าง'],
    [null, '—', 'null'],
    [undefined, '—', 'undefined']
  ];
  cases.forEach(function (c) {
    chk('fmtDateDMY · ' + c[2], realFmtDateDMY(c[0]) === c[1],
      JSON.stringify(c[0]) + ' → ' + realFmtDateDMY(c[0]));
  });

  /* ยืนยันว่าตัวแปลงในไฟล์จริงให้ผลเดียวกับที่ทดสอบ (รันโค้ดจากไฟล์ตรง ๆ) */
  const body = src.slice(src.indexOf('function fmtDateDMY'));
  const end = body.indexOf('\n  }') + 4;
  const fn = new Function('pad', 'return (' + body.slice(0, end) + ')')(n => (n < 10 ? '0' + n : '' + n));
  chk('โค้ดจริงในไฟล์ให้ผลตรงกับที่คาดทุกกรณี',
    cases.every(c => fn(c[0]) === c[1]), '');
}

/* ================= สภาพแวดล้อม jsdom ================= */
/* แถวจาก njhr_ot_list — หน้า #/ot อ่านจาก Supabase แล้ว */
const OTS = [
  { id: 'OT-A', request_no: '260811-0001', employee_id: 'e1', emp_name: 'สมชาย ใจดี',
    ot_date: '2026-08-11', start_time: '18:00:00', end_time: '21:00:00', spans_next_day: false,
    ot_hours: 3, reason: 'ปิดงบ', status: 'PENDING', created_at: '2026-08-11T10:00:00Z',
    jobs_count: 1, files_count: 0, is_holiday: false }
];

const LEAVES = [
  { id: 'lv-1', request_no: '260810-0007', leave_type: 'SICK', status: 'PENDING', ui_status: 'PENDING',
    start_date: '2026-08-10', end_date: '2026-08-12', total_days: 3, hours: 0, leave_unit: 'day',
    reason: 'ไม่สบาย', file_name: null, emp_name: 'สมชาย ใจดี', department: 'ขนส่ง',
    prefix: 'นาย', full_name: 'สมชาย ใจดี', mode_txt: 'หลายวัน', created_at: '2026-08-09T03:00:00Z' }
];
const RPT_OT = [
  { req_id: 'o1', request_no: '260811-0001', prefix: 'นาย', full_name: 'สมชาย ใจดี', nickname: '',
    emp_code: 'NJ001', department: 'ขนส่ง', ot_date: '2026-08-11', start_time: '18:00:00',
    end_time: '21:00:00', spans_next_day: false, ot_hours: 3, is_holiday: false,
    status: 'PENDING', created_at: '2026-08-11T03:00:00Z' }
];

function env(opt) {
  opt = opt || {};
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div><div id="modal-root"></div></body></html>');
  const win = dom.window;
  const db = { employees: [], attendance: [], leaves: [], ots: [], corrections: [], payroll: [],
    announcements: [], holidays: [], notifications: [], leaveTypes: [], departments: [],
    users: [], balances: [], shifts: [], audit: [], settings: {} };
  let modal = null;
  const NJHR = {
    state: { currentRoute: opt.route || '#/leave', docPending: 0 },
    router: { navId: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    features: {}, views: { register: () => {} }, compat: { scope: {} }
  };
  Object.assign(NJHR.compat.scope, {
    icon: () => '<span class="ic"></span>', esc, debounce: f => f,
    avatarHTML: () => '<span class="avatar"></span>',
    emptyState: m => '<div class="empty"><p>' + m + '</p></div>',
    /* ตัวแปลงกลางฉบับจริง — ไม่ stub เป็น identity เพราะชุดนี้ตรวจ "รูปแบบ" โดยตรง */
    fmtDateDMY: realFmtDateDMY,
    fmtDate: d => { const p = String(d || '').split('-');
      return p.length === 3 ? Number(p[2]) + ' ส.ค. ' + (Number(p[0]) + 543) : '—'; },
    empBE: d => { const p = String(d || '').split('-');
      return p.length === 3 ? p[2] + '/' + p[1] + '/' + (Number(p[0]) + 543) : '—'; },
    rptDateBE: d => { const p = String(d || '').split('-');
      return p.length === 3 ? p[2] + '/' + p[1] + '/' + (Number(p[0]) + 543) : ''; },
    todayISO: () => '2026-08-11',
    statusBadge: s => '<span class="badge">' + s + '</span>',
    currentUser: () => ({ id: 'u1', role: 'SUPER_ADMIN', empId: 'e1' }),
    currentEmp: () => ({ id: 'e1', firstName: 'สมชาย', lastName: 'ใจดี', deptId: 'd1' }),
    emp: () => null, empName: () => 'สมชาย ใจดี', dept: () => 'ขนส่ง',
    db: db, toast: () => {}, audit: () => {}, nav: () => {}, saveDB: () => {},
    nowStamp: () => '2026-08-11 10:00', render: () => {}, uid: () => 'x',
    confirmDialog: () => {},
    openModal: (t, b, f) => { modal = { title: t, body: b, foot: f };
      win.document.getElementById('modal-root').innerHTML =
        '<div class="modal-body">' + b + '</div><div class="modal-foot">' + (f || '') + '</div>'; },
    closeModal: () => { modal = null; },
    sbReady: () => true, sbToken: () => 'tok',
    sbRpc: (fn) => {
      if (fn === 'njhr_ot_get') return Promise.resolve({ data: {
        ot_date: '2026-08-11', start_time: '18:00:00', end_time: '21:00:00',
        spans_next_day: false, ot_hours: 3, status: 'PENDING', reason: 'ปิดงบ',
        jobs: [{ job_no: 1, job_type: 'ตรวจปล่อย', detail: '' }], approvals: [] } });
      if (fn === 'njhr_leave_detail') return Promise.resolve({
        leave_type: 'ลาป่วย', emp_name: 'สมชาย ใจดี', status: 'PENDING',
        ui_status: 'PENDING', reason: 'ไม่สบาย', attachments: [], approvals: [] });
      return Promise.resolve({});
    },
    sbRpcList: (fn) => {
      if (fn === 'njhr_ot_list') return Promise.resolve(OTS);
      if (fn === 'njhr_leave_list') return Promise.resolve(LEAVES.map(r => Object.assign({ total_count: 1 }, r)));
      if (fn === 'njhr_rpt_leave_list') return Promise.resolve(LEAVES);
      if (fn === 'njhr_rpt_ot_list') return Promise.resolve(RPT_OT);
      if (fn === 'njhr_att_correction_list') return Promise.resolve([]);
      if (fn === 'njhr_leave_balances') return Promise.resolve([]);
      if (fn === 'njhr_emp_departments') return Promise.resolve([{ name: 'ขนส่ง' }]);
      return Promise.resolve([]);
    },
    rptSafeName: v => String(v), rptLoadZip: () => Promise.resolve(),
    rptBuildXlsx: (sheet, head, rows) => { win.__xlsx = { sheet, head, rows }; return Promise.resolve({}); },
    lvType: c => ({ SICK: { name: 'ลาป่วย', color: '#16A34A' } }[c] || { name: c, color: '#64748B' }),
    lvMode: () => 'FULL', lvModeTxt: m => ({ FULL: 'เต็มวัน' }[m] || m),
    lvNum: v => Number(v) || 0,
    lvCode: x => (x && typeof x === 'object' ? (x.request_no || x.id) : String(x)),
    LEAVE_TYPES: [], refreshLeavePending: () => {}, RQ_CARDS: [],
    rqState: { seq: 0, bal: [], err: '' }, rqRenderMenu: () => {}, rqRenderBal: () => {},
    rqPick: () => null, canAccess: () => true, menuHref: () => '#', rhStatus: () => ({ k: 'PENDING', c: 'badge-warn', t: 'รออนุมัติ' }),
    rhRow: (k, v) => '<div class="rh-drow"><span class="k">' + k + '</span><span class="v">' + v + '</span></div>',
    docTS: v => String(v || ''),
    showTimeline: () => {}, bindReqCardActions: () => {},
    TH_MONTHS: ['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'],
    otJobsHTML: () => '', otBindJobFiles: () => {}, otJobEndDate: j => j.endDate || j.date
  });
  win.NJHR = NJHR;
  win.URL.createObjectURL = () => 'blob:x';
  win.URL.revokeObjectURL = () => {};
  const ctx = vm.createContext(win);
  return { win, NJHR, ctx,
    run: rel => vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), ctx, { filename: rel }),
    host: () => win.document.getElementById('app'),
    doc: () => win.document, modal: () => modal };
}

function grab(E, name) { let f = null; E.NJHR.views.register = (n, x) => { if (n === name) f = x; }; return () => f; }
function dates(text) { return text.match(DMY_ANY) || []; }

async function run() {
  testFormatter();

  /* ================= 2) หน้า OT (Desktop + Mobile) ================= */
  console.log('\n== หน้า OT / คำขอ OT ของฉัน (#/ot) ==');
  const E1 = env({ route: '#/ot' });
  const g1 = grab(E1, 'viewOT');
  E1.run('runtime/shared/requests.js');
  E1.run('views/ot/main.js');
  g1()(E1.host());
  await tick(60);                    // viewOT โหลดจาก njhr_ot_list แบบ async
  const otDesk = E1.doc().querySelector('.lvt-ot tbody td.lvt-c-date').textContent.trim();
  chk('OT Desktop · ตารางแสดง DD/MM/YYYY', otDesk === '11/08/2026', otDesk);
  const otMob = E1.doc().querySelector('.req-card.only-mobile .req-top b').textContent.trim();
  chk('OT Mobile · การ์ดแสดง DD/MM/YYYY', otMob === '11/08/2026', otMob);
  noLegacy('หน้า OT', E1.host().textContent);

  /* ================= 3) หน้าลางาน (Desktop + Mobile) ================= */
  console.log('\n== หน้าลางาน / คำขอลาของฉัน (#/leave) ==');
  const E2 = env({ route: '#/leave' });
  const g2 = grab(E2, 'viewLeave');
  E2.run('views/leave/main.js');
  g2()(E2.host());
  await tick(60);
  const lvDesk = E2.doc().querySelector('.lvt-lv tbody td.lvt-c-date').textContent.trim();
  chk('ลางาน Desktop · ช่วงวันที่เป็น DD/MM/YYYY ทั้งคู่',
    lvDesk === '10/08/2026 – 12/08/2026', lvDesk);
  const lvMob = E2.doc().querySelector('.req-card.only-mobile .req-body span:nth-child(2)').textContent.trim();
  chk('ลางาน Mobile · ช่วงวันที่เป็น DD/MM/YYYY ทั้งคู่',
    lvMob === '10/08/2026 – 12/08/2026', lvMob);
  noLegacy('หน้าลางาน', E2.host().textContent);

  /* ================= 4) หน้ารายการคำขอรวม (Mobile) ================= */
  console.log('\n== หน้ารายการคำขอ ลางาน + OT (Mobile · #/requests) ==');
  const E3 = env({ route: '#/requests' });
  const g3 = grab(E3, 'viewRequests');
  E3.run('views/leave/main.js');
  g3()(E3.host());
  await tick(80);
  const reqTxt = E3.doc().querySelector('#req-list') ? E3.doc().querySelector('#req-list').textContent : '';
  chk('รายการคำขอ Mobile · มีวันที่ DD/MM/YYYY', dates(reqTxt).length > 0, dates(reqTxt).join(' · '));
  noLegacy('รายการคำขอ Mobile', reqTxt);

  /* ================= 5) Modal รายละเอียด OT ================= */
  console.log('\n== Modal รายละเอียด OT ==');
  const E4 = env({ route: '#/requests' });
  E4.run('runtime/shared/requests.js');
  E4.run('views/leave/main.js');
  E4.run('views/leave/detail.js');
  E4.NJHR.features.requestDetail.open('OT', 'o1', E4.host());
  await tick(60);
  const mb = E4.doc().querySelector('#modal-root .modal-body').textContent;
  chk('Modal OT · วันที่ทำ OT เป็น DD/MM/YYYY', mb.indexOf('11/08/2026') >= 0,
    dates(mb).join(' · '));
  noLegacy('Modal OT', mb);

  /* ================= 6) REPORT ลางาน (ตาราง + Excel) ================= */
  console.log('\n== REPORT ลางาน (#/rpt-leave) ==');
  const E5 = env({ route: '#/rpt-leave' });
  const g5 = grab(E5, 'viewRptLeave');
  E5.run('views/reports/menu.js');
  g5()(E5.host());
  await tick(60);
  const rl = Array.from(E5.doc().querySelectorAll('.rptm-table tbody tr td')).map(x => x.textContent.trim());
  chk('REPORT ลางาน · คอลัมน์วันที่เป็นช่วง DD/MM/YYYY',
    rl[3] === '10/08/2026 – 12/08/2026', rl[3]);
  noLegacy('REPORT ลางาน', E5.host().textContent);
  const btn5 = E5.doc().getElementById('rptm-export');
  btn5.onclick.call(btn5);
  await tick(60);
  const x5 = E5.win.__xlsx;
  chk('REPORT ลางาน · Excel ใช้วันที่ DD/MM/YYYY ชุดเดียวกับตาราง',
    x5 && x5.rows[0][3] === '10/08/2026 – 12/08/2026', x5 ? x5.rows[0][3] : 'ไม่มีไฟล์');
  chk('REPORT ลางาน · Excel ไม่เหลือ พ.ศ./เดือนไทย',
    !TH_MONTH_RE.test(JSON.stringify(x5.rows)) && !BE_YEAR_RE.test(JSON.stringify(x5.rows)), '');

  /* ================= 7) REPORT OT (ตาราง + Excel) ================= */
  console.log('\n== REPORT OT (#/rpt-ot) ==');
  const E6 = env({ route: '#/rpt-ot' });
  const g6 = grab(E6, 'viewRptOT');
  E6.run('views/reports/menu.js');
  g6()(E6.host());
  await tick(60);
  const ro = Array.from(E6.doc().querySelectorAll('.rptm-table tbody tr td')).map(x => x.textContent.trim());
  chk('REPORT OT · คอลัมน์วันที่เป็น DD/MM/YYYY', ro[3] === '11/08/2026', ro[3]);
  noLegacy('REPORT OT', E6.host().textContent);
  const btn6 = E6.doc().getElementById('rptm-export');
  btn6.onclick.call(btn6);
  await tick(60);
  const x6 = E6.win.__xlsx;
  chk('REPORT OT · Excel ใช้วันที่ DD/MM/YYYY ชุดเดียวกับตาราง',
    x6 && x6.rows[0][3] === '11/08/2026', x6 ? x6.rows[0][3] : 'ไม่มีไฟล์');
  chk('REPORT OT · Excel ไม่เหลือ พ.ศ./เดือนไทย',
    !TH_MONTH_RE.test(JSON.stringify(x6.rows)) && !BE_YEAR_RE.test(JSON.stringify(x6.rows)), '');

  /* ================= 8) ไม่กระทบการกรอง/เรียง/ค่าที่ส่งไป RPC ================= */
  console.log('\n== ค่าที่ส่งไปฐานข้อมูลยังเป็น ISO เหมือนเดิม ==');
  const E7 = env({ route: '#/rpt-leave' });
  const g7 = grab(E7, 'viewRptLeave');
  const sent = [];
  const origList = E7.NJHR.compat.scope.sbRpcList;
  E7.NJHR.compat.scope.sbRpcList = (fn, body) => { sent.push({ fn, body }); return origList(fn, body); };
  E7.run('views/reports/menu.js');
  g7()(E7.host());
  await tick(60);
  const fromEl = E7.doc().getElementById('rptm-from');
  fromEl.value = '2026-08-01'; fromEl.onchange.call(fromEl);
  await tick(60);
  const last = sent.filter(x => x.fn === 'njhr_rpt_leave_list').slice(-1)[0];
  chk('ตัวกรองส่งค่า ISO (YYYY-MM-DD) ไป RPC ไม่ใช่ DD/MM/YYYY',
    last.body.p_from === '2026-08-01', JSON.stringify(last.body.p_from));
  chk('ช่อง input type=date ยังเก็บค่า ISO', fromEl.value === '2026-08-01', fromEl.value);

  /* ================= 9) ไม่มีตัวแปลงเดิมค้างในไฟล์ในขอบเขต ================= */
  console.log('\n== ไม่มีตัวแปลงวันที่แบบเดิมค้างในไฟล์ในขอบเขต ==');
  ['src/34-view-requests-leave.js', 'src/35-view-ot.js', 'src/37-view-report-menu.js',
   'src/44-view-request-detail.js', 'src/23-shared-requests.js'].forEach(function (f) {
    const s = fs.readFileSync(path.join(ROOT, f), 'utf8');
    chk(f.replace('src/', '') + ' · ไม่เรียก fmtDate/empBE/rptDateBE แล้ว',
      !/\b(fmtDate|empBE|rptDateBE)\s*\(/.test(s), '');
  });

  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
}

run().catch(e => { console.error(e); process.exit(1); });
