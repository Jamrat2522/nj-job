const { launchOpts } = require(require('path').join(__dirname, 'browser.js'));
const { chromium } = require('playwright');
const http=require('http'),fs=require('fs'),path=require('path');const F=require('./fixtures.js');
function serve(root,port){const T={'.html':'text/html','.js':'application/javascript','.css':'text/css','.png':'image/png'};
 return new Promise(r=>{const s=http.createServer((rq,rs)=>{let p=decodeURIComponent(rq.url.split('?')[0]);if(p==='/')p='/index.html';
 const f=path.join(root,p);if(!f.startsWith(root)||!fs.existsSync(f)){rs.writeHead(404);return rs.end();}
 rs.writeHead(200,{'Content-Type':T[path.extname(f)]||'application/octet-stream'});rs.end(fs.readFileSync(f));}).listen(port,()=>r(s));});}
const MGMT=['#/payroll','#/approval-settings','#/pay-items','#/sso','#/reports','#/rpt-leave','#/rpt-ot','#/users','#/departments','#/settings','#/geofence','#/shifts','#/audit','#/reportall'];
(async()=>{const dir=process.argv[2],port=Number(process.argv[3]);const s=await serve(dir,port);const b=await chromium.launch(launchOpts());let fail=0;
 for(const role of ['SUPER_ADMIN','HR','ADMIN','USER']){const c=await b.newContext();await c.route('**/rest/v1/rpc/*',r=>{const fn=r.request().url().split('/rpc/')[1].split('?')[0];let bd={};try{bd=JSON.parse(r.request().postData()||'{}')}catch(e){}let out=F.respond(fn,bd);if(fn==='njhr_session_check'||fn==='njhr_login')out=Object.assign({},out,{role});r.fulfill({status:200,contentType:'application/json',headers:{'access-control-allow-origin':'*'},body:JSON.stringify(out)});});
 const p=await c.newPage();await p.goto(`http://127.0.0.1:${port}/index.html`);await p.evaluate(()=>localStorage.setItem('njhr_token','MOCK-TOKEN-FIXED'));await p.reload();await p.waitForTimeout(1200);
 const txt=await p.locator('#sidebar').innerText();const hasApproval=txt.includes('อนุมัติรายการ');const hasMgmt=MGMT.some(h=>txt.includes(({'#/payroll':'เงินเดือน','#/approval-settings':'ตั้งค่าการอนุมัติ','#/shifts':'ตั้งค่ากะทำงาน','#/users':'จัดการสมาชิก'})[h]||'__NO__'));
 const ok=role==='ADMIN'?(hasApproval&&!hasMgmt):role==='USER'?(!hasApproval&&!hasMgmt):(hasApproval&&hasMgmt);
 console.log((ok?'PASS ':'FAIL ')+role+' approval='+hasApproval+' management='+hasMgmt);if(!ok)fail++;await c.close();}
 await b.close();s.close();process.exit(fail?1:0);})();
