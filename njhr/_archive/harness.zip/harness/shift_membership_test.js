const { launchOpts } = require(require('path').join(__dirname, 'browser.js'));
/* shift_membership_test.js — จัดการพนักงานเข้า–ออกกะ · “ไม่มีกะ” (K2)
   ตรวจว่า Frontend เรียก RPC ของ K2 ถูกตัว ถูก Parameter และเป็น Batch จริง
   ใช้: node harness/shift_membership_test.js <ทางโปรเจกต์ absolute> <port> */
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const F = require(__dirname + '/fixtures.js');

let PASS = 0, FAIL = 0;
const ROOT = process.argv[2] || process.cwd(), PORT = Number(process.argv[3] || 8781);
function chk(n, ok, e) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(60) + (e || '')); }

/* ---------- ฐานข้อมูลจำลอง: employee_shifts แบบ append-only ตาม K2 ---------- */
const SHIFTS = [
  { id: 'sh-1', shift_name: 'NJLOGISTIC', start_time: '08:30:00', end_time: '17:30:00',
    break_minutes: 60, late_allow_minutes: 0, is_overnight: false, is_active: true },
  { id: 'sh-2', shift_name: 'ดึก', start_time: '20:00:00', end_time: '05:00:00',
    break_minutes: 60, late_allow_minutes: 0, is_overnight: true, is_active: true }
];
const EMPS = [];
for (let i = 1; i <= 6; i++) {
  EMPS.push({ employee_id: 'e' + i, emp_code: 'NJ000' + i, full_name: 'พนักงาน ทดสอบ' + i,
    nickname: 'ท' + i, department_name: 'ปฏิบัติการ', position_name: 'เจ้าหน้าที่', emp_status: 'ACTIVE' });
}
/* แถวประวัติ: {employee_id, shift_id, effective_date, status} — ไม่ลบ ไม่แก้ทับ */
let HIST = EMPS.slice(0, 4).map(e => ({ employee_id: e.employee_id, shift_id: 'sh-1',
  effective_date: '2026-01-01', status: 'ACTIVE' }));

const calls = [];                                   // บันทึกทุก RPC ที่ Frontend ยิง

function stateOf(id) {                              // ตรรกะเดียวกับ njhr_shift_state_at
  const rows = HIST.filter(h => h.employee_id === id)
    .sort((a, b) => a.effective_date < b.effective_date ? 1 : -1);
  return rows[0] || null;
}
function mark(ids, shiftId, status, date) {
  const out = [];
  ids.forEach(id => {
    const e = EMPS.find(x => x.employee_id === id);
    const same = HIST.find(h => h.employee_id === id && h.effective_date === date);
    let result;
    if (same && same.status === status && (same.shift_id || null) === (shiftId || null)) result = 'UNCHANGED';
    else if (same) { same.shift_id = shiftId; same.status = status; result = 'REPLACED'; }
    else { HIST.push({ employee_id: id, shift_id: shiftId, effective_date: date, status: status }); result = 'INSERTED'; }
    out.push({ employee_id: id, emp_code: e ? e.emp_code : id, result: result,
      old_shift_name: null });
  });
  return out;
}
function respond(fn, bd) {
  calls.push({ fn: fn, body: bd });
  if (fn === 'njhr_shift_list') {
    return SHIFTS.map(s => Object.assign({}, s, {
      employee_count: EMPS.filter(e => { const st = stateOf(e.employee_id);
        return st && st.status === 'ACTIVE' && st.shift_id === s.id; }).length,
      updated_at: null, updated_by: null }));
  }
  if (fn === 'njhr_shift_employee_list') {
    return EMPS.filter(e => { const st = stateOf(e.employee_id);
      return st && st.status === 'ACTIVE' && st.shift_id === bd.p_shift; })
      .map(e => Object.assign({}, e, { effective_date: stateOf(e.employee_id).effective_date }));
  }
  if (fn === 'njhr_shift_unassigned_employees') {
    const q = String(bd.p_q || '').toLowerCase();
    return EMPS.filter(e => { const st = stateOf(e.employee_id);
      if (st && st.status === 'NO_SHIFT') return false;
      return !st || st.status !== 'ACTIVE' || !st.shift_id; })
      .filter(e => !q || (e.emp_code + e.full_name + e.nickname + e.department_name).toLowerCase().includes(q));
  }
  if (fn === 'njhr_shift_no_shift_employees') {
    const q = String(bd.p_q || '').toLowerCase();
    return EMPS.filter(e => { const st = stateOf(e.employee_id); return st && st.status === 'NO_SHIFT'; })
      .filter(e => !q || (e.emp_code + e.full_name + e.nickname + e.department_name).toLowerCase().includes(q))
      .map(e => Object.assign({}, e, { effective_date: stateOf(e.employee_id).effective_date }));
  }
  if (fn === 'njhr_shift_assign_many') {
    const before = {};
    bd.p_employees.forEach(id => { const st = stateOf(id);
      const s = st && st.status === 'ACTIVE' && st.shift_id ? SHIFTS.find(x => x.id === st.shift_id) : null;
      before[id] = s ? s.shift_name : null; });
    const out = mark(bd.p_employees, bd.p_shift, 'ACTIVE', bd.p_effective_date);
    out.forEach(o => { o.old_shift_name = before[o.employee_id]; });
    return out;
  }
  if (fn === 'njhr_shift_remove') {
    return mark(bd.p_employees, null, bd.p_no_shift ? 'NO_SHIFT' : 'REMOVED', bd.p_effective_date);
  }
  if (fn === 'njhr_shift_no_shift_set') {
    return mark(bd.p_employees, null, bd.p_on ? 'NO_SHIFT' : 'REMOVED', bd.p_effective_date);
  }
  if (fn === 'njhr_emp_list') return [{ total_count: EMPS.length }];
  return F.respond(fn, bd);
}

function serve(root, port) {
  const T = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.png': 'image/png' };
  return new Promise(function (r) {
    const s = http.createServer(function (rq, rs) {
      let p = decodeURIComponent(rq.url.split('?')[0]); if (p === '/') p = '/index.html';
      const f = path.join(root, p);
      if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { rs.writeHead(404); return rs.end(); }
      rs.writeHead(200, { 'Content-Type': T[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
      rs.end(fs.readFileSync(f));
    }).listen(port, function () { r(s); });
  });
}

(async function () {
  const srv = await serve(ROOT, PORT);
  const b = await chromium.launch(launchOpts());
  const errs = [];

  async function newCtx(w, h) {
    const ctx = await b.newContext({ viewport: { width: w, height: h },
      isMobile: w < 800, hasTouch: w < 800, serviceWorkers: 'block' });
    await ctx.route('**/rest/v1/rpc/*', function (route) {
      const fn = route.request().url().split('/rpc/')[1].split('?')[0];
      let bd = {}; try { bd = JSON.parse(route.request().postData() || '{}'); } catch (e) {}
      route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(respond(fn, bd)) });
    });
    const pg = await ctx.newPage();
    pg.on('pageerror', e => errs.push(String(e)));
    pg.on('console', m => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(m.text()); });
    await pg.addInitScript(() => { try { localStorage.setItem('njhr_token', 'MOCK-TOKEN-FIXED'); } catch (e) {} });
    return pg;
  }
  async function openShifts(pg) {
    await pg.goto('http://localhost:' + PORT + '/#/shifts', { waitUntil: 'networkidle' });
    await pg.waitForSelector('.sh-card', { timeout: 15000 });
  }
  const kpiUnassigned = pg => pg.evaluate(() => {
    const k = [].find.call(document.querySelectorAll('.sh-kpi'),
      x => x.textContent.indexOf('พนักงานยังไม่มีกะ') >= 0);
    return k ? Number((k.querySelector('b') || {}).textContent) : -1;
  });
  const cardCount = (pg, name) => pg.evaluate(n => {
    const c = [].find.call(document.querySelectorAll('.sh-card'),
      x => x.querySelector('.sh-r-name') && x.querySelector('.sh-r-name').textContent === n);
    if (!c) return -1;
    const m = /พนักงาน\s*(\d+)\s*คน/.exec(c.textContent);
    return m ? Number(m[1]) : -1;
  }, name);

  const pg = await newCtx(1440, 900);
  await openShifts(pg);

  chk('เมนู ⋮ มี "จัดการพนักงาน"', await (async () => {
    await pg.click('.sh-card [data-more="sh-1"]');
    await pg.waitForSelector('.sh-pop', { timeout: 5000 });
    const t = await pg.$$eval('.sh-pop .us-menu-item', ns => ns.map(x => x.textContent));
    return t.some(x => x.indexOf('จัดการพนักงาน') >= 0);
  })());

  chk('เริ่มต้น: NJLOGISTIC 4 คน · ยังไม่มีกะ 2 คน',
    (await cardCount(pg, 'NJLOGISTIC')) === 4 && (await kpiUnassigned(pg)) === 2,
    'กะ ' + (await cardCount(pg, 'NJLOGISTIC')) + ' · unassigned ' + (await kpiUnassigned(pg)));

  /* ---------- A. ACTIVE → NO_SHIFT ผ่าน Dropdown เดียว ---------- */
  await pg.click('.sh-pop [data-emp="sh-1"]');
  await pg.waitForSelector('#shl-list .shl-pick', { timeout: 8000 });
  chk('Modal มี Dropdown “ย้ายไปกะ” และตัวเลือก “ไม่มีกะ”', await pg.evaluate(() => {
    const s = document.getElementById('shl-to');
    return !!s && [].some.call(s.options, o => o.textContent.trim() === 'ไม่มีกะ') &&
      !document.getElementById('shl-rm') && !document.getElementById('shl-ns');
  }));

  calls.length = 0;
  await pg.check('#shl-list .sh-emp-row:nth-child(1) .shl-pick');
  await pg.check('#shl-list .sh-emp-row:nth-child(2) .shl-pick');
  await pg.selectOption('#shl-to', '__NO_SHIFT__');
  await pg.fill('#shl-date', '2026-08-20');
  await pg.click('#shl-move');
  await pg.waitForSelector('#cf-yes', { timeout: 5000 });
  const cfTxt = await pg.textContent('.confirm-msg');
  chk('A. Confirm ระบุ “ไม่มีกะ” + วันที่มีผล', /2 คน/.test(cfTxt) && /ไม่มีกะ/.test(cfTxt) && /20/.test(cfTxt), cfTxt.slice(0, 100));
  await pg.click('#cf-yes');
  await pg.waitForTimeout(900);
  const nsA = calls.filter(c => c.fn === 'njhr_shift_no_shift_set');
  chk('A. กะ→ไม่มีกะ เรียก njhr_shift_no_shift_set ครั้งเดียวแบบ Batch',
    nsA.length === 1 && nsA[0].body.p_on === true && nsA[0].body.p_employees.length === 2,
    'เรียก ' + nsA.length + ' ครั้ง');
  chk('A. ไม่เรียก njhr_shift_remove จาก UI ใหม่', calls.filter(c => c.fn === 'njhr_shift_remove').length === 0);
  chk('A. ประวัติเดิมยังอยู่ และเพิ่ม effective-date ใหม่',
    HIST.filter(h => h.effective_date === '2026-01-01').length === 4 &&
    HIST.filter(h => h.effective_date === '2026-08-20' && h.status === 'NO_SHIFT').length === 2,
    'history=' + HIST.length);
  chk('A. พนักงานย้ายไปส่วน “ไม่มีกะ” และไม่ตกเป็นยังไม่ได้กำหนดกะ',
    (await cardCount(pg, 'NJLOGISTIC')) === 2 && (await kpiUnassigned(pg)) === 2 &&
    await pg.evaluate(() => /2 คน/.test(document.querySelector('.sh-ns-card .badge').textContent)),
    'NJ=' + (await cardCount(pg, 'NJLOGISTIC')) + ' unassigned=' + (await kpiUnassigned(pg)));

  /* ---------- B. NO_SHIFT → ACTIVE ---------- */
  calls.length = 0;
  await pg.click('#shn-toggle');
  await pg.waitForSelector('#shn-list .shn-pick', { timeout: 8000 });
  await pg.click('#shn-all');
  await pg.selectOption('#shn-to', 'sh-2');
  await pg.fill('#shn-date', '2026-08-21');
  await pg.click('#shn-move');
  await pg.waitForSelector('#cf-yes', { timeout: 5000 });
  const cfB = await pg.textContent('.confirm-msg');
  chk('B. Confirm “ไม่มีกะ” → กะจริง', /ไม่มีกะ/.test(cfB) && /ดึก/.test(cfB), cfB.slice(0, 100));
  await pg.click('#cf-yes');
  await pg.waitForTimeout(900);
  const asB = calls.filter(c => c.fn === 'njhr_shift_assign_many');
  chk('B. ไม่มีกะ→กะ เรียก njhr_shift_assign_many ครั้งเดียวแบบ Batch',
    asB.length === 1 && asB[0].body.p_shift === 'sh-2' && asB[0].body.p_employees.length === 2,
    'เรียก ' + asB.length + ' ครั้ง');
  chk('B. ประวัติ NO_SHIFT ไม่ถูกลบเมื่อกลับเข้ากะ',
    HIST.filter(h => h.status === 'NO_SHIFT' && h.effective_date === '2026-08-20').length === 2 &&
    HIST.filter(h => h.status === 'ACTIVE' && h.effective_date === '2026-08-21').length === 2,
    'history=' + HIST.length);

  /* ---------- C. UNASSIGNED → NO_SHIFT ---------- */
  calls.length = 0;
  await pg.click('#shu-all');
  await pg.selectOption('#shu-to', '__NO_SHIFT__');
  await pg.fill('#shu-date', '2026-08-22');
  await pg.click('#shu-go');
  await pg.waitForSelector('#cf-yes', { timeout: 5000 });
  await pg.click('#cf-yes');
  await pg.waitForTimeout(900);
  const nsC = calls.filter(c => c.fn === 'njhr_shift_no_shift_set');
  chk('C. ยังไม่ได้กำหนดกะ→ไม่มีกะ ใช้ RPC เดียวกัน',
    nsC.length === 1 && nsC[0].body.p_on === true && nsC[0].body.p_employees.length === 2,
    'เรียก ' + nsC.length + ' ครั้ง');
  chk('C. Dropdown หลักไม่มีปุ่ม “ตั้งเป็นไม่ใช้กะ” แยกซ้ำ', await pg.evaluate(() =>
    !document.getElementById('shu-ns') && !!document.getElementById('shu-go')));

  /* ---------- D. NO_SHIFT → ACTIVE กลับเข้ากะปกติ ---------- */
  calls.length = 0;
  if (!(await pg.$('#shn-list'))) await pg.click('#shn-toggle');
  await pg.waitForSelector('#shn-list .shn-pick', { timeout: 8000 });
  await pg.click('#shn-all');
  await pg.selectOption('#shn-to', 'sh-1');
  await pg.fill('#shn-date', '2026-08-23');
  await pg.click('#shn-move');
  await pg.waitForSelector('#cf-yes', { timeout: 5000 });
  await pg.click('#cf-yes');
  await pg.waitForTimeout(900);
  chk('D. กลับจากไม่มีกะเข้ากะได้จริงด้วย Batch Assign',
    calls.filter(c => c.fn === 'njhr_shift_assign_many').length === 1);

  /* ---------- E. ACTIVE → ACTIVE (กะเดิม → กะใหม่) ---------- */
  calls.length = 0;
  await pg.click('.sh-card [data-more="sh-1"]');
  await pg.click('.sh-pop [data-emp="sh-1"]');
  await pg.waitForSelector('#shl-list .shl-pick', { timeout: 8000 });
  await pg.check('#shl-list .sh-emp-row:nth-child(1) .shl-pick');
  await pg.selectOption('#shl-to', 'sh-2');
  await pg.fill('#shl-date', '2026-08-24');
  await pg.click('#shl-move');
  await pg.waitForSelector('#cf-yes', { timeout: 5000 });
  const cfE = await pg.textContent('.confirm-msg');
  chk('E. กะเดิม→กะใหม่ Confirm สรุปต้นทาง/ปลายทางครั้งเดียว',
    /ปัจจุบันอยู่กะ/.test(cfE) && /ดึก/.test(cfE), cfE.slice(0, 100));
  await pg.click('#cf-yes');
  await pg.waitForTimeout(900);
  chk('E. กะเดิม→กะใหม่ใช้ njhr_shift_assign_many ครั้งเดียว',
    calls.filter(c => c.fn === 'njhr_shift_assign_many').length === 1);

  /* ---------- Mobile ---------- */
  for (const w of [360, 390, 768]) {
    const m = await newCtx(w, 800);
    await openShifts(m);
    const hs = await m.evaluate(() =>
      document.documentElement.scrollWidth - document.documentElement.clientWidth);
    await m.click('.sh-card [data-more="sh-1"]');
    await m.click('.sh-pop [data-emp="sh-1"]');
    await m.waitForSelector('#modal-root .modal-body', { timeout: 8000 });
    const fit = await m.evaluate(() => {
      const md = document.querySelector('#modal-root .modal');
      const r = md.getBoundingClientRect();
      return { l: Math.round(r.left), rr: Math.round(r.right),
        vw: document.documentElement.clientWidth,
        hs2: document.documentElement.scrollWidth - document.documentElement.clientWidth };
    });
    chk('Mobile ' + w + 'px: ไม่มี Horizontal Scroll · Modal ไม่ล้นจอ',
      hs <= 0 && fit.l >= -1 && fit.rr <= fit.vw + 1 && fit.hs2 <= 0,
      'page ' + hs + ' · modal ' + fit.l + '→' + fit.rr + '/' + fit.vw);
    await m.context().close();
  }

  chk('ไม่มี JavaScript Error', errs.length === 0, errs.slice(0, 2).join(' | '));

  await b.close(); srv.close();
  console.log('\nPASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
})();
