# RACE3_TEST — ผลทดสอบ Race Condition / Stale Binding 3 จุด

รัน: `node harness/race3_test.js .`  ·  โหลด chunk ที่ build แล้วจริงลง jsdom
stub เฉพาะ `NJHR.compat.scope` ตามสัญญาเดิม · **ไม่แตะ Supabase จริง ไม่แตะข้อมูล Production**

| # | เคส | ก่อนแก้ `e6a0d165` | หลังแก้ `6f9743ab` | หลักฐาน (หลังแก้) |
|---|---|---|---|---|
| 1 | R1 · รายชื่อโหลดเสร็จแล้ว → Modal แสดงรหัส + ชื่อถูกคน | FAIL | **PASS** | confirm-msg">NJ0002 — พนักงาน ทดสอบ2 |
| 2 | R1 · ใช้ cache จากรายชื่อ ไม่ยิง njhr_emp_get เพิ่ม | PASS | **PASS** | njhr_emp_get ก่อน=0 หลัง=0 |
| 3 | R1 · สถานะปัจจุบันถูกเลือกไว้ถูกต้อง | FAIL | **PASS** | ACTIVE selected |
| 4 | R2 · กดเปลี่ยนสถานะก่อนรายชื่อโหลดเสร็จ → ยังได้ชื่อถูกคน | FAIL | **PASS** | confirm-msg">NJ0003 — พนักงาน ทดสอบ3 |
| 5 | R2 · ใช้ RPC เดิม njhr_emp_get ไม่สร้าง RPC ใหม่ | FAIL | **PASS** | calls=njhr_emp_departments,njhr_emp_list,njhr_emp_get |
| 6 | R3 · ไม่เคยโหลดรายชื่อเลย → Modal ยังแสดงชื่อครบ | FAIL | **PASS** | พบ NJ0001 |
| 7 | R4 · เลือก "พ้นสภาพ" → ช่องวันที่พ้นสภาพโผล่เหมือนเดิม | PASS | **PASS** | display="" |
| 8 | R4 · กดบันทึก → เรียก njhr_emp_status เหมือนเดิม | PASS | **PASS** | calls=njhr_emp_departments,njhr_emp_list,njhr_emp_status,njhr_emp_departments,njhr_emp_list |
| 9 | R5 · NJHR.compat.scope.empRows สะท้อนข้อมูลหลังโหลดเสร็จ | FAIL | **PASS** | length=3 |
| 10 | L1 · เปิดฟอร์มโดยยังไม่เคยโหลดสิทธิ์ → แสดงคงเหลือจริง | FAIL | **PASS** | ลาป่วย (คงเหลือ 28 วัน) / ลากิจ (คงเหลือ 9 วัน) / ลาพักร้อน (คงเหลือ 6 วัน) / ลาคลอด (ไม่จำกัด) |
| 11 | L1 · ประเภทที่ไม่มีโควตา ยังแสดง "ไม่จำกัด" เหมือนเดิม | PASS | **PASS** | ลาคลอด (ไม่จำกัด) |
| 12 | L1 · ยิง njhr_leave_balances 1 ครั้ง | FAIL | **PASS** | เรียก 1 ครั้ง |
| 13 | L2 · กด "ขอลางาน" ทันทีหลัง Refresh → สิทธิ์ลาขึ้นถูกต้อง | FAIL | **PASS** | ลากิจ (คงเหลือ 9 วัน) |
| 14 | L3 · กด "ขอลางาน" ซ้ำ 3 ครั้งรวด → ยิง njhr_leave_balances ครั้งเดียว | FAIL | **PASS** | เรียก 1 ครั้ง |
| 15 | L4 · โหลดสิทธิ์ลาไม่สำเร็จ → ไม่เปิดฟอร์ม | FAIL | **PASS** | ไม่เปิดฟอร์ม |
| 16 | L4 · แจ้งข้อความชัดเจน + เป็น error | FAIL | **PASS** | โหลดสิทธิ์การลาไม่สำเร็จ กรุณาลองใหม่ |
| 17 | L5 · NJHR.compat.scope.lvBal สะท้อนข้อมูลหลังโหลดเสร็จ | FAIL | **PASS** | keys=SICK,PERSONAL,VACATION,MATERNITY |
| 18 | D1 · ยืนยันลำดับจริง: njhrBootOnce() อยู่ "ก่อน" จุด publish db | PASS | **PASS** | bootOnce@60922 · publish db@62837 |
| 19 | D2 · loadDB() ไม่ผูกตัวแปร db ใหม่ (ใช้ dbReplace แทน) | FAIL | **PASS** | loadDB() ใช้ dbReplace() · ไม่มี db= ในตัวฟังก์ชัน |
| 20 | D3 · dbReplace() ลบ key ที่หายไปและใส่ key ใหม่ลง object ตัวเดิม | FAIL | **PASS** | มีทั้ง delete และ assign |
| 21 | D4 · db ถูกประกาศเป็น object ตั้งแต่ต้น (ไม่มีช่วง undefined) | FAIL | **PASS** | var db={} |
| 22 | D5 · โครงข้อมูล emptyDB() ครบ 17 key เหมือนเดิม | PASS | **PASS** | ตรวจครบทุก key |
| 23 | D6 · loadDB() ถูกเรียกจุดเดียวใน bundle (นับรวมนิยามฟังก์ชัน) | PASS | **PASS** | พบ loadDB() 2 แห่ง (นิยาม 1 + เรียก 1) |

**ก่อนแก้: PASS 7 · FAIL 16**

**หลังแก้: PASS 23 · FAIL 0**
