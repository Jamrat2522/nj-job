/* dash_rpc_test.js — ตรวจว่าหน้า Dashboard วาดเฉพาะฝั่งที่ผู้ใช้เห็นจริง
     ปัญหาเดิม: viewDashboard() เรียกทั้ง Desktop และ Mobile เสมอ
                ฝั่งที่ถูกซ่อนด้วย CSS ก็ยังยิง RPC ครบทุกตัว

   หมายเหตุเรื่องวิธีตรวจ
     การนับ RPC จริงต้องมี Session จริงและข้อมูลจริงจาก Supabase
     เครื่องทดสอบไม่มีทั้งสองอย่าง ตัวโหลดหลายตัวจึงไม่ทำงานให้นับได้
     เทสนี้จึงตรวจ "โครงสร้างการกั้น" ซึ่งพิสูจน์ได้จริงจาก Source
     ตัวเลข RPC ก่อน/หลัง ต้องวัดบนเบราว์เซอร์จริง — ยังไม่ได้ทำ

   ใช้: node harness/dash_rpc_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(56) + (d || '')); }

const src = fs.readFileSync(path.join(ROOT, 'src/07-view-dashboard.js'), 'utf8');
const out = fs.readFileSync(path.join(ROOT, 'views/dashboard.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8');

/* ---------- 1. เส้นแบ่งต้องตรงกับ CSS ---------- */
console.log('\n== เส้นแบ่ง Desktop / Mobile ==');
chk('CSS สลับ .only-desktop/.only-mobile ที่ 900px',
  css.replace(/\s+/g, '').indexOf('@mediascreenand(max-width:900px)') >= 0, '');
chk('JS ใช้เส้นเดียวกัน (max-width: 900px)',
  /matchMedia\(['"]\(max-width:\s*900px\)['"]\)/.test(src), '');
chk('มีทางสำรองเมื่อเบราว์เซอร์ไม่มี matchMedia',
  /innerWidth[^;]*<=\s*900/.test(src), '');

/* ---------- 2. วาดฝั่งเดียวเท่านั้น ---------- */
console.log('\n== วาดเฉพาะฝั่งที่ผู้ใช้เห็น ==');
const vd = src.slice(src.indexOf('function viewDashboard(el)'),
  src.indexOf('function dashBindResize'));
chk('viewDashboard เลือกฝั่งด้วย dashIsMobile()', vd.indexOf('dashIsMobile()') >= 0, '');
chk('มือถือ → เรียกเฉพาะ dashMobileHome',
  /if \(mob\) \{[\s\S]{0,200}dashMobileHome\(el\);[\s\S]{0,20}\} else/.test(vd), '');
chk('Desktop → เรียกเฉพาะ dashAdmin / dashEmployee',
  /\} else \{[\s\S]{0,120}dashEmployee\(el\)[\s\S]{0,60}dashAdmin\(el\)/.test(vd), '');
chk('ไม่มีการเรียก dashMobileHome นอกบล็อกมือถือ',
  (vd.match(/dashMobileHome\(el\)/g) || []).length === 1, '');
chk('ไม่มีการเรียก dashAdmin/dashEmployee นอกบล็อก Desktop',
  (vd.match(/dashAdmin\(el\)/g) || []).length === 1 &&
  (vd.match(/dashEmployee\(el\)/g) || []).length === 1, '');

/* ---------- 3. Role และหน้าตาไม่เปลี่ยน ---------- */
console.log('\n== สิทธิ์และหน้าตาไม่เปลี่ยน ==');
chk('USER ไปหน้าพนักงาน · Role อื่นไปหน้าผู้ดูแล (เงื่อนไขเดิม)',
  /if \(u\.role === 'USER'\) dashEmployee\(el\); else dashAdmin\(el\);/.test(vd), '');
chk('ฟังก์ชันวาดทั้งสามตัวยังอยู่ครบ',
  src.indexOf('function dashAdmin(') >= 0 &&
  src.indexOf('function dashEmployee(') >= 0 &&
  src.indexOf('function dashMobileHome(') >= 0, '');
chk('ไม่ตัด dashMobileFeed ทิ้ง', src.indexOf('function dashMobileFeed(') >= 0, '');
chk('ไม่แก้โครง HTML การ์ด KPI',
  src.indexOf('rp-kpi') >= 0 && src.indexOf('DASH_KPI') >= 0, '');
const RPCS = ['njhr_dashboard_summary', 'njhr_notify_list', 'njhr_leave_list',
  'njhr_leave_balances', 'njhr_att_today', 'njhr_me_get', 'njhr_ann_feed',
  'njhr_ot_list', 'njhr_att_report', 'njhr_att_correction_list', 'njhr_leave_report'];
chk('รายการ RPC ที่แต่ละฝั่งใช้ ยังครบเหมือนเดิม',
  RPCS.every(function (r) { return src.indexOf(r) >= 0; }), RPCS.length + ' ตัว');

/* ---------- 4. ย่อ/ขยายหน้าต่างต้องไม่เห็นหน้าว่าง ---------- */
console.log('\n== ย่อ/ขยายหน้าต่างข้ามเส้น 900px ==');
chk('มีการวาดใหม่เมื่อข้ามเส้น', src.indexOf("addEventListener('resize'") >= 0, '');
chk('วาดใหม่เฉพาะเมื่อข้ามเส้นจริง ไม่ใช่ทุก resize',
  /if \(now === dashLastMobile\) return;/.test(src), '');
chk('วาดใหม่เฉพาะตอนอยู่หน้า Dashboard',
  /currentRoute !== '#\/dashboard'/.test(src), '');
chk('หน่วงเวลา กันวาดรัวตอนลากหน้าต่าง', /clearTimeout\(t\)/.test(src), '');
chk('ผูก Listener ครั้งเดียว ไม่สะสมซ้ำ',
  /if \(dashResizeBound\) \{[\s\S]{0,90}return;/.test(src), '');

/* ---------- 5. ไฟล์ที่เว็บใช้จริง ---------- */
console.log('\n== ไฟล์ที่ build แล้ว ==');
chk('views/dashboard.js มี dashIsMobile', out.indexOf('dashIsMobile') >= 0, '');
chk('views/dashboard.js มีตัวจัด resize', out.indexOf('dashResizeBound') >= 0, '');
chk('ยังลงทะเบียน viewDashboard เหมือนเดิม',
  out.indexOf('register("viewDashboard"') >= 0 ||
  out.indexOf("register('viewDashboard'") >= 0, '');

console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
console.log('NOT TESTED: จำนวน RPC จริงบนเบราว์เซอร์ — ต้องวัดด้วย DevTools Network');
process.exit(FAIL ? 1 : 0);
