/* browser.js — ตัวช่วยหาเบราว์เซอร์และรากโปรเจกต์แบบ Portable
   ใช้ร่วมกันโดยชุดทดสอบที่ต้องเปิด Chromium ผ่าน Playwright

   ลำดับการเลือกเบราว์เซอร์
     1. ตัวแปรแวดล้อม NJHR_CHROME (ถ้าตั้งไว้และไฟล์มีอยู่จริง)
     2. Chromium ที่ Playwright ติดตั้งเอง (ค่าเริ่มต้น — ไม่ต้องระบุ path)
     3. Chrome/Chromium ของระบบตามพาธมาตรฐานของแต่ละ OS

   ไม่มีพาธเฉพาะเครื่องใดฝังไว้ในไฟล์ทดสอบอีกต่อไป
   ใช้: const { launchOpts, projectRoot } = require('./browser.js'); */
'use strict';
const fs = require('fs');
const path = require('path');

/* พาธมาตรฐานของ Chrome/Chromium ที่พบได้ทั่วไป — ใช้เป็นทางเลือกสุดท้ายเท่านั้น */
const SYSTEM_PATHS = [
  '/usr/bin/google-chrome',
  '/usr/bin/google-chrome-stable',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
  '/opt/google/chrome/chrome',
  '/snap/bin/chromium',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'
];

function findBrowser() {
  const env = process.env.NJHR_CHROME;
  if (env && fs.existsSync(env)) return env;
  for (let i = 0; i < SYSTEM_PATHS.length; i++) {
    try { if (fs.existsSync(SYSTEM_PATHS[i])) return SYSTEM_PATHS[i]; } catch (e) { /* ข้าม */ }
  }
  return null;                       // ให้ Playwright ใช้ Chromium ของตัวเอง
}

/* ตัวเลือกสำหรับ chromium.launch() — ไม่ใส่ executablePath ถ้าไม่จำเป็น */
function launchOpts(extra) {
  const o = Object.assign({ args: ['--no-sandbox'] }, extra || {});
  const exe = findBrowser();
  if (exe) o.executablePath = exe;
  return o;
}

/* รากโปรเจกต์ = โฟลเดอร์แม่ของ harness/ — ไม่ผูกกับ cwd หรือเครื่องใด */
function projectRoot(argvPath) {
  return path.resolve(argvPath || path.join(__dirname, '..'));
}

module.exports = { findBrowser, launchOpts, projectRoot, SYSTEM_PATHS };
