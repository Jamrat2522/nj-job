/* hrdoc_date_test.js — ตรวจช่องวันที่ "ตั้งแต่ / ถึง" ของหน้าเอกสาร HR
     · Desktop = 1 แถว (ป้าย + วันที่ + ไอคอนปฏิทิน อยู่บรรทัดเดียว)
     · ทั้งสองช่องกว้างและสูงเท่ากัน
     · Scope เฉพาะ .doc-filters — ช่องวันที่หน้าอื่นต้องไม่ถูกแตะ
     · ไม่แก้ Logic / DOM / มือถือ
   ใช้: node harness/hrdoc_date_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(60) + (d || '')); }

const mcss = fs.readFileSync(path.join(ROOT, 'mobile.css'), 'utf8');
const scss = fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8');
const min = mcss.replace(/\s+/g, '');
const sMin = scss.replace(/\s+/g, '');
const docJs = fs.readFileSync(path.join(ROOT, 'views/profile/main.js'), 'utf8');

/* ---- ตัดบล็อก @media (min-width:1024px) ที่มีกฎ .doc-filters ---- */
function block(prefix) {
  let i = -1;
  while ((i = min.indexOf(prefix, i + 1)) >= 0) {
    let d = 1, j = i + prefix.length;
    for (; j < min.length && d > 0; j++) {
      if (min[j] === '{') d++;
      else if (min[j] === '}') d--;
    }
    const body = min.slice(i + prefix.length, j - 1);
    if (body.indexOf('.doc-dt') >= 0) return body;
  }
  return '';
}
const DESK = block('@media(min-width:1024px){');
const NARROW = block('@media(min-width:1024px)and(max-width:1450px){');

/* ================= 1. ต้นเหตุ: .field บังคับ column ================= */
console.log('\n== ต้นเหตุเดิม ==');
chk('.field ยังเป็น flex-direction: column (ของกลาง ไม่แตะ)',
  sMin.indexOf('.field{display:flex;flex-direction:column') >= 0, '');
chk('.doc-dt ใช้ class .field ร่วมด้วยจริง', docJs.indexOf('field doc-dt') >= 0, '');

/* ================= 2. Desktop = 1 แถว ================= */
console.log('\n== Desktop: บรรทัดเดียว ==');
chk('มีบล็อก Desktop สำหรับ .doc-dt', DESK.length > 0, DESK.length + ' อักขระ');
chk('ตั้ง flex-direction: row (ทับ column ของ .field)',
  /\.doc-filters\.doc-dt\{[^}]*flex-direction:row/.test(DESK), '');
chk('ตั้ง display: flex', /\.doc-filters\.doc-dt\{display:flex/.test(DESK), '');
chk('จัดกึ่งกลางแนวตั้ง (align-items: center)',
  /\.doc-filters\.doc-dt\{[^}]*align-items:center/.test(DESK), '');
chk('ห้ามตกบรรทัด (flex-wrap: nowrap)',
  /\.doc-filters\.doc-dt\{[^}]*flex-wrap:nowrap/.test(DESK), '');
chk('ข้อความไม่ตัดบรรทัด (white-space: nowrap)',
  /\.doc-filters\.doc-dt\{[^}]*white-space:nowrap/.test(DESK), '');
chk('ป้าย "ตั้งแต่/ถึง" ไม่ตัดบรรทัดและไม่หด',
  /\.doc-dt-lbl\{[^}]*white-space:nowrap/.test(DESK) &&
  /\.doc-dt-lbl\{[^}]*flex:00auto/.test(DESK), '');
chk('ช่องวันที่ยืดเต็มพื้นที่ที่เหลือ (ไอคอนปฏิทินชิดขวา)',
  /\.doc-filters\.doc-dtinput\{[^}]*flex:11auto/.test(DESK), '');
chk('ช่องวันที่ไม่ตั้ง width คงที่แล้ว (ปล่อยให้ยืด)',
  /\.doc-filters\.doc-dtinput\{[^}]*width:auto/.test(DESK), '');
chk('กัน overflow ด้วย min-width: 0',
  /\.doc-filters\.doc-dtinput\{[^}]*min-width:0/.test(DESK), '');

/* ================= 3. สองช่องเท่ากัน ================= */
console.log('\n== สองช่องเท่ากัน ==');
const w = /\.doc-filters\.doc-dt\{[^}]*width:(\d+)px/.exec(DESK);
chk('กำหนดความกว้างคงที่ให้ทั้งสองช่องเท่ากัน', !!w, w ? w[1] + 'px' : 'ไม่มี');
chk('ความสูงเท่ากัน 40px', /\.doc-filters\.doc-dt\{[^}]*height:40px/.test(DESK), '');
chk('ความสูงเท่ากับ select และปุ่มในแถบเดียวกัน',
  /\.doc-filtersselect\{height:40px/.test(DESK) && /\.doc-filters\.btn\{height:40px/.test(DESK), '');
const wn = /\.doc-filters\.doc-dt\{[^}]*width:(\d+)px/.exec(NARROW);
chk('จอแคบ (≤1450px) ก็ยังกว้างเท่ากันทั้งสองช่อง', !!wn, wn ? wn[1] + 'px' : 'ไม่มี');
chk('จอแคบย่อความกว้างลงจริง', !!w && !!wn && +wn[1] < +w[1],
  (wn ? wn[1] : '?') + ' < ' + (w ? w[1] : '?'));

/* ================= 4. คงสไตล์เดิม ================= */
console.log('\n== คงสไตล์เดิม ==');
chk('คง Border เดิม', /\.doc-filters\.doc-dt\{[^}]*border:1pxsolidvar\(--line/.test(DESK), '');
chk('คง Border Radius เดิม (10px)', /\.doc-filters\.doc-dt\{[^}]*border-radius:10px/.test(DESK), '');
chk('คงพื้นหลังขาวเดิม', /\.doc-filters\.doc-dt\{[^}]*background:#fff/.test(DESK), '');
chk('คง Font ของช่องวันที่เดิม',
  /\.doc-filters\.doc-dtinput\{[^}]*font-family:inherit/.test(DESK), '');
chk('คงสีป้ายเดิม', /\.doc-dt-lbl\{font-size:12\.5px;color:var\(--ink-2/.test(DESK), '');

/* ================= 5. ไม่กระทบหน้าอื่น ================= */
console.log('\n== ไม่กระทบช่องวันที่หน้าอื่น ==');
/* ทุกกฎที่แตะ .doc-dt ต้องมี .doc-filters นำหน้าเสมอ */
const rules = (mcss + scss).split('}').filter(r => r.indexOf('.doc-dt') >= 0);
const unscoped = rules.filter(r => {
  const sel = r.split('{')[0];
  return sel.indexOf('.doc-dt') >= 0 && sel.indexOf('.doc-filters') < 0;
});
chk('ทุกกฎของ .doc-dt ถูก scope ใต้ .doc-filters', unscoped.length === 0,
  unscoped.slice(0, 2).join(' | ').trim());
chk('ไม่แก้ .field ของกลาง', sMin.indexOf('.field{display:flex;flex-direction:column;gap:5px') >= 0, '');
/* ช่องวันที่ของหน้าอื่นยังใช้กฎเดิม */
[['หน้ารายงาน', 'rpt-filters'], ['หน้ารายงานทั้งหมด', 'rp-f'],
 ['หน้ารายงานการลา/โอที', 'rptm-f']].forEach(function (x) {
  chk(x[0] + ' · ไม่มีกฎ .doc-dt ปน', (mcss + scss).indexOf('.' + x[1] + ' .doc-dt') < 0, '');
});
chk('styles.css ไม่ถูกแก้ในรอบนี้ (กฎ .doc-dt เดิมยังอยู่)',
  sMin.indexOf('.doc-filters.doc-dt{margin-bottom:0}') >= 0, '');

/* ================= 6. ไม่แตะ Logic / DOM / มือถือ ================= */
console.log('\n== ไม่แตะ Logic ==');
chk('DOM ยังเป็น label.field.doc-dt เหมือนเดิม',
  docJs.indexOf('field doc-dt') >= 0 && docJs.indexOf('doc-dt-lbl') >= 0, '');
chk('ยังใช้ input type=date ตัวเดิม',
  docJs.indexOf('doc-from') >= 0 && docJs.indexOf('doc-to') >= 0, '');
['doc-q', 'doc-ftype', 'doc-fstatus', 'doc-clear'].forEach(function (id) {
  chk('ตัวกรอง ' + id + ' ยังอยู่ครบ', docJs.indexOf(id) >= 0, '');
});
chk('กฎทั้งหมดอยู่ใน @media (min-width: 1024px) — มือถือไม่กระทบ',
  min.indexOf('.doc-filters.doc-dt{display:flex;flex-direction:row') >
  min.indexOf('@media(min-width:1024px){'), '');
chk('ไม่มีกฎ .doc-dt นอก @media ใน mobile.css',
  min.split('@media')[0].indexOf('.doc-dt') < 0, '');

console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
process.exit(FAIL ? 1 : 0);
