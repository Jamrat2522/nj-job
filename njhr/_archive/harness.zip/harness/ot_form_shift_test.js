/* ot_form_shift_test.js — ตรวจว่าแถบ "กะทำงานของคุณ" ถูกถอดออกจากหน้า "ขอ OT" แล้ว
   แต่ Logic ของกะยังทำงานครบเหมือนเดิม
     · ค่าเริ่มต้นช่อง "เวลาเริ่ม" = เวลาเลิกงานของกะ
     · คำเตือนเมื่อเวลา OT ซ้อนกับเวลาทำงานปกติของกะ
     · ลำดับบล็อกเป็น ข้อมูลผู้ยื่นคำขอ → ข้อมูล OT → รายการงาน OT
   ใช้: node harness/ot_form_shift_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(58) + (d || '')); }
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
  .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const tick = ms => new Promise(r => setTimeout(r, ms || 40));

/* กะปกติ 08:30–17:30 — เวลาเลิกงาน 17:30 ใช้เป็นค่าเริ่มต้นของ "เวลาเริ่ม" OT */
const SHIFT = { name: 'กะปกติ', start: '08:30', end: '17:30', overnight: false };

function env() {
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div><div id="modal-root"></div></body></html>');
  const win = dom.window;
  let modalBody = '';
  const NJHR = {
    state: { currentRoute: '#/ot' }, router: { navId: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    features: {}, views: { register: () => {} }, compat: { scope: {} }
  };
  Object.assign(NJHR.compat.scope, {
    icon: (n, c) => '<span class="ic ' + (c || '') + '" data-i="' + (n || '') + '"></span>',
    esc, debounce: f => f, avatarHTML: () => '<span class="avatar"></span>',
    emptyState: m => '<div class="empty">' + m + '</div>',
    fmtDate: d => String(d || ''), fmtDateDMY: v => String(v || ''),
    todayISO: () => '2026-08-12', nowStamp: () => '2026-08-12 12:21',
    statusBadge: s => '<span class="badge">' + s + '</span>',
    currentUser: () => ({ id: 'u1', username: 'admin', role: 'SUPER_ADMIN', empId: 'e1' }),
    currentEmp: () => ({ id: 'e1', code: '0001', title: 'นาย', firstName: 'จำรัส',
      lastName: 'ผาเทพ', position: '-', deptId: 'd1', shift: '08:30-17:30' }),
    emp: () => null, empName: () => 'นายจำรัส ผาเทพ', dept: () => '—',
    db: { ots: [], employees: [], shifts: [] }, saveDB: () => {}, uid: p => p + '-x',
    audit: () => {}, toast: () => {}, notify: () => {}, notifyApprovers: () => {},
    sbReady: () => true, sbToken: () => 'tok',
    sbRpc: () => Promise.resolve({}), sbRpcList: () => Promise.resolve([]),
    openModal: (t, b, f) => {
      modalBody = b;
      win.document.getElementById('modal-root').innerHTML =
        '<div class="modal-head"><h3>' + t + '</h3></div><div class="modal-body">' + b +
        '</div><div class="modal-foot">' + (f || '') + '</div>';
    },
    closeModal: () => { win.document.getElementById('modal-root').innerHTML = ''; },
    confirmDialog: (t, m, ok, fn) => fn(),
    /* ข้อมูลกะ — คงไว้ครบ ไม่ได้ลบ Logic */
    shOf: () => SHIFT,
    shTime: sh => sh.start + '–' + sh.end,
    otSpan: () => null, otJobsOf: o => (o.jobs || []),
    /* stub สำหรับหน้า "ขอลางาน" */
    LEAVE_TYPES: [{ code: 'SICK', name: 'ลาป่วย', needDoc: false },
                  { code: 'BUSINESS', name: 'ลากิจ', needDoc: false }],
    lvType: c => ({ SICK: { name: 'ลาป่วย' }, BUSINESS: { name: 'ลากิจ' } }[c] || { name: c }),
    lvNum: v => Number(v) || 0, lvCode: x => String(x || ''),
    lvModeTxt: m => m, lvMode: () => 'FULL',
    refreshLeavePending: () => {}, isHoliday: () => false, holName: () => '',
    lvAttachUpload: () => Promise.resolve({}), lvAttachDelete: () => Promise.resolve({}),
    remainDays: () => 0, balance: () => ({ used: 0 }), round2: v => v,
    isWeekend: () => false, businessDays: () => 1, hoursDiff: () => 3,
    sbUploadLeaveFile: () => Promise.resolve({}), lvBal: {},
    OT_JOB_TYPES: ['ตรวจปล่อย', 'คีย์ใบขน', 'คีย์ + ตรวจปล่อย'],
    otAttachUpload: () => Promise.resolve({}), otAttachDelete: () => Promise.resolve({}),
    refreshOtPending: () => {}, viewOT: () => {}
  });
  win.NJHR = NJHR;
  win.URL.createObjectURL = () => 'blob:x';
  win.URL.revokeObjectURL = () => {};
  const ctx = vm.createContext(win);
  return { win, NJHR, ctx,
    run: rel => vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), ctx, { filename: rel }),
    host: () => win.document.getElementById('app'),
    doc: () => win.document,
    body: () => modalBody };
}

async function run() {
  console.log('\n== หน้า "ขอ OT" — แถบข้อมูลกะ ==');
  const E = env();
  E.run('runtime/shared/requests.js');
  E.run('views/ot/form.js');
  chk('chunk เปิดใช้งาน NJHR.features.otForm',
    !!(E.NJHR.features.otForm && typeof E.NJHR.features.otForm.open === 'function'), '');
  if (!E.NJHR.features.otForm) return finish();

  E.NJHR.features.otForm.open(E.host());
  await tick(60);
  const doc = E.doc();
  const modal = doc.getElementById('modal-root');
  const txt = modal.textContent;

  /* ---------- แถบกะต้องหายจาก UI ---------- */
  chk('ไม่มีข้อความ "กะทำงานของคุณ"', txt.indexOf('กะทำงานของคุณ') < 0, '');
  chk('ไม่มีข้อความ "เลิกงาน" บนหน้าฟอร์ม', txt.indexOf('เลิกงาน') < 0, '');
  chk('ไม่มี element .ot-shift-info เหลือค้าง',
    modal.querySelector('.ot-shift-info') === null, '');
  chk('ไม่มีชื่อกะ "กะปกติ" โผล่ในฟอร์ม', txt.indexOf('กะปกติ') < 0, '');

  /* ---------- ลำดับบล็อกถูกต้อง ไม่มีช่องว่างค้าง ---------- */
  const info = modal.querySelector('.ot-req-info');
  chk('ยังมีบล็อกข้อมูลผู้ยื่นคำขอ', !!info, '');
  if (info) {
    const next = info.nextElementSibling;
    chk('ถัดจากข้อมูลผู้ยื่นคำขอคือ "ข้อมูล OT" ทันที (ไม่มี element คั่น)',
      !!next && next.classList.contains('otj-head') && next.textContent.trim() === 'ข้อมูล OT',
      next ? next.className + ' · ' + next.textContent.trim() : 'ไม่มี');
  }
  const heads = Array.from(modal.querySelectorAll('.otj-head')).map(x => x.textContent.trim());
  chk('ลำดับหัวข้อ: ข้อมูล OT → รายการงาน OT',
    heads[0] === 'ข้อมูล OT' && heads.some(h => h.indexOf('รายการงาน OT') >= 0),
    heads.join(' → '));

  /* ---------- Logic ของกะยังอยู่ครบ ---------- */
  const start = doc.getElementById('otf-start');
  chk('ค่าเริ่มต้น "เวลาเริ่ม" = เวลาเลิกงานของกะ (17:30)',
    start && start.value === '17:30', start ? start.value : 'ไม่มีช่อง');
  const end = doc.getElementById('otf-end');
  chk('ช่อง "เวลาสิ้นสุด" ยังอยู่', !!end, end ? end.value : '');
  chk('ช่อง "วันที่" ยังอยู่', !!doc.getElementById('otf-date'), '');
  chk('ช่อง "สิ้นสุดวัน" ยังอยู่', !!doc.getElementById('otf-next'), '');
  chk('ช่อง "จำนวนชั่วโมง" ยังอยู่', !!doc.getElementById('otf-hours'),
    (doc.getElementById('otf-hours') || {}).value || '');

  /* คำเตือนเวลาซ้อนกะ — ตั้งเวลาเริ่มเป็น 10:00 ซึ่งอยู่ในช่วง 08:30–17:30 */
  if (start) {
    start.value = '10:00';
    if (typeof start.oninput === 'function') start.oninput();
    if (typeof start.onchange === 'function') start.onchange();
    await tick(40);
    const warn = modal.querySelector('#otf-warn, .ot-warn');
    const wtxt = warn ? warn.textContent : '';
    chk('เวลาซ้อนกะ → ยังขึ้นคำเตือน (Logic กะไม่ถูกลบ)',
      wtxt.indexOf('ซ้อนกับเวลาทำงานปกติของกะ') >= 0, wtxt.trim() || 'ไม่มีคำเตือน');
    chk('คำเตือนยังอ้างช่วงเวลากะจริง (08:30–17:30)',
      wtxt.indexOf('08:30–17:30') >= 0, wtxt.trim());
  }

  /* ---------- ตรวจ Source ---------- */
  const src = fs.readFileSync(path.join(ROOT, 'views/ot/form.js'), 'utf8');
  chk('โค้ดไม่มี class ot-shift-info แล้ว', src.indexOf('ot-shift-info') < 0, '');
  chk('โค้ดยังเรียก shOf() เพื่อใช้ข้อมูลกะ', src.indexOf('shOf') >= 0, '');
  chk('โค้ดยังเรียก shTime() ในคำเตือน', src.indexOf('shTime') >= 0, '');
  const css = fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8');
  chk('CSS ไม่เหลือกฎ .ot-shift-info ที่ไม่ได้ใช้', css.indexOf('ot-shift-info') < 0, '');

  /* ================= แถบข้อมูลผู้ยื่นคำขอ — ทั้ง 2 หน้าต้องเหมือนกัน ================= */
  await testReqInfoBar();

  finish();
}

const EXPECT_LABELS = ['เลขที่คำขอ', 'วันที่ยื่น', 'ผู้ยื่น', 'รหัส', 'แผนก'];

function auditBar(label, modal, noId) {
  const bar = modal.querySelector('.ot-req-info');
  chk(label + ' · มีแถบข้อมูลผู้ยื่นคำขอ', !!bar, '');
  if (!bar) return null;
  const cells = Array.from(bar.children);
  chk(label + ' · มี 5 ช่องพอดี', cells.length === 5, cells.length + ' ช่อง');
  const labels = cells.map(c => (c.querySelector('small') || {}).textContent || '');
  chk(label + ' · ลำดับ Label ถูกต้อง',
    JSON.stringify(labels) === JSON.stringify(EXPECT_LABELS), labels.join(' | '));
  const vals = cells.map(c => (c.querySelector('b') || {}).textContent || '');
  chk(label + ' · ทุกช่องมี Label บน + Value ล่าง',
    cells.every(c => c.querySelector('small') && c.querySelector('b')), '');
  chk(label + ' · ก่อนบันทึก เลขที่คำขอแสดง —', vals[0] === '—', vals[0]);
  chk(label + ' · ไม่แสดง "ตำแหน่ง" ในส่วนหัว',
    labels.indexOf('ตำแหน่ง') < 0 && bar.textContent.indexOf('ตำแหน่ง') < 0, '');
  chk(label + ' · ไม่มีข้อความ "สร้างเมื่อบันทึกสำเร็จ" แล้ว',
    bar.textContent.indexOf('สร้างเมื่อบันทึกสำเร็จ') < 0, '');
  chk(label + ' · ช่องเลขที่คำขอมี id สำหรับเขียนทับหลังบันทึก (' + noId + ')',
    !!bar.querySelector('#' + noId), '');
  chk(label + ' · ไม่มี undefined / null บนแถบ',
    !/undefined|null/.test(bar.textContent), bar.textContent.replace(/\s+/g, ' ').trim());
  return { bar, labels, vals };
}

async function testReqInfoBar() {
  console.log('\n== แถบข้อมูลผู้ยื่นคำขอ: ขอ OT ==');
  const E1 = env();
  E1.run('runtime/shared/requests.js');
  E1.run('views/ot/form.js');
  E1.NJHR.features.otForm.open(E1.host());
  await tick(60);
  const r1 = auditBar('ขอ OT', E1.doc().getElementById('modal-root'), 'otf-no');
  if (r1) {
    chk('ขอ OT · วันที่ยื่นใช้ค่าจริงจาก nowStamp()', r1.vals[1] === '2026-08-12 12:21', r1.vals[1]);
    chk('ขอ OT · ผู้ยื่นใช้ชื่อจริงจาก currentEmp()', r1.vals[2] === 'นายจำรัส ผาเทพ', r1.vals[2]);
    chk('ขอ OT · รหัสใช้ค่าจริง', r1.vals[3] === '0001', r1.vals[3]);
    chk('ขอ OT · แผนกใช้ค่าจริง', r1.vals[4] === '—', r1.vals[4]);
  }
  /* หลังบันทึกสำเร็จ Flow เดิมเขียนทับเลขคำขอผ่าน id เดิม */
  const noEl = E1.doc().getElementById('otf-no');
  if (noEl) {
    noEl.textContent = '260812-0001';
    noEl.classList.remove('muted');
    chk('ขอ OT · เขียนทับเลขคำขอจริงได้ (Flow เดิมไม่เสีย)',
      E1.doc().getElementById('otf-no').textContent === '260812-0001', noEl.textContent);
  }

  console.log('\n== แถบข้อมูลผู้ยื่นคำขอ: ขอลางาน ==');
  const E2 = env();
  E2.run('runtime/shared/requests.js');
  E2.run('views/leave/main.js');
  E2.run('views/leave/form.js');
  chk('ขอลางาน · chunk เปิดใช้งาน NJHR.features.leaveForm',
    !!(E2.NJHR.features.leaveForm && typeof E2.NJHR.features.leaveForm.open === 'function'), '');
  if (E2.NJHR.features.leaveForm) {
    E2.NJHR.features.leaveForm.open(E2.host());
    await tick(80);
    const r2 = auditBar('ขอลางาน', E2.doc().getElementById('modal-root'), 'lvf-no');
    /* ---- สองหน้าต้องเป็นรูปแบบเดียวกันจริง ---- */
    if (r1 && r2) {
      chk('สองหน้าใช้ Label ชุดเดียวกัน',
        JSON.stringify(r1.labels) === JSON.stringify(r2.labels), r2.labels.join(' | '));
      chk('สองหน้าใช้จำนวนช่องเท่ากัน (5)',
        r1.bar.children.length === r2.bar.children.length, '');
      chk('สองหน้าใช้ class ชุดเดียวกัน',
        Array.from(r1.bar.children).map(c => c.className).join(',') ===
        Array.from(r2.bar.children).map(c => c.className).join(','),
        Array.from(r2.bar.children).map(c => c.className).join(','));
    }
  }

  /* ---- Source: ทั้งสองหน้าเรียกตัวสร้างแถบตัวเดียวกัน ---- */
  const otSrc = fs.readFileSync(path.join(ROOT, 'views/ot/form.js'), 'utf8');
  const lvSrc = fs.readFileSync(path.join(ROOT, 'views/leave/form.js'), 'utf8');
  chk('ขอ OT เรียก reqInfoBar()', otSrc.indexOf('reqInfoBar') >= 0, '');
  chk('ขอลางาน เรียก reqInfoBar()', lvSrc.indexOf('reqInfoBar') >= 0, '');
  chk('ไม่มี markup แถบซ้ำในหน้า OT', otSrc.indexOf('ri-dup') < 0, '');
  chk('ไม่มี markup แถบซ้ำในหน้าลางาน', lvSrc.indexOf('ri-dup') < 0, '');

  /* ---- CSS: Desktop 5 คอลัมน์ · Mobile ไหลได้ ---- */
  const css = fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8');
  /* CSS ถูก minify แล้ว ช่องว่างหายหมด จึงเทียบแบบไม่มีช่องว่าง */
  const cssMin = css.replace(/\s/g, '');
  chk('CSS Desktop กำหนด 5 คอลัมน์ในแถวเดียว',
    cssMin.indexOf('.ot-req-info{display:grid;grid-template-columns:18%20%24%12%26%') >= 0, '');
  chk('CSS Mobile ปรับเป็น 2 คอลัมน์',
    cssMin.indexOf('.ot-req-info{grid-template-columns:1fr1fr') >= 0, '');
  chk('CSS Mobile ให้ช่องแผนกกินเต็มแถวสุดท้าย',
    cssMin.indexOf('.ot-req-info.ri-dp{grid-column:1/-1}') >= 0, '');
  chk('CSS กัน overflow ไม่ให้ข้อความล้น',
    cssMin.indexOf('.ot-req-info>div{overflow:hidden') >= 0, '');
  const mcss = fs.readFileSync(path.join(ROOT, 'mobile.css'), 'utf8');
  chk('mobile.css ไม่เหลือกฎซ่อนช่อง .ri-dup', mcss.indexOf('ri-dup') < 0, '');
}

function finish() {
  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
}

run().catch(e => { console.error(e); process.exit(1); });
