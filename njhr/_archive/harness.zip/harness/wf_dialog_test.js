const { launchOpts } = require(require('path').join(__dirname, 'browser.js'));
/* wf_dialog_test.js — หน้าต่างตั้งค่าการอนุมัติ (Dialog) + บั๊กหัวการ์ดขั้นอนุมัติ
   ใช้: node harness/wf_dialog_test.js <ทางโปรเจกต์ absolute> <port> */
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const F = require(path.join(__dirname, 'fixtures.js'));

let PASS = 0, FAIL = 0;
const ROOT = process.argv[2] || process.cwd(), PORT = Number(process.argv[3] || 8990);
function chk(n, ok, e) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(58) + (e || '')); }

const WFS = [
  { workflow_id: 'wf-1', wf_name: 'ACCOUNT', request_type: 'BOTH', active: true,
    step_count: 3, approver_count: 3, scope: 'SELECTED', anchor_dept: 'ACCOUNT',
    departments: ['ACCOUNT', 'MAID'] },
  { workflow_id: 'wf-2', wf_name: 'CUSTOMER SERVICE EXPORT', request_type: 'BOTH', active: true,
    step_count: 3, approver_count: 4, scope: 'SELECTED', anchor_dept: 'CUSTOMER SERVICE EXPORT',
    departments: ['CUSTOMER SERVICE EXPORT'] }
];
const STEPS = [
  { step_id: 's1', step_no: 1, name: 'MANAGER', mode: 'ANY', active: true, cond_type: 'ALL',
    approvers: [{ employee_id: 'e1', emp_code: 'NJ001', name: 'จิทธ์ คนเทพ', position: 'MANAGER', department: 'ACCOUNT' }] },
  { step_id: 's2', step_no: 2, name: 'MANAGING DIRECTOR', mode: 'ANY', active: true, cond_type: 'ALL',
    approvers: [{ employee_id: 'e2', emp_code: 'NJ002', name: 'สุภัทร ศิริญาดา', position: 'MD', department: 'ACCOUNT' }] },
  { step_id: 's3', step_no: 3, name: 'MANAGEMENT', mode: 'ANY', active: true, cond_type: 'ALL',
    approvers: [{ employee_id: 'e3', emp_code: 'NJ003', name: 'จำลอง นาคเทพ', position: 'MGMT', department: 'ACCOUNT' }] }
];

function serve(root, port) {
  const T = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.png': 'image/png' };
  return new Promise(function (r) {
    const s = http.createServer(function (rq, rs) {
      let p = decodeURIComponent(rq.url.split('?')[0]); if (p === '/') p = '/index.html';
      const f = path.join(root, p);
      if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { rs.writeHead(404); return rs.end(); }
      rs.writeHead(200, { 'Content-Type': T[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
      rs.end(fs.readFileSync(f));
    }).listen(port, function () { r(s); });
  });
}

(async function () {
  const srv = await serve(ROOT, PORT);
  const b = await chromium.launch(launchOpts());
  const errs = [], fixtureErrs = [];
  const ctx = await b.newContext({ viewport: { width: 1440, height: 900 }, serviceWorkers: 'block' });
  await ctx.route('**/rest/v1/rpc/*', function (route) {
    const fn = route.request().url().split('/rpc/')[1].split('?')[0];
    let bd = {}; try { bd = JSON.parse(route.request().postData() || '{}'); } catch (e) {}
    let out;
    if (fn === 'njhr_wf_list') out = WFS;
    else if (fn === 'njhr_wf_steps') out = STEPS;
    else out = F.respond(fn, bd);
    route.fulfill({ status: 200, contentType: 'application/json',
      headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(out) });
  });
  await ctx.route('**/storage/v1/**', function (r) { r.fulfill({ status: 200, body: '{}' }); });
  const page = await ctx.newPage();
  page.on('pageerror', function (e) { errs.push('pageerror: ' + String(e.message)); });
  page.on('console', function (m) {
    const t = String(m.text());
    if (m.type() !== 'error') return;
    if (t.indexOf('403') >= 0 || t.indexOf('400') >= 0 || t.indexOf('404') >= 0) return;
    /* Mock fixture ไม่ได้ทำ RPC ของหน้า Dashboard — แยกออกจากผลของงานนี้ */
    if (/njhr_dashboard_summary|DASHBOARD/.test(t)) { fixtureErrs.push(t); return; }
    errs.push(t);
  });

  await page.goto('http://127.0.0.1:' + PORT + '/index.html', { waitUntil: 'load' });
  await page.waitForFunction(function () { return !!document.getElementById('lg-user'); }, { timeout: 15000 });
  await page.evaluate(function () {
    document.getElementById('lg-user').value = 'admin';
    document.getElementById('lg-pass').value = 'Admin1234';
    document.getElementById('login-form').onsubmit({ preventDefault: function () {} });
  });
  await page.waitForTimeout(2500);
  await page.evaluate(function () { location.hash = '#/approval-settings'; });
  await page.waitForFunction(function () { return document.querySelectorAll('.wf-set').length > 0; },
    { timeout: 25000 }).catch(function () {});
  await page.waitForTimeout(1000);

  chk('1 · ยังไม่เปิดหน้าต่างตอนเข้าหน้ารายการ',
    await page.evaluate(function () { return !document.getElementById('aswf-root'); }), '');

  await page.evaluate(function () { document.querySelector('[data-as-wfedit="wf-1"]').click(); });
  await page.waitForTimeout(1500);

  const d = await page.evaluate(function () {
    const box = document.querySelector('.aswf-box');
    const r = box ? box.getBoundingClientRect() : null;
    const ov = document.querySelector('.aswf-overlay');
    const body = document.querySelector('.aswf-body');
    return {
      hasDlg: !!box, w: r ? Math.round(r.width) : 0, h: r ? Math.round(r.height) : 0,
      top: r ? Math.round(r.top) : 0, vw: window.innerWidth, vh: window.innerHeight,
      overlayZ: ov ? Number(getComputedStyle(ov).zIndex) : 0,
      title: (document.getElementById('aswf-title') || {}).textContent || '',
      hasX: !!document.getElementById('aswf-x'),
      sumCells: document.querySelectorAll('.aswf-sum .wf-top-cell').length,
      sumText: (document.querySelector('.aswf-sum') || {}).innerText || '',
      stepCards: document.querySelectorAll('#as-steps .wf-card').length,
      addBtnTxt: (document.getElementById('as-add-step') || {}).textContent || '',
      recap: (document.querySelector('.aswf-recap') || {}).innerText || '',
      footBtns: [].slice.call(document.querySelectorAll('.aswf-foot .btn')).map(function (x) { return x.textContent.trim(); }),
      bodyScroll: getComputedStyle(document.body).overflow,
      bodyOverflowY: body ? getComputedStyle(body).overflowY : '',
      detailInDlg: !!(document.getElementById('as-detail') && document.getElementById('as-detail').closest('.aswf-box')),
      detailDup: document.querySelectorAll('#as-detail').length,
      pageOverflow: document.documentElement.scrollWidth <= window.innerWidth + 1
    };
  });

  chk('2 · เปิดเป็นหน้าต่างกลางจอ', d.hasDlg, '');
  chk('3 · กว้าง 820–980px และไม่เต็มจอ', d.w >= 820 && d.w <= 980 && d.w < d.vw, 'กว้าง=' + d.w + ' จอ=' + d.vw);
  chk('4 · สูงไม่ล้นจอ', d.h > 0 && d.top >= 0 && d.top + d.h <= d.vh + 1, 'สูง=' + d.h + ' top=' + d.top);
  chk('5 · z-index ต่ำกว่า .modal-overlay (100)', d.overlayZ > 0 && d.overlayZ < 100, 'z=' + d.overlayZ);
  chk('6 · หัวเรื่อง "ตั้งค่าการอนุมัติ (Workflow)"', d.title.indexOf('ตั้งค่าการอนุมัติ (Workflow)') >= 0, d.title);
  chk('7 · มีปุ่มปิด X มุมขวาบน', d.hasX, '');
  chk('8 · การ์ดสรุป 3 ช่อง', d.sumCells === 3, 'พบ ' + d.sumCells);
  chk('8b · สรุปแสดงค่าจริง',
    /ประเภทคำขอ/.test(d.sumText) && /แผนก/.test(d.sumText) && /3 ขั้น/.test(d.sumText),
    d.sumText.replace(/\s+/g, ' ').slice(0, 80));
  chk('9 · รายการลำดับอนุมัติครบ 3 ขั้น', d.stepCards === 3, 'พบ ' + d.stepCards);
  chk('10 · ปุ่มใช้คำว่า "เพิ่มขั้นอนุมัติ"',
    /เพิ่มขั้นอนุมัติ/.test(d.addBtnTxt) && !/เพิ่มผู้อนุมัติ/.test(d.addBtnTxt), d.addBtnTxt.trim());
  chk('11 · มีส่วนสรุปก่อนบันทึก', /สรุปการตั้งค่า/.test(d.recap), '');
  chk('11b · สรุปไล่ลำดับ 1) 2) 3)',
    /1\) MANAGER/.test(d.recap) && /2\) MANAGING DIRECTOR/.test(d.recap) && /3\) MANAGEMENT/.test(d.recap), '');
  chk('12 · ปุ่มล่าง: ปิด + บันทึกการตั้งค่า',
    d.footBtns.length === 2 && d.footBtns[0] === 'ปิด' &&
    d.footBtns[1].indexOf('บันทึกการตั้งค่า') >= 0, d.footBtns.join(' | '));
  chk('13 · เลื่อนเฉพาะใน Body ของหน้าต่าง',
    d.bodyScroll === 'hidden' && /auto|scroll/.test(d.bodyOverflowY), 'body=' + d.bodyScroll);
  chk('14 · #as-detail อยู่ในหน้าต่าง และไม่ซ้ำ id', d.detailInDlg && d.detailDup === 1, 'พบ ' + d.detailDup);
  chk('15 · ไม่มีจุดล้นแนวนอน', d.pageOverflow, '');

  /* ---------- บั๊กหัวการ์ด: ต้องคงครบทุกอย่างหลัง sync ---------- */
  function headSnap() {
    return page.evaluate(function () {
      const cards = [].slice.call(document.querySelectorAll('#as-steps .wf-card'));
      return cards.map(function (c) {
        const h = c.querySelector('.wf-card-head');
        return {
          stepNo: !!h.querySelector('.wf-stepno'),
          name: (h.querySelector('b') || {}).textContent || '',
          badge: !!h.querySelector('.badge'),
          menuBtn: !!h.querySelector('[data-as-menu]'),
          caret: !!h.querySelector('.wf-caret'),
          smalls: h.querySelectorAll('small').length,
          menuItems: h.querySelectorAll('.wf-menu-pop button').length,
          hasEdit: !!h.querySelector('[data-as-edit]'), hasUp: !!h.querySelector('[data-as-up]'),
          hasDown: !!h.querySelector('[data-as-down]'), hasToggle: !!h.querySelector('[data-as-toggle]'),
          hasDel: !!h.querySelector('[data-as-del]')
        };
      });
    });
  }
  const h0 = await headSnap();
  const full = function (x) {
    return x.stepNo && x.name && x.badge && x.menuBtn && x.caret && x.smalls >= 2 &&
      x.menuItems === 5 && x.hasEdit && x.hasUp && x.hasDown && x.hasToggle && x.hasDel;
  };
  chk('16 · หัวการ์ดครบทุกใบตอนวาดครั้งแรก', h0.length === 3 && h0.every(full),
    JSON.stringify(h0[0] || {}));

  await page.evaluate(function () { document.querySelector('.wf-card-head').click(); });
  await page.waitForTimeout(400);
  const h1 = await headSnap();
  chk('17 · พับแล้วหัวการ์ดยังครบ (บั๊กเดิม)', h1.length === 3 && h1.every(full), JSON.stringify(h1[0] || {}));
  chk('17b · พับแล้วซ่อนเฉพาะรายชื่อผู้อนุมัติ',
    await page.evaluate(function () {
      const b = document.querySelector('#as-steps .wf-card .wf-card-body');
      return b.hidden === true && document.querySelectorAll('#as-steps .wf-card-body:not([hidden])').length === 2;
    }), '');

  await page.evaluate(function () { document.querySelector('.wf-card-head').click(); });
  await page.waitForTimeout(400);
  const h2 = await headSnap();
  chk('18 · กางกลับแล้วหัวการ์ดยังครบ', h2.length === 3 && h2.every(full), JSON.stringify(h2[0] || {}));

  const menu = await page.evaluate(function () {
    const btn = document.querySelector('[data-as-menu]');
    if (!btn) return { ok: false, items: 0 };
    btn.click();
    const pop = document.querySelector('.wf-menu-pop:not([hidden])');
    return { ok: !!pop, items: pop ? pop.querySelectorAll('button').length : 0,
      labels: pop ? [].slice.call(pop.querySelectorAll('button')).map(function (x) { return x.textContent.trim(); }) : [] };
  });
  chk('19 · เมนู ⋮ เปิดได้และมีคำสั่งครบ 5',
    menu.ok && menu.items === 5 &&
    /แก้ไข/.test(menu.labels[0]) && /ย้ายขึ้น/.test(menu.labels[1]) &&
    /ย้ายลง/.test(menu.labels[2]) && /ปิดใช้งาน/.test(menu.labels[3]) && /ลบขั้น/.test(menu.labels[4]),
    (menu.labels || []).join(' / '));

  /* ---------- หน้าต่างย่อยต้องซ้อนบนสุด ---------- */
  await page.evaluate(function () { document.getElementById('as-add-step').click(); });
  await page.waitForTimeout(800);
  const sub = await page.evaluate(function () {
    const m = document.querySelector('#modal-root .modal-overlay');
    return { open: !!m, z: m ? Number(getComputedStyle(m).zIndex) : 0,
      dlgStill: !!document.getElementById('aswf-root') };
  });
  chk('20 · เปิดหน้าต่างเพิ่มขั้นอนุมัติได้', sub.open, '');
  chk('20b · หน้าต่างย่อยซ้อนบนสุด', sub.z > 90, 'z=' + sub.z);
  chk('20c · หน้าต่างหลักไม่ถูกทำลาย', sub.dlgStill, '');
  await page.evaluate(function () { NJHR.ui.closeModal(); });
  await page.waitForTimeout(400);
  chk('21 · ปิดหน้าต่างย่อยแล้วหน้าต่างหลักยังอยู่',
    await page.evaluate(function () { return !!document.getElementById('aswf-root'); }), '');

  await page.keyboard.press('Escape');
  await page.waitForTimeout(600);
  const closed = await page.evaluate(function () {
    return { gone: !document.getElementById('aswf-root'),
      body: getComputedStyle(document.body).overflow,
      list: document.querySelectorAll('.wf-set').length };
  });
  chk('22 · Esc ปิดหน้าต่างได้', closed.gone, '');
  chk('22b · คืนค่า scroll ให้หน้าเว็บ', closed.body !== 'hidden', 'overflow=' + closed.body);
  chk('22c · กลับมาเห็นรายการชุด Workflow', closed.list === 2, 'การ์ด=' + closed.list);

  await page.evaluate(function () { document.querySelector('[data-as-wfedit="wf-2"]').click(); });
  await page.waitForTimeout(1400);
  chk('23 · เปิดชุดที่สองได้',
    await page.evaluate(function () { return !!document.getElementById('aswf-root'); }), '');
  await page.evaluate(function () { document.getElementById('as-close').click(); });
  await page.waitForTimeout(600);
  chk('24 · ปุ่มบันทึกการตั้งค่าปิดหน้าต่างได้',
    await page.evaluate(function () {
      return !document.getElementById('aswf-root') && document.querySelectorAll('.wf-set').length === 2;
    }), '');

  await page.evaluate(function () { document.querySelector('[data-as-wfedit="wf-1"]').click(); });
  await page.waitForTimeout(1200);
  await page.evaluate(function () { location.hash = '#/dashboard'; });
  await page.waitForTimeout(1200);
  const navAway = await page.evaluate(function () {
    return { gone: !document.getElementById('aswf-root'), body: getComputedStyle(document.body).overflow };
  });
  chk('25 · เปลี่ยนหน้าแล้วไม่มีหน้าต่างค้าง', navAway.gone, '');
  chk('25b · scroll ของหน้าเว็บกลับปกติ', navAway.body !== 'hidden', 'overflow=' + navAway.body);

  await page.setViewportSize({ width: 390, height: 780 });
  await page.evaluate(function () { location.hash = '#/approval-settings'; });
  await page.waitForTimeout(1800);
  await page.evaluate(function () {
    var b = document.querySelector('[data-as-wfedit="wf-1"]'); if (b) b.click();
  });
  await page.waitForTimeout(1500);
  const mb = await page.evaluate(function () {
    const box = document.querySelector('.aswf-box');
    const r = box ? box.getBoundingClientRect() : null;
    return { has: !!box, w: r ? Math.round(r.width) : 0, vw: window.innerWidth,
      noOverflow: document.documentElement.scrollWidth <= window.innerWidth + 1,
      steps: document.querySelectorAll('#as-steps .wf-card').length };
  });
  chk('26 · มือถือเปิดได้และไม่ล้นจอ', mb.has && mb.w <= mb.vw && mb.noOverflow, 'กว้าง=' + mb.w);
  chk('26b · มือถือแสดงขั้นอนุมัติครบ', mb.steps === 3, 'พบ ' + mb.steps);

  chk('CONSOLE · ไม่มี unhandled error (ไม่นับ Fixture)', errs.length === 0, errs.slice(0, 3).join(' | '));

  console.log('\n========== สรุป ==========');
  console.log('PASS ' + PASS + ' · FAIL ' + FAIL);
  if (fixtureErrs.length) {
    console.log('UNRELATED (Existing/Fixture Issue) · njhr_dashboard_summary ไม่มีใน Mock Fixture · ' +
      fixtureErrs.length + ' ครั้ง — ไม่นับเป็น FAIL ของงานนี้');
  }
  await b.close(); srv.close();
  process.exit(FAIL ? 1 : 0);
})();
