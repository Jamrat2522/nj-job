#!/usr/bin/env node
/* calendar_test.js — Regression หน้า "ปฏิทินองค์กร" (#/calendar)
   โหลด views/calendar/main.js ตัวจริงที่ build ออกมา แล้วรันบน jsdom
   โดยจำลอง NJHR.compat.scope ตามสัญญาเดิมของ Runtime (26 symbol)

   ทดสอบ 3 Role จริง: SUPER_ADMIN · ADMIN · USER
   ใช้: node harness/calendar_test.js      (exit 1 เมื่อพบปัญหา)

   ไม่แตะ Production · ไม่ต่อ Supabase · ตอบ RPC ด้วย fixture ในไฟล์นี้ */
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');

const ROOT = path.join(__dirname, '..');
let FAIL = 0;
const ok = m => console.log('  ok    ' + m);
const bad = m => { FAIL++; console.error('  FAIL  ' + m); };
const chk = (cond, m) => cond ? ok(m) : bad(m);

/* ---------- Fixture: ผลลัพธ์ที่ njhr_calendar_month ต้องคืน ---------- */
const DEPT_IT = '11111111-1111-1111-1111-111111111111';
const DEPT_OP = '22222222-2222-2222-2222-222222222222';

function calendarPayload(from, to, dept) {
  const all = {
    departments: [
      { id: DEPT_IT, code: 'IT', name: 'เทคโนโลยีสารสนเทศ' },
      { id: DEPT_OP, code: 'OP', name: 'ปฏิบัติการ' }
    ],
    holidays: [{ holiday_date: '2026-08-12', name: 'วันแม่แห่งชาติ' }],
    leaves: [
      { start_date: '2026-08-03', end_date: '2026-08-04', display_name: 'ต้น', department: 'เทคโนโลยีสารสนเทศ' },
      { start_date: '2026-08-10', end_date: '2026-08-10', display_name: 'หนึ่ง', department: 'ปฏิบัติการ' }
    ],
    ot: [
      { ot_date: '2026-08-05', display_name: 'ต้น', department: 'เทคโนโลยีสารสนเทศ' },
      { ot_date: '2026-08-20', display_name: 'หนึ่ง', department: 'ปฏิบัติการ' }
    ]
  };
  const inRange = d => d >= from && d <= to;
  const deptName = dept === DEPT_IT ? 'เทคโนโลยีสารสนเทศ' : dept === DEPT_OP ? 'ปฏิบัติการ' : null;
  return {
    from: from, to: to,
    departments: all.departments,
    holidays: all.holidays.filter(h => inRange(h.holiday_date)),
    leaves: all.leaves.filter(l => l.start_date <= to && l.end_date >= from)
                      .filter(l => !deptName || l.department === deptName),
    ot: all.ot.filter(o => inRange(o.ot_date))
              .filter(o => !deptName || o.department === deptName)
  };
}

/* ---------- Runtime จำลอง: scope 26 symbol ตามที่ build.js ฉีดให้ ----------
   views/calendar/main.js ลงทะเบียน view ผ่าน NJHR.views.register — ดักไว้เพื่อเรียกใช้ */
function mount(role, rpcImpl) {
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div></body></html>');
  const win = dom.window;
  const calls = [], toasts = [], logouts = [];
  let viewCalendar = null;

  const pad = n => (n < 10 ? '0' : '') + n;
  const TH_MONTHS = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
    'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];
  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  const scope = {
    icon: () => '<svg></svg>', pad: pad, todayISO: () => '2026-08-10',
    fmtDate: d => d, fmtMonthYear: (m, y) => TH_MONTHS[m - 1] + ' ' + (y + 543), esc: esc,
    holLoad: () => Promise.resolve(true), holInvalidate: () => {},
    dept: () => '', currentUser: () => ({ role: role, active: true }), audit: () => {},
    toast: (m, k) => toasts.push({ m: m, k: k }),
    openModal: () => {}, closeModal: () => {},
    withButtonLoading: (b, t, fn) => fn(), confirmDialog: () => {},
    sbRpcList: (fn, body) => { calls.push({ fn, body }); return Promise.resolve([]); },
    sbRpc: (fn, body) => { calls.push({ fn, body }); return rpcImpl(fn, body); },
    sbToken: () => 'TEST-TOKEN',
    doLogout: silent => logouts.push(!!silent),
    emptyState: t => '<div class="empty">' + esc(t) + '</div>',
    TH_DAYS: ['อา', 'จ', 'อ', 'พ', 'พฤ', 'ศ', 'ส'],
    ALL: ['SUPER_ADMIN', 'ADMIN', 'USER'],
    rptBuildXlsx: () => Promise.resolve(null), rptLoadZip: () => Promise.resolve(true),
    rptDateBE: d => d
  };

  win.NJHR = { compat: { scope: scope },
               views: { register: (name, fn) => { if (name === 'viewCalendar') viewCalendar = fn; } } };
  const ctx = vm.createContext(win);
  vm.runInContext(fs.readFileSync(path.join(ROOT, 'views/calendar/main.js'), 'utf8'), ctx,
    { filename: 'views/calendar/main.js' });

  return { win, doc: win.document, el: win.document.getElementById('app'),
           calls, toasts, logouts, viewCalendar };
}

const settle = () => new Promise(r => setImmediate(() => setImmediate(() => setImmediate(r))));
const okRpc = () => (fn, body) => {
  if (fn !== 'njhr_calendar_month') return Promise.resolve(null);
  return Promise.resolve(calendarPayload(body.p_from, body.p_to, body.p_dept));
};

(async function main() {
  /* ─── 1) ทั้ง 3 Role เปิดปฏิทินได้ · เห็นข้อมูลชุดเดียวกัน ─── */
  console.log('== 1) เปิดหน้าได้ทั้ง 3 Role ==');
  const snap = {};
  for (const role of ['SUPER_ADMIN', 'ADMIN', 'USER']) {
    const t = mount(role, okRpc());
    chk(typeof t.viewCalendar === 'function', role + ': ลงทะเบียน viewCalendar แล้ว');
    t.viewCalendar(t.el);
    await settle();
    const html = t.el.innerHTML;
    chk(html.indexOf('ไม่สามารถโหลดปฏิทินองค์กรได้') < 0, role + ': ไม่ขึ้น Error State');
    chk(!!t.doc.getElementById('cal-dept'), role + ': มีตัวกรองแผนก');
    chk(html.indexOf('วันแม่แห่งชาติ') >= 0, role + ': เห็นวันหยุด');
    chk(html.indexOf('ต้น ลา') >= 0, role + ': เห็นรายการลาที่อนุมัติแล้ว');
    chk(html.indexOf('ต้น OT') >= 0, role + ': เห็นรายการ OT ที่อนุมัติแล้ว');
    chk(t.logouts.length === 0, role + ': ไม่ถูกบังคับออกจากระบบ');
    snap[role] = (html.match(/class="cal-ev ev-[a-z]+">[^<]*/g) || []).join('|');
  }
  chk(snap.USER.length > 0 && snap.SUPER_ADMIN === snap.USER && snap.ADMIN === snap.USER,
      'ทั้ง 3 Role เห็นวันหยุด/ลา/OT ชุดเดียวกันทุกตัวอักษร');

  /* ─── 2) เรียก RPC ปฏิทินตัวเดียว ไม่แตะ Guard เดิม ─── */
  console.log('== 2) RPC ที่หน้าเรียกจริง ==');
  {
    const t = mount('USER', okRpc());
    t.viewCalendar(t.el); await settle();
    const names = t.calls.map(c => c.fn);
    chk(names.length === 1 && names[0] === 'njhr_calendar_month',
        'เรียก njhr_calendar_month ครั้งเดียว (ได้ ' + JSON.stringify(names) + ')');
    ['njhr_dept_list', 'njhr_leave_report', 'njhr_ot_list', 'njhr_holiday_list'].forEach(f =>
      chk(names.indexOf(f) < 0, 'ไม่เรียก ' + f + ' อีกแล้ว'));
    const b = t.calls[0].body;
    chk(b.p_from === '2026-08-01' && b.p_to === '2026-08-31', 'ส่งช่วงวันที่ของเดือนที่แสดง');
    chk(b.p_dept === null, 'ค่าเริ่มต้น = ทุกแผนก (p_dept = null)');
    chk(b.p_token === 'TEST-TOKEN', 'ส่ง p_token จาก sbToken()');
  }

  /* ─── 3) สิทธิ์จัดการวันหยุด ─── */
  console.log('== 3) ปุ่มจัดการวันหยุด ==');
  for (const [role, want] of [['SUPER_ADMIN', true], ['ADMIN', true], ['USER', false]]) {
    const t = mount(role, okRpc());
    t.viewCalendar(t.el); await settle();
    chk(!!t.doc.getElementById('cal-hol') === want,
        role + ': ' + (want ? 'มี' : 'ไม่มี') + 'ปุ่ม "จัดการวันหยุด"');
  }

  /* ─── 4) กรองแผนก (ส่ง Department UUID) ─── */
  console.log('== 4) ตัวกรองแผนก ==');
  {
    const t = mount('USER', okRpc());
    t.viewCalendar(t.el); await settle();
    const sel = t.doc.getElementById('cal-dept');
    chk(sel.options.length === 3 && sel.options[0].value === '', 'dropdown = ทุกแผนก + 2 แผนก');
    chk(sel.options[1].value === DEPT_IT, 'value ของตัวเลือก = Department UUID จริง');
    sel.value = DEPT_OP; sel.onchange.call(sel); await settle();
    const last = t.calls[t.calls.length - 1].body;
    chk(last.p_dept === DEPT_OP, 'ส่ง p_dept เป็น UUID ที่เลือก');
    const html = t.doc.getElementById('app').innerHTML;
    chk(html.indexOf('หนึ่ง ลา') >= 0 && html.indexOf('ต้น ลา') < 0, 'แสดงเฉพาะแผนกที่เลือก');
  }

  /* ─── 5) เปลี่ยนเดือน + กันข้อมูลเดือนเก่าทับเดือนใหม่ ─── */
  console.log('== 5) เปลี่ยนเดือน ==');
  {
    const t = mount('USER', okRpc());
    t.viewCalendar(t.el); await settle();
    t.doc.getElementById('cal-next').onclick(); await settle();
    chk(t.el.innerHTML.indexOf('กันยายน 2569') >= 0, 'กดถัดไป → กันยายน 2569');
    t.doc.getElementById('cal-prev').onclick(); await settle();
    chk(t.el.innerHTML.indexOf('สิงหาคม 2569') >= 0, 'กดก่อนหน้า → สิงหาคม 2569');
  }
  {
    /* Race: คำขอเก่ายังค้างอยู่แล้วมีการ render รอบใหม่ซ้อนขึ้นมา
       คำตอบของคำขอเก่าที่มาถึงทีหลังต้องถูกทิ้ง (seq guard) */
    const pending = [];
    let nth = 0;
    const t = mount('USER', (fn, body) => {
      const tag = (++nth === 1) ? 'STALE' : 'FRESH';
      return new Promise(res => pending.push(() => {
        const p = calendarPayload(body.p_from, body.p_to, body.p_dept);
        p.leaves = [{ start_date: '2026-08-03', end_date: '2026-08-03', display_name: tag, department: '' }];
        res(p);
      }));
    });
    t.viewCalendar(t.el);              // คำขอ #1 (STALE) — ยังไม่ตอบ
    await settle();
    t.viewCalendar(t.el);              // render รอบใหม่ → คำขอ #2 (FRESH) · seq เพิ่ม
    await settle();
    chk(pending.length === 2, 'มีคำขอค้างพร้อมกัน 2 คำขอ');
    pending[1]();                      // คำขอใหม่ตอบก่อน
    await settle();
    chk(t.el.innerHTML.indexOf('FRESH ลา') >= 0, 'คำขอล่าสุดแสดงผลแล้ว');
    pending[0]();                      // คำขอเก่าตอบทีหลัง
    await settle();
    chk(t.el.innerHTML.indexOf('STALE') < 0, 'ข้อมูลคำขอเก่าที่ตอบทีหลังไม่ทับของใหม่');
    chk(t.el.innerHTML.indexOf('FRESH ลา') >= 0, 'ข้อมูลล่าสุดยังอยู่ครบ');
    chk(t.el.innerHTML.indexOf('ไม่สามารถโหลดปฏิทินองค์กรได้') < 0, 'ไม่ขึ้น Error State');
  }

  /* ─── 6) Error State ─── */
  console.log('== 6) Error State ==');
  {
    const t = mount('USER', () => Promise.reject(
      Object.assign(new Error('permission denied for function njhr_dept_list'), { sbServer: true })));
    t.viewCalendar(t.el); await settle();
    const html = t.el.innerHTML;
    chk(html.indexOf('ไม่สามารถโหลดปฏิทินองค์กรได้ กรุณาลองใหม่') >= 0, 'แสดงข้อความมาตรฐาน');
    chk(html.indexOf('permission denied') < 0, 'ไม่หลุดข้อความภายในของฐานข้อมูล');
    chk(html.indexOf('คุณไม่มีสิทธิ์') < 0, 'ไม่แสดงข้อความสิทธิ์ที่ทำให้ผู้ใช้สับสน');
    chk(!!t.doc.getElementById('cal-retry'), 'มีปุ่มลองใหม่');
    chk(!!t.doc.getElementById('cal-prev') && !!t.doc.getElementById('cal-next'),
        'ยังเปลี่ยนเดือนได้จากหน้า Error');
    chk(t.logouts.length === 0, 'Error ทั่วไปไม่บังคับออกจากระบบ');
  }

  /* ─── 7) Session หมดอายุ → Flow ออกจากระบบเดิม ─── */
  console.log('== 7) Session หมดอายุ ==');
  {
    const t = mount('USER', () => Promise.reject(
      Object.assign(new Error('เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่'), { sbServer: true })));
    t.viewCalendar(t.el); await settle();
    chk(t.logouts.length === 1 && t.logouts[0] === true, 'เรียก doLogout(true) ตาม Flow เดิม');
    chk(t.el.innerHTML.indexOf('ต้น ลา') < 0 && t.el.innerHTML.indexOf('วันแม่') < 0,
        'ไม่แสดงข้อมูลค้างหลัง Session หมดอายุ');
  }

  /* ─── 8) ไม่มีข้อมูลจากเครื่อง ─── */
  console.log('== 8) แหล่งข้อมูล ==');
  {
    const src = fs.readFileSync(path.join(ROOT, 'src/17-view-calendar.js'), 'utf8');
    // ตัดคอมเมนต์ออกก่อน เพื่อไม่ให้ข้อความอธิบายทำให้ตรวจผิด
    const body = src.slice(src.indexOf('function calLoad'), src.indexOf('function calIsSuper'))
      .replace(/\/\*[\s\S]*?\*\//g, ' ').replace(/^[ \t]*\/\/.*$/gm, ' ');
    ['localStorage', 'db.departments', 'db.holidays', 'db.leaves', 'db.ots', 'holHas(']
      .forEach(k => chk(body.indexOf(k) < 0, 'calLoad/calRender ไม่อ้าง ' + k));
    // ตรวจไฟล์ที่ deploy จริงด้วย (minify แล้วไม่มีคอมเมนต์เหลือ)
    const out = fs.readFileSync(path.join(ROOT, 'views/calendar/main.js'), 'utf8');
    ['njhr_dept_list', 'njhr_leave_report', 'njhr_ot_list']
      .forEach(k => chk(out.indexOf(k) < 0, 'views/calendar/main.js ไม่มีชื่อ RPC ' + k));
    chk(out.indexOf('njhr_calendar_month') >= 0, 'views/calendar/main.js เรียก njhr_calendar_month');
    chk(out.indexOf('njhr_holiday_list') >= 0, 'ยังใช้ njhr_holiday_list เฉพาะโมดัลจัดการวันหยุด');
  }

  /* ─── 9) มุมมองรายการ ─── */
  console.log('== 9) มุมมองเดือน / รายการ ==');
  {
    const t = mount('SUPER_ADMIN', okRpc());
    t.viewCalendar(t.el); await settle();
    t.doc.getElementById('cal-lv').onclick(); await settle();
    const html = t.el.innerHTML;
    chk(html.indexOf('วันแม่แห่งชาติ') >= 0 && html.indexOf('ต้น ลา') >= 0 && html.indexOf('ต้น OT') >= 0,
        'มุมมองรายการแสดงครบทั้งวันหยุด/ลา/OT');
    t.doc.getElementById('cal-mv').onclick(); await settle();
    chk(t.el.innerHTML.indexOf('cal-grid') >= 0, 'กลับมุมมองเดือนได้');
  }

  console.log(FAIL ? '\nCALENDAR TEST FAILED (' + FAIL + ')' : '\nCALENDAR TEST PASSED');
  process.exit(FAIL ? 1 : 0);
})();
