| Test Case | ผล | หลักฐาน |
|---|---|---|
| ROLE SUPER_ADMIN · login + shell | PASS | role=SUPER_ADMIN hash=#/dashboard |
| ROLE SUPER_ADMIN · Dashboard เปิดได้ | PASS | viewHost=4535B |
| ROLE SUPER_ADMIN · เมนูไม่มีลิงก์ที่ไม่มีสิทธิ์ | PASS | เมนู 17 ลิงก์ · เกิน 0 |
| ROLE SUPER_ADMIN · route ที่มีสิทธิ์เปิดได้ 28/28 | PASS | ครบทุก route |
| ROLE SUPER_ADMIN · ไม่มี route ต้องห้าม (สิทธิ์สูงสุด) | PASS | denied=0 |
| ROLE SUPER_ADMIN · console ไม่มี error | PASS | ไม่มี |
| ROLE ADMIN · login + shell | PASS | role=ADMIN hash=#/dashboard |
| ROLE ADMIN · Dashboard เปิดได้ | PASS | viewHost=4535B |
| ROLE ADMIN · เมนูไม่มีลิงก์ที่ไม่มีสิทธิ์ | PASS | เมนู 17 ลิงก์ · เกิน 0 |
| ROLE ADMIN · route ที่มีสิทธิ์เปิดได้ 27/27 | PASS | ครบทุก route |
| ROLE ADMIN · route ไม่มีสิทธิ์ถูก redirect 1/1 | PASS | เด้งกลับ #/dashboard ทุกตัว |
| ROLE ADMIN · Access Denied แสดง toast | PASS | toast="ยินดีต้อนรับ พนักงาน ทดสอบ001คุณไม่มีสิท" |
| ROLE ADMIN · route ไม่มีสิทธิ์ไม่โหลด Module | PASS | js ที่โหลดเพิ่ม: ไม่มี |
| ROLE ADMIN · ไม่มี Feature Module ใดถูกโหลดจากการลองเข้าที่ไม่มีสิทธิ์ | PASS | moduleState={"dashboard":"loaded"} |
| ROLE ADMIN · console ไม่มี error | PASS | ไม่มี |
| ROLE USER · login + shell | PASS | role=USER hash=#/dashboard |
| ROLE USER · Dashboard เปิดได้ | PASS | viewHost=3860B |
| ROLE USER · เมนูไม่มีลิงก์ที่ไม่มีสิทธิ์ | PASS | เมนู 7 ลิงก์ · เกิน 0 |
| ROLE USER · route ที่มีสิทธิ์เปิดได้ 13/13 | PASS | ครบทุก route |
| ROLE USER · route ไม่มีสิทธิ์ถูก redirect 15/15 | PASS | เด้งกลับ #/dashboard ทุกตัว |
| ROLE USER · Access Denied แสดง toast | PASS | toast="คุณไม่มีสิทธิ์เข้าถึงหน้านี้คุณไม่มีสิทธ" |
| ROLE USER · route ไม่มีสิทธิ์ไม่โหลด Module | PASS | js ที่โหลดเพิ่ม: ไม่มี |
| ROLE USER · ไม่มี Feature Module ใดถูกโหลดจากการลองเข้าที่ไม่มีสิทธิ์ | PASS | moduleState={"dashboard":"loaded"} |
| ROLE USER · console ไม่มี error | PASS | ไม่มี |
| ROLE · เมนู USER ต่างจาก ADMIN | PASS | USER=7 ลิงก์ · ADMIN=17 ลิงก์ |
| ROLE · SUPER_ADMIN และ ADMIN มีเมนู Sidebar ชุดเดียวกัน (ตามการออกแบบเดิม) | PASS | ทั้งคู่ 17 ลิงก์ · ต่างกันที่ #/geofence ซึ่งเป็นแท็บ ไม่ใช่เมนู |
| SESSION · ไม่มี session → หน้า Login | PASS | hash=#/login shell=false |
| SESSION · หน้า Login ไม่โหลด compat/dashboard | PASS | js=config.js,asset-manifest.js,runtime/namespace.js,runtime/core.js |
| SESSION · Login สำเร็จ → Dashboard | PASS | hash=#/dashboard |
| SESSION · Refresh หลัง Login → Restore Session | PASS | hash=#/dashboard role=SUPER_ADMIN |
| SESSION · Logout → กลับหน้า Login | PASS | shell=false hash=#/login |
| SESSION · Session หมดอายุ → หน้า Login | PASS | shell=false hash=#/login |
| SESSION · Session หมดอายุ ไม่โหลด Feature Module | PASS | js=config.js,asset-manifest.js,runtime/namespace.js,runtime/core.js |
| SESSION · Logout ระหว่าง Module โหลด → ไม่ render view | PASS | shell=false hash=#/login |
| SESSION · Logout ระหว่างโหลด ไม่มี unhandled error | PASS | ไม่มี |
| SESSION · Session เปลี่ยนระหว่าง Route โหลด → ปลอดภัย | PASS | shell=false err=ไม่มี |
| DASH · เปิดหลัง Login | PASS | viewHost=4540B |
| DASH · โหลดเฉพาะ dashboard.js ไม่โหลด compat | PASS | js=config.js,asset-manifest.js,runtime/namespace.js,runtime/core.js,views/dashboard.js |
| DASH · Back กลับ Dashboard | PASS | hash=#/dashboard viewHost=4540 |
| DASH · Forward ไป route เดิม | PASS | hash=#/attendance |
| DASH · Refresh บน route ปัจจุบัน (deep link) | PASS | hash=#/attendance |
| DASH · Deep Link #/dashboard | PASS | viewHost=4540 |
| DASH · กด Dashboard ซ้ำไม่พัง | PASS | navId 2→3 |
| DASH · กดเมนูรัว 6 ครั้ง → ลงที่ route สุดท้าย | PASS | hash=#/profile viewHost=1202 |
| DASH · กดเมนูรัวแล้วไม่มีจอขาว | PASS | ข้อความบนจอ 458 ตัวอักษร |
| DASH · เปลี่ยน route ระหว่างโหลด → ไม่ถูก render ทับ | PASS | hash=#/dashboard viewHost=4540 |
| DASH · ไม่มี unhandled error ตลอดชุดทดสอบ | PASS | ไม่มี |
| DASH · Module โหลดไม่สำเร็จ → แสดง Error State | PASS | state=failed ปุ่ม=true |
| DASH · Error State ไม่เปิดเผย path/ชื่อไฟล์ | PASS | ข้อความ="ไม่สามารถโหลดหน้านี้ได้ กรุณาลองใหม่ ลองใหม่" |
| DASH · Module โหลดไม่สำเร็จแล้วไม่เปิด Route ต่อ | PASS | ยังอยู่ที่ Error State |
| DASH · กดลองใหม่แล้วโหลดสำเร็จ | PASS | state=loaded viewHost=59475B |
| DASH · ไม่มี infinite retry | PASS | retry ทำงานเมื่อผู้ใช้กดเท่านั้น (module-loader ไม่มี auto-retry) |
| LISTENER · window/document listener ไม่เพิ่มหลังเปิดหน้าซ้ำ 3 รอบ + Back/Forward | PASS | {"window:load":1,"window:hashchange":1,"window:keydown":1,"window:resize":1,"window:afterprint":2} |
| LISTENER · ไม่เพิ่มหลัง Logout แล้ว Login ใหม่ | PASS | คงที่ {"window:load":1,"window:hashchange":1,"window:keydown":1,"window:resize":1,"window:afterprint":2} |
| LISTENER · รายการ listener ระดับ window/document | PASS | `{"window:load":1,"window:hashchange":1,"window:keydown":1,"window:resize":1,"window:afterprint":2}` |
| RESPONSIVE Mobile Portrait 360x740 · ไม่มีเนื้อหาล้นจอ | PASS | scrollWidth เกิน 0px · ล้นจริง 0 · ลิ้นชักนอกจอ(ตามดีไซน์เดิม) 204 |
| RESPONSIVE Mobile Portrait 360x740 · Sidebar + Dashboard การ์ดแสดงผล | PASS | sidebar=true bottomNav=true cards=5 |
| RESPONSIVE Mobile Portrait 360x740 · Modal ไม่ล้นจอ | PASS | modal 360px / viewport 360px |
| RESPONSIVE Mobile Portrait 360x740 · Loading/Error/Retry ไม่ล้นจอ | PASS | ปุ่มลองใหม่ 79×48px |
| RESPONSIVE Mobile Landscape 740x360 · ไม่มีเนื้อหาล้นจอ | PASS | scrollWidth เกิน 0px · ล้นจริง 0 · ลิ้นชักนอกจอ(ตามดีไซน์เดิม) 204 |
| RESPONSIVE Mobile Landscape 740x360 · Sidebar + Dashboard การ์ดแสดงผล | PASS | sidebar=true bottomNav=true cards=5 |
| RESPONSIVE Mobile Landscape 740x360 · Modal ไม่ล้นจอ | PASS | modal 740px / viewport 740px |
| RESPONSIVE Mobile Landscape 740x360 · Loading/Error/Retry ไม่ล้นจอ | PASS | ปุ่มลองใหม่ 89×48px |
| RESPONSIVE Tablet 768x1024 · ไม่มีเนื้อหาล้นจอ | PASS | scrollWidth เกิน 0px · ล้นจริง 0 · ลิ้นชักนอกจอ(ตามดีไซน์เดิม) 204 |
| RESPONSIVE Tablet 768x1024 · Sidebar + Dashboard การ์ดแสดงผล | PASS | sidebar=true bottomNav=true cards=5 |
| RESPONSIVE Tablet 768x1024 · Modal ไม่ล้นจอ | PASS | modal 768px / viewport 768px |
| RESPONSIVE Tablet 768x1024 · Loading/Error/Retry ไม่ล้นจอ | PASS | ปุ่มลองใหม่ 89×48px |
| RESPONSIVE Desktop 1440x900 · ไม่มีเนื้อหาล้นจอ | PASS | scrollWidth เกิน 0px · ล้นจริง 0 · ลิ้นชักนอกจอ(ตามดีไซน์เดิม) 0 |
| RESPONSIVE Desktop 1440x900 · Sidebar + Dashboard การ์ดแสดงผล | PASS | sidebar=true bottomNav=true cards=5 |
| RESPONSIVE Desktop 1440x900 · Modal ไม่ล้นจอ | PASS | modal 480px / viewport 1440px |
| RESPONSIVE Desktop 1440x900 · Loading/Error/Retry ไม่ล้นจอ | PASS | ปุ่มลองใหม่ 81×42px |
| RESPONSIVE Desktop 1920x1080 · ไม่มีเนื้อหาล้นจอ | PASS | scrollWidth เกิน 0px · ล้นจริง 0 · ลิ้นชักนอกจอ(ตามดีไซน์เดิม) 0 |
| RESPONSIVE Desktop 1920x1080 · Sidebar + Dashboard การ์ดแสดงผล | PASS | sidebar=true bottomNav=true cards=5 |
| RESPONSIVE Desktop 1920x1080 · Modal ไม่ล้นจอ | PASS | modal 480px / viewport 1920px |
| RESPONSIVE Desktop 1920x1080 · Loading/Error/Retry ไม่ล้นจอ | PASS | ปุ่มลองใหม่ 81×42px |
| RESPONSIVE · iPhone Safari (WebKit จริง) | NOT TESTED | ยังไม่ได้ทดสอบบนอุปกรณ์ iPhone Safari จริง — สภาพแวดล้อมนี้มีเฉพาะ Chromium |
| COMPAT · เปิดครบทุก Route 28/28 | PASS | ทุก route แสดงเนื้อหา |
| COMPAT · Bundle โหลดครั้งเดียว | PASS | app-legacy.js ถูกร้องขอ 1 ครั้ง |
| COMPAT · dashboard.js โหลดครั้งเดียว | PASS | dashboard.js ถูกร้องขอ 1 ครั้ง |
| COMPAT · ไม่มี Boot/Router/Store ซ้ำ | PASS | views=27 modules=dashboard,employees,shared-emp-meta,shared-hr-meta,compatibility,shared-report,shared-requests,shared-leave-meta,shared-attachments,attendance,requests-leave,ot,attendance-report |
| COMPAT · console ไม่มี error ตลอด 28 route | PASS | ไม่มี |
| P3 · ไม่มี Module ใดถูกร้องขอซ้ำตลอด 28 route | PASS | ทุกไฟล์ถูกร้องขอ 1 ครั้ง |

**PASS 80 · FAIL 0**
