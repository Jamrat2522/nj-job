const fs=require('fs'),path=require('path');
const root=process.argv[2]||path.resolve(__dirname,'..');
let pass=0,fail=0;
function T(name,ok){if(ok){pass++;console.log('PASS',name)}else{fail++;console.error('FAIL',name)}}
function R(f){return fs.readFileSync(path.join(root,f),'utf8')}
const core=R('runtime/core.js'), cal=R('views/calendar/main.js'), compat=R('compat/app-legacy.js'), emp=R('views/employees/list.js'), empForm=R('views/employees/form.js'), sql=R('sql/101_role_permissions.sql');
T('4 roles in frontend', core.includes("r === 'SUPER_ADMIN' || r === 'HR' || r === 'ADMIN'") && core.includes("HR: 'ฝ่าย HR'") && core.includes("ADMIN: 'ผู้อนุมัติ'"));
T('ADMIN has approval menu', core.includes('var ADMIN_MENU = USER_MENU.concat') && core.includes("{ r: '#/approvals', t: 'อนุมัติรายการ'"));
T('ADMIN management exception only approval', core.includes("'#/approvals': { title: 'อนุมัติรายการ', roles: ['SUPER_ADMIN', 'HR', 'ADMIN']") && core.includes("'#/employees': { title: 'พนักงาน', roles: ['SUPER_ADMIN', 'HR']") && !core.includes("'#/payroll': { title: 'เงินเดือน', roles: ['SUPER_ADMIN', 'ADMIN']"));
T('HR management routes', core.includes("'#/payroll': { title: 'เงินเดือน', roles: ['SUPER_ADMIN', 'HR']") && core.includes("'#/shifts': { title: 'ตั้งค่ากะทำงาน', roles: ['SUPER_ADMIN', 'HR']"));
T('calendar USER/ADMIN holiday only UI', cal.includes('แสดงเฉพาะวันหยุดของบริษัท') && cal.includes('วันหยุดบริษัท'));
T('calendar manage HR/SA only', cal.includes("function calCanManage() { return ['SUPER_ADMIN', 'HR'].indexOf(currentUser().role) >= 0; }"));
T('employee delete shortcut SUPER only', emp.includes("currentUser().role !== 'SUPER_ADMIN'") && empForm.includes("currentUser().role !== 'SUPER_ADMIN'"));
T('workflow step/delete SUPER only', compat.includes("currentUser().role === 'SUPER_ADMIN'") && compat.includes('asf-del') && compat.includes('เฉพาะ SUPER_ADMIN เท่านั้นที่ลบ'));
T('payroll delete SUPER only', compat.includes("currentUser().role === 'SUPER_ADMIN' && r.can_delete") && compat.includes("String(action || '').toUpperCase() === 'DELETE' && currentUser().role !== 'SUPER_ADMIN'"));
T('shift delete menu SUPER only', compat.includes("currentUser().role === 'SUPER_ADMIN'") && compat.includes('ลบกะ'));
T('server ADMIN approval only', sql.includes("(c.role in ('SUPER_ADMIN','HR','ADMIN'))") && sql.includes("c.role='ADMIN' and not public.njhr_request_approver_member"));
T('server calendar privacy', sql.includes("v_full := v_role in ('SUPER_ADMIN','HR')") && sql.includes("when not v_full then '[]'::jsonb"));
T('server HR session role preserved', sql.includes("when 'HR'          then 'HR'") && sql.includes("when 'MANAGER'     then 'USER'"));
T('server old ADMIN management RPC hardening', sql.includes('ROLE HARDENING ROUND 2') && sql.includes("public.njhr_audit_list") && sql.includes("public.njhr_pay_item_save") && sql.includes("public.njhr_doc_pdf_access"));
T('server delete helper not client API', sql.includes('revoke all on function public.njhr_require_super_delete(text) from public, anon, authenticated'));
T('server approval helper not client API', sql.includes('revoke all on function public.njhr_request_approver_member(text,uuid,uuid) from public, anon, authenticated'));
console.log(`RESULT PASS ${pass} FAIL ${fail}`);process.exit(fail?1:0);
