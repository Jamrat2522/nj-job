/* dash_kpi_test.js — ตรวจการ์ด KPI หน้า Dashboard ให้ใช้ Component เดียวกับ "รายงานทั้งหมด"
     · ใช้ .rp-kpi / .rp-kpi-ic / .rp-kpis เหมือนกัน
     · ขนาด · มุมโค้ง · เงา · ระยะห่าง · ตัวอักษร มาจากกฎกลางชุดเดียว
     · Desktop 4 ใบ/แถว · แท็บเล็ต 2 · มือถือ 1
     · ยังคลิกได้ · Route · id · ข้อความ · Logic เดิม
     · ไม่กระทบหน้ารายงานทั้งหมดและหน้าอื่น
   ใช้: node harness/dash_kpi_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(62) + (d || '')); }

const scss = fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8');
const min = scss.replace(/\s+/g, '');
const dash = fs.readFileSync(path.join(ROOT, 'views/dashboard.js'), 'utf8');
const compat = fs.readFileSync(path.join(ROOT, 'compat/app-legacy.js'), 'utf8');

/* ================= 1. ใช้ Component เดียวกัน ================= */
console.log('\n== ใช้ Component เดียวกับรายงานทั้งหมด ==');
chk('การ์ด KPI ใช้ class .rp-kpi', dash.indexOf('rp-kpi ') >= 0, '');
chk('ไอคอนใช้ class .rp-kpi-ic', dash.indexOf('rp-kpi-ic') >= 0, '');
chk('กล่องข้อความใช้ .grow เหมือนกัน', /rp-kpi-ic[\s\S]{0,120}class="grow"/.test(dash), '');
chk('Container ใช้ .rp-kpis', dash.indexOf('rp-kpis dash-kpis') >= 0, '');
/* ตรวจแบบระบุ class เต็ม เพราะ "kpi-ic" เป็นส่วนหนึ่งของ "rp-kpi-ic" */
chk('ไม่ใช้ .kpi / .kpi-ic / .kpi-txt เดิมแล้ว',
  dash.indexOf('class="kpi ') < 0 && dash.indexOf('class="kpi-ic"') < 0 &&
  dash.indexOf('class="kpi-txt"') < 0 && dash.indexOf('class="kpi-grid"') < 0, '');
chk('หน้ารายงานทั้งหมดยังใช้ .rp-kpi ชุดเดียวกัน', compat.indexOf('rp-kpi ') >= 0, '');

/* ================= 2. สไตล์มาจากกฎกลาง ================= */
console.log('\n== สไตล์จากกฎกลาง (ไม่ประกาศซ้ำ) ==');
chk('กฎกลาง .rp-kpi ยังเป็นตัวกำหนดขนาด/กรอบ/เงา',
  /\.rp-kpi\{display:flex;align-items:center;gap:11px;background:#fff/.test(min) &&
  /\.rp-kpi\{[^}]*border-radius:14px/.test(min) &&
  /\.rp-kpi\{[^}]*box-shadow:/.test(min), '');
chk('กฎกลาง .rp-kpi-ic ขนาด 40px เหมือนกัน',
  /\.rp-kpi-ic\{width:40px;height:40px/.test(min), '');
chk('กฎกลาง .rp-kpi b ขนาด 21px เหมือนกัน', /\.rp-kpib\{[^}]*font-size:21px/.test(min), '');
chk('กฎกลาง .rp-kpi small ขนาด 11.5px เหมือนกัน', /\.rp-kpismall\{[^}]*font-size:11\.5px/.test(min), '');
chk('กฎกลาง .rp-kpis ระยะห่าง 12px เหมือนกัน',
  /\.rp-kpis\{display:grid;grid-template-columns:repeat\(4,1fr\);gap:12px/.test(min), '');
/* Dashboard ต้องไม่ประกาศค่าซ้ำที่ทำให้ต่างจากรายงาน */
const deskBlock = (function () {
  const key = '@media(min-width:1024px){';
  let i = -1;
  while ((i = min.indexOf(key, i + 1)) >= 0) {
    let d = 1, j = i + key.length;
    for (; j < min.length && d > 0; j++) {
      if (min[j] === '{') d++;
      else if (min[j] === '}') d--;
    }
    const b = min.slice(i + key.length, j - 1);
    if (b.indexOf('.dash-legacy.rp-kpi') >= 0 || b.indexOf('.dash-legacy.dash-kpis') >= 0) return b;
  }
  return '';
})();
chk('มีบล็อก .dash-legacy สำหรับ KPI', deskBlock.length > 0, deskBlock.length + ' อักขระ');
[['height', 'ความสูงคงที่'], ['padding', 'ระยะขอบใน'], ['border-radius', 'มุมโค้ง'],
 ['font-size:26px', 'ขนาดตัวเลขเดิม'], ['font-size:14px', 'ขนาด Label เดิม']].forEach(function (x) {
  chk('Dashboard ไม่ประกาศ ' + x[1] + ' ทับกฎกลาง',
    deskBlock.indexOf('.dash-legacy.rp-kpi{') < 0 ||
    !new RegExp('\\.dash-legacy\\.rp-kpi\\{[^}]*' + x[0]).test(deskBlock), '');
});

/* ================= 3. เฉพาะสิ่งที่ต่างจริง ================= */
console.log('\n== สิ่งที่กำหนดเพิ่มเฉพาะ Dashboard ==');
chk('การ์ดเป็นลิงก์ — ล้าง text-decoration',
  /\.dash-legacy\.rp-kpi\{[^}]*text-decoration:none/.test(deskBlock), '');
chk('การ์ดเป็นลิงก์ — สีตัวอักษรไม่เปลี่ยน',
  /\.dash-legacy\.rp-kpi\{[^}]*color:inherit/.test(deskBlock), '');
chk('มี hover', deskBlock.indexOf('.dash-legacy.rp-kpi:hover{') >= 0, '');
chk('ไอคอน SVG กำหนดขนาด 20px',
  /\.dash-legacy\.rp-kpi-ic\.ic\{width:20px;height:20px\}/.test(deskBlock), '');
chk('ทุกสีกำหนดทั้งพื้นหลังและสีไอคอน (SVG ใช้ currentColor)',
  ['k-navy', 'k-green', 'k-yellow', 'k-blue', 'k-red', 'k-purple', 'k-pink', 'k-slate']
    .every(function (c) {
      return new RegExp('\\.dash-legacy\\.rp-kpi\\.' + c + '\\.rp-kpi-ic\\{background:#[0-9A-Fa-f]{6};color:#').test(deskBlock);
    }), '');
chk('ทุกสีกำหนดสีตัวเลขด้วย',
  ['k-navy', 'k-green', 'k-yellow', 'k-blue', 'k-red', 'k-purple', 'k-pink', 'k-slate']
    .every(function (c) {
      return new RegExp('\\.dash-legacy\\.rp-kpi\\.' + c + 'b\\{color:#').test(deskBlock);
    }), '');

/* ================= 4. จำนวนต่อแถว ================= */
console.log('\n== จำนวนการ์ดต่อแถว ==');
chk('Desktop 4 ใบต่อแถว',
  /\.dash-legacy\.dash-kpis\{grid-template-columns:repeat\(4,minmax\(0,1fr\)\)/.test(deskBlock), '');
chk('แท็บเล็ต (901–1023px) 2 ใบต่อแถว',
  min.indexOf('@mediascreenand(min-width:901px)and(max-width:1023px){.dash-legacy.dash-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}') >= 0, '');
chk('มือถือ 1 ใบต่อแถว (กฎกลาง .rp-kpis)',
  min.indexOf('.rp-kpis{grid-template-columns:1fr}') >= 0, '');
chk('ระยะห่างระหว่างการ์ด 12px เท่ารายงานทั้งหมด',
  !/\.dash-legacy\.dash-kpis\{[^}]*gap:/.test(deskBlock), 'ไม่ทับ gap ของกฎกลาง');

/* ================= 5. ไม่แตะ Logic ================= */
console.log('\n== Logic เดิม ==');
[['dk-emp', '#/employees'], ['dk-in', '#/reports'], ['dk-late', '#/reports'],
 ['dk-leave', '#/calendar'], ['dk-abs', '#/reports'], ['dk-ot', '#/ot'],
 ['dk-pend', '#/approvals'], ['dk-pay', '#/payroll']].forEach(function (x) {
  chk('ยังมี id ' + x[0] + ' และ Route ' + x[1],
    dash.indexOf(x[0]) >= 0 && dash.indexOf(x[1]) >= 0, '');
});
chk('การ์ดยังเป็น <a href> คลิกได้', /<a href="'\+route\+'"class="rp-kpi/.test(dash.replace(/\s+/g, '')) ||
  dash.indexOf('<a href="') >= 0, '');
chk('ยังสลับสีการ์ดรออนุมัติได้ (closest ตรงกับ class ใหม่)',
  dash.indexOf('closest(".rp-kpi")') >= 0 || dash.indexOf("closest('.rp-kpi')") >= 0, '');
chk('ยังเรียก njhr_dashboard_summary ตัวเดิม', dash.indexOf('njhr_dashboard_summary') >= 0, '');
chk('ป้ายงวดเงินเดือน (dk-pay-label) ยังอยู่', dash.indexOf('dk-pay-label') >= 0, '');
chk('ค่าเริ่มต้นยังเป็น … ระหว่างโหลด', dash.indexOf('…') >= 0, '');

/* ================= 6. ไม่กระทบหน้าอื่น ================= */
console.log('\n== ไม่กระทบหน้าอื่น ==');
chk('ทุกกฎ KPI ใหม่ scope ใต้ .dash-legacy',
  deskBlock.split('}').filter(function (r) {
    const sel = r.split('{')[0];
    return sel.indexOf('.rp-kpi') >= 0 && sel.indexOf('.dash-legacy') < 0;
  }).length === 0, '');
chk('ไม่แก้กฎกลาง .rp-kpi (รายงานทั้งหมดไม่เปลี่ยน)',
  /\.rp-kpi\{display:flex;align-items:center;gap:11px/.test(min), '');
/* clean-css แปลงรหัสสีเป็นตัวพิมพ์เล็ก */
chk('ไม่แก้สีของรายงานทั้งหมด (.rp-kpi.k-teal ฯลฯ)',
  min.toLowerCase().indexOf('.rp-kpi.k-teal.rp-kpi-ic{background:#ccfbf1}') >= 0, '');
chk('ไม่เหลือกฎ .dash-legacy .kpi เดิมค้าง', min.indexOf('.dash-legacy.kpi{') < 0, '');
chk('ไม่เหลือกฎ .dash-legacy .kpi-grid เดิมค้าง', min.indexOf('.dash-legacy.kpi-grid{') < 0, '');
chk('Component อื่นที่ชื่อคล้ายไม่ถูกแตะ (.sh-kpi)',
  (min + fs.readFileSync(path.join(ROOT, 'mobile.css'), 'utf8')).indexOf('.sh-kpi') >= 0, '');
chk('ส่วนอื่นของ Dashboard ไม่ถูกแตะ (.dash-cols)',
  deskBlock.indexOf('.dash-legacy.dash-cols{display:grid') >= 0, '');

console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
process.exit(FAIL ? 1 : 0);
