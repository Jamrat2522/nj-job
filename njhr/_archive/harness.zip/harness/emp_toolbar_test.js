/* emp_toolbar_test.js — ตรวจแถบเครื่องมือหน้า "พนักงาน"
     · Desktop = แถวเดียว (nowrap) ไม่มีอะไรตกบรรทัด
     · ลำดับ: ค้นหา · แผนก · สถานะ · เรียงตาม · น้อย→มาก · เทมเพลต · นำเข้า · Export · เพิ่มพนักงาน
     · ประมาณความกว้างรวมที่ 1366px ว่าไม่ล้นกรอบ (ไม่มี Horizontal Scroll)
     · มือถือและ Logic เดิมไม่ถูกแตะ
   ใช้: node harness/emp_toolbar_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(60) + (d || '')); }

const mcss = fs.readFileSync(path.join(ROOT, 'mobile.css'), 'utf8');
const min = mcss.replace(/\s+/g, '');
const empJs = fs.readFileSync(path.join(ROOT, 'views/employees/list.js'), 'utf8');

/* ---- ตัดบล็อก @media ที่มีกฎ .emp-filters ---- */
function blocks(prefix) {
  const out = [];
  let i = -1;
  while ((i = min.indexOf(prefix, i + 1)) >= 0) {
    let d = 1, j = i + prefix.length;
    for (; j < min.length && d > 0; j++) {
      if (min[j] === '{') d++;
      else if (min[j] === '}') d--;
    }
    const body = min.slice(i + prefix.length, j - 1);
    if (body.indexOf('.emp-filters') >= 0) out.push(body);
  }
  return out;
}
const BASE = blocks('@media(min-width:1024px){')[0] || '';
const T1400 = blocks('@media(min-width:1024px)and(max-width:1400px){')[0] || '';
const T1320 = blocks('@media(min-width:1024px)and(max-width:1320px){')[0] || '';

/* ================= 1. แถวเดียว ================= */
console.log('\n== Desktop: แถวเดียว ==');
chk('มีบล็อก Desktop (min-width: 1024px)', BASE.length > 0, BASE.length + ' อักขระ');
/* แบ่ง 2 แถวโดยตั้งใจ: แถวบน = ปุ่มจัดการ · แถวล่าง = ตัวกรอง */
chk('.emp-filters ใช้ flex-wrap: wrap เพื่อแบ่ง 2 แถว', BASE.indexOf('flex-wrap:wrap') >= 0, '');
chk('มีระยะห่างระหว่างแถว (row-gap)', /row-gap:1[02]px/.test(BASE), '');
chk('กลุ่มปุ่มจัดการถูกดันขึ้นแถวบน (order: -1)',
  /\.emp-filters\.emp-actions\{[^}]*order:-1/.test(BASE), '');
chk('กลุ่มปุ่มกินเต็มแถว (บังคับตัวกรองตกแถวล่าง)',
  /\.emp-filters\.emp-actions\{[^}]*flex:00100%/.test(BASE), '');
chk('ปุ่มจัดการชิดซ้าย', /\.emp-filters\.emp-actions\{[^}]*justify-content:flex-start/.test(BASE), '');
chk('ระยะห่างระหว่างปุ่ม 10–12px',
  /\.emp-filters\.emp-actions\{[^}]*gap:1[012]px/.test(BASE), '');
chk('ปุ่มเพิ่มพนักงานไม่ถูกดันไปขวาสุดแล้ว',
  BASE.indexOf('.emp-actions.emp-addbtn{margin-left:0}') >= 0, '');
chk('ปุ่มในแถวบนสูงเท่ากัน 48px',
  /\.emp-filters\.emp-actions\.btn\{height:48px/.test(BASE), '');
chk('ระยะห่างระหว่างช่อง 8–10px (จอกว้าง)', /\.emp-filters\{display:flex;align-items:center;gap:(8|9|10)px/.test(BASE), '');
chk('ทุกช่องสูง 48px เท่ากัน', BASE.indexOf('.emp-filters>*{height:48px') >= 0, '');
chk('จัดกึ่งกลางแนวตั้ง (align-items: center)', BASE.indexOf('align-items:center') >= 0, '');
chk('ช่องอื่นไม่ยืดเอง (flex: 0 0 auto)', BASE.indexOf('.emp-filters>*{height:48px;flex:00auto}') >= 0, '');
chk('ช่องค้นหายืด/หดได้มากที่สุด', /\.emp-filters\.emp-search\{flex:11320px/.test(BASE), '');
chk('ปุ่มไม่แตกบรรทัด (white-space: nowrap)', BASE.indexOf('white-space:nowrap') >= 0, '');
chk('ข้อความในปุ่มไม่แตกบรรทัด', BASE.indexOf('.emp-btxt{white-space:nowrap}') >= 0, '');
chk('กฎ margin-left:auto เดิมยังอยู่ (มือถือใช้ดันปุ่มไปขวา)',
  BASE.indexOf('.emp-addbtn{margin-left:auto}') >= 0, '');

/* ================= 2. ลำดับใน DOM ================= */
console.log('\n== ลำดับใน DOM ==');
const bar = empJs.slice(empJs.indexOf('toolbar emp-filters'), empJs.indexOf('emp-table'));
const ORDER = [['ค้นหา', 'emp-q'], ['ทุกแผนก', 'emp-dept'], ['ทุกสถานะ', 'emp-status'],
  ['เรียงตาม', 'emp-sort'], ['น้อย→มาก', 'emp-dir'], ['ดาวน์โหลดเทมเพลต', 'emp-tpl'],
  ['นำเข้า Excel', 'emp-import'], ['Export Excel', 'emp-export'], ['เพิ่มพนักงาน', 'emp-add']];
/* ปุ่มจัดการ 3 ตัวต้องอยู่ในกลุ่ม .emp-actions เท่านั้น และไม่ซ้ำที่อื่น */
const grp = empJs.slice(empJs.indexOf('emp-actions'), empJs.indexOf('emp-table'));
chk('มีกลุ่ม .emp-actions 1 กลุ่ม', (empJs.match(/class="emp-actions"/g) || []).length === 1, '');
['emp-import', 'emp-export', 'emp-add'].forEach(function (id) {
  chk('ปุ่ม ' + id + ' อยู่ในกลุ่ม .emp-actions', grp.indexOf(id) >= 0, '');
  chk('ปุ่ม ' + id + ' ไม่ถูกสร้างซ้ำ',
    (empJs.match(new RegExp('id="' + id + '"', 'g')) || []).length === 1, '');
});
chk('ดาวน์โหลดเทมเพลตยังอยู่แถวตัวกรอง (นอกกลุ่ม)', grp.indexOf('emp-tpl') < 0, '');
chk('เทมเพลตไม่ถูกสร้างซ้ำ',
  (empJs.match(/id="emp-tpl"/g) || []).length === 1, '');
let last = -1, ok = true, seen = [];
ORDER.forEach(function (x) {
  const i = bar.indexOf('"' + x[1] + '"');
  seen.push(x[0] + (i < 0 ? '(ไม่พบ)' : ''));
  if (i < 0 || i < last) ok = false;
  if (i >= 0) last = i;
});
chk('ลำดับครบและถูกต้องทั้ง 9 รายการ', ok, seen.join(' → '));
chk('Export Excel อยู่ก่อน เพิ่มพนักงาน',
  bar.indexOf('"emp-export"') < bar.indexOf('"emp-add"'), '');
chk('ดาวน์โหลดเทมเพลต และ นำเข้า Excel อยู่ก่อน Export',
  bar.indexOf('"emp-tpl"') < bar.indexOf('"emp-export"') &&
  bar.indexOf('"emp-import"') < bar.indexOf('"emp-export"'), '');
chk('ทุกปุ่มอยู่ใน Toolbar เดียว (.emp-filters)',
  (bar.match(/toolbar emp-filters/g) || []).length === 1, '');

/* ================= 3. งบความกว้างที่ 1366px ================= */
console.log('\n== งบความกว้าง 1366px ==');
/* กรอบเนื้อหา = 1366 − 270 (Sidebar) − 48 (padding ซ้าย+ขวา) */
const FRAME = 1366 - 270 - 48;
function num(block, re, dflt) {
  const m = re.exec(block);
  return m ? parseFloat(m[1]) : dflt;
}
const gap = num(T1400, /\.emp-filters\{gap:([\d.]+)px/, 8);
const selPadR = num(T1400, /\.emp-filtersselect\{max-width:[\d.]+px;font-size:[\d.]+px;padding:0([\d.]+)px/, 30);
const selPadL = num(T1400, /padding:0[\d.]+px0([\d.]+)px/, 12);
const selFont = num(T1400, /\.emp-filtersselect\{max-width:[\d.]+px;font-size:([\d.]+)px/, 13.5);
const selMax = num(T1400, /\.emp-filtersselect\{max-width:([\d.]+)px/, 190);
const deptMax = num(T1400, /#emp-dept\{max-width:([\d.]+)px\}/, 210);
const btnPad = num(T1400, /\.emp-filters\.btn\{padding:0([\d.]+)px/, 14);
const btnFont = num(T1400, /\.emp-filters\.btn\{padding:0[\d.]+px;font-size:([\d.]+)px/, 13.5);
const icW = num(T1400, /\.ic\{width:([\d.]+)px/, 18);
const btnGap = num(T1400, /\.emp-filters\.btn\{[^}]*gap:([\d.]+)px/, 7);
const searchMin = num(T1400, /\.emp-search\{flex:11[\d.]+px;min-width:([\d.]+)px/, 150);

/* ประมาณความกว้างข้อความไทย/อังกฤษ ≈ 0.62 เท่าของ font-size ต่อตัวอักษร (ค่าปลอดภัย) */
const textW = (s, f) => Math.ceil(s.length * f * 0.62);
const selW = (s) => Math.min(selMax, textW(s, selFont) + selPadL + selPadR);
const btnW = (s, hasIcon) => textW(s, btnFont) + btnPad * 2 + (hasIcon ? icW + btnGap : 0);

/* แถวล่างเหลือ 6 ช่อง: ค้นหา · แผนก · สถานะ · เรียงตาม · น้อย→มาก · เทมเพลต */
const items = [
  ['แผนก', Math.min(deptMax, textW('ทุกแผนก (108)', selFont) + selPadL + selPadR)],
  ['สถานะ', selW('ทุกสถานะ')],
  ['เรียงตาม', selW('เรียงตามวันเริ่มงาน')],
  ['น้อย→มาก', btnW('มาก→น้อย', false)],
  ['เทมเพลต', btnW('ดาวน์โหลดเทมเพลต', true)]
];
const fixed = items.reduce((n, x) => n + x[1], 0);
const gaps = gap * 5;                       // 6 ช่อง = 5 ช่องว่าง
const need = fixed + gaps + searchMin;
items.forEach(x => console.log('        ' + x[0].padEnd(16) + '≈ ' + x[1] + 'px'));
console.log('        ' + 'ช่องค้นหา (ต่ำสุด)'.padEnd(16) + '≈ ' + searchMin + 'px');
console.log('        ' + 'ช่องว่าง 5 ช่อง'.padEnd(16) + '≈ ' + gaps + 'px');
chk('รวมทุกช่องไม่เกินกรอบ 1366px (' + FRAME + 'px)', need <= FRAME, need + ' / ' + FRAME + 'px');
chk('เหลือที่ว่างให้ช่องค้นหายืดได้', FRAME - fixed - gaps >= searchMin,
  (FRAME - fixed - gaps) + 'px สำหรับช่องค้นหา');

/* 1920px ต้องสบาย ๆ */
const FRAME19 = 1920 - 270 - 48;
chk('ที่ 1920px เหลือที่ว่างมาก (ช่องค้นหายืดเต็ม)', FRAME19 - fixed - gaps >= 320,
  (FRAME19 - fixed - gaps) + 'px');

/* แถวบน 3 ปุ่ม ต้องพอในกรอบเดียวกันสบาย ๆ */
const topRow = btnW('นำเข้า Excel', true) + btnW('Export Excel', true) +
               btnW('เพิ่มพนักงาน', true) + 11 * 2;
console.log('        ' + 'แถวบน 3 ปุ่ม'.padEnd(16) + '≈ ' + topRow + 'px');
chk('แถวบน 3 ปุ่มพอในกรอบ 1366px', topRow <= FRAME, topRow + ' / ' + FRAME + 'px');

/* ================= 4. ลำดับการย่อตามที่กำหนด ================= */
console.log('\n== ลำดับการย่อเมื่อพื้นที่ไม่พอ ==');
chk('มีระดับย่อสำหรับ ≤1400px', T1400.length > 0, '');
chk('มีระดับย่อสำหรับ ≤1320px', T1320.length > 0, '');
chk('ย่อช่องค้นหาก่อน (min-width เล็กลงตามระดับ)',
  num(T1320, /\.emp-search\{flex:11[\d.]+px;min-width:([\d.]+)px/, 999) < searchMin, '');
chk('ลด padding ของ select', T1400.indexOf('padding:0') >= 0, '');
/* แถวตัวกรองเหลือ 6 ช่องแล้ว จึงไม่ต้องบีบ gap เท่าเดิม — ตรวจว่าอยู่ในช่วงที่อ่านง่าย */
chk('gap ของแถวตัวกรองอยู่ในช่วง 6–10px', gap >= 6 && gap <= 10, gap + 'px');
chk('จอแคบ (≤1320px) ย่อ gap ลงอีกขั้น',
  num(T1320, /\.emp-filters\{gap:([\d.]+)px/, 99) < gap, '');
chk('ลด padding ของปุ่ม', btnPad < 14, btnPad + 'px');
chk('ไม่ซ่อนปุ่มใดเลย', T1400.indexOf('display:none') < 0 && T1320.indexOf('display:none') < 0, '');

/* ================= 5. ไม่แตะ Logic และมือถือ ================= */
console.log('\n== ไม่กระทบส่วนอื่น ==');
['emp-q', 'emp-dept', 'emp-status', 'emp-sort', 'emp-dir', 'emp-tpl', 'emp-import',
 'emp-export', 'emp-add'].forEach(function (id) {
  chk('ยังมี Handler ของ ' + id, empJs.indexOf("getElementById('" + id + "')") >= 0 ||
    empJs.indexOf('getElementById("' + id + '")') >= 0, '');
});
chk('ไม่สร้าง class ใหม่ที่ไม่ได้ใช้ (.employee-toolbar)',
  mcss.indexOf('employee-toolbar') < 0 && empJs.indexOf('employee-toolbar') < 0, '');
chk('กฎมือถือ .emp-filters > select ยังอยู่ (styles.css)',
  fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8').indexOf('.emp-filters>select') >= 0 ||
  fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8').replace(/\s+/g, '')
    .indexOf('.emp-filters>select{flex:1146%') >= 0, '');
chk('กฎ Desktop อยู่ใน @media min-width เท่านั้น (ไม่หลุดไปมือถือ)',
  min.indexOf('.emp-filters{display:flex;align-items:center;gap') > min.indexOf('@media(min-width:1024px){'), '');

console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
process.exit(FAIL ? 1 : 0);
