# SELFSERVICE_TEST — ผลทดสอบ Employee Self Service

รัน: `node harness/selfservice_test.js .` · โหลด chunk ที่ build แล้วจริงลง jsdom
stub เฉพาะ `NJHR.compat.scope` · **ไม่แตะ Supabase จริง ไม่แตะข้อมูล Production**

| # | เคส | ผล | หลักฐาน |
|---|---|---|---|
| 1 | S1 · USER เข้า #/employees แล้วได้ Self Service ไม่ใช่รายชื่อทั้งบริษัท | **PASS** | พบชื่อตัวเอง · ไม่มีตารางรายชื่อ |
| 2 | S2 · ห้าม Query พนักงานทั้งบริษัท (njhr_emp_list / njhr_emp_departments) | **PASS** | calls=njhr_me_get |
| 3 | S3 · ใช้ njhr_me_get และไม่ส่ง employee_id จาก browser | **PASS** | params=p_token |
| 4 | S4 · ซ่อน Toolbar บริหารครบทั้ง 9 รายการ | **PASS** | ไม่มีรายการใดหลุด |
| 5 | S5 · ฟอร์มมี input เฉพาะ 7 ช่องที่อนุญาต | **PASS** | input=address,birth_date,email,emergency_phone,national_id,nickname,phone |
| 6 | S6 · ข้อมูลบริษัท/เงินเดือนไม่มีช่องกรอกเลย | **PASS** | ไม่มี input ของ field ต้องห้าม |
| 7 | S7 · ไม่มีปุ่ม "ส่งตรวจ" ตามที่ตกลง | **PASS** | ไม่พบข้อความ "ส่งตรวจ" |
| 8 | S8 · ข้อมูลครบ → แสดง ✅ ข้อมูลพนักงานครบถ้วน | **PASS** | แสดงสถานะครบ |
| 9 | S9 · บอกชื่อช่องที่ขาดจริง ไม่ใช่แค่ "ข้อมูลไม่ครบ" | **PASS** | ระบุครบทั้ง 3 ช่อง |
| 10 | S10 · แสดงจำนวน 4/7 | **PASS** | พบ 4/7 |
| 11 | S11 · บอกเอกสารที่ขาดเป็นชื่อรายการ | **PASS** | ขาด: วุฒิการศึกษา |
| 12 | S12 · แสดง ✅/❌ รายเอกสาร | **PASS** | เช็กลิสต์ถูกต้อง |
| 13 | S13 · ไม่ครบ → แสดง ⚠ ข้อมูลพนักงานยังไม่ครบถ้วน | **PASS** | แสดงสถานะไม่ครบ |
| 14 | S14 · Payload มีเฉพาะ 7 key ที่อนุญาต | **PASS** | keys=address,birth_date,email,emergency_phone,national_id,nickname,phone |
| 15 | S15 · Payload ไม่มี field ต้องห้ามแม้แต่ตัวเดียว | **PASS** | ไม่มี field บริษัทหลุด |
| 16 | S16 · Trim ช่องว่างหัวท้ายก่อนส่ง | **PASS** | address="1 ถนนทดสอบ" |
| 17 | S17 · บันทึกสำเร็จ → แจ้งผู้ใช้ | **PASS** | บันทึกข้อมูลส่วนตัวแล้ว |
| 18 | S18 · เลขบัตรไม่ครบ 13 หลัก → ไม่ยิง RPC | **PASS** | เลขบัตรประชาชนต้องเป็นตัวเลข 13 หลัก |
| 19 | S19 · อีเมลผิดรูปแบบ → ไม่ยิง RPC | **PASS** | รูปแบบอีเมลไม่ถูกต้อง |
| 20 | S20 · โหลดไม่สำเร็จ → แสดง Error + ปุ่มลองใหม่ | **PASS** | มีปุ่มลองใหม่ |
| 21 | S21 · บันทึกไม่สำเร็จ → แสดงข้อความจากเซิร์ฟเวอร์ + คืนสถานะปุ่ม | **PASS** | btn.disabled=false |
| 22 | A1 · ADMIN ได้ Self Service เหมือน USER | **PASS** | ไม่ได้รายชื่อทั้งบริษัท |
| 23 | A2 · ADMIN ไม่เห็นปุ่มเพิ่มพนักงาน / Import / Export | **PASS** | ซ่อนครบ |
| 24 | A3 · ADMIN ไม่ Query พนักงานทั้งบริษัท | **PASS** | calls=njhr_me_get |
| 25 | P1 · SUPER_ADMIN ยังได้ Employee Management เดิมครบ 9 ส่วน | **PASS** | ครบทุกส่วน |
| 26 | P2 · SUPER_ADMIN ยัง Query รายชื่อทั้งบริษัทได้ตามเดิม | **PASS** | calls=njhr_emp_departments,njhr_emp_list |
| 27 | P3 · SUPER_ADMIN ไม่เรียก njhr_me_get | **PASS** | ไม่ปนกับ Self Service |
| 28 | D1 · เจ้าของเปิดแฟ้มเอกสารตัวเองได้ | **PASS** | เปิดได้ |
| 29 | D2 · เจ้าของมีปุ่มแนบไฟล์ในหมวด PERSONAL | **PASS** | ครบทั้ง 3 รายการ |
| 30 | D3 · เจ้าของแนบหมวด COMPANY ไม่ได้ | **PASS** | ไม่มีปุ่มแนบหมวด COMPANY |
| 31 | D4 · เจ้าของไม่มีปุ่มลบ (can_delete = false) | **PASS** | ไม่มีปุ่มลบ |
| 32 | D5 · USER เปิดแฟ้มเอกสารคนอื่นไม่ได้ | **PASS** | คุณไม่มีสิทธิ์เปิดแฟ้มเอกสารพนักงาน |
| 33 | D6 · SUPER_ADMIN แนบได้ทั้ง PERSONAL และ COMPANY | **PASS** | ครบทั้ง 2 หมวด |
| 34 | D7 · SUPER_ADMIN ยังไม่เสียสิทธิ์เดิม (แฟ้มพนักงานคนอื่น) | **PASS** | เปิดแฟ้มคนอื่นได้ |

**PASS 34 · FAIL 0**
