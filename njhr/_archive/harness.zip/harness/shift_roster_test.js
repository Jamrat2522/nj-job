const { launchOpts } = require(require('path').join(__dirname, 'browser.js'));
/* shift_roster_test.js — หน้า "ตั้งค่ากะทำงาน" 2 ส่วน + ย้ายกะ + ประวัติกะ
   ใช้: node harness/shift_roster_test.js <ทางโปรเจกต์ absolute> <port> */
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const F = require(path.join(__dirname, 'fixtures.js'));

let PASS = 0, FAIL = 0;
const ROOT = process.argv[2] || process.cwd(), PORT = Number(process.argv[3] || 8970);
function chk(n, ok, e) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(56) + (e || '')); }

const SHIFTS = [
  { id: 'sh-1', shift_name: 'กะเช้า', start_time: '08:00:00', end_time: '17:00:00',
    is_overnight: false, break_minutes: 60, late_allow_minutes: 15, is_active: true, employee_count: 2 },
  { id: 'sh-2', shift_name: 'กะบ่าย', start_time: '13:00:00', end_time: '22:00:00',
    is_overnight: false, break_minutes: 60, late_allow_minutes: 10, is_active: true, employee_count: 1 },
  { id: 'sh-3', shift_name: 'กะดึก', start_time: '22:00:00', end_time: '07:00:00',
    is_overnight: true, break_minutes: 60, late_allow_minutes: 10, is_active: true, employee_count: 1 }
];
const MEMBERS = {
  'sh-1': [
    { employee_id: 'e-101', emp_code: '0101', full_name: 'นายสมชาย ใจดี', nickname: 'ชาย',
      department_name: 'OPERATION', position_name: 'SUPERVISOR', emp_status: 'ACTIVE', effective_date: '2026-01-05' },
    { employee_id: 'e-103', emp_code: '0103', full_name: 'นายเอกชัย ตั้งใจ', nickname: '',
      department_name: 'WAREHOUSE', position_name: 'STAFF', emp_status: 'ACTIVE', effective_date: '2026-02-01' }
  ],
  'sh-2': [
    { employee_id: 'e-104', emp_code: '0104', full_name: 'น.ส.พรพิมล ขยัน', nickname: 'พิม',
      department_name: 'DOCUMENT', position_name: 'STAFF', emp_status: 'ACTIVE', effective_date: '2026-03-01' }
  ],
  'sh-3': [
    { employee_id: 'e-102', emp_code: '0102', full_name: 'น.ส.สมศรี รักงาน', nickname: 'ศรี',
      department_name: 'OPERATION', position_name: 'STAFF', emp_status: 'ACTIVE', effective_date: '2026-01-20' }
  ]
};
const UNASSIGNED = [
  { employee_id: 'e-402', emp_code: '0402', full_name: 'นายวรินทร บุญสิทธิ์', nickname: '',
    department_name: 'MANAGEMENT', position_name: 'MANAGER', emp_status: 'ACTIVE' }
];
/* ตรงกับ Return type จริงของ njhr_shift_history (sql/100_shift_history.sql) */
const HISTORY = [
  { row_id: 'r4', effective_date: '2026-01-05', shift_id: 'sh-1', shift_name: 'กะเช้า',
    start_time: '08:00:00', end_time: '17:00:00', is_overnight: false, shift_active: true,
    status: 'ACTIVE', is_current: true, assigned_by: 'admin', assigned_at: '2026-01-05T09:00:00+07:00' },
  { row_id: 'r3', effective_date: '2025-09-01', shift_id: null, shift_name: '',
    start_time: null, end_time: null, is_overnight: false, shift_active: false,
    status: 'REMOVED', is_current: false, assigned_by: 'hr01', assigned_at: '2025-09-01T09:00:00+07:00' },
  { row_id: 'r2', effective_date: '2025-06-01', shift_id: 'sh-3', shift_name: 'กะดึก',
    start_time: '22:00:00', end_time: '07:00:00', is_overnight: true, shift_active: true,
    status: 'ACTIVE', is_current: false, assigned_by: 'hr01', assigned_at: '2025-06-01T09:00:00+07:00' }
];
let assignCalls = [], noShiftCalls = [], histCalls = [];

function serve(root, port) {
  const T = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.png': 'image/png' };
  return new Promise(function (r) {
    const s = http.createServer(function (rq, rs) {
      let p = decodeURIComponent(rq.url.split('?')[0]); if (p === '/') p = '/index.html';
      const f = path.join(root, p);
      if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { rs.writeHead(404); return rs.end(); }
      rs.writeHead(200, { 'Content-Type': T[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
      rs.end(fs.readFileSync(f));
    }).listen(port, function () { r(s); });
  });
}

(async function () {
  const srv = await serve(ROOT, PORT);
  const b = await chromium.launch(launchOpts());
  const errs = [], fixtureErrs = [];
  const ctx = await b.newContext({ viewport: { width: 1440, height: 900 }, serviceWorkers: 'block' });
  await ctx.route('**/rest/v1/rpc/*', function (route) {
    const fn = route.request().url().split('/rpc/')[1].split('?')[0];
    let bd = {}; try { bd = JSON.parse(route.request().postData() || '{}'); } catch (e) {}
    let out;
    if (fn === 'njhr_shift_list') out = SHIFTS;
    else if (fn === 'njhr_shift_employee_list') out = MEMBERS[bd.p_shift] || [];
    else if (fn === 'njhr_shift_unassigned_employees') out = UNASSIGNED;
    else if (fn === 'njhr_shift_no_shift_employees') out = [];
    else if (fn === 'njhr_shift_history') {
      histCalls.push(bd);
      out = HISTORY.filter(function (h) {
        if (bd.p_from && h.effective_date < bd.p_from) return false;
        if (bd.p_to && h.effective_date > bd.p_to) return false;
        return true;
      });
    } else if (fn === 'njhr_shift_assign_many') {
      assignCalls.push(bd);
      out = (bd.p_employees || []).map(function (id) { return { employee_id: id, result: 'ASSIGNED' }; });
    } else if (fn === 'njhr_shift_no_shift_set') {
      noShiftCalls.push(bd);
      out = (bd.p_employees || []).map(function (id) { return { employee_id: id, result: 'INSERTED' }; });
    } else if (fn === 'njhr_emp_list') out = [{ total_count: 7 }];
    else out = F.respond(fn, bd);
    route.fulfill({ status: 200, contentType: 'application/json',
      headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(out) });
  });
  await ctx.route('**/storage/v1/**', function (r) { r.fulfill({ status: 200, body: '{}' }); });
  const page = await ctx.newPage();
  page.on('pageerror', function (e) { errs.push('pageerror: ' + String(e.message)); });
  page.on('console', function (m) {
    const t = String(m.text());
    if (m.type() !== 'error') return;
    if (t.indexOf('403') >= 0 || t.indexOf('400') >= 0 || t.indexOf('404') >= 0) return;
    if (/njhr_dashboard_summary|DASHBOARD/.test(t)) { fixtureErrs.push(t); return; }
    errs.push(t);
  });

  await page.goto('http://127.0.0.1:' + PORT + '/index.html', { waitUntil: 'load' });
  await page.waitForFunction(function () { return !!document.getElementById('lg-user'); }, { timeout: 15000 });
  await page.evaluate(function () {
    document.getElementById('lg-user').value = 'admin';
    document.getElementById('lg-pass').value = 'Admin1234';
    document.getElementById('login-form').onsubmit({ preventDefault: function () {} });
  });
  await page.waitForTimeout(2500);
  await page.evaluate(function () { location.hash = '#/shifts'; });
  await page.waitForFunction(function () {
    return document.querySelectorAll('#sh-assigned .sh-tbl tbody tr').length > 0;
  }, { timeout: 25000 }).catch(function () {});
  await page.waitForTimeout(800);

  const s = await page.evaluate(function () {
    function txt(el) { return el ? el.innerText.replace(/\s+/g, ' ').trim() : ''; }
    const secs = [].slice.call(document.querySelectorAll('.sh-sec'));
    const unTbl = document.getElementById('shu-list');
    const asTbl = document.querySelector('#sh-assigned .sh-tbl table');
    function heads(t) {
      return t ? [].slice.call(t.querySelectorAll('thead th')).map(function (x) { return x.textContent.trim(); }) : [];
    }
    return {
      secTitles: secs.map(function (x) { return txt(x.querySelector('h3')); }),
      unBadge: txt(secs[0] && secs[0].querySelector('.badge')),
      unHeads: heads(unTbl), unRows: unTbl ? unTbl.querySelectorAll('tbody tr').length : 0,
      unStatusBadge: txt(document.querySelector('#shu-list .sh-t-warn')),
      hasUnSearch: !!document.getElementById('shu-q'),
      asBadge: txt(document.querySelector('#sh-assigned .badge')),
      asHeads: heads(asTbl), asRows: asTbl ? asTbl.querySelectorAll('tbody tr').length : 0,
      hasAsSearch: !!document.getElementById('sha-q'),
      shiftBadges: [].slice.call(document.querySelectorAll('#sh-assigned tbody .sh-badge'))
        .map(function (x) { return x.textContent.trim() + '|' + x.className.replace('sh-badge ', ''); }),
      moveBtns: document.querySelectorAll('[data-shmove]').length,
      histBtns: document.querySelectorAll('[data-shhist]').length,
      infoBtns: document.querySelectorAll('[data-shinfo]').length,
      histTitle: (document.querySelector('[data-shhist]') || {}).title || '',
      dropdown: [].slice.call(document.querySelectorAll('#shu-to option')).map(function (o) { return o.textContent.trim(); }),
      hasDate: !!document.getElementById('shu-date'),
      dateVal: (document.getElementById('shu-date') || {}).value || '',
      oldNsBtn: !!document.getElementById('shu-ns'), goBtn: txt(document.getElementById('shu-go')),
      noOverflow: document.documentElement.scrollWidth <= window.innerWidth + 1
    };
  });

  chk('1 · แยก 2 ส่วนชัดเจน',
    s.secTitles[0] === 'พนักงานที่ยังไม่ได้กำหนดกะ' && s.secTitles[1] === 'พนักงานที่มีกะใช้งานอยู่',
    s.secTitles.join(' / '));
  chk('2 · Badge จำนวนคนที่ยังไม่มีกะ', s.unBadge === '1 คน', s.unBadge);
  chk('3 · ตารางส่วนที่ 1 ครบคอลัมน์',
    s.unHeads.join('|') === '|พนักงาน|ตำแหน่ง|แผนก|สถานะ', s.unHeads.join('|'));
  chk('4 · มีแถวพนักงานที่ยังไม่มีกะ', s.unRows === 1, 'แถว=' + s.unRows);
  chk('5 · Badge สถานะ "ไม่ได้กำหนดกะ"', s.unStatusBadge === 'ไม่ได้กำหนดกะ', s.unStatusBadge);
  chk('6 · มีช่องค้นหาทั้ง 2 ส่วน', s.hasUnSearch && s.hasAsSearch, '');
  chk('7 · Badge จำนวนคนที่มีกะ', s.asBadge === '4 คน', s.asBadge);
  chk('8 · ตารางส่วนที่ 2 ครบคอลัมน์',
    s.asHeads.join('|') === 'พนักงาน|ตำแหน่ง|แผนก|กะปัจจุบัน|จัดการ', s.asHeads.join('|'));
  chk('9 · รวมพนักงานจากทุกกะครบ', s.asRows === 4, 'แถว=' + s.asRows);
  chk('10 · กะปัจจุบันแสดงชื่อ + เวลา', /กะเช้า \(08:00–17:00\)/.test(s.shiftBadges.join(' ')), '');
  chk('10b · กะเช้า/บ่าย/ดึก แยกสีกัน',
    /กะเช้า.*sh-t-green/.test(s.shiftBadges.join(' ')) &&
    /กะบ่าย.*sh-t-orange/.test(s.shiftBadges.join(' ')) &&
    /กะดึก.*sh-t-blue/.test(s.shiftBadges.join(' ')), s.shiftBadges.join(' , '));
  chk('11 · ปุ่มย้ายกะครบทุกแถว', s.moveBtns === 4, 'พบ ' + s.moveBtns);
  chk('11b · ปุ่มประวัติกะครบทุกแถว', s.histBtns === 4 && s.histTitle === 'ประวัติกะ',
    'พบ ' + s.histBtns + ' title=' + s.histTitle);
  chk('11c · ปุ่มดูรายละเอียดครบทุกแถว', s.infoBtns === 4, 'พบ ' + s.infoBtns);
  chk('12 · Dropdown มี “ไม่มีกะ” + กะจริงพร้อมเวลา',
    s.dropdown.length === 5 && s.dropdown[1] === 'ไม่มีกะ' &&
    /กะเช้า \(08:00–17:00\)/.test(s.dropdown[2]) &&
    /กะบ่าย \(13:00–22:00\)/.test(s.dropdown[3]) && /กะดึก \(22:00–07:00/.test(s.dropdown[4]),
    s.dropdown.join(' , '));
  chk('13 · มีช่องวันที่มีผล พร้อมค่าเริ่มต้น', s.hasDate && /^\d{4}-\d{2}-\d{2}$/.test(s.dateVal), s.dateVal);
  chk('14 · ไม่มีปุ่มแยก “ตั้งเป็นไม่ใช้กะ” ซ้ำอีก', !s.oldNsBtn && /ย้ายกะ/.test(s.goBtn), s.goBtn);
  chk('15 · ไม่มีจุดล้นแนวนอน', s.noOverflow, '');

  await page.evaluate(function () {
    const c = document.querySelector('.shu-pick');
    c.checked = true; c.dispatchEvent(new Event('change', { bubbles: true }));
  });
  await page.waitForTimeout(300);
  const cnt = await page.evaluate(function () {
    return { go: (document.getElementById('shu-n') || {}).textContent };
  });
  chk('16 · เลือก 1 คน → ปุ่มย้ายกะขึ้น (1)', cnt.go === '1', 'go=' + cnt.go);

  await page.evaluate(function () {
    document.getElementById('shu-to').value = 'sh-2';
    document.getElementById('shu-date').value = '2026-08-20';
    document.getElementById('shu-go').click();
  });
  await page.waitForTimeout(700);
  await page.evaluate(function () { const y = document.getElementById('cf-yes'); if (y) y.click(); });
  await page.waitForTimeout(1500);
  chk('17 · ย้ายเข้ากะยิง njhr_shift_assign_many ถูกต้อง',
    assignCalls.length === 1 && assignCalls[0].p_shift === 'sh-2' &&
    assignCalls[0].p_effective_date === '2026-08-20' &&
    (assignCalls[0].p_employees || []).join() === 'e-402',
    JSON.stringify(assignCalls[0] || {}).slice(0, 120));

  /* ---------- ย้ายกะรายคน ---------- */
  assignCalls = [];
  await page.evaluate(function () { document.querySelector('[data-shmove]').click(); });
  await page.waitForTimeout(700);
  const mv = await page.evaluate(function () {
    const body = document.querySelector('#modal-root .modal-body');
    const sel = document.getElementById('shmv-to');
    return { open: !!body, text: body ? body.innerText.replace(/\s+/g, ' ') : '',
      opts: sel ? [].slice.call(sel.options).map(function (o) { return o.textContent.trim(); }) : [],
      hasDate: !!document.getElementById('shmv-date'),
      foot: [].slice.call(document.querySelectorAll('#modal-root .modal-foot .btn'))
        .map(function (x) { return x.textContent.trim(); }) };
  });
  chk('18 · เปิดหน้าต่างย้ายกะรายคนได้', mv.open, '');
  chk('18b · แสดงพนักงาน + กะปัจจุบัน',
    /นายสมชาย ใจดี/.test(mv.text) && /0101/.test(mv.text) && /SUPERVISOR/.test(mv.text) &&
    /OPERATION/.test(mv.text) && /กะปัจจุบัน/.test(mv.text), mv.text.slice(0, 90));
  chk('18c · Dropdown มี “ไม่มีกะ” และไม่มีกะปัจจุบันซ้ำ',
    mv.opts.length === 4 && mv.opts.indexOf('ไม่มีกะ') >= 0 && mv.opts.join(' ').indexOf('กะเช้า') < 0, mv.opts.join(' , '));
  chk('18d · มีวันที่มีผล + ปุ่มยกเลิก/ย้ายกะ',
    mv.hasDate && mv.foot.length === 2 && /ยกเลิก/.test(mv.foot[0]) && /ย้ายกะ/.test(mv.foot[1]),
    mv.foot.join(' | '));
  await page.evaluate(function () {
    document.getElementById('shmv-to').value = 'sh-3';
    document.getElementById('shmv-date').value = '2026-09-01';
    document.getElementById('shmv-go').click();
  });
  await page.waitForSelector('#cf-yes', { timeout: 5000 });
  await page.click('#cf-yes');
  await page.waitForTimeout(1200);
  chk('19 · ย้ายกะรายคนยิง RPC เดิมถูกต้อง',
    assignCalls.length === 1 && assignCalls[0].p_shift === 'sh-3' &&
    assignCalls[0].p_effective_date === '2026-09-01' &&
    (assignCalls[0].p_employees || []).join() === 'e-101',
    JSON.stringify(assignCalls[0] || {}).slice(0, 120));

  /* ---------- ประวัติกะ ---------- */
  await page.waitForTimeout(600);
  histCalls = [];
  await page.evaluate(function () { document.querySelector('[data-shhist]').click(); });
  await page.waitForTimeout(1500);
  const hs = await page.evaluate(function () {
    const body = document.querySelector('#modal-root .modal-body');
    const tbl = document.querySelector('#shh-body table');
    return {
      open: !!body, title: (document.querySelector('#modal-root .modal-head h3') || {}).textContent || '',
      heads: tbl ? [].slice.call(tbl.querySelectorAll('thead th')).map(function (x) { return x.textContent.trim(); }) : [],
      rows: tbl ? tbl.querySelectorAll('tbody tr').length : 0,
      text: tbl ? tbl.innerText.replace(/\s+/g, ' ') : '',
      nowRows: document.querySelectorAll('#shh-body .sh-hist-now').length,
      hasFrom: !!document.getElementById('shh-from'), hasTo: !!document.getElementById('shh-to'),
      empText: body ? (body.querySelector('.fm-emp') || {}).innerText || '' : ''
    };
  });
  chk('20 · เปิด Modal ประวัติกะได้', hs.open && /ประวัติกะ/.test(hs.title), hs.title);
  chk('20b · เรียก njhr_shift_history ด้วย employee ที่ถูกต้อง',
    histCalls.length === 1 && histCalls[0].p_employee === 'e-101' && histCalls[0].p_limit === 200,
    JSON.stringify(histCalls[0] || {}).slice(0, 110));
  chk('20c · ตารางครบคอลัมน์ตาม Return type ของ RPC',
    hs.heads.join('|') === 'วันที่มีผล|กะ|เวลา|สถานะ|บันทึกโดย|บันทึกเมื่อ', hs.heads.join('|'));
  chk('20d · แสดงประวัติครบทุกแถว', hs.rows === 3, 'แถว=' + hs.rows);
  chk('20e · ไฮไลต์แถวที่ใช้อยู่ 1 แถว', hs.nowRows === 1 && /ใช้อยู่/.test(hs.text), 'ไฮไลต์=' + hs.nowRows);
  chk('20f · แปลสถานะเป็นภาษาไทย',
    /ใช้งานกะนี้/.test(hs.text) && /นำออกจากกะ/.test(hs.text), hs.text.slice(0, 90));
  chk('20g · แถวที่ไม่มีกะแสดง — ไม่ใช่ค่าว่าง', /—/.test(hs.text), '');
  chk('20h · มีตัวกรองช่วงวันที่', hs.hasFrom && hs.hasTo, '');
  chk('20i · แสดงชื่อพนักงานเจ้าของประวัติ', /นายสมชาย ใจดี/.test(hs.empText), hs.empText.replace(/\s+/g, ' '));

  histCalls = [];
  await page.evaluate(function () {
    document.getElementById('shh-from').value = '2025-01-01';
    document.getElementById('shh-to').value = '2025-12-31';
    document.getElementById('shh-go').click();
  });
  await page.waitForTimeout(1200);
  const hf = await page.evaluate(function () {
    const tbl = document.querySelector('#shh-body table');
    return { rows: tbl ? tbl.querySelectorAll('tbody tr').length : 0 };
  });
  chk('21 · กรองช่วงวันที่ส่ง p_from/p_to ถูกต้อง',
    histCalls.length === 1 && histCalls[0].p_from === '2025-01-01' && histCalls[0].p_to === '2025-12-31',
    JSON.stringify(histCalls[0] || {}).slice(0, 110));
  chk('21b · ผลลัพธ์ถูกกรองจริง', hf.rows === 2, 'แถว=' + hf.rows);

  await page.evaluate(function () {
    document.getElementById('shh-from').value = '2026-12-31';
    document.getElementById('shh-to').value = '2026-01-01';
    document.getElementById('shh-go').click();
  });
  await page.waitForTimeout(600);
  chk('22 · กันช่วงวันที่กลับด้าน',
    await page.evaluate(function () {
      return /วันที่เริ่มต้องไม่เกิน/.test((document.getElementById('shh-err') || {}).textContent || '');
    }), '');
  await page.evaluate(function () { NJHR.ui.closeModal(); });

  /* ---------- ดูรายละเอียด ---------- */
  await page.waitForTimeout(500);
  await page.evaluate(function () { document.querySelector('[data-shinfo]').click(); });
  await page.waitForTimeout(600);
  const info = await page.evaluate(function () {
    const body = document.querySelector('#modal-root .modal-body');
    return body ? body.innerText.replace(/\s+/g, ' ') : '';
  });
  chk('23 · ดูรายละเอียดแสดงข้อมูลครบ',
    /รหัสพนักงาน/.test(info) && /ตำแหน่ง/.test(info) && /แผนก/.test(info) &&
    /กะปัจจุบัน/.test(info) && /เริ่มใช้กะนี้/.test(info), info.slice(0, 90));
  await page.evaluate(function () { NJHR.ui.closeModal(); });

  /* ---------- ค้นหา + พับ ---------- */
  await page.waitForTimeout(400);
  await page.evaluate(function () {
    const i = document.getElementById('sha-q');
    i.value = 'WAREHOUSE'; i.dispatchEvent(new Event('input', { bubbles: true }));
  });
  await page.waitForTimeout(500);
  const search = await page.evaluate(function () {
    return { rows: document.querySelectorAll('#sh-assigned .sh-tbl tbody tr').length,
      text: (document.querySelector('#sh-assigned .sh-tbl') || {}).innerText || '',
      focused: document.activeElement && document.activeElement.id };
  });
  chk('24 · ค้นหาในส่วนที่ 2 กรองได้', search.rows === 1 && /เอกชัย/.test(search.text), 'แถว=' + search.rows);
  chk('24b · โฟกัสยังอยู่ในช่องค้นหา', search.focused === 'sha-q', 'focus=' + search.focused);

  await page.evaluate(function () { document.getElementById('sha-toggle').click(); });
  await page.waitForTimeout(400);
  const folded = await page.evaluate(function () {
    return { tbl: document.querySelectorAll('#sh-assigned .sh-tbl').length,
      btn: (document.getElementById('sha-toggle') || {}).innerText || '' };
  });
  chk('25 · พับส่วนที่ 2 ได้', folded.tbl === 0 && /แสดงรายชื่อ/.test(folded.btn), folded.btn.trim());

  chk('CONSOLE · ไม่มี unhandled error (ไม่นับ Fixture)', errs.length === 0, errs.slice(0, 3).join(' | '));

  console.log('\n========== สรุป ==========');
  console.log('PASS ' + PASS + ' · FAIL ' + FAIL);
  if (fixtureErrs.length) {
    console.log('UNRELATED (Existing/Fixture Issue) · njhr_dashboard_summary ไม่มีใน Mock Fixture · ' +
      fixtureErrs.length + ' ครั้ง — ไม่นับเป็น FAIL ของงานนี้');
  }
  await b.close(); srv.close();
  process.exit(FAIL ? 1 : 0);
})();
