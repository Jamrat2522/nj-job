/* reportall_layout_test.js — ตรวจหน้า REPORT ALL (#/reportall) บน Desktop
     · ไม่มี Card ใบใหญ่ครอบทั้งหน้า · ไม่มีหัวข้อซ้ำในเนื้อหา
     · ตัวกรองเต็มความกว้าง · EXPORT EXCEL ขวาสุด · KPI 4 ใบต่อแถว
     · KPI แต่ละใบยังมีกรอบ/พื้นขาว/เงา
     · Scope ด้วย .rp-page เท่านั้น — ไม่แตะ .card / .main-view / หน้าอื่น / มือถือ
   ใช้: node harness/reportall_layout_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(60) + (d || '')); }

const scss = fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8');
const min = scss.replace(/\s+/g, '');
const compat = fs.readFileSync(path.join(ROOT, 'compat/app-legacy.js'), 'utf8');
const rptm = fs.readFileSync(path.join(ROOT, 'views/reports/menu.js'), 'utf8');

/* ---- ตัดบล็อก @media (min-width:901px) ที่มีกฎ .rp-page ---- */
function deskBlock() {
  const key = '@mediascreenand(min-width:901px){';
  let i = -1;
  while ((i = min.indexOf(key, i + 1)) >= 0) {
    let d = 1, j = i + key.length;
    for (; j < min.length && d > 0; j++) {
      if (min[j] === '{') d++;
      else if (min[j] === '}') d--;
    }
    const body = min.slice(i + key.length, j - 1);
    if (body.indexOf('.rp-page') >= 0) return body;
  }
  return '';
}
const DESK = deskBlock();

/* ================= 1. ถอด Card ใบใหญ่ ================= */
console.log('\n== ถอด Card ใบใหญ่ ==');
chk('มีบล็อก Desktop สำหรับ .rp-page', DESK.length > 0, DESK.length + ' อักขระ');
chk('DOM ใส่ class rp-page บน Card ชั้นนอก', compat.indexOf('card rp-page') >= 0, '');
const outer = /\.main-view>\.rp-page\{([^}]*)\}/.exec(DESK);
chk('มีกฎ .main-view > .rp-page', !!outer, '');
if (outer) {
  const r = outer[1];
  /* clean-css ย่อ background: transparent เป็น background: 0 0 */
  chk('พื้นหลังโปร่งใส (ไม่มีการ์ดขาว)', /background:(transparent|00)/.test(r), '');
  chk('ไม่มีเส้นขอบ', r.indexOf('border:0') >= 0, '');
  chk('ไม่มีเงา', r.indexOf('box-shadow:none') >= 0, '');
  chk('ไม่มีมุมโค้ง', r.indexOf('border-radius:0') >= 0, '');
  chk('ไม่มี padding ของการ์ด', /padding:0[;}]/.test(r + '}'), '');
  chk('ไม่มี margin ของการ์ด', /margin:0[;}]/.test(r + '}'), '');
  chk('เต็มความกว้าง ไม่จำกัด max-width',
    r.indexOf('width:100%') >= 0 && r.indexOf('max-width:none') >= 0, '');
}
chk('ซ่อนหัวข้อซ้ำในเนื้อหา (.rp-page > .card-head)',
  DESK.indexOf('.rp-page>.card-head{display:none}') >= 0, '');
chk('ยังคง <h3>REPORT ALL</h3> ไว้ใน DOM (ไม่ลบ ไม่เปลี่ยนชื่อ)',
  compat.indexOf('<h3>REPORT ALL</h3>') >= 0, '');

/* ================= 2. ตัวกรองเต็มความกว้าง ================= */
console.log('\n== ตัวกรอง ==');
chk('.rp-filters เป็น flex เต็มความกว้าง',
  /\.rp-page\.rp-filters\{display:flex/.test(DESK) &&
  /\.rp-page\.rp-filters\{[^}]*width:100%/.test(DESK), '');
chk('Label อยู่ด้านบนเหมือนเดิม (align-items: flex-end)',
  /\.rp-page\.rp-filters\{[^}]*align-items:flex-end/.test(DESK), '');
chk('ไม่ตกบรรทัด (flex-wrap: nowrap)',
  /\.rp-page\.rp-filters\{[^}]*flex-wrap:nowrap/.test(DESK), '');
chk('ระยะห่างระหว่างช่อง 12px', /\.rp-page\.rp-filters\{[^}]*gap:12px/.test(DESK), '');
chk('ช่องพนักงานขยายตามพื้นที่ที่เหลือ',
  /\.rp-page\.rp-f-emp\{flex:11\d+px/.test(DESK), '');
chk('ช่องแผนกกว้าง ~280px (ไม่ยืดเกิน)',
  /\.rp-page\.rp-filters>\.rp-f:nth-of-type\(2\)\{flex:01280px/.test(DESK), '');
chk('ทุก input / select / ปุ่ม สูง 42px เท่ากัน',
  DESK.indexOf('min-height:42px') >= 0, '');
chk('EXPORT EXCEL ถูกดันไปขวาสุด',
  /\.rp-page\.rp-fbtns\{[^}]*margin-left:auto/.test(DESK), '');
/* เทียบลำดับภายในบล็อก .rp-fbtns เท่านั้น — id เหล่านี้ปรากฏที่อื่นในไฟล์ด้วย */
const fb = compat.slice(compat.indexOf('rp-fbtns'), compat.indexOf('rp-fbtns') + 400);
chk('ล้างตัวกรองอยู่ก่อน EXPORT EXCEL ใน DOM',
  fb.indexOf('rp-clear') >= 0 && fb.indexOf('rp-export') > fb.indexOf('rp-clear'), '');
chk('ปุ่มทั้งสองอยู่ในกลุ่ม .rp-fbtns เดียวกัน',
  fb.indexOf('EXPORT EXCEL') >= 0 && fb.indexOf('ล้างตัวกรอง') >= 0, '');

/* ================= 3. ระยะห่าง ================= */
console.log('\n== ระยะห่าง ==');
chk('ตัวกรอง → ช่วงวันที่ ~10px', /\.rp-page\.rptm-cycle\{margin:10px/.test(DESK), '');
chk('→ ชิปตัวกรอง ~10px', /\.rp-page\.rp-chips\{margin-top:10px/.test(DESK), '');
chk('ชิป → KPI ~14px', /\.rp-page\.rp-kpis\{margin-top:14px/.test(DESK), '');
chk('ไม่สร้าง max-width หรือ margin auto ให้ Container',
  DESK.indexOf('margin:0auto') < 0 && DESK.indexOf('max-width:1') < 0, '');

/* ================= 4. KPI ================= */
console.log('\n== KPI ==');
chk('KPI 4 ใบต่อแถว (Desktop)',
  min.indexOf('.rp-kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:12px') >= 0, '');
chk('KPI กว้างเต็ม Content', /\.rp-page\.rp-kpis\{[^}]*width:100%/.test(DESK), '');
chk('KPI แต่ละใบยังมีพื้นขาว', /\.rp-kpi\{[^}]*background:#fff/.test(min), '');
chk('KPI แต่ละใบยังมีเส้นขอบ', /\.rp-kpi\{[^}]*border:1pxsolidvar\(--line\)/.test(min), '');
chk('KPI แต่ละใบยังมีมุมโค้ง', /\.rp-kpi\{[^}]*border-radius:14px/.test(min), '');
chk('KPI แต่ละใบยังมีเงา', /\.rp-kpi\{[^}]*box-shadow:/.test(min), '');
chk('ไม่มีกฎถอดกรอบ KPI', DESK.indexOf('.rp-kpi{') < 0 && DESK.indexOf('.rp-kpi ') < 0, '');

/* ================= 5. Scope — ไม่กระทบส่วนกลาง/หน้าอื่น ================= */
console.log('\n== Scope ==');
chk('ทุกกฎในบล็อกนี้อยู่ใต้ .rp-page',
  DESK.split('}').filter(function (r) {
    const sel = r.split('{')[0];
    return sel.trim() && sel.indexOf('.rp-page') < 0;
  }).length === 0, '');
chk('ไม่แก้ .card ส่วนกลาง', /\.card\{background:var\(--card\)/.test(min) ||
  min.indexOf('.card{') >= 0, '');
chk('ไม่แก้ .main-view ส่วนกลาง',
  min.indexOf('.main-view{padding:20px24px40px;width:100%;max-width:none') >= 0, '');
chk('ไม่แตะ .rptm-filters ของ REPORT ลางาน/OT', DESK.indexOf('.rptm-filters') < 0, '');
chk('ไฟล์ REPORT ลางาน/OT ไม่เปลี่ยน (ยังมี rptm-filters เดิม)',
  rptm.indexOf('toolbar rptm-filters') >= 0, '');

/* ================= 6. มือถือไม่เปลี่ยน ================= */
console.log('\n== มือถือ ==');
chk('กฎมือถือ .rp-filters 2 คอลัมน์ ยังอยู่',
  min.indexOf('.rp-filters{grid-template-columns:1fr1fr') >= 0, '');
chk('กฎมือถือ .rp-fbtns เป็น grid ยังอยู่',
  min.indexOf('.rp-fbtns{display:grid;grid-template-columns:1fr1.4fr') >= 0, '');
chk('กฎมือถือ KPI 2 คอลัมน์ ยังอยู่',
  min.indexOf('.rp-kpis{grid-template-columns:1fr1fr') >= 0, '');
chk('กฎมือถือ KPI 1 คอลัมน์ (จอเล็ก) ยังอยู่',
  min.indexOf('.rp-kpis{grid-template-columns:1fr}') >= 0, '');
chk('กฎใหม่อยู่ใน @media min-width: 901px เท่านั้น',
  min.indexOf('.main-view>.rp-page') > min.indexOf('@mediascreenand(min-width:901px){'), '');

/* ================= 7. Logic / Export ไม่ถูกแตะ ================= */
console.log('\n== Logic และ Export ==');
['rp-ym', 'rp-dept', 'rp-q', 'rp-ac', 'rp-clear', 'rp-export', 'rp-cards', 'rp-status',
 'rp-err', 'rp-warn'].forEach(function (id) {
  chk('ยังมี element/Handler ' + id, compat.indexOf(id) >= 0, '');
});
chk('ระบบชิปตัวกรองยังครบ (rp-chips / rp-chip-x / data-rpclr)',
  compat.indexOf('rp-chips') >= 0 && compat.indexOf('rp-chip-x') >= 0 &&
  compat.indexOf('data-rpclr') >= 0, '');
chk('Export ยังใช้ชื่อ Sheet เดิม "REPORT ALL"', compat.indexOf('REPORT ALL') >= 0, '');
chk('ไม่มีการเปลี่ยน RPC ของ REPORT ALL',
  compat.indexOf('njhr_report_all_employees') >= 0 &&
  compat.indexOf('njhr_report_all_ot') >= 0, '');

console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
process.exit(FAIL ? 1 : 0);
