/* wht50_test.js — ตรวจ "รายงาน 50 ทวิ" รอบที่ 1 (เมนู · Route · หน้ารายการ · SQL ส่ง/เปิด)
     · เมนูอยู่กลุ่มรายงาน · Route ผูก view ถูก · สิทธิ์เฉพาะผู้ดูแล
     · ตารางแสดงข้อมูลจริงจาก njhr_wht50_send_list ไม่ hardcode
     · สถานะ 2 แกนแยกกัน (เอกสาร / การส่ง)
     · SQL 88 ไม่แก้ 87 และไม่แตะระบบอื่น
   ใช้: node harness/wht50_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(60) + (d || '')); }
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
  .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const tick = ms => new Promise(r => setTimeout(r, ms || 60));

const core = fs.readFileSync(path.join(ROOT, 'runtime/core.js'), 'utf8');
const flat = core.replace(/\s/g, '');
const menuJs = fs.readFileSync(path.join(ROOT, 'views/reports/menu.js'), 'utf8');
const sql88 = fs.readFileSync(path.join(ROOT, 'supabase-new/88_wht50_send.sql'), 'utf8');
const sql87 = fs.readFileSync(path.join(ROOT, 'supabase-new/87_wht50.sql'), 'utf8');

/* ================= 1. เมนูและ Route ================= */
console.log('\n== เมนูและ Route ==');
chk('มีเมนู "รายงาน 50 ทวิ"', core.indexOf('รายงาน 50 ทวิ') >= 0, '');
chk('เมนูอยู่กลุ่ม "รายงาน" (ไม่สร้างกลุ่มใหม่)',
  /key:"report"[\s\S]{0,700}รายงาน50ทวิ/.test(flat), '');
chk('ไม่สร้างกลุ่มเมนูหลักใหม่',
  (flat.match(/key:"(people|requests|money|report|system)"/g) || []).length === 5 &&
  flat.indexOf('key:"list"') < 0, '');
chk('เมนูผูกกับ Route #/rpt-wht', flat.indexOf('{r:"#/rpt-wht",t:"รายงาน50ทวิ"') >= 0, '');
chk('Route ผูกกับ view viewRptWht50',
  /"#\/rpt-wht":\{[^}]*view:"viewRptWht50"/.test(flat), '');
chk('Route อยู่ chunk report-menu เดิม',
  /"#\/rpt-wht":\{[^}]*mod:"report-menu"/.test(flat), '');
chk('สิทธิ์เฉพาะ SUPER_ADMIN / ADMIN',
  /"#\/rpt-wht":\{[^}]*roles:\["SUPER_ADMIN","ADMIN"\]/.test(flat), '');
chk('เมนูเดิมในกลุ่มรายงานยังครบ 5 รายการ',
  ['#/reports', '#/sso', '#/reportall', '#/rpt-leave', '#/rpt-ot']
    .every(function (r) { return flat.indexOf('{r:"' + r + '"') >= 0; }), '');

/* ================= 2. หน้ารายการ ================= */
console.log('\n== หน้ารายการ ==');
function env() {
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div>' +
    '<div id="modal-root"></div><div id="toasts"></div></body></html>');
  const win = dom.window;
  const calls = [];
  const ROWS = [
    { employee_id: 'e1', emp_code: '0001', full_name: 'นายจำรัส ผาเทพ', nickname: '',
      national_id_masked: '1-xxxx-xxx45-67', has_national_id: true, has_address: true,
      department_name: 'MANAGING DIRECTOR', position_name: 'MD', emp_status: 'ACTIVE',
      periods: 8, total_income: 480000, total_tax: 12500.5, total_sso: 6000,
      doc_id: 'd1', doc_no: 'WHT-2569-0001', doc_status: 'CONFIRMED',
      issue_date: '2026-12-31', amend_seq: 0,
      send_status: 'SENT', sent_at: '2026-12-31T10:00:00Z', sent_by: 'admin',
      opened_at: null, send_count: 1, is_ready: false },
    { employee_id: 'e2', emp_code: '0002', full_name: 'นางสาวมาลี ใจดี', nickname: 'มาลี',
      national_id_masked: '', has_national_id: false, has_address: false,
      department_name: 'ACCOUNT', position_name: '-', emp_status: 'ACTIVE',
      periods: 8, total_income: 240000, total_tax: 0, total_sso: 5400,
      doc_id: null, doc_no: '', doc_status: 'NONE', issue_date: null, amend_seq: 0,
      send_status: 'NOT_SENT', sent_at: null, sent_by: '', opened_at: null,
      send_count: 0, is_ready: false }
  ];
  const SUM = { total_emp: 2, ready: 0, already_sent: 1, opened: 0, no_doc: 1, incomplete: 1 };
  const NJHR = {
    state: { currentRoute: '#/rpt-wht' }, router: { navId: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    features: {}, views: { register: () => {} }, compat: { scope: {} }
  };
  Object.assign(NJHR.compat.scope, {
    icon: (n, c) => '<span class="ic ' + (c || '') + '" data-i="' + (n || '') + '"></span>',
    esc, debounce: f => f, emptyState: m => '<div class="empty">' + m + '</div>',
    todayISO: () => '2026-08-12', fmtDateDMY: v => String(v || ''),
    money: n => Number(n || 0).toFixed(2),
    statusBadge: s => '<span class="badge">' + s + '</span>',
    currentUser: () => ({ id: 'u1', username: 'admin', role: 'SUPER_ADMIN' }),
    currentEmp: () => ({ id: 'e1', code: '0001' }),
    dept: () => '—', audit: () => {}, toast: () => {},
    sbReady: () => true, sbToken: () => 'tok',
    sbRpc: (fn, body) => {
      calls.push({ fn, body });
      return Promise.resolve(fn === 'njhr_wht50_send_summary' ? SUM : {});
    },
    sbRpcList: (fn, body) => {
      calls.push({ fn, body });
      return Promise.resolve(fn === 'njhr_wht50_send_list' ? ROWS : []);
    },
    cycleRange: ym => ({ ym: ym, start: '2026-07-26', end: '2026-08-25', endExclusive: '2026-08-26' }),
    cycleCurrent: () => ({ ym: '2026-08', start: '2026-07-26', end: '2026-08-25', endExclusive: '2026-08-26' }),
    cycleLabel: ym => String(ym), cycleRangeText: () => '', cycleOptions: () => ['2026-08'],
    rptSafeName: v => String(v), lvType: c => ({ name: c }), lvNum: v => Number(v) || 0,
    LEAVE_TYPES: [], LV_STATUS_TH: {}, loadScriptOnce: () => Promise.resolve(),
    njAsset: p => p, withButtonLoading: (b, t, f) => f()
  });
  win.NJHR = NJHR;
  const ctx = vm.createContext(win);
  return { win, NJHR, calls, ROWS,
    run: rel => vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), ctx, { filename: rel }),
    host: () => win.document.getElementById('app'),
    doc: () => win.document };
}

async function page() {
  const E = env();
  let view = null;
  E.NJHR.views.register = (n, f) => { if (n === 'viewRptWht50') view = f; };
  E.run('runtime/shared/report-export.js');
  E.run('views/reports/menu.js');
  chk('chunk ลงทะเบียน viewRptWht50', typeof view === 'function', '');
  if (typeof view !== 'function') return;
  view(E.host());
  await tick(100);
  const doc = E.doc(), host = E.host();

  chk('มีคำอธิบายหน้าตามที่กำหนด',
    host.textContent.indexOf('จัดทำ ตรวจสอบ ดาวน์โหลด และส่งหนังสือรับรองการหักภาษี ณ ที่จ่ายให้พนักงาน') >= 0, '');
  /* ---- ตัวกรอง ---- */
  chk('มีตัวกรองปีภาษี', !!doc.getElementById('wht-year'), '');
  chk('มีช่องค้นหารหัส/ชื่อพนักงาน', !!doc.getElementById('wht-q'), '');
  chk('มีตัวกรองสถานะ', !!doc.getElementById('wht-send'), '');
  const opts = Array.from((doc.getElementById('wht-send') || {}).options || []).map(o => o.textContent);
  chk('สถานะครบ 4 ตัวเลือก (ทั้งหมด/ยังไม่ส่ง/ส่งแล้ว/เปิดแล้ว)',
    JSON.stringify(opts) === JSON.stringify(['ทั้งหมด', 'ยังไม่ส่ง', 'ส่งแล้ว', 'เปิดแล้ว']),
    opts.join(' | '));
  chk('ปีภาษีเริ่มต้นเป็นปีปัจจุบัน', doc.getElementById('wht-year').value === '2026',
    doc.getElementById('wht-year').value);
  chk('ปีภาษีแสดง พ.ศ. กำกับให้อ่านง่าย',
    (doc.getElementById('wht-year').options[0].textContent || '').indexOf('2569') >= 0,
    doc.getElementById('wht-year').options[0].textContent);

  /* ---- ดึงข้อมูลจริง ---- */
  const list = E.calls.filter(c => c.fn === 'njhr_wht50_send_list').slice(-1)[0];
  const sum = E.calls.filter(c => c.fn === 'njhr_wht50_send_summary').slice(-1)[0];
  chk('เรียก njhr_wht50_send_list ด้วยปีภาษีจริง', !!list && list.body.p_year === 2026,
    list ? String(list.body.p_year) : 'ไม่เรียก');
  chk('เรียก njhr_wht50_send_summary ด้วยปีเดียวกัน', !!sum && sum.body.p_year === 2026, '');
  chk('ส่ง token ไปด้วยทุกครั้ง', !!list && list.body.p_token === 'tok', '');

  /* ---- ตาราง ---- */
  const heads = Array.from(doc.querySelectorAll('#wht-table thead th')).map(t => t.textContent.trim());
  chk('หัวตารางครบตามที่กำหนด',
    JSON.stringify(heads) === JSON.stringify(['รหัสพนักงาน', 'ชื่อพนักงาน', 'แผนก',
      'รายได้รวม', 'ภาษีหัก ณ ที่จ่าย', 'สถานะเอกสาร', 'สถานะการส่ง', 'จัดการ']),
    heads.join(' | '));
  const rows = Array.from(doc.querySelectorAll('#wht-table tbody tr'))
    .map(tr => Array.from(tr.children).map(td => td.textContent.trim()));
  chk('แสดงครบทุกแถวจาก RPC', rows.length === 2, rows.length + '/2');
  if (rows.length === 2) {
    chk('รหัสพนักงานมาจากข้อมูลจริง', rows[0][0] === '0001', rows[0][0]);
    chk('รายได้รวมจัดรูปแบบเงิน', rows[0][3] === '480,000.00', rows[0][3]);
    chk('ภาษีหัก ณ ที่จ่ายจัดรูปแบบเงิน', rows[0][4] === '12,500.50', rows[0][4]);
    chk('สถานะเอกสารแปลเป็นไทย', rows[0][5].indexOf('ยืนยันแล้ว') === 0, rows[0][5]);
    chk('แสดงเลขที่เอกสารใต้สถานะ', rows[0][5].indexOf('WHT-2569-0001') > 0, rows[0][5]);
    chk('สถานะการส่งแปลเป็นไทย', rows[0][6].indexOf('ส่งแล้ว') === 0, rows[0][6]);
    chk('สถานะ 2 แกนแยกคอลัมน์กัน', rows[0][5] !== rows[0][6], '');
    chk('พนักงานที่ยังไม่มีเอกสาร → ยังไม่มีเอกสาร + ยังไม่ส่ง',
      rows[1][5].indexOf('ยังไม่มีเอกสาร') === 0 && rows[1][6].indexOf('ยังไม่ส่ง') === 0,
      rows[1][5] + ' / ' + rows[1][6]);
    chk('เตือนเมื่อไม่มีเลขประจำตัวประชาชน',
      rows[1][1].indexOf('ไม่มีเลขประจำตัวประชาชน') > 0, rows[1][1]);
    chk('ไม่มีข้อความ undefined / null / NaN',
      !/undefined|null|NaN/.test(doc.getElementById('wht-table').textContent), '');
  }

  /* ---- ตัวเลขสรุป ---- */
  const sumTxt = (doc.getElementById('wht-sum') || {}).textContent || '';
  [['พนักงานทั้งหมด', '2'], ['พร้อมส่ง', '0'], ['ส่งแล้ว', '1'],
   ['เปิดแล้ว', '0'], ['ยังไม่มีเอกสาร', '1'], ['ข้อมูลไม่ครบ', '1']].forEach(function (x) {
    chk('สรุป "' + x[0] + '" = ' + x[1], sumTxt.indexOf(x[0] + x[1]) >= 0, '');
  });

  /* ---- ปุ่มที่ยังไม่เปิดใช้ ---- */
  const acts = doc.querySelectorAll('#wht-table tbody tr:first-child .lvt-acts button');
  chk('มีปุ่มจัดการ 3 ปุ่ม (ดู / ดาวน์โหลด / ส่ง)', acts.length === 3, acts.length + '/3');
  chk('ปุ่มจัดการยังปิดอยู่ (รอบนี้เป็นหน้าอ่านอย่างเดียว)',
    Array.prototype.every.call(acts, b => b.disabled), '');
  chk('ปุ่มบอกเหตุผลตามที่กำหนด (ยังไม่ได้ตั้งค่าแบบฟอร์ม 50 ทวิ)',
    acts.length > 0 && (acts[0].getAttribute('title') || '').indexOf('ยังไม่ได้ตั้งค่าแบบฟอร์ม 50 ทวิ') > 0,
    acts.length ? acts[0].getAttribute('title') : '');
  const sa = doc.getElementById('wht-sendall');
  chk('มีปุ่ม "ส่งทั้งหมด" และยังปิดอยู่', !!sa && sa.disabled, '');
  chk('ปุ่มส่งทั้งหมดบอกเหตุผลเดียวกัน',
    !!sa && (sa.getAttribute('title') || '').indexOf('ยังไม่ได้ตั้งค่าแบบฟอร์ม 50 ทวิ') >= 0, '');
  chk('มีแถบแจ้งเหตุผลบนหน้า',
    (host.textContent || '').indexOf('ยังไม่ได้ตั้งค่าแบบฟอร์ม 50 ทวิ') >= 0, '');

  /* ---- ตัวกรองทำงาน ---- */
  const se = doc.getElementById('wht-send');
  se.value = 'NOT_SENT'; se.onchange.call(se);
  await tick(80);
  const l2 = E.calls.filter(c => c.fn === 'njhr_wht50_send_list').slice(-1)[0];
  chk('เลือกสถานะแล้วส่ง p_send_status ไป RPC', l2.body.p_send_status === 'NOT_SENT',
    String(l2.body.p_send_status));
  const ye = doc.getElementById('wht-year');
  ye.value = '2025'; ye.onchange.call(ye);
  await tick(80);
  const l3 = E.calls.filter(c => c.fn === 'njhr_wht50_send_list').slice(-1)[0];
  chk('เปลี่ยนปีภาษีแล้วโหลดใหม่ด้วยปีนั้น', l3.body.p_year === 2025, String(l3.body.p_year));
  doc.getElementById('wht-clear').onclick();
  await tick(80);
  chk('ล้างตัวกรองคืนปีปัจจุบันและล้างสถานะ',
    doc.getElementById('wht-year').value === '2026' &&
    doc.getElementById('wht-send').value === '', '');
}

/* ================= 3. SQL ================= */
function sqlChecks() {
  console.log('\n== SQL (88_wht50_send.sql) ==');
  chk('มี PREFLIGHT ตรวจว่ารัน 87 มาก่อน',
    sql88.indexOf("to_regclass('public.njhr_wht50') is null") >= 0 &&
    sql88.indexOf('ต้องรัน 87_wht50.sql ก่อน') >= 0, '');
  ['send_status', 'sent_at', 'sent_by', 'opened_at', 'send_error', 'send_count'].forEach(function (c) {
    chk('เพิ่มคอลัมน์ ' + c, new RegExp('add column if not exists\\s+' + c).test(sql88), '');
  });
  chk('ใช้ add column if not exists (รันซ้ำได้)',
    sql88.indexOf('add column if not exists') >= 0, '');
  chk('constraint สถานะการส่ง 3 ค่า',
    /check \(send_status in \('NOT_SENT','SENT','OPENED'\)\)/.test(sql88), '');
  chk('ไม่แตะ constraint สถานะเอกสารเดิม',
    sql88.indexOf('njhr_wht50_status_chk') >= 0 &&
    sql88.indexOf('drop constraint njhr_wht50_status_chk') < 0, '');
  chk('ไม่ DROP อะไรเลย', !/\bdrop\s+(table|column|function|constraint)\b/i.test(sql88), '');
  chk('มี RPC njhr_wht50_send_list', sql88.indexOf('function public.njhr_wht50_send_list') >= 0, '');
  chk('มี RPC njhr_wht50_send_summary', sql88.indexOf('function public.njhr_wht50_send_summary') >= 0, '');
  chk('ตรวจสิทธิ์ผ่าน njhr_wht50_guard (Role จากฐานข้อมูล)',
    (sql88.match(/njhr_wht50_guard/g) || []).length >= 2, '');
  chk('นับรายได้เฉพาะงวด CALCULATED / PAID (เหมือน 87)',
    sql88.indexOf("in ('CALCULATED','PAID')") >= 0 &&
    sql87.indexOf("in ('CALCULATED','PAID')") >= 0, '');
  chk('กรองด้วย period_year = ปีภาษี ไม่ข้ามปี',
    sql88.indexOf('p.period_year = p_year') >= 0, '');
  chk('ตัวเลขสรุปนับจากรายการชุดเดียวกัน (ไม่นับคนละที่)',
    /from public\.njhr_wht50_send_list\(p_token, p_year/.test(sql88), '');
  chk('เพิกถอนสิทธิ์ public ก่อน grant', sql88.indexOf('revoke all on function') >= 0, '');
  chk('บันทึกเวอร์ชัน schema', sql88.indexOf('njhr_schema_version') >= 0, '');
  chk('มี VERIFICATION ท้ายไฟล์', sql88.indexOf('VERIFICATION') >= 0, '');
  chk('87_wht50.sql ไม่ถูกแก้ (ยังมีวงจรเอกสารเดิมครบ)',
    ['DRAFT', 'CONFIRMED', 'CANCELLED', 'AMENDED'].every(function (x) {
      return sql87.indexOf("'" + x + "'") >= 0;
    }), '');
  chk('87 ยังไม่มีคอลัมน์การส่ง (แยกไฟล์จริง)',
    sql87.indexOf('send_status') < 0, '');
}

/* ================= 3b. SQL 89 — เชื่อมกับระบบเอกสารเดิม ================= */
function sql89() {
  console.log('\n== SQL (89_wht50_deliver.sql) ==');
  const q = fs.readFileSync(path.join(ROOT, 'supabase-new/89_wht50_deliver.sql'), 'utf8');
  chk('PREFLIGHT ตรวจครบ 4 อย่าง (87 · 60 · 88 · 67)',
    ['njhr_wht50', 'njhr_emp_documents', 'send_status', 'doc_meta']
      .every(function (x) { return q.indexOf(x) >= 0; }) &&
    (q.match(/raise exception 'PREFLIGHT/g) || []).length >= 4, '');
  chk('เพิ่ม WHT50 เข้า constraint โดยอ่านค่าเดิมจากฐานข้อมูล (ไม่เดารายชื่อ)',
    q.indexOf('pg_get_constraintdef') >= 0 && q.indexOf("regexp_matches") >= 0 &&
    q.indexOf("vals || 'WHT50'") >= 0, '');
  chk('หยุดถ้าอ่านประเภทเดิมไม่ได้ (ไม่เดา)',
    q.indexOf('อ่านรายชื่อประเภทเอกสารเดิมไม่ได้') >= 0, '');
  chk('ข้ามถ้ามี WHT50 อยู่แล้ว (รันซ้ำได้)', q.indexOf("'WHT50' = any(vals)") >= 0, '');
  chk('เพิ่มคอลัมน์ document_id', /add column if not exists document_id uuid/.test(q), '');
  chk('FK document_id → njhr_emp_documents ON DELETE SET NULL',
    /references public\.njhr_emp_documents\(id\) on delete set null/.test(q), '');
  chk('มี RPC njhr_wht50_send(text, uuid)',
    /function public\.njhr_wht50_send\(p_token text, p_id uuid\)/.test(q), '');
  ['CONFIRMED', 'employee_id', 'doc_no', 'national_id'].forEach(function (x) {
    chk('ตรวจเงื่อนไข ' + x + ' ก่อนส่ง', q.indexOf(x) >= 0, '');
  });
  chk('กันส่งซ้ำ → คืน ALREADY_SENT ไม่สร้างเอกสารใหม่',
    q.indexOf("'ALREADY_SENT'") >= 0 &&
    /if w\.document_id is not null or w\.send_status in \('SENT','OPENED'\)/.test(q), '');
  chk('ล็อกแถวกันส่งพร้อมกันสองเครื่อง (for update)', q.indexOf('for update') >= 0, '');
  chk('สร้างเอกสารด้วย doc_type = WHT50', q.indexOf("'WHT50', w.employee_id") >= 0, '');
  chk('สถานะเอกสารตอนสร้าง = SENT', q.indexOf("'SENT', false") >= 0, '');
  chk('ไม่บังคับลงนาม (requires_signature = false)', q.indexOf("'SENT', false") >= 0, '');
  ['wht50_id', 'tax_year', 'wht50_doc_no', 'amend_seq', 'form_type'].forEach(function (k) {
    chk('doc_meta มี ' + k, new RegExp("'" + k + "'").test(q), '');
  });
  chk('ไม่ duplicate ข้อมูลภาษีทั้งชุด (ไม่คัดลอก income_source/income_final)',
    q.indexOf('income_source') < 0 && q.indexOf('income_final') < 0, '');
  chk('ผูกกลับ document_id + send_status + sent_at + sent_by + send_count',
    /set document_id = v_doc[\s\S]{0,220}send_count  = coalesce\(send_count,0\) \+ 1/.test(q), '');
  chk('ทั้งชุดอยู่ใน Transaction เดียว (begin … commit)',
    q.indexOf('\nbegin;') >= 0 && q.indexOf('\ncommit;') >= 0, '');
  chk('แจ้งเตือนเฉพาะเจ้าของ (ผูก employee_id → app_users)',
    /where u\.employee_id = w\.employee_id/.test(q), '');
  chk('ไม่ยิงแจ้งเตือนให้ทุกคน', !/role.*in \('SUPER_ADMIN'/.test(q.slice(q.indexOf('notifications'))), '');
  chk('Audit action = WHT50_SEND', q.indexOf("'WHT50_SEND'") >= 0, '');
  /* Trigger sync OPENED */
  chk('มี Trigger sync สถานะเปิดแล้ว', q.indexOf('njhr_wht50_opened_trg') >= 0, '');
  chk('Trigger ทำงานเฉพาะ doc_type = WHT50',
    /if new\.doc_type = 'WHT50'/.test(q), '');
  chk('Trigger จุดเฉพาะตอนเปลี่ยนเป็น VIEWED ครั้งแรก',
    /new\.status = 'VIEWED' and coalesce\(old\.status,''\) <> 'VIEWED'/.test(q), '');
  chk('ไม่แก้ njhr_doc_view ของกลาง',
    q.indexOf('create or replace function public.njhr_doc_view') < 0, '');
  chk('ไม่เพิ่ม RLS policy แบบกว้าง', !/create policy/i.test(q), '');
  chk('ไม่ DROP ตาราง/คอลัมน์/ฟังก์ชันเดิม',
    !/drop\s+(table|column)\b/i.test(q) &&
    !/drop function (?!if exists public\.njhr_wht50)/i.test(q), '');
  chk('เพิกถอนสิทธิ์ public ก่อน grant', q.indexOf('revoke all on function public.njhr_wht50_send') >= 0, '');
  chk('มี VERIFICATION ท้ายไฟล์', q.indexOf('VERIFICATION') >= 0, '');

  /* ---- ดักบั๊กที่เคยเจอจริงบน Production ---- */
  chk('ต่อ array ด้วย array_append ไม่ใช่ || สตริง (กัน ERROR 22P02)',
    q.indexOf("array_append(vals, 'WHT50'::text)") >= 0 &&
    !/vals :=\s*vals \|\| '/.test(q), '');
  /* ตัดคอมเมนต์ออกก่อนตรวจ เพราะในคอมเมนต์มีตัวอย่างโค้ดผิดที่จงใจเขียนไว้เตือน */
  const qCode = q.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*--.*$/gm, '');
  chk('ไม่มีการต่อ text[] กับสตริงตรง ๆ ที่ใดในไฟล์',
    !/\b(vals|arr|list_arr)\s*\|\|\s*'[A-Za-z]/.test(qCode), '');
  /* เรียกฟังก์ชันช่วยให้ตรง signature จริงของระบบ */
  chk('njhr_doc_event เรียกครบ 5 อาร์กิวเมนต์ (doc · event · actor · role · detail)',
    /njhr_doc_event\(v_doc, 'SEND', c\.username, c\.role,/.test(q), '');
  chk('njhr_audit_write เรียกครบ 9 อาร์กิวเมนต์',
    /njhr_audit_write\(p_token, 'WHT50_SEND', 'wht50', 'njhr_wht50', w\.id::text,[\s\S]{0,220}null, null, null\)/.test(q), '');
  chk('njhr_wht50_guard เรียกด้วย p_write = true (การเขียน)',
    /njhr_wht50_guard\(p_token, true\)/.test(q), '');
  /* ทุกตัวแปรที่ประกาศต้องถูกใช้จริง — กันพิมพ์ชื่อผิด */
  ['cn', 'def', 'vals', 'list'].forEach(function (v) {
    chk('ตัวแปร ' + v + ' ถูกใช้จริงในบล็อก constraint',
      (q.match(new RegExp('\\b' + v + '\\b', 'g')) || []).length >= 2, '');
  });
}

/* ================= 3c. ฝั่งพนักงาน ================= */
function empSide() {
  console.log('\n== เอกสารของฉัน (ฝั่งพนักงาน) ==');
  const meta = fs.readFileSync(path.join(ROOT, 'runtime/shared/hr-meta.js'), 'utf8');
  chk('ลงทะเบียนประเภทเอกสาร WHT50', meta.indexOf('WHT50') >= 0, '');
  chk('มีชื่อภาษาไทยของ 50 ทวิ', meta.indexOf('50 ทวิ') >= 0, '');
  chk('ประเภทเอกสารเดิมยังครบ 8 ชนิด',
    ['CONTRACT', 'WARNING', 'SUSPENSION', 'PROBATION_RESULT', 'COE',
     'SALARY_CERT', 'SEPARATION', 'CONTRACT_PROBATION']
      .every(function (c) { return meta.indexOf(c) >= 0; }), '');
  chk('สถานะ SENT / VIEWED มีคำแปลไทยอยู่แล้ว',
    meta.indexOf('ส่งแล้ว') >= 0 && meta.indexOf('เปิดอ่านแล้ว') >= 0, '');
}

/* ================= 4. ไม่กระทบส่วนอื่น ================= */
function scope() {
  console.log('\n== ไม่กระทบส่วนอื่น ==');
  chk('รายงานการลา/โอที ยังอยู่ในไฟล์เดียวกัน',
    menuJs.indexOf('viewRptLeave') >= 0 && menuJs.indexOf('viewRptOT') >= 0, '');
  chk('ไม่แตะ RPC ของรายงานเดิม',
    menuJs.indexOf('njhr_rpt_leave_list') >= 0 && menuJs.indexOf('njhr_rpt_ot_list') >= 0, '');
  chk('ไม่เรียก RPC ของโมดูลอื่นในหน้านี้',
    !/njhr_(leave|ot|att|payroll)_/.test(menuJs.slice(menuJs.indexOf('viewRptWht50'))), '');
  /* "ดูตัวอย่าง" เป็นชื่อปุ่ม ไม่ใช่ข้อมูลตัวอย่าง — ตรวจที่ค่าข้อมูลแทน */
  const whtPart = menuJs.slice(menuJs.indexOf('WHT_SEND_TH'));
  chk('ไม่มีข้อมูลตัวอย่างฝังในโค้ด (ไม่ hardcode)',
    !/emp_code:\s*['"]\d{4}['"]/.test(whtPart) &&
    !/total_income:\s*\d/.test(whtPart) &&
    !/full_name:\s*['"]/.test(whtPart), '');
  chk('ทุกค่าที่แสดงอ่านจากแถวที่ RPC คืนมา (r.*)',
    /r\.emp_code/.test(whtPart) && /r\.total_income/.test(whtPart) &&
    /r\.total_tax/.test(whtPart) && /r\.send_status/.test(whtPart), '');
  const css = fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8');
  chk('CSS ใหม่ scope ใต้ .wht- / .lvt-wht เท่านั้น',
    css.indexOf('.wht-sum') >= 0 && css.indexOf('.lvt-wht') >= 0, '');
  chk('ไม่แก้ .lvt ส่วนกลาง',
    css.replace(/\s+/g, '').indexOf('.lvt{width:100%') >= 0 ||
    css.indexOf('.lvt ') >= 0, '');
}

(async function () {
  await page();
  sqlChecks();
  sql89();
  empSide();
  scope();
  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
