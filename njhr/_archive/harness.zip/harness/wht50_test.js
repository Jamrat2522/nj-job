/* wht50_test.js — ตรวจ "รายงาน 50 ทวิ" รอบที่ 1 (เมนู · Route · หน้ารายการ · SQL ส่ง/เปิด)
     · เมนูอยู่กลุ่มรายงาน · Route ผูก view ถูก · สิทธิ์เฉพาะผู้ดูแล
     · ตารางแสดงข้อมูลจริงจาก njhr_wht50_send_list ไม่ hardcode
     · สถานะ 2 แกนแยกกัน (เอกสาร / การส่ง)
     · SQL 88 ไม่แก้ 87 และไม่แตะระบบอื่น
   ใช้: node harness/wht50_test.js [ทางโปรเจกต์] */
'use strict';
const fs = require('fs'), path = require('path'), vm = require('vm');
const { JSDOM } = require('jsdom');
const ROOT = path.resolve(process.argv[2] || '.');

let PASS = 0, FAIL = 0;
function chk(n, ok, d) { ok ? PASS++ : FAIL++; console.log((ok ? 'PASS  ' : 'FAIL  ') + n.padEnd(60) + (d || '')); }
const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
  .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const tick = ms => new Promise(r => setTimeout(r, ms || 60));

const core = fs.readFileSync(path.join(ROOT, 'runtime/core.js'), 'utf8');
const flat = core.replace(/\s/g, '');
const menuJs = fs.readFileSync(path.join(ROOT, 'views/reports/menu.js'), 'utf8');
const sql88 = fs.readFileSync(path.join(ROOT, 'supabase-new/88_wht50_send.sql'), 'utf8');
const sql87 = fs.readFileSync(path.join(ROOT, 'supabase-new/87_wht50.sql'), 'utf8');

/* ================= 1. เมนูและ Route ================= */
console.log('\n== เมนูและ Route ==');
chk('มีเมนู "รายงาน 50 ทวิ"', core.indexOf('รายงาน 50 ทวิ') >= 0, '');
chk('เมนูอยู่กลุ่ม "รายงาน" (ไม่สร้างกลุ่มใหม่)',
  /key:"report"[\s\S]{0,700}รายงาน50ทวิ/.test(flat), '');
chk('ไม่สร้างกลุ่มเมนูหลักใหม่',
  (flat.match(/key:"(people|requests|money|report|system)"/g) || []).length === 5 &&
  flat.indexOf('key:"list"') < 0, '');
chk('เมนูผูกกับ Route #/rpt-wht', flat.indexOf('{r:"#/rpt-wht",t:"รายงาน50ทวิ"') >= 0, '');
chk('Route ผูกกับ view viewRptWht50',
  /"#\/rpt-wht":\{[^}]*view:"viewRptWht50"/.test(flat), '');
chk('Route อยู่ chunk report-menu เดิม',
  /"#\/rpt-wht":\{[^}]*mod:"report-menu"/.test(flat), '');
chk('สิทธิ์เฉพาะ SUPER_ADMIN / ADMIN',
  /"#\/rpt-wht":\{[^}]*roles:\["SUPER_ADMIN","ADMIN"\]/.test(flat), '');
chk('เมนูเดิมในกลุ่มรายงานยังครบ 5 รายการ',
  ['#/reports', '#/sso', '#/reportall', '#/rpt-leave', '#/rpt-ot']
    .every(function (r) { return flat.indexOf('{r:"' + r + '"') >= 0; }), '');

/* ================= 2. หน้ารายการ ================= */
console.log('\n== หน้ารายการ ==');
function env() {
  const dom = new JSDOM('<!doctype html><html><body><div id="app"></div>' +
    '<div id="modal-root"></div><div id="toasts"></div></body></html>');
  const win = dom.window;
  const calls = [];
  const ROWS = [
    { employee_id: 'e1', emp_code: '0001', full_name: 'นายจำรัส ผาเทพ', nickname: '',
      national_id_masked: '1-xxxx-xxx45-67', has_national_id: true, has_address: true,
      department_name: 'MANAGING DIRECTOR', position_name: 'MD', emp_status: 'ACTIVE',
      periods: 8, total_income: 480000, total_tax: 12500.5, total_sso: 6000,
      wht50_id: 'w1', document_id: 'd1', doc_no: 'WHT-2569-0001', doc_status: 'CONFIRMED',
      issue_date: '2026-12-31', amend_seq: 0,
      send_status: 'SENT', sent_at: '2026-12-31T10:00:00Z', sent_by: 'admin',
      opened_at: null, send_count: 1, is_ready: false },
    { employee_id: 'e2', emp_code: '0002', full_name: 'นางสาวมาลี ใจดี', nickname: 'มาลี',
      national_id_masked: '', has_national_id: false, has_address: false,
      department_name: 'ACCOUNT', position_name: '-', emp_status: 'ACTIVE',
      periods: 8, total_income: 240000, total_tax: 0, total_sso: 5400,
      wht50_id: null, document_id: null, doc_no: '', doc_status: 'NONE', issue_date: null, amend_seq: 0,
      send_status: 'NOT_SENT', sent_at: null, sent_by: '', opened_at: null,
      send_count: 0, is_ready: false }
  ];
  const SUM = { total_emp: 2, ready: 0, already_sent: 1, opened: 0, no_doc: 1, incomplete: 1 };
  const NJHR = {
    state: { currentRoute: '#/rpt-wht' }, router: { navId: () => 1, moduleMap: {} },
    modules: { isLoaded: () => true, load: () => Promise.resolve() },
    features: {}, views: { register: () => {} }, compat: { scope: {} }
  };
  Object.assign(NJHR.compat.scope, {
    icon: (n, c) => '<span class="ic ' + (c || '') + '" data-i="' + (n || '') + '"></span>',
    esc, debounce: f => f, emptyState: m => '<div class="empty">' + m + '</div>',
    todayISO: () => '2026-08-12', fmtDateDMY: v => String(v || ''),
    money: n => Number(n || 0).toFixed(2),
    statusBadge: s => '<span class="badge">' + s + '</span>',
    currentUser: () => ({ id: 'u1', username: 'admin', role: 'SUPER_ADMIN' }),
    currentEmp: () => ({ id: 'e1', code: '0001' }),
    dept: () => '—', audit: () => {}, toast: () => {},
    sbReady: () => true, sbToken: () => 'tok',
    sbRpc: (fn, body) => {
      calls.push({ fn, body });
      return Promise.resolve(fn === 'njhr_wht50_send_summary' ? SUM : {});
    },
    sbRpcList: (fn, body) => {
      calls.push({ fn, body });
      return Promise.resolve(fn === 'njhr_wht50_send_list' ? ROWS : []);
    },
    cycleRange: ym => ({ ym: ym, start: '2026-07-26', end: '2026-08-25', endExclusive: '2026-08-26' }),
    cycleCurrent: () => ({ ym: '2026-08', start: '2026-07-26', end: '2026-08-25', endExclusive: '2026-08-26' }),
    cycleLabel: ym => String(ym), cycleRangeText: () => '', cycleOptions: () => ['2026-08'],
    rptSafeName: v => String(v), lvType: c => ({ name: c }), lvNum: v => Number(v) || 0,
    LEAVE_TYPES: [], LV_STATUS_TH: {}, loadScriptOnce: () => Promise.resolve(),
    njAsset: p => p, withButtonLoading: (b, t, f) => f()
  });
  win.NJHR = NJHR;
  const ctx = vm.createContext(win);
  return { win, NJHR, calls, ROWS,
    run: rel => vm.runInContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), ctx, { filename: rel }),
    host: () => win.document.getElementById('app'),
    doc: () => win.document };
}

async function page() {
  const E = env();
  let view = null;
  E.NJHR.views.register = (n, f) => { if (n === 'viewRptWht50') view = f; };
  E.run('runtime/shared/report-export.js');
  E.run('views/reports/menu.js');
  chk('chunk ลงทะเบียน viewRptWht50', typeof view === 'function', '');
  if (typeof view !== 'function') return;
  view(E.host());
  await tick(100);
  const doc = E.doc(), host = E.host();

  chk('มีคำอธิบายหน้าตามที่กำหนด',
    host.textContent.indexOf('จัดทำ ตรวจสอบ ดาวน์โหลด และส่งหนังสือรับรองการหักภาษี ณ ที่จ่ายให้พนักงาน') >= 0, '');
  /* ---- ตัวกรอง ---- */
  chk('มีตัวกรองปีภาษี', !!doc.getElementById('wht-year'), '');
  chk('มีช่องค้นหารหัส/ชื่อพนักงาน', !!doc.getElementById('wht-q'), '');
  chk('มีตัวกรองสถานะ', !!doc.getElementById('wht-send'), '');
  const opts = Array.from((doc.getElementById('wht-send') || {}).options || []).map(o => o.textContent);
  chk('สถานะครบ 4 ตัวเลือก (ทั้งหมด/ยังไม่ส่ง/ส่งแล้ว/เปิดแล้ว)',
    JSON.stringify(opts) === JSON.stringify(['ทั้งหมด', 'ยังไม่ส่ง', 'ส่งแล้ว', 'เปิดแล้ว']),
    opts.join(' | '));
  chk('ปีภาษีเริ่มต้นเป็นปีปัจจุบัน', doc.getElementById('wht-year').value === '2026',
    doc.getElementById('wht-year').value);
  chk('ปีภาษีแสดง พ.ศ. กำกับให้อ่านง่าย',
    (doc.getElementById('wht-year').options[0].textContent || '').indexOf('2569') >= 0,
    doc.getElementById('wht-year').options[0].textContent);

  /* ---- ดึงข้อมูลจริง ---- */
  const list = E.calls.filter(c => c.fn === 'njhr_wht50_send_list').slice(-1)[0];
  const sum = E.calls.filter(c => c.fn === 'njhr_wht50_send_summary').slice(-1)[0];
  chk('เรียก njhr_wht50_send_list ด้วยปีภาษีจริง', !!list && list.body.p_year === 2026,
    list ? String(list.body.p_year) : 'ไม่เรียก');
  chk('เรียก njhr_wht50_send_summary ด้วยปีเดียวกัน', !!sum && sum.body.p_year === 2026, '');
  chk('ส่ง token ไปด้วยทุกครั้ง', !!list && list.body.p_token === 'tok', '');

  /* ---- ตาราง ---- */
  const heads = Array.from(doc.querySelectorAll('#wht-table thead th')).map(t => t.textContent.trim());
  chk('หัวตารางครบตามที่กำหนด',
    JSON.stringify(heads) === JSON.stringify(['', 'รหัสพนักงาน', 'ชื่อพนักงาน', 'แผนก',
      'รายได้รวม', 'ภาษีหัก ณ ที่จ่าย', 'สถานะเอกสาร', 'สถานะการส่ง', 'จัดการ']),
    heads.join(' | '));
  const rows = Array.from(doc.querySelectorAll('#wht-table tbody tr'))
    .map(tr => Array.from(tr.children).map(td => td.textContent.trim()));
  chk('แสดงครบทุกแถวจาก RPC', rows.length === 2, rows.length + '/2');
  if (rows.length === 2) {
    chk('รหัสพนักงานมาจากข้อมูลจริง', rows[0][1] === '0001', rows[0][0]);
    chk('รายได้รวมจัดรูปแบบเงิน', rows[0][4] === '480,000.00', rows[0][7]);
    chk('ภาษีหัก ณ ที่จ่ายจัดรูปแบบเงิน', rows[0][5] === '12,500.50', rows[0][7]);
    chk('สถานะเอกสารแปลเป็นไทย', rows[0][6].indexOf('ยืนยันแล้ว') === 0, rows[0][7]);
    chk('แสดงเลขที่เอกสารใต้สถานะ', rows[0][6].indexOf('WHT-2569-0001') > 0, rows[0][7]);
    chk('สถานะการส่งแปลเป็นไทย', rows[0][7].indexOf('ส่งแล้ว') === 0, rows[0][7]);
    chk('สถานะ 2 แกนแยกคอลัมน์กัน', rows[0][6] !== rows[0][7], '');
    chk('พนักงานที่ยังไม่มีเอกสาร → ยังไม่มีเอกสาร + ยังไม่ส่ง',
      rows[1][6].indexOf('ยังไม่มีเอกสาร') === 0 && rows[1][7].indexOf('ยังไม่ส่ง') === 0,
      rows[1][6] + ' / ' + rows[1][7]);
    chk('เตือนเมื่อไม่มีเลขประจำตัวประชาชน',
      rows[1][2].indexOf('ไม่มีเลขประจำตัวประชาชน') > 0, rows[1][2]);
    chk('ไม่มีข้อความ undefined / null / NaN',
      !/undefined|null|NaN/.test(doc.getElementById('wht-table').textContent), '');
  }

  /* ---- ตัวเลขสรุป ---- */
  const sumTxt = (doc.getElementById('wht-sum') || {}).textContent || '';
  [['พนักงานทั้งหมด', '2'], ['พร้อมส่ง', '0'], ['ส่งแล้ว', '1'],
   ['เปิดแล้ว', '0'], ['ยังไม่มีเอกสาร', '1'], ['ข้อมูลไม่ครบ', '1']].forEach(function (x) {
    chk('สรุป "' + x[0] + '" = ' + x[1], sumTxt.indexOf(x[0] + x[1]) >= 0, '');
  });

  /* ---- ปุ่มที่ยังไม่เปิดใช้ ---- */
  /* ---- ปุ่มจัดการตามสถานะเอกสาร ---- */
  const acts = doc.querySelectorAll('#wht-table tbody tr:first-child .lvt-acts button');
  /* ส่งแล้ว → ดู · สร้าง PDF · ดาวน์โหลด (ไม่มีปุ่มส่งซ้ำ) */
  chk('แถวที่ส่งแล้ว: ดู + สร้าง PDF + ดาวน์โหลด (ไม่มีปุ่มส่งซ้ำ)',
    acts.length === 3, acts.length + '/3');
  chk('แถวที่ส่งแล้วไม่มีปุ่มส่งซ้ำ',
    !Array.prototype.some.call(acts, function (b) { return b.hasAttribute('data-wht-send'); }), '');
  chk('ปุ่มดูตัวอย่างเปิดได้เมื่อมีเอกสารแล้ว', acts.length >= 1 && !acts[0].disabled, '');
  chk('ปุ่มดูตัวอย่างใช้ wht50_id',
    acts.length >= 1 && acts[0].getAttribute('data-wht-view') === 'w1',
    acts.length ? acts[0].getAttribute('data-wht-view') : '');
  const dl2 = Array.prototype.filter.call(acts, function (b) { return b.hasAttribute('data-wht-dl'); })[0];
  chk('ปุ่มดาวน์โหลดใช้ document_id (ไม่ใช่ wht50_id)',
    !!dl2 && dl2.getAttribute('data-wht-dl') === 'd1',
    dl2 ? dl2.getAttribute('data-wht-dl') : 'ไม่พบ');
  chk('ปุ่มดาวน์โหลดยังปิดอยู่ (Feature Gate)', !!dl2 && dl2.disabled, '');
  chk('ปุ่มที่ปิดอยู่บอกเหตุผล',
    acts.length >= 2 &&
    (acts[1].getAttribute('title') || '').indexOf('ยังไม่ได้ตั้งค่าแบบฟอร์ม 50 ทวิ') > 0,
    acts.length >= 2 ? acts[1].getAttribute('title') : '');
  /* แถวที่ยังไม่มีเอกสาร → ปุ่มสร้างร่าง */
  const acts2 = doc.querySelectorAll('#wht-table tbody tr:nth-child(2) .lvt-acts button');
  chk('แถวที่ยังไม่มีเอกสาร: มีปุ่มสร้างร่าง 1 ปุ่ม', acts2.length === 1, acts2.length + '/1');
  chk('ปุ่มสร้างร่างใช้ employee_id',
    acts2.length === 1 && acts2[0].getAttribute('data-wht-draft') === 'e2',
    acts2.length ? acts2[0].getAttribute('data-wht-draft') : '');
  chk('ปุ่มสร้างร่างกดได้', acts2.length === 1 && !acts2[0].disabled, '');
  const sa = doc.getElementById('wht-sendall');
  chk('มีปุ่ม "ส่งทั้งหมด" และยังปิดอยู่', !!sa && sa.disabled, '');
  chk('ปุ่มส่งทั้งหมดบอกเหตุผลเดียวกัน',
    !!sa && (sa.getAttribute('title') || '').indexOf('ยังไม่ได้ตั้งค่าแบบฟอร์ม 50 ทวิ') >= 0, '');
  chk('มีแถบแจ้งเหตุผลบนหน้า',
    (host.textContent || '').indexOf('ยังไม่ได้ตั้งค่าแบบฟอร์ม 50 ทวิ') >= 0, '');

  /* ---- ตัวกรองทำงาน ---- */
  const se = doc.getElementById('wht-send');
  se.value = 'NOT_SENT'; se.onchange.call(se);
  await tick(80);
  const l2 = E.calls.filter(c => c.fn === 'njhr_wht50_send_list').slice(-1)[0];
  chk('เลือกสถานะแล้วส่ง p_send_status ไป RPC', l2.body.p_send_status === 'NOT_SENT',
    String(l2.body.p_send_status));
  const ye = doc.getElementById('wht-year');
  ye.value = '2025'; ye.onchange.call(ye);
  await tick(80);
  const l3 = E.calls.filter(c => c.fn === 'njhr_wht50_send_list').slice(-1)[0];
  chk('เปลี่ยนปีภาษีแล้วโหลดใหม่ด้วยปีนั้น', l3.body.p_year === 2025, String(l3.body.p_year));
  doc.getElementById('wht-clear').onclick();
  await tick(80);
  chk('ล้างตัวกรองคืนปีปัจจุบันและล้างสถานะ',
    doc.getElementById('wht-year').value === '2026' &&
    doc.getElementById('wht-send').value === '', '');
}

/* ================= 3. SQL ================= */
function sqlChecks() {
  console.log('\n== SQL (88_wht50_send.sql) ==');
  chk('มี PREFLIGHT ตรวจว่ารัน 87 มาก่อน',
    sql88.indexOf("to_regclass('public.njhr_wht50') is null") >= 0 &&
    sql88.indexOf('ต้องรัน 87_wht50.sql ก่อน') >= 0, '');
  ['send_status', 'sent_at', 'sent_by', 'opened_at', 'send_error', 'send_count'].forEach(function (c) {
    chk('เพิ่มคอลัมน์ ' + c, new RegExp('add column if not exists\\s+' + c).test(sql88), '');
  });
  chk('ใช้ add column if not exists (รันซ้ำได้)',
    sql88.indexOf('add column if not exists') >= 0, '');
  chk('constraint สถานะการส่ง 3 ค่า',
    /check \(send_status in \('NOT_SENT','SENT','OPENED'\)\)/.test(sql88), '');
  chk('ไม่แตะ constraint สถานะเอกสารเดิม',
    sql88.indexOf('njhr_wht50_status_chk') >= 0 &&
    sql88.indexOf('drop constraint njhr_wht50_status_chk') < 0, '');
  chk('ไม่ DROP อะไรเลย', !/\bdrop\s+(table|column|function|constraint)\b/i.test(sql88), '');
  chk('มี RPC njhr_wht50_send_list', sql88.indexOf('function public.njhr_wht50_send_list') >= 0, '');
  chk('มี RPC njhr_wht50_send_summary', sql88.indexOf('function public.njhr_wht50_send_summary') >= 0, '');
  chk('ตรวจสิทธิ์ผ่าน njhr_wht50_guard (Role จากฐานข้อมูล)',
    (sql88.match(/njhr_wht50_guard/g) || []).length >= 2, '');
  chk('นับรายได้เฉพาะงวด CALCULATED / PAID (เหมือน 87)',
    sql88.indexOf("in ('CALCULATED','PAID')") >= 0 &&
    sql87.indexOf("in ('CALCULATED','PAID')") >= 0, '');
  chk('กรองด้วย period_year = ปีภาษี ไม่ข้ามปี',
    sql88.indexOf('p.period_year = p_year') >= 0, '');
  chk('ตัวเลขสรุปนับจากรายการชุดเดียวกัน (ไม่นับคนละที่)',
    /from public\.njhr_wht50_send_list\(p_token, p_year/.test(sql88), '');
  chk('เพิกถอนสิทธิ์ public ก่อน grant', sql88.indexOf('revoke all on function') >= 0, '');
  chk('บันทึกเวอร์ชัน schema', sql88.indexOf('njhr_schema_version') >= 0, '');
  chk('มี VERIFICATION ท้ายไฟล์', sql88.indexOf('VERIFICATION') >= 0, '');
  chk('87_wht50.sql ไม่ถูกแก้ (ยังมีวงจรเอกสารเดิมครบ)',
    ['DRAFT', 'CONFIRMED', 'CANCELLED', 'AMENDED'].every(function (x) {
      return sql87.indexOf("'" + x + "'") >= 0;
    }), '');
  chk('87 ยังไม่มีคอลัมน์การส่ง (แยกไฟล์จริง)',
    sql87.indexOf('send_status') < 0, '');
}

/* ================= 3b. SQL 89 — เชื่อมกับระบบเอกสารเดิม ================= */
function sql89() {
  console.log('\n== SQL (89_wht50_deliver.sql) ==');
  const q = fs.readFileSync(path.join(ROOT, 'supabase-new/89_wht50_deliver.sql'), 'utf8');
  chk('PREFLIGHT ตรวจครบ 4 อย่าง (87 · 60 · 88 · 67)',
    ['njhr_wht50', 'njhr_emp_documents', 'send_status', 'doc_meta']
      .every(function (x) { return q.indexOf(x) >= 0; }) &&
    (q.match(/raise exception 'PREFLIGHT/g) || []).length >= 4, '');
  chk('เพิ่ม WHT50 เข้า constraint โดยอ่านค่าเดิมจากฐานข้อมูล (ไม่เดารายชื่อ)',
    q.indexOf('pg_get_constraintdef') >= 0 && q.indexOf("regexp_matches") >= 0 &&
    q.indexOf("vals || 'WHT50'") >= 0, '');
  chk('หยุดถ้าอ่านประเภทเดิมไม่ได้ (ไม่เดา)',
    q.indexOf('อ่านรายชื่อประเภทเอกสารเดิมไม่ได้') >= 0, '');
  chk('ข้ามถ้ามี WHT50 อยู่แล้ว (รันซ้ำได้)', q.indexOf("'WHT50' = any(vals)") >= 0, '');
  chk('เพิ่มคอลัมน์ document_id', /add column if not exists document_id uuid/.test(q), '');
  chk('FK document_id → njhr_emp_documents ON DELETE SET NULL',
    /references public\.njhr_emp_documents\(id\) on delete set null/.test(q), '');
  chk('มี RPC njhr_wht50_send(text, uuid)',
    /function public\.njhr_wht50_send\(p_token text, p_id uuid\)/.test(q), '');
  ['CONFIRMED', 'employee_id', 'doc_no', 'national_id'].forEach(function (x) {
    chk('ตรวจเงื่อนไข ' + x + ' ก่อนส่ง', q.indexOf(x) >= 0, '');
  });
  chk('กันส่งซ้ำ → คืน ALREADY_SENT ไม่สร้างเอกสารใหม่',
    q.indexOf("'ALREADY_SENT'") >= 0 &&
    /if w\.document_id is not null or w\.send_status in \('SENT','OPENED'\)/.test(q), '');
  chk('ล็อกแถวกันส่งพร้อมกันสองเครื่อง (for update)', q.indexOf('for update') >= 0, '');
  chk('สร้างเอกสารด้วย doc_type = WHT50', q.indexOf("'WHT50', w.employee_id") >= 0, '');
  chk('สถานะเอกสารตอนสร้าง = SENT', q.indexOf("'SENT', false") >= 0, '');
  chk('ไม่บังคับลงนาม (requires_signature = false)', q.indexOf("'SENT', false") >= 0, '');
  ['wht50_id', 'tax_year', 'wht50_doc_no', 'amend_seq', 'form_type'].forEach(function (k) {
    chk('doc_meta มี ' + k, new RegExp("'" + k + "'").test(q), '');
  });
  chk('ไม่ duplicate ข้อมูลภาษีทั้งชุด (ไม่คัดลอก income_source/income_final)',
    q.indexOf('income_source') < 0 && q.indexOf('income_final') < 0, '');
  chk('ผูกกลับ document_id + send_status + sent_at + sent_by + send_count',
    /set document_id = v_doc[\s\S]{0,220}send_count  = coalesce\(send_count,0\) \+ 1/.test(q), '');
  chk('ทั้งชุดอยู่ใน Transaction เดียว (begin … commit)',
    q.indexOf('\nbegin;') >= 0 && q.indexOf('\ncommit;') >= 0, '');
  chk('แจ้งเตือนเฉพาะเจ้าของ (ผูก employee_id → app_users)',
    /where u\.employee_id = w\.employee_id/.test(q), '');
  chk('ไม่ยิงแจ้งเตือนให้ทุกคน', !/role.*in \('SUPER_ADMIN'/.test(q.slice(q.indexOf('notifications'))), '');
  chk('Audit action = WHT50_SEND', q.indexOf("'WHT50_SEND'") >= 0, '');
  /* Trigger sync OPENED */
  chk('มี Trigger sync สถานะเปิดแล้ว', q.indexOf('njhr_wht50_opened_trg') >= 0, '');
  chk('Trigger ทำงานเฉพาะ doc_type = WHT50',
    /if new\.doc_type = 'WHT50'/.test(q), '');
  chk('Trigger จุดเฉพาะตอนเปลี่ยนเป็น VIEWED ครั้งแรก',
    /new\.status = 'VIEWED' and coalesce\(old\.status,''\) <> 'VIEWED'/.test(q), '');
  chk('ไม่แก้ njhr_doc_view ของกลาง',
    q.indexOf('create or replace function public.njhr_doc_view') < 0, '');
  chk('ไม่เพิ่ม RLS policy แบบกว้าง', !/create policy/i.test(q), '');
  chk('ไม่ DROP ตาราง/คอลัมน์/ฟังก์ชันเดิม',
    !/drop\s+(table|column)\b/i.test(q) &&
    !/drop function (?!if exists public\.njhr_wht50)/i.test(q), '');
  chk('เพิกถอนสิทธิ์ public ก่อน grant', q.indexOf('revoke all on function public.njhr_wht50_send') >= 0, '');
  chk('มี VERIFICATION ท้ายไฟล์', q.indexOf('VERIFICATION') >= 0, '');

  /* ---- ดักบั๊กที่เคยเจอจริงบน Production ---- */
  chk('ต่อ array ด้วย array_append ไม่ใช่ || สตริง (กัน ERROR 22P02)',
    q.indexOf("array_append(vals, 'WHT50'::text)") >= 0 &&
    !/vals :=\s*vals \|\| '/.test(q), '');
  /* ตัดคอมเมนต์ออกก่อนตรวจ เพราะในคอมเมนต์มีตัวอย่างโค้ดผิดที่จงใจเขียนไว้เตือน */
  const qCode = q.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*--.*$/gm, '');
  chk('ไม่มีการต่อ text[] กับสตริงตรง ๆ ที่ใดในไฟล์',
    !/\b(vals|arr|list_arr)\s*\|\|\s*'[A-Za-z]/.test(qCode), '');
  /* เรียกฟังก์ชันช่วยให้ตรง signature จริงของระบบ */
  chk('njhr_doc_event เรียกครบ 5 อาร์กิวเมนต์ (doc · event · actor · role · detail)',
    /njhr_doc_event\(v_doc, 'SEND', c\.username, c\.role,/.test(q), '');
  chk('njhr_audit_write เรียกครบ 9 อาร์กิวเมนต์',
    /njhr_audit_write\(p_token, 'WHT50_SEND', 'wht50', 'njhr_wht50', w\.id::text,[\s\S]{0,220}null, null, null\)/.test(q), '');
  chk('njhr_wht50_guard เรียกด้วย p_write = true (การเขียน)',
    /njhr_wht50_guard\(p_token, true\)/.test(q), '');
  /* ทุกตัวแปรที่ประกาศต้องถูกใช้จริง — กันพิมพ์ชื่อผิด */
  ['cn', 'def', 'vals', 'list'].forEach(function (v) {
    chk('ตัวแปร ' + v + ' ถูกใช้จริงในบล็อก constraint',
      (q.match(new RegExp('\\b' + v + '\\b', 'g')) || []).length >= 2, '');
  });
}

/* ================= 3c. ฝั่งพนักงาน ================= */
function empSide() {
  console.log('\n== เอกสารของฉัน (ฝั่งพนักงาน) ==');
  const meta = fs.readFileSync(path.join(ROOT, 'runtime/shared/hr-meta.js'), 'utf8');
  chk('ลงทะเบียนประเภทเอกสาร WHT50', meta.indexOf('WHT50') >= 0, '');
  chk('มีชื่อภาษาไทยของ 50 ทวิ', meta.indexOf('50 ทวิ') >= 0, '');
  chk('ประเภทเอกสารเดิมยังครบ 8 ชนิด',
    ['CONTRACT', 'WARNING', 'SUSPENSION', 'PROBATION_RESULT', 'COE',
     'SALARY_CERT', 'SEPARATION', 'CONTRACT_PROBATION']
      .every(function (c) { return meta.indexOf(c) >= 0; }), '');
  chk('สถานะ SENT / VIEWED มีคำแปลไทยอยู่แล้ว',
    meta.indexOf('ส่งแล้ว') >= 0 && meta.indexOf('เปิดอ่านแล้ว') >= 0, '');
}

/* ================= 3d. เอกสารของฉัน — พฤติกรรมเฉพาะ 50 ทวิ ================= */
function empWht50() {
  console.log('\n== เอกสารของฉัน · การ์ด 50 ทวิ ==');
  const doc = fs.readFileSync(path.join(ROOT, 'views/profile/main.js'), 'utf8');
  chk('มีตัวแยกประเภท 50 ทวิ (docIsWht50)', doc.indexOf('docIsWht50') >= 0, '');
  chk('50 ทวิ ไม่นับเป็น "รอดำเนินการ"',
    /docMyIsPending\(r\)\{if\(docIsWht50\(r\)\)return!1/.test(doc.replace(/\s/g, '')) ||
    /if\s*\(docIsWht50\(r\)\)\s*return false/.test(doc), '');
  chk('SENT → "ยังไม่ได้เปิด"', doc.indexOf('ยังไม่ได้เปิด') >= 0, '');
  chk('VIEWED → "เปิดแล้ว"', doc.indexOf('เปิดแล้ว') >= 0, '');
  chk('การ์ด 50 ทวิ แสดงปีภาษี (แปลงเป็น พ.ศ.)',
    doc.indexOf('50 ทวิ ประจำปีภาษี') >= 0 && doc.indexOf('543') >= 0, '');
  chk('การ์ดแสดง "วันที่ได้รับ"', doc.indexOf('วันที่ได้รับ') >= 0, '');
  chk('มีปุ่ม ดูเอกสาร และ ดาวน์โหลด', doc.indexOf('data-doc-dl') >= 0 &&
    doc.indexOf('data-doc-open') >= 0, '');
  chk('ปุ่มดาวน์โหลดใช้ docPdfDownload เดิม (Signed URL ตรวจสิทธิ์ที่ Server)',
    /docPdfDownload\(dl\.dataset\.docDl/.test(doc.replace(/\s/g, '')) ||
    doc.indexOf('docPdfDownload(dl.dataset.docDl') >= 0, '');
  chk('ไม่มีปุ่มรับทราบ/ลงนามในการ์ด 50 ทวิ',
    doc.indexOf('doc-wht50') >= 0, '');
  /* คำว่า "รอรับทราบ" ต้องไม่มีทางเกิดกับ WHT50 */
  const st = doc.slice(doc.indexOf('docMyStateText'), doc.indexOf('docMyStateText') + 700);
  chk('เส้นทาง 50 ทวิ ถูกตรวจก่อนคำว่า "รอรับทราบ"',
    st.indexOf('docIsWht50') >= 0 && st.indexOf('docIsWht50') < st.indexOf('รอรับทราบ'), '');
  /* เอกสารเดิมต้องไม่เปลี่ยน */
  chk('เอกสารประเภทอื่นยังใช้ "รอรับทราบ" / "รอลงนาม" เหมือนเดิม',
    doc.indexOf('รอรับทราบ') >= 0 && doc.indexOf('รอลงนาม') >= 0, '');

  console.log('\n== ฟอร์มสร้างเอกสาร HR ==');
  /* โค้ดถูก minify แล้ว ช่องว่างหายและเครื่องหมายคำพูดเปลี่ยนเป็น " */
  chk('WHT50 ถูกตัดออกจาก Dropdown สร้างเอกสาร',
    doc.replace(/\s/g, '').indexOf('DOC_TYPES.filter(function(t){returnt.code!=="WHT50"})') >= 0, '');
  chk('WHT50 ยังอยู่ใน Dropdown ตัวกรองประเภท (ไว้ค้นหา)',
    (doc.match(/DOC_TYPES\.map/g) || []).length >= 1, '');
  const meta = fs.readFileSync(path.join(ROOT, 'runtime/shared/hr-meta.js'), 'utf8');
  chk('WHT50 ยังอยู่ใน DOC_TYPES (ใช้ชื่อ/ไอคอน)', meta.indexOf('WHT50') >= 0, '');
}

/* ================= 3e. Renderer 50 ทวิ ================= */
function renderer() {
  console.log('\n== Renderer (edge-functions/njhr-doc-pdf/wht50.ts) ==');
  const f = path.join(ROOT, 'edge-functions/njhr-doc-pdf/wht50.ts');
  chk('มีไฟล์ Renderer แยกต่างหาก', fs.existsSync(f), '');
  if (!fs.existsSync(f)) return;
  const r = fs.readFileSync(f, 'utf8');
  chk('อ้างแหล่งแบบฟอร์มของกรมสรรพากร (ไม่ได้วาดจากความจำ)',
    r.indexOf('rd.go.th') >= 0 && r.indexOf('ฉบับที่ 131') >= 0, '');
  chk('มี buildWht50Pdf()', r.indexOf('export async function buildWht50Pdf') >= 0, '');
  chk('มี buildWht50Model() เป็น Layout Definition กลาง',
    r.indexOf('export function buildWht50Model') >= 0, '');
  /* ถ้อยคำตามแบบทางการ */
  [['ฉบับที่ 1', 'สำหรับผู้ถูกหักภาษี ณ ที่จ่ายใช้แนบพร้อมกับแบบแสดงรายการ'],
   ['ฉบับที่ 2', 'สำหรับผู้ถูกหักภาษี ณ ที่จ่ายเก็บไว้เป็นหลักฐาน'],
   ['ชื่อเอกสาร', 'หนังสือรับรองการหักภาษี ณ ที่จ่าย'],
   ['อ้างมาตรา', 'ตามมาตรา 50 ทวิ แห่งประมวลรัษฎากร'],
   ['คำรับรอง', 'ขอรับรองว่าข้อความและตัวเลขดังกล่าวข้างต้นถูกต้องตรงกับความจริงทุกประการ'],
   ['ผู้จ่ายเงิน', 'ผู้จ่ายเงิน'], ['รวมยอด', 'รวมเงินที่จ่ายและภาษีที่หักนำส่ง'],
   ['ตัวอักษร', 'รวมเงินภาษีที่หักนำส่ง (ตัวอักษร)']].forEach(function (x) {
    chk('ถ้อยคำตามแบบ: ' + x[0], r.indexOf(x[1]) >= 0, '');
  });
  ['ภ.ง.ด.1ก', 'ภ.ง.ด.1ก พิเศษ', 'ภ.ง.ด.2', 'ภ.ง.ด.3', 'ภ.ง.ด.2ก', 'ภ.ง.ด.3ก', 'ภ.ง.ด.53']
    .forEach(function (t) { chk('มี checkbox ' + t, r.indexOf('"' + t + '"') >= 0, ''); });
  ['เงินเดือน ค่าจ้าง เบี้ยเลี้ยง โบนัส ฯลฯ ตามมาตรา 40 (1)',
   'ค่าธรรมเนียม ค่านายหน้า ฯลฯ ตามมาตรา 40 (2)',
   'ค่าแห่งลิขสิทธิ์ หรือสิทธิอย่างอื่น ฯลฯ ตามมาตรา 40 (3)',
   'ตามมาตรา 40 (4)', 'มาตรา 3 เตรส', 'เงินได้นอกจาก 1. – 5.']
    .forEach(function (t) { chk('รายการเงินได้: ' + t.slice(0, 28), r.indexOf(t) >= 0, ''); });
  ['หัก ณ ที่จ่าย', 'ออกให้ตลอดไป', 'ออกให้ครั้งเดียว', 'อื่น ๆ']
    .forEach(function (t) { chk('ประเภทการออกภาษี: ' + t, r.indexOf('"' + t + '"') >= 0, ''); });
  ['กบข./กสจ./กองทุนสงเคราะห์ครูโรงเรียนเอกชน', 'กองทุนประกันสังคม', 'กองทุนสำรองเลี้ยงชีพ']
    .forEach(function (t) { chk('กองทุน: ' + t.slice(0, 20), r.indexOf(t) >= 0, ''); });
  /* Snapshot field */
  ['payer_snapshot', 'payee_snapshot', 'income_final', 'income_section', 'total_income',
   'total_tax', 'total_sso', 'total_pvd', 'form_type', 'doc_no', 'book_no', 'issue_date',
   'signer_name', 'signer_position', 'amend_seq'].forEach(function (k) {
    chk('ใช้ Snapshot field ' + k, r.indexOf(k) >= 0, '');
  });
  /* ตัดคอมเมนต์ออกก่อน เพราะหัวไฟล์เขียนเตือนว่า "ห้ามใช้ ...body" ไว้ */
  const rCode = r.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  chk('ไม่ใช้ body เป็นแหล่งข้อมูล',
    rCode.indexOf('snap.body') < 0 && rCode.indexOf('.body') < 0, '');
  chk('ไม่ hardcode ทุกเอกสารเป็น 40(1)',
    r.indexOf('income_section') >= 0 && !/byKey\["40_1"\]\s*=/.test(r), '');
  chk('ไม่มีข้อมูลตัวอย่างฝังในไฟล์',
    !/สมชาย|ทดสอบ|example\.com|123456789/.test(r), '');
  chk('มีการตรวจข้อมูลไม่ครบก่อนออกเอกสาร (validateWht50Model)',
    r.indexOf('validateWht50Model') >= 0 &&
    r.indexOf('payer_snapshot.company_name') >= 0 &&
    r.indexOf('payee_snapshot.national_id') >= 0, '');
  chk('ออก 2 ฉบับตามที่กรมสรรพากรกำหนด',
    /for \(const copyLabel of m\.copyLabels\)/.test(r) &&
    (r.match(/ฉบับที่ 1|ฉบับที่ 2/g) || []).length >= 2, '');
  chk('ฝังฟอนต์แบบไม่ subset (กันสระ/วรรณยุกต์หาย)', r.indexOf('subset: false') >= 0, '');
  chk('มีตัวแปลงจำนวนเงินเป็นตัวอักษรไทย', r.indexOf('export function bahtText') >= 0, '');

  console.log('\n== Branch ใน Edge Function ==');
  const idx = fs.readFileSync(path.join(ROOT, 'edge-functions/njhr-doc-pdf/index.ts'), 'utf8');
  chk('import buildWht50Pdf', idx.indexOf('import { buildWht50Pdf') >= 0, '');
  chk('แยกทางด้วย doc_type === "WHT50"', idx.indexOf('=== "WHT50"') >= 0, '');
  chk('เอกสารประเภทอื่นยังใช้ buildFinalPdf เดิม', idx.indexOf('buildFinalPdf(snap') >= 0, '');
  chk('WHT50 ไม่บังคับต้องมี ack', /!isWht50 && !snap\?\.ack/.test(idx), '');
  chk('pdf.ts เดิมไม่ถูกแก้ (ยังมี buildFinalPdf)',
    fs.readFileSync(path.join(ROOT, 'edge-functions/njhr-doc-pdf/pdf.ts'), 'utf8')
      .indexOf('export async function buildFinalPdf') >= 0, '');
  const fonts = fs.readdirSync(path.join(ROOT, 'edge-functions/njhr-doc-pdf/fonts'));
  chk('มีไฟล์ฟอนต์ไทยครบทั้ง Regular และ Bold',
    fonts.indexOf('Prompt-Regular.ttf') >= 0 && fonts.indexOf('Prompt-Bold.ttf') >= 0,
    fonts.join(', '));
  chk('แนบสัญญาอนุญาต OFL มาด้วย', fonts.indexOf('OFL.txt') >= 0, '');
}

/* ================= 3f. SQL 90 (ยังไม่ได้รัน) ================= */
function sql90() {
  console.log('\n== SQL PDF Pipeline (90_wht50_pdf.sql) ==');
  const f = path.join(ROOT, 'supabase-new/90_wht50_pdf.sql');
  chk('มีไฟล์ Migration', fs.existsSync(f), '');
  if (!fs.existsSync(f)) return;
  const q = fs.readFileSync(f, 'utf8');
  chk('ระบุชัดว่ายังไม่ได้รัน', q.indexOf('ยังไม่ได้รัน') >= 0, '');
  /* เลือกทางเดียว: เพิ่ม branch WHT50 ใน generic RPC ที่ Edge Function เรียกอยู่แล้ว
     ไม่สร้าง RPC แยกที่ไม่มีใครเรียก */
  chk('ไม่สร้าง RPC แยกที่ Edge Function ไม่ได้เรียก',
    q.indexOf('njhr_wht50_pdf_claim') < 0 && q.indexOf('njhr_wht50_pdf_commit') < 0, '');
  chk('เพิ่ม branch ใน njhr_doc_pdf_claim เดิม',
    q.indexOf('create or replace function public.njhr_doc_pdf_claim') >= 0, '');
  chk('เพิ่ม branch ใน njhr_doc_pdf_commit เดิม',
    q.indexOf('create or replace function public.njhr_doc_pdf_commit') >= 0, '');
  chk('เงื่อนไข: doc_type = WHT50', q.indexOf("d.doc_type = 'WHT50'") >= 0, '');
  chk('เงื่อนไข: njhr_wht50.status = CONFIRMED', q.indexOf("w.status <> 'CONFIRMED'") >= 0, '');
  chk('ผูกด้วย document_id = p_id', q.indexOf('where document_id = p_id') >= 0, '');
  chk('เอกสารอื่นยังบังคับ ACK/SIGN เหมือนเดิม',
    q.indexOf("d.status not in ('ACKNOWLEDGED','SIGNED')") >= 0, '');
  chk('WHT50 ไม่บังคับ ACK/SIGN — ใช้ SENT/VIEWED',
    q.indexOf("d.status not in ('SENT','VIEWED')") >= 0, '');
  chk('WHT50 ไม่ต้องมีแถวรับทราบ (ข้าม njhr_emp_doc_acks)',
    /if d\.doc_type = 'WHT50' then[\s\S]{0,2000}return;\s*\n  end if;[\s\S]{0,400}njhr_emp_doc_acks/.test(q), '');
  /* ตัดคอมเมนต์ก่อนตรวจ เพราะหัวไฟล์มี changelog ที่อ้างชื่อเดิมที่แก้ไปแล้ว */
  const qC = q.split('\n').filter(function (l) { return !/^\s*--/.test(l); }).join('\n');
  chk('final_pdf_status ใช้ PENDING ไม่ใช่ BUILDING',
    qC.indexOf("final_pdf_status = 'PENDING'") >= 0 && qC.indexOf("'BUILDING'") < 0, '');
  chk('ใช้ final_pdf_bytes ไม่ใช่ final_pdf_size', qC.indexOf('final_pdf_size') < 0, '');
  chk('ใช้ seq_no ไม่ใช่ seq_in_form',
    qC.indexOf("'seq_no', w.seq_no") >= 0 && qC.indexOf('seq_in_form') < 0, '');
  chk('ใช้ c.app_user_id ไม่ใช่ c.user_id', qC.indexOf('c.user_id') < 0, '');
  /* payer_mode/total_gpf เหลืออยู่แค่ในคอมเมนต์ changelog ที่อธิบายว่าเคยผิด
     ส่วน tax_payment_mode เป็นคอลัมน์ที่ไฟล์นี้เพิ่มเองพร้อม CHECK จึงถูกต้อง */
  chk('ไม่อ้างคอลัมน์ที่ Production ไม่มีโดยไม่เพิ่มให้',
    qC.indexOf('payer_mode') < 0 && qC.indexOf('total_gpf') < 0 &&
    qC.indexOf('add column if not exists tax_payment_mode') >= 0, '');
  chk('Snapshot มาจาก njhr_wht50 ไม่ใช่ body',
    q.indexOf("'wht50', jsonb_build_object") >= 0, '');
  /* Claim Data ครบตามที่กำหนด */
  ['id', 'tax_year', 'doc_no', 'book_no', 'seq_no', 'form_type', 'income_section',
   'payer_snapshot', 'payee_snapshot', 'income_final', 'total_income', 'total_tax',
   'total_sso', 'total_pvd', 'issue_date', 'signer_name', 'signer_position', 'amend_seq']
    .forEach(function (k) {
      chk('Claim คืน ' + k, new RegExp("'" + k + "',\\s*w\\." + k).test(q), '');
    });
  chk('READY แล้วคืน already_ready ไม่สร้างซ้ำ',
    q.indexOf('already_ready') >= 0 || q.indexOf('select false, true,') >= 0, '');
  /* แยก wht50_id / document_id */
  chk('send_list คืน wht50_id และ document_id แยกกัน',
    q.indexOf('wht50_id uuid, document_id uuid') >= 0, '');
  chk('DROP ก่อน CREATE เพราะเปลี่ยนชนิดผลลัพธ์',
    q.indexOf('drop function if exists public.njhr_wht50_send_list') >= 0, '');
  chk('มี PREFLIGHT และ VERIFICATION',
    q.indexOf('PREFLIGHT') >= 0 && q.indexOf('VERIFICATION') >= 0, '');
}

/* ================= 3g. Feature Gate + Bulk Send ================= */
function gateBulk() {
  console.log('\n== Feature Gate และ Bulk Send ==');
  const m = fs.readFileSync(path.join(ROOT, 'views/reports/menu.js'), 'utf8');
  chk('มี Feature Gate WHT_PDF_READY', m.indexOf('WHT_PDF_READY') >= 0, '');
  chk('Gate ค่าเริ่มต้นเป็น false', m.indexOf('WHT_PDF_READY=false') >= 0, '');
  chk('Batch = 25 รายการ', /WHT_BATCH\s*=\s*25/.test(m.replace(/\s/g, ' ')), '');
  chk('มี Checkbox เลือกทั้งหมด', m.indexOf('wht-all') >= 0, '');
  chk('มี Checkbox รายแถว', m.indexOf('data-wht-pick') >= 0, '');
  chk('แสดง "เลือกแล้ว X รายการ"', m.indexOf('เลือกแล้ว ') >= 0, '');
  chk('มีปุ่มส่งรายการที่เลือก', m.indexOf('ส่งรายการที่เลือก') >= 0, '');
  chk('มีปุ่มส่งทั้งหมด', m.indexOf('ส่งทั้งหมด') >= 0, '');
  chk('Confirm Modal ใช้ตัวเลขจาก summary ไม่ hardcode',
    m.indexOf('sum.total_emp') >= 0, '');
  chk('Progress "กำลังส่ง X / Y"', m.indexOf('กำลังส่ง ') >= 0, '');
  chk('สรุปแยก ส่งสำเร็จ / ข้าม / ส่งผิดพลาด / PDF สำเร็จ / PDF ผิดพลาด',
    ['ส่งสำเร็จ', 'ข้าม (ส่งแล้ว)', 'ส่งผิดพลาด', 'PDF สำเร็จ', 'PDF ผิดพลาด']
      .every(function (x) { return m.indexOf(x) >= 0; }), '');
  chk('Retry ส่งใหม่เฉพาะที่ผิดพลาด', m.indexOf('ส่งใหม่เฉพาะที่ผิดพลาด') >= 0, '');
  chk('Retry สร้าง PDF แยกจากการส่ง', m.indexOf('สร้าง PDF ใหม่เฉพาะที่ผิดพลาด') >= 0, '');
  chk('ALREADY_SENT นับเป็น "ข้าม" ไม่ใช่ผิดพลาด', m.indexOf('ALREADY_SENT') >= 0, '');
  chk('ใช้ RPC เดิม njhr_wht50_send (ไม่สร้างตัวส่งใหม่)',
    m.indexOf('njhr_wht50_send') >= 0 && m.indexOf('njhr_wht50_send2') < 0, '');
  chk('คืนคิวให้เบราว์เซอร์ระหว่างรอบ (ไม่ค้าง Main Thread)',
    /setTimeout\(runBatch,0\)/.test(m.replace(/\s/g, '')), '');
  chk('เลือกได้เฉพาะรายการ is_ready', m.indexOf('is_ready') >= 0, '');
  chk('Preview เปิด Modal ไม่เปิดแท็บใหม่',
    m.indexOf('whtPreview') >= 0 && !/_blank/.test(m), '');
  chk('Preview ไม่เรียก njhr_doc_view (ผู้ดูแลเปิดไม่นับว่าเปิดแล้ว)',
    m.indexOf('njhr_doc_view') < 0, '');
  chk('ดาวน์โหลดผ่าน Edge Function + fileDownload',
    /action:\s*["']download["']/.test(m) && m.indexOf('fileDownload') >= 0, '');
  chk('ไม่เรียก njhr_doc_pdf_access ตรงจากหน้าเว็บ',
    m.indexOf("sbRpc('njhr_doc_pdf_access'") < 0, '');
  chk('ชื่อไฟล์ตามรูปแบบ 50ทวิ_ปี_รหัสพนักงาน', m.indexOf('50ทวิ_') >= 0, '');
}

/* ================= 4. ไม่กระทบส่วนอื่น ================= */
function scope() {
  console.log('\n== ไม่กระทบส่วนอื่น ==');
  chk('รายงานการลา/โอที ยังอยู่ในไฟล์เดียวกัน',
    menuJs.indexOf('viewRptLeave') >= 0 && menuJs.indexOf('viewRptOT') >= 0, '');
  chk('ไม่แตะ RPC ของรายงานเดิม',
    menuJs.indexOf('njhr_rpt_leave_list') >= 0 && menuJs.indexOf('njhr_rpt_ot_list') >= 0, '');
  chk('ไม่เรียก RPC ของโมดูลอื่นในหน้านี้',
    !/njhr_(leave|ot|att|payroll)_/.test(menuJs.slice(menuJs.indexOf('viewRptWht50'))), '');
  /* "ดูตัวอย่าง" เป็นชื่อปุ่ม ไม่ใช่ข้อมูลตัวอย่าง — ตรวจที่ค่าข้อมูลแทน */
  const whtPart = menuJs.slice(menuJs.indexOf('WHT_SEND_TH'));
  chk('ไม่มีข้อมูลตัวอย่างฝังในโค้ด (ไม่ hardcode)',
    !/emp_code:\s*['"]\d{4}['"]/.test(whtPart) &&
    !/total_income:\s*\d/.test(whtPart) &&
    !/full_name:\s*['"]/.test(whtPart), '');
  chk('ทุกค่าที่แสดงอ่านจากแถวที่ RPC คืนมา (r.*)',
    /r\.emp_code/.test(whtPart) && /r\.total_income/.test(whtPart) &&
    /r\.total_tax/.test(whtPart) && /r\.send_status/.test(whtPart), '');
  const css = fs.readFileSync(path.join(ROOT, 'styles.css'), 'utf8');
  chk('CSS ใหม่ scope ใต้ .wht- / .lvt-wht เท่านั้น',
    css.indexOf('.wht-sum') >= 0 && css.indexOf('.lvt-wht') >= 0, '');
  chk('ไม่แก้ .lvt ส่วนกลาง',
    css.replace(/\s+/g, '').indexOf('.lvt{width:100%') >= 0 ||
    css.indexOf('.lvt ') >= 0, '');
}

/* ================= Font Loader / Preflight ================= */
function fontPreflight() {
  console.log('\n== ฟอนต์ไทย ==');
  const dir = path.join(ROOT, 'edge-functions/njhr-doc-pdf/fonts');
  const files = fs.existsSync(dir) ? fs.readdirSync(dir) : [];
  const ttf = files.filter(function (x) { return /\.ttf$/i.test(x); });

  const r = fs.readFileSync(path.join(ROOT, 'edge-functions/njhr-doc-pdf/wht50.ts'), 'utf8');
  const idx = fs.readFileSync(path.join(ROOT, 'edge-functions/njhr-doc-pdf/index.ts'), 'utf8');

  chk('มี assertThaiFontsReady()', r.indexOf('export function assertThaiFontsReady') >= 0, '');
  chk('เรียกก่อนวาดหน้าแรก',
    /assertThaiFontsReady\(fontRegular, fontBold\);[\s\S]{0,200}buildWht50Model/.test(r), '');
  chk('ข้อความบอกชื่อไฟล์ที่ขาด', r.indexOf('"Missing Thai font: "') >= 0, '');
  chk('ระบุชื่อไฟล์ที่ต้องมี', r.indexOf('Prompt-Regular.ttf') >= 0 &&
    r.indexOf('Prompt-Bold.ttf') >= 0, '');
  /* ตัดคอมเมนต์ก่อน — หัวไฟล์อธิบายว่า "ห้าม fallback Helvetica" ไว้ */
  const rCode2 = r.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  const iCode = idx.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  chk('ไม่ fallback Helvetica สำหรับข้อความไทย',
    rCode2.indexOf('Helvetica') < 0 && iCode.indexOf('Helvetica') < 0 &&
    iCode.indexOf('StandardFonts') < 0, '');
  chk('loadFonts() ล้มทันทีเมื่อไฟล์ไม่ครบ',
    idx.indexOf('Missing Thai font: ') >= 0, '');

  /* จำลองเรียกจริง */
  let tsc = null;
  try { tsc = require('typescript'); } catch (e) { tsc = null; }
  if (tsc) {
    const start = r.indexOf('export const WHT50_FONT_FILES');
    const end = r.indexOf('/**\n * สร้าง PDF หนังสือรับรอง');
    const js = tsc.transpileModule(r.slice(start, end > start ? end : r.length), {
      compilerOptions: { target: tsc.ScriptTarget.ES2019, module: tsc.ModuleKind.None }
    }).outputText.replace(/^export\s+/gm, '');
    const fn2 = new Function('exports', js + '\nreturn assertThaiFontsReady;')({});
    const good = new Uint8Array(30000);
    function fails(a, b) {
      try { fn2(a, b); return ''; } catch (e) { return e.message; }
    }
    chk('ไม่มี Regular → ล้มพร้อมชื่อไฟล์',
      fails(null, good).indexOf('Prompt-Regular.ttf') >= 0, fails(null, good));
    chk('ไม่มี Bold → ล้มพร้อมชื่อไฟล์',
      fails(good, null).indexOf('Prompt-Bold.ttf') >= 0, fails(good, null));
    chk('ไฟล์เล็กผิดปกติ → ถือว่าไม่ใช่ฟอนต์จริง',
      fails(new Uint8Array(10), good) !== '', '');
    chk('มีครบทั้งคู่ → เดินต่อได้', fails(good, good) === '', '');
  }

  /* สถานะจริงของ Repository */
  chk('มีไฟล์ฟอนต์ไทยใน Repository แล้ว', ttf.length === 2, ttf.join(', '));
  chk('README บอกวิธีเตรียมฟอนต์',
    fs.existsSync(path.join(dir, 'README.md')) &&
    fs.readFileSync(path.join(dir, 'README.md'), 'utf8').indexOf('Prompt-Regular.ttf') >= 0, '');
}

/* ================= Employee Detail แยกจาก ACK/SIGN ================= */
function empDetailSplit() {
  console.log('\n== เอกสารของฉัน · 50 ทวิ แยกจาก ACK/SIGN ==');
  const src = fs.readFileSync(path.join(ROOT, 'src/14-view-profile-hrdocs.js'), 'utf8');
  const out = fs.readFileSync(path.join(ROOT, 'views/profile/main.js'), 'utf8');

  chk('docPaintDetail ตรวจ WHT50 เป็นบรรทัดแรกแล้ว return ทันที',
    /function docPaintDetail\(el\) \{[\s\S]{0,400}if \(docIsWht50\(docDetailData\.doc\)\) \{ docPaintWht50Detail\(el\); return; \}/.test(src), '');
  chk('มี docPaintWht50Detail แยกต่างหาก',
    src.indexOf('function docPaintWht50Detail') >= 0, '');

  /* เนื้อฟังก์ชัน 50 ทวิ ต้องไม่มีอะไรของ ACK/SIGN เลย */
  const i = src.indexOf('function docPaintWht50Detail');
  const j = src.indexOf('function docPaintDetail(el)');
  const body = src.slice(i, j);
  ['docA4Html', 'docAckPanelHtml', 'รอรับทราบ', 'รอลงนาม', 'รับทราบ', 'ปฏิเสธ',
   'docAck', 'requires_signature'].forEach(function (t) {
    chk('ไม่มี "' + t + '" ในหน้า 50 ทวิ', body.indexOf(t) < 0, '');
  });
  chk('แสดงปีภาษีเป็น พ.ศ.', body.indexOf('50 ทวิ ประจำปีภาษี') >= 0 && body.indexOf('543') >= 0, '');
  chk('แสดงเลขที่เอกสาร', body.indexOf('เลขที่เอกสาร') >= 0, '');
  chk('แสดงวันที่ได้รับ', body.indexOf('วันที่ได้รับ') >= 0, '');
  chk('แสดงสถานะ ยังไม่ได้เปิด / เปิดแล้ว', body.indexOf('docMyStateText') >= 0, '');
  chk('มีปุ่มดาวน์โหลดและปิด',
    body.indexOf('wht50-emp-dl') >= 0 && body.indexOf('wht50-emp-close') >= 0, '');
  chk('เปิดไฟล์จริงผ่าน Edge Function (Signed URL)',
    /sbDocPdfFn\(\{ action: 'download', document_id: d\.id \}\)/.test(body), '');
  chk('ใช้ document_id ไม่ใช่ wht50_id', body.indexOf('wht50_id') < 0, '');

  /* เอกสารประเภทอื่นต้องยังมี ACK/SIGN เหมือนเดิม */
  chk('เอกสาร HR อื่นยังมีเส้นทาง ACK/SIGN เดิม',
    src.indexOf('docAckPanelHtml') >= 0 && src.indexOf('docA4Html') >= 0, '');

  /* VIEWED ทำเฉพาะฝั่งพนักงานเจ้าของ */
  chk('njhr_doc_view เรียกเฉพาะผู้ที่ไม่ใช่ผู้ดูแล',
    /if \(!docCanManage\(\) && d\.status === 'SENT'\)[\s\S]{0,160}njhr_doc_view/.test(src), '');
  chk('ไฟล์ที่เว็บใช้จริงมี docPaintWht50Detail',
    out.indexOf('docPaintWht50Detail') >= 0, '');
}

/* ================= ห้ามมีฟังก์ชัน/ตัวแปรประกาศซ้ำ =================
   บทเรียนจริง: เคยมีบล็อกเก่าค้างท้ายไฟล์ ทำให้ตัวที่ประกาศทีหลัง
   ทับตัวใหม่ ระบบจึงรันโค้ดเก่าโดยที่เทสข้อความยังผ่านหมด
   จึงต้องตรวจที่ระดับการประกาศ ไม่ใช่แค่หาข้อความ */
function noDuplicateDecls() {
  console.log('\n== ไม่มีการประกาศซ้ำ ==');
  ['src/37-view-report-menu.js', 'src/14-view-profile-hrdocs.js',
   'src/06-auth-supabase.js'].forEach(function (rel) {
    const f = path.join(ROOT, rel);
    if (!fs.existsSync(f)) return;
    const src = fs.readFileSync(f, 'utf8');
    const seen = {}, dup = [];
    src.split('\n').forEach(function (ln) {
      /* เฉพาะระดับบนสุดของโมดูล (ย่อหน้า 2 ช่องพอดี)
         ฟังก์ชันซ้อนในฟังก์ชันอื่นมี scope ของตัวเอง ไม่ถือว่าซ้ำ */
      const m = /^ {2}function\s+([A-Za-z0-9_$]+)\s*\(/.exec(ln) ||
                /^ {2}var\s+([A-Z][A-Za-z0-9_$]*)\s*=/.exec(ln);
      if (!m) return;
      if (seen[m[1]]) { if (dup.indexOf(m[1]) < 0) dup.push(m[1]); }
      seen[m[1]] = true;
    });
    chk(rel.split('/').pop() + ' ไม่มีชื่อซ้ำ', dup.length === 0,
      dup.length ? 'ซ้ำ: ' + dup.join(', ') : '');
  });
  /* ไฟล์ที่ build ออกมาก็ต้องไม่ซ้ำ */
  ['views/reports/menu.js', 'views/profile/main.js'].forEach(function (rel) {
    const src = fs.readFileSync(path.join(ROOT, rel), 'utf8');
    const names = (src.match(/function (wht[A-Za-z0-9_]+|doc[A-Za-z0-9_]+)\(/g) || [])
      .map(function (x) { return x.slice(9, -1); });
    const seen = {}, dup = [];
    names.forEach(function (n) {
      if (seen[n] && dup.indexOf(n) < 0) dup.push(n);
      seen[n] = true;
    });
    chk(rel + ' (ไฟล์ที่เว็บใช้จริง) ไม่มีชื่อซ้ำ', dup.length === 0,
      dup.length ? 'ซ้ำ: ' + dup.join(', ') : '');
  });
}

/* ================= Frontend Model = Edge Model =================
   Fixture ชุดเดียว ป้อนเข้าทั้งสองฝั่ง แล้วเทียบค่าทีละช่อง
   Edge เป็น TypeScript จึงถอดเป็น JS ด้วยการตัด type annotation
   เพียงพอสำหรับเทียบค่า ไม่ได้แทนการ Deploy จริง */
const WHT_FIXTURE = {
  tax_year: 2026,
  doc_no: 'WHT-2569-0007',
  book_no: '1',
  seq_no: 12,
  form_type: 'PND1A',
  income_section: '40(1)',
  issue_date: '2027-02-10',
  payer_snapshot: {
    company_name: 'บริษัท เอ็น.เจ. โลจิสติกส์ แอนด์ ฟรุ๊ตส์ จำกัด',
    company_address: '99/9 หมู่ 5 ตำบลหนองปรือ อำเภอบางละมุง ชลบุรี 20150',
    company_tax_id: '0205558000123'
  },
  payee_snapshot: {
    prefix: 'นาย', first_name: 'จำรัส', last_name: 'ทองดี',
    national_id: '1234567890123', address: '12/3 ซอย 5 ชลบุรี'
  },
  income_final: null,
  total_income: 480000, total_tax: 12500.5,
  total_sso: 9000, total_pvd: 14400,
  tax_payment_mode: 'WITHHOLD', tax_payment_mode_other: '',
  signer_name: 'สมชาย ผู้จัดการ', signer_position: 'กรรมการผู้จัดการ',
  amend_seq: 0
};

function loadEdgeModel() {
  const ts = fs.readFileSync(path.join(ROOT, 'edge-functions/njhr-doc-pdf/wht50.ts'), 'utf8');
  const start = ts.indexOf('export const WHT50_FORM_TYPES');
  const end = ts.indexOf('/** ตรวจว่า Model ออกเอกสารได้หรือไม่');
  const slice = ts.slice(start, end);

  /* ถอด Type ด้วย TypeScript compiler จริง ไม่ใช้ regex เดา
     (ถ้าเครื่องไม่มี typescript จะข้ามการเทียบ แล้วรายงานตรง ๆ) */
  let tsc = null;
  try { tsc = require('typescript'); } catch (e) { tsc = null; }
  if (!tsc) return null;

  const js = tsc.transpileModule(slice, {
    compilerOptions: { target: tsc.ScriptTarget.ES2019, module: tsc.ModuleKind.None }
  }).outputText.replace(/^export\s+/gm, '');

  /* transpile ยังใส่ exports.xxx = ... ไว้ จึงเตรียม object เปล่ารองรับ */
  return new Function('exports',
    js +
    '\nreturn { buildWht50Model: buildWht50Model, bahtText: bahtText, ' +
    'normalizeSection: normalizeSection, normalizeWht50Snapshot: normalizeWht50Snapshot };')({});
}

function loadFrontModel() {
  const src = fs.readFileSync(path.join(ROOT, 'src/37-view-report-menu.js'), 'utf8');
  const start = src.indexOf('  var WHT_FORMS = [');
  const end = src.indexOf('  /* ---------- สร้างร่าง ----------');
  const code = src.slice(start, end) +
    '\nreturn { whtModel: whtModel, whtBahtText: whtBahtText, whtSection: whtSection, ' +
    'normalizeWht50Snapshot: normalizeWht50Snapshot };';
  return new Function(code)();
}

function modelParity() {
  console.log('\n== Frontend Model = Edge Model (Fixture ชุดเดียว) ==');
  let edge, front;
  try { edge = loadEdgeModel(); } catch (e) {
    chk('ถอด Edge Model มาเทียบได้', false, String(e.message).slice(0, 90));
    return;
  }
  if (!edge) {
    console.log('SKIP  ไม่มี typescript ในเครื่อง — ข้ามการเทียบ Model สองฝั่ง');
    console.log('      ติดตั้งด้วย npm i -D typescript แล้วรันใหม่');
    return;
  }
  try { front = loadFrontModel(); } catch (e) {
    chk('ถอด Frontend Model มาเทียบได้', false, String(e.message).slice(0, 90));
    return;
  }
  chk('ถอดทั้งสองฝั่งมาเทียบได้', !!edge.buildWht50Model && !!front.whtModel, '');

  const E = edge.buildWht50Model(WHT_FIXTURE);
  const F = front.whtModel(WHT_FIXTURE);

  function same(name, a, b, show) {
    const ok = JSON.stringify(a) === JSON.stringify(b);
    chk(name, ok, ok ? (show === false ? '' : String(a).slice(0, 40))
      : 'Edge=' + JSON.stringify(a).slice(0, 40) + ' · Front=' + JSON.stringify(b).slice(0, 40));
  }

  same('taxYear', E.taxYear, F.taxYear);
  same('docNo', E.docNo, F.docNo);
  same('bookNo', E.bookNo, F.bookNo);
  same('seqNo', E.seqNo, F.seqNo);
  same('copyLabels (ฉบับที่ 1 / 2)', E.copyLabels, F.copyLabels, false);
  same('title', E.title, F.title);
  same('subtitle', E.subtitle, F.subtitle);
  same('payer.name (company_name)', E.payer.name, F.payer.name);
  same('payer.address (company_address)', E.payer.address, F.payer.address, false);
  same('payer.taxid (company_tax_id)', E.payer.taxid, F.payer.taxid);
  same('payee.name (prefix+first+last)', E.payee.name, F.payee.name);
  same('payee.address', E.payee.address, F.payee.address, false);
  same('payee.taxid (national_id)', E.payee.taxid, F.payee.taxid);
  same('formType (PND1A ติ๊กตัวเดียว)', E.formType, F.formType, false);
  same('incomeRows (40(1) ลงแถว 1)', E.incomeRows, F.incomeRows, false);
  same('totalIncome', E.totalIncome, F.totalIncome);
  same('totalTax', E.totalTax, F.totalTax);
  same('taxWords (ตัวอักษรไทย)', E.taxWords, F.taxWords);
  same('totalGpf', E.totalGpf, F.totalGpf);
  same('totalSso', E.totalSso, F.totalSso);
  same('totalPvd', E.totalPvd, F.totalPvd);
  same('paymentMode (WITHHOLD)', E.paymentMode, F.paymentMode, false);
  same('paymentModeOther', E.paymentModeOther, F.paymentModeOther, false);
  same('certifyText', E.certifyText, F.certifyText, false);
  same('signer', E.signer, F.signer, false);
  same('issueDate (พ.ศ.)', E.issueDate, F.issueDate);
  same('amendSeq', E.amendSeq, F.amendSeq);
  same('missing (ข้อมูลครบ = ว่าง)', E.missing, F.missing, false);

  /* ค่าที่ควรได้จริง — ไม่ใช่แค่ "เท่ากันสองฝั่ง" แต่ต้องถูกด้วย */
  chk('PND1A ติ๊กช่อง ภ.ง.ด.1ก ช่องเดียว',
    E.formType.filter(function (x) { return x.checked; }).length === 1 &&
    E.formType[0].checked === true && E.formType[0].label === 'ภ.ง.ด.1ก', '');
  chk('40(1) ลงแถวเงินเดือน และแถวอื่นว่าง',
    E.incomeRows[0].amount === 480000 && E.incomeRows[0].tax === 12500.5 &&
    E.incomeRows[1].amount === null, '');
  chk('WITHHOLD ติ๊ก "หัก ณ ที่จ่าย" ช่องเดียว',
    E.paymentMode.filter(function (x) { return x.checked; }).length === 1 &&
    E.paymentMode[0].code === 'WITHHOLD' && E.paymentMode[0].checked === true, '');
  chk('ข้อมูลครบ → ออกเอกสารได้ (missing ว่าง)', E.missing.length === 0,
    E.missing.join(' · '));
  chk('วันที่แปลงเป็น พ.ศ. ถูก (10/02/2570)', E.issueDate === '10/02/2570', E.issueDate);

  /* ไม่ระบุวิธีออกภาษี → ทั้งสองฝั่งต้องบอกว่าข้อมูลไม่ครบเหมือนกัน */
  const noMode = Object.assign({}, WHT_FIXTURE, { tax_payment_mode: '' });
  const E2 = edge.buildWht50Model(noMode), F2 = front.whtModel(noMode);
  chk('ไม่ระบุวิธีออกภาษี → Edge บอกว่าไม่ครบ',
    E2.missing.some(function (x) { return x.indexOf('วิธีออกภาษี') >= 0; }), '');
  same('ไม่ระบุวิธีออกภาษี → สองฝั่งได้ missing เท่ากัน', E2.missing, F2.missing, false);
  chk('ไม่ระบุวิธีออกภาษี → ไม่ติ๊กช่องใดเลย',
    E2.paymentMode.every(function (x) { return !x.checked; }), '');

  /* OTHER ต้องมีรายละเอียด */
  const other = Object.assign({}, WHT_FIXTURE,
    { tax_payment_mode: 'OTHER', tax_payment_mode_other: '' });
  const E3 = edge.buildWht50Model(other), F3 = front.whtModel(other);
  chk('OTHER ไม่มีรายละเอียด → ไม่ครบ',
    E3.missing.some(function (x) { return x.indexOf('รายละเอียดวิธีออกภาษี') >= 0; }), '');
  same('OTHER ไม่มีรายละเอียด → สองฝั่งเท่ากัน', E3.missing, F3.missing, false);

  /* income_final แบบรายการ */
  const withFinal = Object.assign({}, WHT_FIXTURE, {
    income_final: [
      { section: '40(1)', paid_on: 'ปีภาษี 2569', amount: 300000, tax: 8000 },
      { section: '40(2)', paid_on: 'ปีภาษี 2569', amount: 50000, tax: 2500 }
    ]
  });
  const E4 = edge.buildWht50Model(withFinal), F4 = front.whtModel(withFinal);
  same('income_final หลายมาตรา → สองฝั่งเท่ากัน', E4.incomeRows, F4.incomeRows, false);
  chk('income_final ลงแถวถูกตามมาตรา',
    E4.incomeRows[0].amount === 300000 && E4.incomeRows[1].amount === 50000, '');

  /* alias เช่น 40_1 ต้อง normalize เหมือนกัน */
  chk('normalizeSection("40_1") = "40(1)" ทั้งสองฝั่ง',
    edge.normalizeSection('40_1') === '40(1)' && front.whtSection('40_1') === '40(1)', '');
  chk('ตัวอักษรไทยของยอดภาษีตรงกัน',
    edge.bahtText(12500.5) === front.whtBahtText(12500.5),
    edge.bahtText(12500.5));
}

/* ================= WRITE RPC + PDF Status จาก RPC จริง ================= */
function writeRpcAndPdfStatus() {
  console.log('\n== WHT50 อยู่ในกลุ่ม WRITE RPC ==');
  const core = fs.readFileSync(path.join(ROOT, 'src/06-auth-supabase.js'), 'utf8');
  const out = fs.readFileSync(path.join(ROOT, 'runtime/core.js'), 'utf8');
  const blk = core.slice(core.indexOf('var SB_WRITE_RPC'), core.indexOf('function sbIsWriteRpc'));

  ['njhr_wht50_draft', 'njhr_wht50_update', 'njhr_wht50_confirm', 'njhr_wht50_send']
    .forEach(function (fn2) {
      chk("SB_WRITE_RPC มี '" + fn2 + "'",
        new RegExp("'" + fn2 + "':\\s*1").test(blk), '');
      chk(fn2 + ' อยู่ในไฟล์ที่เว็บใช้จริงด้วย',
        new RegExp('"' + fn2 + '":1|' + fn2 + ':1').test(out) || out.indexOf(fn2) >= 0, '');
    });
  chk('ไม่ได้สร้าง SB_WRITE_RPC ตัวใหม่',
    (core.match(/var SB_WRITE_RPC/g) || []).length === 1, '');
  chk('RPC อ่านข้อมูลของ 50 ทวิ ไม่ถูกจัดเป็น WRITE',
    blk.indexOf("'njhr_wht50_get'") < 0 && blk.indexOf("'njhr_wht50_send_list'") < 0, '');

  /* ทดสอบพฤติกรรมจริงของ sbIsWriteRpc — ตัดให้จบพอดีที่ปีกกาปิดของฟังก์ชัน */
  const fnStart = core.indexOf('function sbIsWriteRpc');
  const fnEnd = core.indexOf('\n', core.indexOf('}', fnStart));
  const fnBody = core.slice(core.indexOf('var SB_WRITE_RPC'), fnEnd);
  const probe = new Function(fnBody + '\nreturn sbIsWriteRpc;')();
  ['njhr_wht50_draft', 'njhr_wht50_update', 'njhr_wht50_confirm', 'njhr_wht50_send']
    .forEach(function (fn2) {
      chk('sbIsWriteRpc("' + fn2 + '") = true', probe(fn2) === true, String(probe(fn2)));
    });
  chk('sbIsWriteRpc("njhr_wht50_get") = false (เป็น Read)',
    probe('njhr_wht50_get') === false, String(probe('njhr_wht50_get')));

  console.log('\n== Admin อ่านสถานะ PDF จาก RPC จริง ==');
  const m = fs.readFileSync(path.join(ROOT, 'src/37-view-report-menu.js'), 'utf8');
  const built = fs.readFileSync(path.join(ROOT, 'views/reports/menu.js'), 'utf8');

  chk('ไม่อ่าน final_pdf_status จากแถวของ send_list อีกแล้ว',
    m.indexOf('r.final_pdf_status') < 0, '');
  chk('มี helper กลาง whtPdfStatus()', m.indexOf('function whtPdfStatus(') >= 0, '');
  chk('helper เรียก njhr_doc_pdf_status ด้วย document_id',
    /whtPdfStatus\(documentId\)[\s\S]{0,320}njhr_doc_pdf_status[\s\S]{0,80}p_id: documentId/.test(m), '');
  chk('helper ใช้ Pattern เดิม (sbRpcList → rows[0].data)',
    /njhr_doc_pdf_status[\s\S]{0,200}rows\[0\]\) \|\| \{\}\)\.data/.test(m), '');
  chk('ไม่มี document_id → คืน null ไม่ยิง RPC',
    /if \(!documentId\) return Promise\.resolve\(null\)/.test(m), '');

  chk('Preview เปิดโหมด "ตัวอย่างก่อนสร้าง Final PDF" เสมอ',
    m.indexOf('ตัวอย่างก่อนสร้าง Final PDF') >= 0, '');
  chk('เปิดปุ่มดูไฟล์จริงเฉพาะเมื่อ READY และ can_download',
    /final_pdf_status === 'READY' && st\.can_download/.test(m), '');
  chk('แสดงสถานะตามจริง (READY / PENDING / FAILED)',
    m.indexOf("v === 'READY'") >= 0 && m.indexOf("v === 'FAILED'") >= 0 &&
    m.indexOf("v === 'PENDING'") >= 0, '');
  chk('FAILED แสดงข้อความผิดพลาดที่ Server อนุญาต',
    m.indexOf('st.final_pdf_error') >= 0, '');

  console.log('\n== Download ตรวจสถานะก่อนเสมอ ==');
  chk('ตรวจ whtPdfStatus ก่อนเรียก Edge Function',
    /whtPdfStatus\(documentId\)[\s\S]{0,600}sbDocPdfFn\(\{ action: 'download'/.test(m), '');
  chk('ไม่ READY → ไม่เรียก Download',
    /final_pdf_status !== 'READY' \|\| !st\.can_download[\s\S]{0,400}return null;/.test(m), '');
  chk('ข้อความ "PDF ยังไม่พร้อมดาวน์โหลด"',
    m.indexOf('PDF ยังไม่พร้อมดาวน์โหลด') >= 0, '');
  chk('ไฟล์ที่เว็บใช้จริงมี whtPdfStatus', built.indexOf('whtPdfStatus') >= 0, '');

  console.log('\n== njhr_wht50_update ยังมี Logic เดิมครบ ==');
  const q = fs.readFileSync(path.join(ROOT, 'supabase-new/90_wht50_pdf.sql'), 'utf8');
  const q87 = fs.readFileSync(path.join(ROOT, 'supabase-new/87_wht50.sql'), 'utf8');
  const upd = q.slice(q.indexOf('function public.njhr_wht50_update'),
    q.indexOf('-- ─── 6)'));
  [['แก้ได้เฉพาะ DRAFT', "d.status <> 'DRAFT'"],
   ['income_final merge', "d.income_final || coalesce(p_patch->'income_final'"],
   ['ยอดต่างต้องมีเหตุผล', 'การแก้ยอดเงินต้องระบุเหตุผล'],
   ['เทียบกับ income_source', 'is distinct from d.income_source'],
   ['คำนวณ total_income', "total_income    = coalesce(nullif(v_final->>'total_income'"],
   ['คำนวณ total_tax', "total_tax       = coalesce(nullif(v_final->>'tax'"],
   ['คำนวณ total_sso', "total_sso       = coalesce(nullif(v_final->>'social_security'"],
   ['คำนวณ total_pvd', "total_pvd       = coalesce(nullif(v_final->>'pvd'"],
   ['audit WHT50_EDIT', "njhr_audit_write(p_token, 'WHT50_EDIT'"],
   ['updated_at / updated_by', 'updated_at = now(), updated_by = c.username'],
   ['payee_snapshot merge', "payee_snapshot  = payee_snapshot || coalesce"]].forEach(function (x) {
    chk('คง Logic เดิม: ' + x[0], upd.indexOf(x[1]) >= 0, '');
    chk('  ตรงกับของจริงใน 87_wht50.sql', q87.indexOf(x[1]) >= 0, '');
  });
  chk('เพิ่ม tax_payment_mode เข้า patch', upd.indexOf('tax_payment_mode       = coalesce(v_mode') >= 0, '');
  chk('OTHER ต้องมีรายละเอียด (ตรวจที่ Server)',
    upd.indexOf('กรุณาระบุรายละเอียดวิธีออกภาษี') >= 0, '');
  chk('Constraint ใช้ค่าเดียวกับ Source',
    ['WITHHOLD', 'PAID_CONTINUOUS', 'PAID_ONCE', 'OTHER'].every(function (v) {
      return q.indexOf("'" + v + "'") >= 0 && m.indexOf("'" + v + "'") >= 0;
    }), '');

  console.log('\n== SQL Static ==');
  const qC = q.split('\n').filter(function (l) { return !/^\s*--/.test(l); }).join('\n');
  [['ไม่มี BUILDING', qC.indexOf('BUILDING') < 0],
   ['ไม่มี final_pdf_size', qC.indexOf('final_pdf_size') < 0],
   ['ไม่มี seq_in_form', qC.indexOf('seq_in_form') < 0],
   ['ไม่มี c.user_id', qC.indexOf('c.user_id') < 0],
   ['มี final_pdf_bytes', qC.indexOf('final_pdf_bytes') >= 0],
   ['Generic ACK/SIGN เดิมยังอยู่', qC.indexOf("d.status not in ('ACKNOWLEDGED','SIGNED')") >= 0],
   ['WHT50 ใช้ SENT/VIEWED', qC.indexOf("'SENT','VIEWED'") >= 0]].forEach(function (x) {
    chk(x[0], x[1], '');
  });
  chk('ไม่มี RPC PDF แยกที่ไม่มีใครเรียก',
    qC.indexOf('njhr_wht50_pdf_claim') < 0 && qC.indexOf('njhr_wht50_pdf_commit') < 0, '');
  const idx = fs.readFileSync(path.join(ROOT, 'edge-functions/njhr-doc-pdf/index.ts'), 'utf8');
  chk('Edge Generate เรียก Generic Pipeline',
    idx.indexOf('njhr_doc_pdf_claim') >= 0 && idx.indexOf('njhr_doc_pdf_commit') >= 0 &&
    idx.indexOf('njhr_doc_pdf_fail') >= 0, '');

  console.log('\n== Feature Gate + ฟอนต์ ==');
  chk('WHT_PDF_READY ยังเป็น false', built.indexOf('WHT_PDF_READY=false') >= 0, '');
  const fdir = path.join(ROOT, 'edge-functions/njhr-doc-pdf/fonts');
  const ttf = fs.existsSync(fdir)
    ? fs.readdirSync(fdir).filter(function (x) { return /\.ttf$/i.test(x); }) : [];
  chk('มีไฟล์ฟอนต์ .ttf จริง 2 ตัว', ttf.length === 2, ttf.join(', '));
  chk('ไม่ใช่ไฟล์เปล่า/ปลอม (ขนาดสมเหตุสมผล)',
    ttf.every(function (f) { return fs.statSync(path.join(fdir, f)).size > 100000; }),
    ttf.map(function (f) { return fs.statSync(path.join(fdir, f)).size; }).join(' · '));
  chk('เป็น TrueType จริง (ตรวจ header)',
    ttf.every(function (f) {
      const b = fs.readFileSync(path.join(fdir, f));
      return b.readUInt32BE(0) === 0x00010000 || b.slice(0, 4).toString() === 'true';
    }), '');
}

/* ================= รอบแก้: ตรวจตาม Signature Production จริง ================= */
function verifyProdSignatures() {
  console.log('\n== ตรงกับ Production Signature ==');
  const m = fs.readFileSync(path.join(ROOT, 'views/reports/menu.js'), 'utf8');
  const sql87 = fs.readFileSync(path.join(ROOT, 'supabase-new/87_wht50.sql'), 'utf8');
  const sql90 = fs.readFileSync(path.join(ROOT, 'supabase-new/90_wht50_pdf.sql'), 'utf8');
  const core = fs.readFileSync(path.join(ROOT, 'runtime/core.js'), 'utf8');

  /* 1. สร้างร่าง — p_employees เป็น array */
  chk('87 ประกาศ p_employees uuid[] จริง',
    /njhr_wht50_draft\([\s\S]{0,120}p_employees uuid\[\]/.test(sql87), '');
  chk('Frontend ส่ง p_employees เป็น array ไม่ใช่ p_employee เดี่ยว',
    /p_employees:\s*\[employeeId\]/.test(m) && !/p_employee\s*:/.test(m), '');
  chk('ส่ง p_form_type และ p_income_section ครบ',
    /p_form_type:\s*["']PND1A["']/.test(m) && /p_income_section:\s*["']40\(1\)["']/.test(m), '');
  chk('อ่าน response ตามจริง (ok / message)',
    /r0\.ok\s*===\s*(!1|false)/.test(m) && /r0\.message/.test(m), '');

  /* 2. แก้ไข — เรียก njhr_wht50_update จริง */
  chk('ปุ่มแก้ไขเรียก njhr_wht50_get แล้วเปิด Modal',
    /whtEdit[\s\S]{0,240}njhr_wht50_get/.test(m), '');
  chk('บันทึกเรียก njhr_wht50_update พร้อม p_patch',
    /njhr_wht50_update[\s\S]{0,200}p_patch/.test(m), '');
  chk('มีช่องเหตุผลส่ง p_reason', /p_reason/.test(m), '');
  ['form_type', 'income_section', 'book_no', 'seq_no', 'issue_date',
   'signer_name', 'signer_position', 'note'].forEach(function (k) {
    chk('Patch key ' + k + ' ตรงกับที่ RPC รองรับจริง',
      m.indexOf(k) >= 0 && sql87.indexOf("p_patch->>'" + k + "'") >= 0, '');
  });
  chk('ไม่ส่ง key ที่ RPC ไม่รองรับ',
    !/p_patch[\s\S]{0,300}(emp_code|total_income|total_tax)\s*:/.test(m), '');
  chk('บันทึกแล้ว Refresh จากฐานข้อมูล',
    /njhr_wht50_update[\s\S]{0,360}whtLoad\(\)/.test(m), '');

  /* 3. Edge Function กลาง */
  chk('core มี sbDocPdfFn ตัวกลาง', core.indexOf('sbDocPdfFn') >= 0, '');
  chk('sbDocPdfFn ยิงไปที่ /functions/v1/njhr-doc-pdf',
    /functions\/v1\/njhr-doc-pdf/.test(core), '');
  chk('ส่ง token ไปกับทุกคำขอ', /sbDocPdfFn[\s\S]{0,400}token:\s*sbToken\(\)/.test(core), '');

  /* 4. SQL 90 — pdf_status branch */
  chk('90 มี branch WHT50 ใน njhr_doc_pdf_status',
    /njhr_doc_pdf_status[\s\S]{0,1400}doc_type = 'WHT50'/.test(sql90), '');
  chk('can_generate ของ WHT50 ใช้ SENT/VIEWED',
    /can_generate[\s\S]{0,220}WHT50[\s\S]{0,140}'SENT','VIEWED'/.test(sql90), '');
  chk('เอกสารชนิดอื่นยังใช้ ACKNOWLEDGED/SIGNED เหมือนเดิม',
    /else d\.status in \('ACKNOWLEDGED','SIGNED'\)/.test(sql90), '');
  chk('can_download ยังผูกกับ final_pdf_status = READY',
    /can_download[\s\S]{0,140}final_pdf_status = 'READY'/.test(sql90), '');
  chk('PREFLIGHT ตรวจ njhr_doc_pdf_status ด้วย',
    /PREFLIGHT[\s\S]{0,220}njhr_doc_pdf_status/.test(sql90), '');
  /* ตัดคอมเมนต์ออกก่อน เพราะหัวไฟล์อธิบายบั๊กเดิมไว้ด้วยชื่อผิดที่จงใจเขียน */
  const q90 = sql90.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*--.*$/gm, '');
  chk('90 ไม่ใช้ final_pdf_size (ใช้ final_pdf_bytes)',
    q90.indexOf('final_pdf_size') < 0 && q90.indexOf('final_pdf_bytes') >= 0, '');
  chk('90 ไม่ใช้สถานะ BUILDING', q90.indexOf('BUILDING') < 0, '');
  chk('90 ใช้เฉพาะสถานะที่ constraint อนุญาต (PENDING · READY)',
    q90.indexOf('PENDING') >= 0 && q90.indexOf('READY') >= 0, '');
  /* njhr_doc_pdf_fail ไม่ถูกแก้ในไฟล์นี้ — สถานะ FAILED จึงยังใช้ของเดิม */
  chk('ไม่แก้ njhr_doc_pdf_fail (ของเดิมจัดการ FAILED อยู่แล้ว)',
    q90.indexOf('function public.njhr_doc_pdf_fail') < 0, '');
}

(async function () {
  await page();
  sqlChecks();
  sql89();
  empSide();
  empWht50();
  renderer();
  sql90();
  gateBulk();
  scope();
  /* ================= Mapping test — ค่าจาก Production จริง ================= */
  console.log('\n== Mapping (PND / มาตรา 40 / payer / payee) ==');
  const w = fs.readFileSync(path.join(ROOT, 'edge-functions/njhr-doc-pdf/wht50.ts'), 'utf8');
  [['PND1A', 'ภ.ง.ด.1ก'], ['PND1A_SPECIAL', 'ภ.ง.ด.1ก พิเศษ'], ['PND2', 'ภ.ง.ด.2'],
   ['PND3', 'ภ.ง.ด.3'], ['PND2A', 'ภ.ง.ด.2ก'], ['PND3A', 'ภ.ง.ด.3ก'], ['PND53', 'ภ.ง.ด.53']]
    .forEach(function (x) {
      chk('form_type ' + x[0] + ' → ' + x[1],
        new RegExp('code:\\s*"' + x[0] + '",\\s*label:\\s*"' + x[1] + '"').test(w), '');
    });
  chk('ไม่เทียบข้อความไทยกับ enum ตรง ๆ', w.indexOf('f.code === ft') >= 0, '');
  [['40(1)', '1.'], ['40(2)', '2.'], ['40(3)', '3.'], ['40(4)', '4.']].forEach(function (x) {
    chk('income_section ' + x[0] + ' → แถว ' + x[1],
      new RegExp('key:\\s*"' + x[0].replace(/[()]/g, '\\$&') + '"[\\s\\S]{0,90}no:\\s*"' + x[1] + '"').test(w), '');
  });
  chk('40(1) ลงแถวเงินเดือน/ค่าจ้าง/โบนัส',
    /key: "40\(1\)"[\s\S]{0,180}เงินเดือน ค่าจ้าง เบี้ยเลี้ยง โบนัส/.test(w), '');
  chk('มี normalizeSection() รองรับรูปแบบอื่น', w.indexOf('export function normalizeSection') >= 0, '');
  chk('มี normalizeWht50Snapshot()', w.indexOf('export function normalizeWht50Snapshot') >= 0, '');
  chk('payer ใช้ company_name / company_address / company_tax_id',
    w.indexOf('p.company_name') >= 0 && w.indexOf('p.company_address') >= 0 &&
    w.indexOf('p.company_tax_id') >= 0, '');
  chk('payee ประกอบชื่อจาก prefix + first_name + last_name',
    /e\.prefix[\s\S]{0,120}e\.first_name[\s\S]{0,120}e\.last_name/.test(w), '');
  chk('payee ใช้ national_id เป็นเลขประจำตัว', w.indexOf('e.national_id') >= 0, '');
  chk('ไม่พึ่ง payee.name เป็นหลัก', /built \|\| String\(e\.name/.test(w), '');
  chk('ไม่อ้าง field ที่ Production ไม่มี',
    w.indexOf('snap.payer_mode') < 0 && w.indexOf('snap.total_gpf') < 0 &&
    w.indexOf('snap.seq_in_form') < 0, '');

  /* ---- ฝั่งเว็บใช้ Mapping ชุดเดียวกัน ---- */
  console.log('\n== Preview ใช้ Model เดียวกับ Renderer ==');
  const mv = fs.readFileSync(path.join(ROOT, 'views/reports/menu.js'), 'utf8');
  chk('Preview มี Model กลาง (whtModel)', mv.indexOf('whtModel') >= 0, '');
  chk('Preview map PND ชุดเดียวกัน', mv.indexOf('PND1A_SPECIAL') >= 0, '');
  chk('Preview map มาตรา 40 ชุดเดียวกัน', mv.indexOf('40(1)') >= 0, '');
  chk('Preview normalize payer/payee แบบเดียวกัน',
    mv.indexOf('company_tax_id') >= 0 && mv.indexOf('national_id') >= 0, '');
  chk('Preview ไม่ใช่ placeholder แล้ว (มีตารางเงินได้)',
    mv.indexOf('ประเภทเงินได้พึงประเมินที่จ่าย') >= 0, '');
  chk('Preview อ่านข้อมูลจริงด้วย njhr_wht50_get', mv.indexOf('njhr_wht50_get') >= 0, '');
  chk('Preview ไม่เรียก njhr_doc_view (ไม่เปลี่ยนเป็น OPENED)',
    mv.indexOf('njhr_doc_view') < 0, '');

  /* ---- ID separation ---- */
  console.log('\n== แยก wht50_id / document_id ==');
  chk('ส่งใช้ wht50_id (ตัวแปรจาก whtSel ซึ่งเก็บ wht50_id)',
    mv.indexOf('njhr_wht50_send') >= 0 && mv.indexOf('whtSel[r.wht50_id]') >= 0, '');
  chk('เลือกหลายคนเก็บ wht50_id', mv.indexOf('whtSel[r.wht50_id]') >= 0, '');
  chk('ดาวน์โหลดใช้ document_id',
    /action:\s*["']download["']/.test(mv) &&
    mv.indexOf('x.document_id===documentId') >= 0, '');
  chk('สร้างร่างใช้ employee_id', mv.indexOf('data-wht-draft') >= 0 &&
    mv.indexOf('njhr_wht50_draft') >= 0, '');
  chk('ยืนยันใช้ njhr_wht50_confirm', mv.indexOf('njhr_wht50_confirm') >= 0, '');
  chk('ไม่มี doc_id ปนอยู่แล้ว', mv.indexOf('r.doc_id') < 0, '');

  verifyProdSignatures();
  writeRpcAndPdfStatus();
  noDuplicateDecls();
  fontPreflight();
  empDetailSplit();
  modelParity();
  console.log('\nรวม PASS ' + PASS + ' · FAIL ' + FAIL);
  process.exit(FAIL ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
